import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('path-like bare query keeps its shape with default sorting', () => {
	const url = 'https://example.com/index.php?/catalog/item';
	assert.equal(normalizeUrl(url), url);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('bare query parameters sort alphabetically without acquiring values', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?zeta&alpha&middle'),
		'https://example.com/index.php?alpha&middle&zeta',
	);
});

test('default and explicit query sorting keep assigned values', () => {
	const input = 'https://example.com/index.php?z=last&a=first&m=middle';
	const expected = 'https://example.com/index.php?a=first&m=middle&z=last';
	assert.equal(normalizeUrl(input), expected);
	assert.equal(normalizeUrl(input, {sortQueryParameters: true}), expected);
});

test('sorting opt-out preserves path-like and mixed query shapes and order', () => {
	for (const input of [
		'https://example.com/index.php?/catalog/item',
		'https://example.com/index.php?z=last&/catalog/item&empty=&a=first&flag',
	]) {
		assert.equal(normalizeUrl(input, {sortQueryParameters: false}), input);
	}
});

test('sorting mixes path-like, bare, assigned, and explicitly empty parameters', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=last&flag&empty=&/catalog/item&a=first'),
		'https://example.com/index.php?/catalog/item&a=first&empty=&flag&z=last',
	);
});

test('similar query names retain their own bare or assigned shape', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?foobar=&foo&foob=value'),
		'https://example.com/index.php?foo&foob=value&foobar=',
	);
	assert.equal(
		normalizeUrl('https://example.com/index.php?foobar&foo=&foob=value'),
		'https://example.com/index.php?foo=&foob=value&foobar',
	);
});

test('explicit empty values remain distinct from bare parameters', () => {
	const bare = 'https://example.com/index.php?/catalog/item';
	const empty = `${bare}=`;
	assert.equal(normalizeUrl(bare), bare);
	assert.equal(normalizeUrl(empty), empty);
	assert.notEqual(normalizeUrl(bare), normalizeUrl(empty));
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=&a='),
		'https://example.com/index.php?a=&z=',
	);
});

test('query repair preserves ordinary host, port, and path normalization', () => {
	assert.equal(
		normalizeUrl(' HTTPS://WWW.EXAMPLE.COM:443/a//b/../index.php?z=last&flag&a=first '),
		'https://example.com/a/index.php?a=first&flag&z=last',
	);
	assert.equal(normalizeUrl('example.com/'), 'http://example.com');
});

test('query shape repair preserves fragments and existing fragment options', () => {
	const input = 'https://example.com/index.php?z=last&/catalog/item#details';
	assert.equal(normalizeUrl(input), 'https://example.com/index.php?/catalog/item&z=last#details');
	assert.equal(
		normalizeUrl(input, {stripHash: true}),
		'https://example.com/index.php?/catalog/item&z=last',
	);
	assert.equal(
		normalizeUrl(`${input}:~:text=hello`),
		'https://example.com/index.php?/catalog/item&z=last#details',
	);
});

test('query sorting retains encoded path backslashes', () => {
	assert.equal(
		normalizeUrl('https://example.com/some%5Bthing%5Celse/index.php?z=last&/catalog/item&a=first'),
		'https://example.com/some[thing%5Celse/index.php?/catalog/item&a=first&z=last',
	);
});

test('query sorting preserves Unicode values alongside bare parameters', () => {
	const expected = 'https://example.com/index.php?/catalog/item&a=%E4%B8%AD%E6%96%87&z=%F0%9F%A6%84';
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=🦄&/catalog/item&a=中文'),
		expected,
	);
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=%F0%9F%A6%84&/catalog/item&a=%E4%B8%AD%E6%96%87'),
		expected,
	);
});

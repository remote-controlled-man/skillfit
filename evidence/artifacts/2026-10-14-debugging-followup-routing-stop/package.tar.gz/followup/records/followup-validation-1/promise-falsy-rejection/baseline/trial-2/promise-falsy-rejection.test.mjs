#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [name, value] of falsyValues) {
	test(`shared callers preserve ${name} rejection`, async () => {
		const pending = gate();
		const calls = [];
		const debounced = pDebounce.promise(async argument => {
			calls.push(argument);
			if (argument === 'reject') {
				await pending.promise;
				throw value;
			}

			return argument;
		});

		const outcomes = Promise.allSettled([
			debounced('reject'),
			debounced('ignored first'),
			debounced('ignored second'),
		]);
		assert.deepEqual(calls, ['reject']);
		pending.release();
		assert.deepEqual(await outcomes, Array.from({length: 3}, () => ({status: 'rejected', reason: value})));
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['reject', 'recovered']);
	});

	test(`shared callers preserve synchronous ${name} throws`, async () => {
		let calls = 0;
		const debounced = pDebounce.promise(() => {
			calls++;
			throw value;
		});

		assert.deepEqual(await Promise.allSettled([debounced(), debounced()]), [
			{status: 'rejected', reason: value},
			{status: 'rejected', reason: value},
		]);
		assert.equal(calls, 1);
		assert.deepEqual(await Promise.allSettled([debounced()]), [{status: 'rejected', reason: value}]);
		assert.equal(calls, 2);
	});

	test(`shared and subsequent calls preserve successful ${name} returns`, async () => {
		const pending = gate();
		let calls = 0;
		const debounced = pDebounce.promise(async () => {
			calls++;
			await pending.promise;
			return value;
		});

		const outcomes = Promise.allSettled([debounced(), debounced()]);
		pending.release();
		assert.deepEqual(await outcomes, [
			{status: 'fulfilled', value},
			{status: 'fulfilled', value},
		]);
		assert.equal(calls, 1);
		assert.strictEqual(await debounced(), value);
		assert.equal(calls, 2);
	});

	test(`after: true preserves ${name} rejection while executing the latest queued call`, async () => {
		const initial = gate();
		const queued = gate();
		const calls = [];
		const debounced = pDebounce.promise(async argument => {
			calls.push(argument);
			if (argument === 'initial') {
				await initial.promise;
				throw value;
			}

			if (argument === 'latest') {
				await queued.promise;
				return value;
			}

			return argument;
		}, {after: true});

		const first = debounced('initial');
		const firstState = observe(first);
		const outcomes = Promise.allSettled([
			first,
			debounced('superseded'),
			debounced('latest'),
		]);
		assert.deepEqual(calls, ['initial']);
		initial.release();
		await flush();
		assert.deepEqual(calls, ['initial', 'latest']);
		assert.deepEqual(firstState, {status: 'pending'});
		queued.release();
		assert.deepEqual(await outcomes, [
			{status: 'rejected', reason: value},
			{status: 'fulfilled', value},
			{status: 'fulfilled', value},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['initial', 'latest', 'recovered']);
	});

	test(`after: true shares queued ${name} rejection and preserves the initial successful value`, async () => {
		const initial = gate();
		const queued = gate();
		const calls = [];
		const debounced = pDebounce.promise(async argument => {
			calls.push(argument);
			if (argument === 'initial') {
				await initial.promise;
				return value;
			}

			if (argument === 'latest') {
				await queued.promise;
				throw value;
			}

			return argument;
		}, {after: true});

		const outcomes = Promise.allSettled([
			debounced('initial'),
			debounced('superseded'),
			debounced('latest'),
		]);
		assert.deepEqual(calls, ['initial']);
		initial.release();
		await flush();
		assert.deepEqual(calls, ['initial', 'latest']);
		queued.release();
		assert.deepEqual(await outcomes, [
			{status: 'fulfilled', value},
			{status: 'rejected', reason: value},
			{status: 'rejected', reason: value},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['initial', 'latest', 'recovered']);
	});
}

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {gate, flush, observe} from './test-clock.mjs';

const falsyCases = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [label, reason] of falsyCases) {
	for (const mode of ['promise rejection', 'synchronous throw']) {
		test(`pDebounce.promise shares ${mode} with reason ${label} and recovers`, async () => {
			const pending = gate();
			let calls = 0;
			const debounced = pDebounce.promise(() => {
				calls++;
				if (calls === 1) {
					if (mode === 'synchronous throw') {
						throw reason;
					}

					return pending.promise.then(() => Promise.reject(reason));
				}

				return calls === 2 ? reason : 'recovered';
			});

			const outcomes = Promise.allSettled([debounced(), debounced(), debounced()]);
			assert.equal(calls, 1, 'concurrent callers must share one execution');
			pending.release();
			assert.deepEqual(await outcomes, [
				{status: 'rejected', reason},
				{status: 'rejected', reason},
				{status: 'rejected', reason},
			]);

			assert.equal(await debounced(), reason, 'a successful falsy value must remain fulfilled');
			assert.equal(await debounced(), 'recovered');
			assert.equal(calls, 3, 'settled calls must allow fresh executions');
		});
	}

	test(`pDebounce.promise after:true preserves initial rejection ${label} while draining the queue`, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const initialContext = {name: 'initial context'};
		const staleContext = {name: 'stale context'};
		const latestContext = {name: 'latest context'};
		const calls = [];
		const debounced = pDebounce.promise(async function (name, value) {
			calls.push({context: this, name, value});
			if (name === 'initial') {
				await initialGate.promise;
				throw reason;
			}

			if (name === 'latest') {
				await queuedGate.promise;
			}

			return value;
		}, {after: true});

		const initial = observe(debounced.call(initialContext, 'initial', reason));
		const queued = observe(debounced.call(staleContext, 'stale', 'superseded'));
		const sharedQueued = observe(debounced.call(latestContext, 'latest', reason));
		assert.deepEqual(calls, [{context: initialContext, name: 'initial', value: reason}]);

		initialGate.release();
		await flush();
		assert.deepEqual(calls, [
			{context: initialContext, name: 'initial', value: reason},
			{context: latestContext, name: 'latest', value: reason},
		]);
		assert.deepEqual(initial, {status: 'pending'}, 'initial rejection must wait for the queue to drain');
		assert.deepEqual(queued, {status: 'pending'});
		assert.deepEqual(sharedQueued, {status: 'pending'});

		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'rejected', reason});
		assert.deepEqual(queued, {status: 'fulfilled', value: reason});
		assert.deepEqual(sharedQueued, {status: 'fulfilled', value: reason});
		assert.equal(await debounced.call(initialContext, 'recovered', 'success'), 'success');
		assert.deepEqual(calls.at(-1), {context: initialContext, name: 'recovered', value: 'success'});
		assert.equal(calls.length, 3);
	});

	test(`pDebounce.promise after:true keeps initial success and shares queued rejection ${label}`, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const calls = [];
		const debounced = pDebounce.promise(async name => {
			calls.push(name);
			if (name === 'initial') {
				await initialGate.promise;
				return reason;
			}

			if (name === 'queued') {
				await queuedGate.promise;
				throw reason;
			}

			return 'recovered';
		}, {after: true});

		const initial = observe(debounced('initial'));
		const queued = observe(debounced('superseded'));
		const sharedQueued = observe(debounced('queued'));
		initialGate.release();
		await flush();
		assert.deepEqual(calls, ['initial', 'queued']);
		assert.deepEqual(initial, {status: 'pending'});
		assert.deepEqual(queued, {status: 'pending'});
		assert.deepEqual(sharedQueued, {status: 'pending'});

		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'fulfilled', value: reason});
		assert.deepEqual(queued, {status: 'rejected', reason});
		assert.deepEqual(sharedQueued, {status: 'rejected', reason});
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['initial', 'queued', 'recovered']);
	});
}

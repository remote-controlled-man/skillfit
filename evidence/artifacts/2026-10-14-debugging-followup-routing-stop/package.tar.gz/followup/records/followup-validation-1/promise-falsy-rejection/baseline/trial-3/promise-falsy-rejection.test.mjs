#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {gate} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [name, reason] of falsyValues) {
	test(`shared callers preserve rejection with ${name} and recover`, async () => {
		const pending = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			if (calls.length === 1) {
				await pending.promise;
				throw reason;
			}

			return value;
		});

		const rejected = Promise.allSettled([
			debounced('first'),
			debounced('second'),
			debounced('third'),
		]);
		assert.deepEqual(calls, ['first']);
		pending.release();
		assert.deepEqual(await rejected, Array.from({length: 3}, () => ({status: 'rejected', reason})));

		const fulfilled = await Promise.allSettled([
			debounced(reason),
			debounced('ignored'),
		]);
		assert.deepEqual(fulfilled, Array.from({length: 2}, () => ({status: 'fulfilled', value: reason})));
		assert.deepEqual(calls, ['first', reason]);
		assert.equal(await debounced('next'), 'next');
		assert.deepEqual(calls, ['first', reason, 'next']);
	});

	test(`synchronous ${name} throws reject shared callers and recover`, async () => {
		let calls = 0;
		const debounced = pDebounce.promise(() => {
			calls++;
			if (calls === 1) {
				throw reason;
			}

			return reason;
		});

		assert.deepEqual(await Promise.allSettled([debounced(), debounced()]), [
			{status: 'rejected', reason},
			{status: 'rejected', reason},
		]);
		assert.equal(calls, 1);
		assert.equal(await debounced(), reason);
		assert.equal(calls, 2);
	});

	test(`after:true runs the latest queued call after rejection with ${name}`, {timeout: 1000}, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const queuedStarted = gate();
		const calls = [];
		const firstContext = {name: 'first'};
		const latestContext = {name: 'latest'};
		const debounced = pDebounce.promise(async function (value) {
			calls.push({context: this, value});
			if (value === 'first') {
				await initialGate.promise;
				throw reason;
			}

			if (value === 'latest') {
				queuedStarted.release();
				await queuedGate.promise;
				return reason;
			}

			return value;
		}, {after: true});

		const results = Promise.allSettled([
			debounced.call(firstContext, 'first'),
			debounced.call({name: 'superseded'}, 'superseded'),
			debounced.call(latestContext, 'latest'),
		]);
		assert.deepEqual(calls, [{context: firstContext, value: 'first'}]);
		initialGate.release();
		await queuedStarted.promise;
		assert.deepEqual(calls, [
			{context: firstContext, value: 'first'},
			{context: latestContext, value: 'latest'},
		]);
		queuedGate.release();
		assert.deepEqual(await results, [
			{status: 'rejected', reason},
			{status: 'fulfilled', value: reason},
			{status: 'fulfilled', value: reason},
		]);
		assert.equal(await debounced.call(firstContext, 'next'), 'next');
		assert.deepEqual(calls[2], {context: firstContext, value: 'next'});
	});

	test(`after:true preserves successful ${name} and shared queued rejection`, async () => {
		const initialGate = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			if (value === 'first') {
				await initialGate.promise;
				return reason;
			}

			if (value === 'latest') {
				throw reason;
			}

			return value;
		}, {after: true});

		const results = Promise.allSettled([
			debounced('first'),
			debounced('superseded'),
			debounced('latest'),
		]);
		initialGate.release();
		assert.deepEqual(await results, [
			{status: 'fulfilled', value: reason},
			{status: 'rejected', reason},
			{status: 'rejected', reason},
		]);
		assert.deepEqual(calls, ['first', 'latest']);
		assert.equal(await debounced(reason), reason);
		assert.deepEqual(calls, ['first', 'latest', reason]);
	});
}

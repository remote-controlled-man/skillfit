#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {gate, observe, flush} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [label, reason] of falsyValues) {
	for (const synchronous of [false, true]) {
		test(`shared callers preserve ${label} from ${synchronous ? 'a synchronous throw' : 'a rejected promise'}`, async () => {
			const pending = gate();
			const calls = [];
			const debounced = pDebounce.promise(value => {
				calls.push(value);
				if (calls.length === 1) {
					if (synchronous) {
						throw reason;
					}

					return pending.promise.then(() => {
						throw reason;
					});
				}

				return value;
			});
			const callers = [1, 2, 3].map(value => observe(debounced(value)));
			assert.deepEqual(calls, [1]);

			pending.release();
			await flush();
			for (const caller of callers) {
				assert.deepEqual(caller, {status: 'rejected', reason});
			}

			const subsequent = observe(debounced(reason));
			await flush();
			assert.deepEqual(subsequent, {status: 'fulfilled', value: reason});
			assert.deepEqual(calls, [1, reason]);
		});
	}

	test(`shared callers keep successful ${label} return values`, async () => {
		const pending = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			await pending.promise;
			return value;
		});
		const callers = [reason, 'ignored', 'also ignored'].map(value => observe(debounced(value)));
		assert.deepEqual(calls, [reason]);

		pending.release();
		await flush();
		for (const caller of callers) {
			assert.deepEqual(caller, {status: 'fulfilled', value: reason});
		}

		const subsequent = observe(debounced('subsequent'));
		await flush();
		assert.deepEqual(subsequent, {status: 'fulfilled', value: 'subsequent'});
		assert.deepEqual(calls, [reason, 'subsequent']);
	});

	test(`after:true drains queued calls before preserving initial ${label} rejection`, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const initialContext = {name: 'initial'};
		const latestContext = {name: 'latest'};
		const calls = [];
		const debounced = pDebounce.promise(async function (value) {
			calls.push({value, context: this});
			if (value === 'initial') {
				await initialGate.promise;
				throw reason;
			}

			if (value === 'latest') {
				await queuedGate.promise;
				return reason;
			}

			return value;
		}, {after: true});
		const initial = observe(debounced.call(initialContext, 'initial'));
		const queued = observe(debounced.call({name: 'superseded'}, 'superseded'));
		const latest = observe(debounced.call(latestContext, 'latest'));
		assert.deepEqual(calls, [{value: 'initial', context: initialContext}]);

		initialGate.release();
		await flush();
		assert.deepEqual(calls, [
			{value: 'initial', context: initialContext},
			{value: 'latest', context: latestContext},
		]);
		for (const caller of [initial, queued, latest]) {
			assert.deepEqual(caller, {status: 'pending'});
		}

		const followUp = observe(debounced.call(latestContext, 'follow-up'));
		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'rejected', reason});
		for (const caller of [queued, latest]) {
			assert.deepEqual(caller, {status: 'fulfilled', value: reason});
		}
		assert.deepEqual(followUp, {status: 'fulfilled', value: 'follow-up'});
		assert.deepEqual(calls.at(-1), {value: 'follow-up', context: latestContext});
		assert.equal(calls.length, 3);

		const subsequent = observe(debounced.call(initialContext, 'subsequent'));
		await flush();
		assert.deepEqual(subsequent, {status: 'fulfilled', value: 'subsequent'});
		assert.deepEqual(calls.at(-1), {value: 'subsequent', context: initialContext});
		assert.equal(calls.length, 4);
	});

	test(`after:true preserves successful initial ${label} and shared queued rejection`, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			if (value === 'initial') {
				await initialGate.promise;
				return reason;
			}

			if (value === 'latest') {
				await queuedGate.promise;
				throw reason;
			}

			return value;
		}, {after: true});
		const initial = observe(debounced('initial'));
		const queued = observe(debounced('superseded'));
		const latest = observe(debounced('latest'));

		initialGate.release();
		await flush();
		assert.deepEqual(calls, ['initial', 'latest']);
		assert.deepEqual(initial, {status: 'pending'});
		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'fulfilled', value: reason});
		for (const caller of [queued, latest]) {
			assert.deepEqual(caller, {status: 'rejected', reason});
		}

		const subsequent = observe(debounced(reason));
		await flush();
		assert.deepEqual(subsequent, {status: 'fulfilled', value: reason});
		assert.deepEqual(calls, ['initial', 'latest', reason]);
	});
}

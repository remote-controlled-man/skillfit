#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [label, reason] of falsyValues) {
	for (const synchronous of [false, true]) {
		test(`shared callers preserve ${synchronous ? 'synchronous' : 'async'} rejection with ${label}`, async () => {
			const initial = gate();
			const calls = [];
			const debounced = pDebounce.promise(value => {
				calls.push(value);
				if (value === 'initial') {
					if (synchronous) {
						throw reason;
					}

					return initial.promise.then(() => {
						throw reason;
					});
				}

				return value;
			});
			const callers = ['initial', 'shared one', 'shared two'].map(value => observe(debounced(value)));
			assert.deepEqual(calls, ['initial']);
			initial.release();
			await flush();

			for (const caller of callers) {
				assert.deepEqual(caller, {status: 'rejected', reason});
			}

			const subsequent = observe(debounced('subsequent'));
			await flush();
			assert.deepEqual(subsequent, {status: 'fulfilled', value: 'subsequent'});
			assert.deepEqual(calls, ['initial', 'subsequent']);
		});
	}

	test(`rejection with ${label} still runs the latest after:true queued call`, async () => {
		const initial = gate();
		const queued = gate();
		const initialContext = {};
		const latestContext = {};
		const calls = [];
		const debounced = pDebounce.promise(async function (value) {
			calls.push({value, context: this});
			if (value === 'initial') {
				await initial.promise;
				throw reason;
			}

			if (value === 'latest') {
				await queued.promise;
				return reason;
			}

			return value;
		}, {after: true});
		const first = observe(debounced.call(initialContext, 'initial'));
		const sharedQueued = observe(debounced.call({}, 'superseded'));
		const latest = observe(debounced.call(latestContext, 'latest'));
		assert.deepEqual(calls, [{value: 'initial', context: initialContext}]);

		initial.release();
		await flush();
		assert.deepEqual(calls, [
			{value: 'initial', context: initialContext},
			{value: 'latest', context: latestContext},
		]);
		assert.equal(calls[1].context, latestContext);
		assert.deepEqual(sharedQueued, {status: 'pending'});
		assert.deepEqual(latest, {status: 'pending'});

		queued.release();
		await flush();
		assert.deepEqual(first, {status: 'rejected', reason});
		assert.deepEqual(sharedQueued, {status: 'fulfilled', value: reason});
		assert.deepEqual(latest, {status: 'fulfilled', value: reason});

		const subsequent = observe(debounced('subsequent'));
		await flush();
		assert.deepEqual(subsequent, {status: 'fulfilled', value: 'subsequent'});
		assert.deepEqual(calls.map(call => call.value), ['initial', 'latest', 'subsequent']);
	});

	test(`successful falsy ${label} values remain shared and reusable`, async () => {
		const initial = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			await initial.promise;
			return value;
		});
		const first = observe(debounced(reason));
		const shared = observe(debounced('ignored'));
		initial.release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: reason});
		assert.deepEqual(shared, {status: 'fulfilled', value: reason});

		const subsequent = observe(debounced(reason));
		await flush();
		assert.deepEqual(subsequent, {status: 'fulfilled', value: reason});
		assert.deepEqual(calls, [reason, reason]);
	});

	test(`after:true queued callers preserve rejection with ${label} after a falsy success`, async () => {
		const initial = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			if (value === 'initial') {
				await initial.promise;
				return reason;
			}

			if (value === 'latest') {
				throw reason;
			}

			return value;
		}, {after: true});
		const first = observe(debounced('initial'));
		const sharedQueued = observe(debounced('superseded'));
		const latest = observe(debounced('latest'));
		initial.release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: reason});
		assert.deepEqual(sharedQueued, {status: 'rejected', reason});
		assert.deepEqual(latest, {status: 'rejected', reason});

		const subsequent = observe(debounced('subsequent'));
		await flush();
		assert.deepEqual(subsequent, {status: 'fulfilled', value: 'subsequent'});
		assert.deepEqual(calls, ['initial', 'latest', 'subsequent']);
	});
}

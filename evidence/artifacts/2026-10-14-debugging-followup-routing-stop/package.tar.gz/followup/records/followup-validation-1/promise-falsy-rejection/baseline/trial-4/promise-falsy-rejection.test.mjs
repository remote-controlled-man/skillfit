#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

const deferred = () => {
	let resolve;
	let reject;
	const promise = new Promise((resolvePromise, rejectPromise) => {
		resolve = resolvePromise;
		reject = rejectPromise;
	});
	return {promise, resolve, reject};
};

for (const [name, reason] of falsyValues) {
	test(`shared callers preserve a rejection with ${name}`, async () => {
		const pending = deferred();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			return value === 'reject' ? pending.promise : value;
		});

		const outcomes = Promise.allSettled([
			debounced('reject'),
			debounced('shared'),
		]);
		assert.deepEqual(calls, ['reject']);
		pending.reject(reason);
		assert.deepEqual(await outcomes, [
			{status: 'rejected', reason},
			{status: 'rejected', reason},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['reject', 'recovered']);
	});

	test(`shared callers preserve a synchronous throw of ${name}`, async () => {
		const calls = [];
		const debounced = pDebounce.promise(value => {
			calls.push(value);
			if (value === 'throw') {
				throw reason;
			}

			return value;
		});

		assert.deepEqual(await Promise.allSettled([
			debounced('throw'),
			debounced('shared'),
		]), [
			{status: 'rejected', reason},
			{status: 'rejected', reason},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['throw', 'recovered']);
	});

	test(`shared callers keep a successful ${name} value`, async () => {
		const pending = deferred();
		const calls = [];
		const debounced = pDebounce.promise(value => {
			calls.push(value);
			return value === 'pending' ? pending.promise : value;
		});

		const outcomes = Promise.allSettled([
			debounced('pending'),
			debounced('shared'),
		]);
		pending.resolve(reason);
		assert.deepEqual(await outcomes, [
			{status: 'fulfilled', value: reason},
			{status: 'fulfilled', value: reason},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['pending', 'recovered']);
	});

	test(`after:true preserves ${name} rejection and executes the latest queued call`, async () => {
		const initial = deferred();
		const queued = deferred();
		const queuedStarted = deferred();
		const initialContext = {name: 'initial'};
		const latestContext = {name: 'latest'};
		const calls = [];
		const debounced = pDebounce.promise(function (value, extra) {
			calls.push({context: this, value, extra});
			if (value === 'initial') {
				return initial.promise;
			}

			if (value === 'latest') {
				queuedStarted.resolve();
				return queued.promise;
			}

			return value;
		}, {after: true});

		const outcomes = Promise.allSettled([
			debounced.call(initialContext, 'initial', 1),
			debounced('superseded', 2),
			debounced.call(latestContext, 'latest', 3),
		]);
		assert.deepEqual(calls, [{context: initialContext, value: 'initial', extra: 1}]);
		initial.reject(reason);
		await queuedStarted.promise;
		assert.deepEqual(calls, [
			{context: initialContext, value: 'initial', extra: 1},
			{context: latestContext, value: 'latest', extra: 3},
		]);
		queued.resolve(reason);
		assert.deepEqual(await outcomes, [
			{status: 'rejected', reason},
			{status: 'fulfilled', value: reason},
			{status: 'fulfilled', value: reason},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.equal(calls.length, 3);
		assert.equal(calls[2].value, 'recovered');
	});

	test(`after:true shares a queued ${name} rejection and keeps the initial successful value`, async () => {
		const initial = deferred();
		const queued = deferred();
		const queuedStarted = deferred();
		const calls = [];
		const debounced = pDebounce.promise(value => {
			calls.push(value);
			if (value === 'initial') {
				return initial.promise;
			}

			if (value === 'latest') {
				queuedStarted.resolve();
				return queued.promise;
			}

			return value;
		}, {after: true});

		const outcomes = Promise.allSettled([
			debounced('initial'),
			debounced('superseded'),
			debounced('latest'),
		]);
		initial.resolve(reason);
		await queuedStarted.promise;
		assert.deepEqual(calls, ['initial', 'latest']);
		queued.reject(reason);
		assert.deepEqual(await outcomes, [
			{status: 'fulfilled', value: reason},
			{status: 'rejected', reason},
			{status: 'rejected', reason},
		]);
		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['initial', 'latest', 'recovered']);
	});
}

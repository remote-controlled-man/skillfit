#!/usr/bin/env node
import assert from 'node:assert/strict';
import test from 'node:test';
import pDebounce from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [name, reason] of falsyValues) {
	for (const asynchronous of [false, true]) {
		test(`shares ${asynchronous ? 'an asynchronous rejection' : 'a synchronous throw'}: ${name}`, {timeout: 1000}, async () => {
			const pending = gate();
			let calls = 0;
			const debounced = pDebounce.promise(() => {
				calls++;
				if (calls > 1) {
					return reason;
				}

				if (asynchronous) {
					return pending.promise.then(() => {
						throw reason;
					});
				}

				throw reason;
			});
			const callers = [observe(debounced()), observe(debounced()), observe(debounced())];
			assert.equal(calls, 1, 'concurrent callers must share one execution');

			pending.release();
			await flush();
			for (const caller of callers) {
				assert.deepEqual(caller, {status: 'rejected', reason});
			}

			assert.equal(await debounced(), reason, 'a later falsy result must fulfill');
			assert.equal(calls, 2, 'a later call must start a new execution');
		});
	}

	test(`after:true runs the latest queued call after rejection: ${name}`, {timeout: 1000}, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const calls = [];
		const debounced = pDebounce.promise(async function (value) {
			calls.push({context: this, value});
			if (value === 'initial') {
				await initialGate.promise;
				throw reason;
			}

			if (value === 'latest') {
				await queuedGate.promise;
				return reason;
			}

			return value;
		}, {after: true});
		const initialContext = {name: 'initial'};
		const latestContext = {name: 'latest'};
		const initial = observe(debounced.call(initialContext, 'initial'));
		const queued = [
			observe(debounced.call({name: 'superseded'}, 'superseded')),
			observe(debounced.call(latestContext, 'latest')),
		];
		assert.deepEqual(calls, [{context: initialContext, value: 'initial'}]);

		initialGate.release();
		await flush();
		assert.deepEqual(calls, [
			{context: initialContext, value: 'initial'},
			{context: latestContext, value: 'latest'},
		]);
		for (const caller of queued) {
			assert.deepEqual(caller, {status: 'pending'});
		}

		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'rejected', reason});
		for (const caller of queued) {
			assert.deepEqual(caller, {status: 'fulfilled', value: reason});
		}

		assert.equal(await debounced('recovered'), 'recovered');
		assert.equal(calls.length, 3);
	});

	test(`after:true keeps a successful falsy result and shared queued rejection: ${name}`, {timeout: 1000}, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			if (value === 'initial') {
				await initialGate.promise;
				return reason;
			}

			if (value === 'latest') {
				await queuedGate.promise;
				throw reason;
			}

			return value;
		}, {after: true});
		const initial = observe(debounced('initial'));
		const queued = [observe(debounced('superseded')), observe(debounced('latest'))];

		initialGate.release();
		await flush();
		assert.deepEqual(calls, ['initial', 'latest']);
		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'fulfilled', value: reason});
		for (const caller of queued) {
			assert.deepEqual(caller, {status: 'rejected', reason});
		}

		assert.equal(await debounced('recovered'), 'recovered');
		assert.deepEqual(calls, ['initial', 'latest', 'recovered']);
	});
}

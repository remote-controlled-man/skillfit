#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [index, [name, reason]] of falsyValues.entries()) {
	for (const synchronous of [false, true]) {
		test(`shared callers preserve ${synchronous ? 'synchronous' : 'asynchronous'} ${name} rejection and recover`, {timeout: 2000}, async () => {
			const pending = gate();
			const calls = [];
			const debounced = pDebounce.promise(value => {
				calls.push(value);
				if (calls.length === 1) {
					if (synchronous) {
						throw reason;
					}

					return pending.promise.then(() => {
						throw reason;
					});
				}

				return value;
			});
			const outcomes = Promise.allSettled([
				debounced('initial'),
				debounced('shared one'),
				debounced('shared two'),
			]);
			assert.deepEqual(calls, ['initial']);
			pending.release();
			assert.deepEqual(await outcomes, Array.from({length: 3}, () => ({status: 'rejected', reason})));
			assert.equal(await debounced('recovered'), 'recovered');
			assert.deepEqual(calls, ['initial', 'recovered']);
		});
	}

	for (const queuedRejects of [false, true]) {
		test(`after:true drains a ${queuedRejects ? 'rejecting' : 'successful'} queue after ${name} rejection`, {timeout: 2000}, async () => {
			const initialGate = gate();
			const queuedGate = gate();
			const queuedReason = falsyValues[(index + 1) % falsyValues.length][1];
			const calls = [];
			const initialContext = {name: 'initial context'};
			const latestContext = {name: 'latest context'};
			const debounced = pDebounce.promise(async function (value) {
				calls.push({context: this, value});
				if (value === 'initial') {
					await initialGate.promise;
					throw reason;
				}

				if (value === 'latest') {
					await queuedGate.promise;
					if (queuedRejects) {
						throw queuedReason;
					}

					return reason;
				}

				return value;
			}, {after: true});
			const initial = debounced.call(initialContext, 'initial');
			const queuedOne = debounced.call({name: 'replaced context'}, 'replaced');
			const queuedTwo = debounced.call(latestContext, 'latest');
			const queuedStates = [observe(queuedOne), observe(queuedTwo)];
			const outcomes = Promise.allSettled([initial, queuedOne, queuedTwo]);
			assert.deepEqual(calls, [{context: initialContext, value: 'initial'}]);
			initialGate.release();
			await flush();
			assert.deepEqual(calls, [
				{context: initialContext, value: 'initial'},
				{context: latestContext, value: 'latest'},
			]);
			assert.deepEqual(queuedStates, [{status: 'pending'}, {status: 'pending'}]);
			queuedGate.release();
			const queuedOutcome = queuedRejects
				? {status: 'rejected', reason: queuedReason}
				: {status: 'fulfilled', value: reason};
			assert.deepEqual(await outcomes, [
				{status: 'rejected', reason},
				queuedOutcome,
				queuedOutcome,
			]);
			assert.equal(await debounced('recovered'), 'recovered');
			assert.equal(calls.length, 3);
		});
	}

	test(`successful ${name} values remain fulfilled for shared and subsequent calls`, {timeout: 2000}, async () => {
		const pending = gate();
		const calls = [];
		const debounced = pDebounce.promise(async value => {
			calls.push(value);
			await pending.promise;
			return value;
		});
		const outcomes = Promise.allSettled([debounced(reason), debounced('ignored')]);
		assert.deepEqual(calls, [reason]);
		pending.release();
		assert.deepEqual(await outcomes, [
			{status: 'fulfilled', value: reason},
			{status: 'fulfilled', value: reason},
		]);
		assert.deepEqual(await Promise.allSettled([debounced(reason)]), [{status: 'fulfilled', value: reason}]);
		assert.equal(await debounced('next'), 'next');
		assert.deepEqual(calls, [reason, reason, 'next']);
	});
}

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {gate, observe, flush} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

const rejectionKinds = [
	['synchronous throw', reason => {
		throw reason;
	}],
	['promise rejection', reason => Promise.reject(reason)],
];

for (const [label, value] of falsyValues) {
	for (const [kind, reject] of rejectionKinds) {
		test(`shared callers preserve ${label} from a ${kind}`, async () => {
			let calls = 0;
			const debounced = pDebounce.promise(argument => {
				calls++;
				return calls === 1 ? reject(value) : argument;
			});

			const outcomes = await Promise.allSettled([
				debounced('initial'),
				debounced('ignored'),
				debounced('also ignored'),
			]);
			assert.deepEqual(outcomes, [
				{status: 'rejected', reason: value},
				{status: 'rejected', reason: value},
				{status: 'rejected', reason: value},
			]);
			assert.equal(calls, 1);

			assert.equal(await debounced('recovered'), 'recovered');
			assert.equal(calls, 2);
		});
	}

	test(`shared callers still receive successful ${label} values`, async () => {
		let calls = 0;
		const debounced = pDebounce.promise(argument => {
			calls++;
			return argument;
		});

		const outcomes = await Promise.allSettled([
			debounced(value),
			debounced('ignored'),
		]);
		assert.deepEqual(outcomes, [
			{status: 'fulfilled', value},
			{status: 'fulfilled', value},
		]);
		assert.equal(calls, 1);

		assert.equal(await debounced('later'), 'later');
		assert.equal(calls, 2);
	});

	test(`after:true runs the latest queued call before propagating a ${label} rejection`, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const calls = [];
		const initialContext = {name: 'initial'};
		const replacedContext = {name: 'replaced'};
		const latestContext = {name: 'latest'};
		const laterContext = {name: 'later'};
		const debounced = pDebounce.promise(async function (argument) {
			calls.push({argument, context: this});
			if (argument === 'initial') {
				await initialGate.promise;
				throw value;
			}

			if (argument === 'latest') {
				await queuedGate.promise;
				return value;
			}

			return argument;
		}, {after: true});

		const initial = debounced.call(initialContext, 'initial');
		const initialState = observe(initial);
		const outcomes = Promise.allSettled([
			initial,
			debounced.call(replacedContext, 'replaced'),
			debounced.call(latestContext, 'latest'),
		]);
		assert.deepEqual(calls, [{argument: 'initial', context: initialContext}]);

		initialGate.release();
		await flush();
		assert.deepEqual(calls, [
			{argument: 'initial', context: initialContext},
			{argument: 'latest', context: latestContext},
		]);
		assert.deepEqual(initialState, {status: 'pending'});

		queuedGate.release();
		assert.deepEqual(await outcomes, [
			{status: 'rejected', reason: value},
			{status: 'fulfilled', value},
			{status: 'fulfilled', value},
		]);

		assert.equal(await debounced.call(laterContext, 'later'), 'later');
		assert.deepEqual(calls, [
			{argument: 'initial', context: initialContext},
			{argument: 'latest', context: latestContext},
			{argument: 'later', context: laterContext},
		]);
	});
}

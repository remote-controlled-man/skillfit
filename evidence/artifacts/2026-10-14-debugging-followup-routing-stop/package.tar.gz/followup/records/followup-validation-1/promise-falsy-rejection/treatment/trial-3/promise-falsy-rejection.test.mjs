#!/usr/bin/env node
import assert from 'node:assert/strict';
import test from 'node:test';
import pDebounce from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

const falsyValues = [
	['undefined', undefined],
	['null', null],
	['false', false],
	['zero', 0],
	['empty string', ''],
	['NaN', Number.NaN],
];

for (const [label, value] of falsyValues) {
	test(`shared callers preserve a rejection with ${label}`, async () => {
		const pending = gate();
		const calls = [];
		const debounced = pDebounce.promise(async argument => {
			calls.push(argument);
			if (argument === 'initial') {
				await pending.promise;
				throw value;
			}

			return argument;
		});
		const callers = ['initial', 'shared one', 'shared two'].map(argument => observe(debounced(argument)));
		assert.deepEqual(calls, ['initial']);
		assert.deepEqual(callers, Array.from({length: 3}, () => ({status: 'pending'})));

		pending.release();
		await flush();
		for (const caller of callers) {
			assert.deepEqual(caller, {status: 'rejected', reason: value});
		}

		const next = observe(debounced('next'));
		await flush();
		assert.deepEqual(next, {status: 'fulfilled', value: 'next'});
		assert.deepEqual(calls, ['initial', 'next']);
	});

	test(`after: true runs the queue and preserves an initial rejection with ${label}`, async () => {
		const initialGate = gate();
		const queuedGate = gate();
		const calls = [];
		const debounced = pDebounce.promise(async argument => {
			calls.push(argument);
			if (argument === 'initial') {
				await initialGate.promise;
				throw value;
			}

			if (argument === 'latest') {
				await queuedGate.promise;
				return value;
			}

			return argument;
		}, {after: true});
		const initial = observe(debounced('initial'));
		const queued = [observe(debounced('superseded')), observe(debounced('latest'))];
		assert.deepEqual(calls, ['initial']);

		initialGate.release();
		await flush();
		assert.deepEqual(calls, ['initial', 'latest']);
		assert.deepEqual(initial, {status: 'pending'});
		assert.deepEqual(queued, [{status: 'pending'}, {status: 'pending'}]);

		queuedGate.release();
		await flush();
		assert.deepEqual(initial, {status: 'rejected', reason: value});
		for (const caller of queued) {
			assert.deepEqual(caller, {status: 'fulfilled', value});
		}

		const next = observe(debounced('next'));
		await flush();
		assert.deepEqual(next, {status: 'fulfilled', value: 'next'});
		assert.deepEqual(calls, ['initial', 'latest', 'next']);
	});

	test(`synchronous throws and queued rejections preserve ${label}`, async () => {
		const throwing = pDebounce.promise(() => {
			throw value;
		});
		const shared = [observe(throwing()), observe(throwing())];
		await flush();
		for (const caller of shared) {
			assert.deepEqual(caller, {status: 'rejected', reason: value});
		}

		const pending = gate();
		const calls = [];
		const debounced = pDebounce.promise(async argument => {
			calls.push(argument);
			if (argument === 'initial') {
				await pending.promise;
				return 'initial result';
			}

			throw value;
		}, {after: true});
		const initial = observe(debounced('initial'));
		const queued = [observe(debounced('superseded')), observe(debounced('latest'))];
		pending.release();
		await flush();
		assert.deepEqual(initial, {status: 'fulfilled', value: 'initial result'});
		for (const caller of queued) {
			assert.deepEqual(caller, {status: 'rejected', reason: value});
		}
		assert.deepEqual(calls, ['initial', 'latest']);
	});

	test(`successful shared and subsequent calls preserve ${label}`, async () => {
		const pending = gate();
		let calls = 0;
		const debounced = pDebounce.promise(async () => {
			calls++;
			await pending.promise;
			return value;
		});
		const shared = [observe(debounced()), observe(debounced())];
		assert.equal(calls, 1);
		pending.release();
		await flush();
		for (const caller of shared) {
			assert.deepEqual(caller, {status: 'fulfilled', value});
		}

		const next = observe(debounced());
		await flush();
		assert.deepEqual(next, {status: 'fulfilled', value});
		assert.equal(calls, 2);
	});
}

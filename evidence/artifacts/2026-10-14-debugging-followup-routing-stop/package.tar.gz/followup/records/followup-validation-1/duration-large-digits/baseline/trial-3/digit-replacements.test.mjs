#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];
const scientificCases = [
  [1e21, '1e+21', '①e+②①'],
  [1.2345e24, '1.2345e+24', '①.②③④⑤e+②④'],
  [1e100, '1e+100', '①e+①⓪⓪'],
  [1e-7, '1e-7', '①e-⑦'],
  [1.2345e-7, '1.2345e-7', '①.②③④⑤e-⑦'],
  [Number.MIN_VALUE, '5e-324', '⑤e-③②④'],
];

for (const [duration, plain, replaced] of scientificCases) {
  test(`digit replacements preserve scientific notation for ${plain} milliseconds`, () => {
    assert.equal(
      humanizeDuration(duration, {units: ['ms'], digitReplacements}),
      `${replaced} milliseconds`,
    );
  });
}

test('ordinary replacements and fixed notation at exponent boundaries stay intact', () => {
  const options = {units: ['ms'], digitReplacements};
  assert.equal(humanizeDuration(0, options), '⓪ milliseconds');
  assert.equal(humanizeDuration(1234567890, options), '①②③④⑤⑥⑦⑧⑨⓪ milliseconds');
  assert.equal(humanizeDuration(1e20, options), `①${'⓪'.repeat(20)} milliseconds`);
  assert.equal(humanizeDuration(1e-6, options), '⓪.⓪⓪⓪⓪⓪① milliseconds');
  assert.equal(
    humanizeDuration(1234.56789, {...options, decimal: '٫'}),
    '①②③④٫⑤⑥⑦⑧⑨ milliseconds',
  );
  assert.equal(
    humanizeDuration(1500, {units: ['s'], digitReplacements}),
    '①.⑤ seconds',
  );
});

test('localized unit words and decimal separators survive scientific digit replacement', () => {
  const options = {units: ['ms'], digitReplacements, language: 'fr'};
  assert.equal(humanizeDuration(1.2345e24, options), '①,②③④⑤e+②④ millisecondes');
  assert.equal(humanizeDuration(1.2345e-7, options), '①,②③④⑤e-⑦ milliseconde');
  assert.equal(
    humanizeDuration(1.2345e24, {...options, decimal: '٫'}),
    '①٫②③④⑤e+②④ millisecondes',
  );
});

test('digits in custom separators and unit words are preserved', () => {
  assert.equal(
    humanizeDuration(1.2345e-7, {
      units: ['ms'],
      digitReplacements,
      language: 'custom',
      languages: {custom: {ms: 'unit 2 e+3', decimal: '[9]'}},
    }),
    '①[9]②③④⑤e-⑦ unit 2 e+3',
  );
});

test('humanizer defaults and per-call replacement overrides work with exponents', () => {
  const humanizer = humanizeDuration.humanizer({units: ['ms'], digitReplacements});
  assert.equal(humanizer(1e21), '①e+②① milliseconds');
  assert.equal(humanizer(1e-7), '①e-⑦ milliseconds');
  assert.equal(humanizer(1e21, {digitReplacements: undefined}), '1e+21 milliseconds');
});

test('calls without replacements retain ordinary, scientific, and localized output', () => {
  for (const [duration, plain] of scientificCases) {
    assert.equal(humanizeDuration(duration, {units: ['ms']}), `${plain} milliseconds`);
  }
  assert.equal(humanizeDuration(1500, {units: ['s']}), '1.5 seconds');
  assert.equal(humanizeDuration(1e20, {units: ['ms']}), '100000000000000000000 milliseconds');
  assert.equal(humanizeDuration(1e-6, {units: ['ms']}), '0.000001 milliseconds');
  assert.equal(
    humanizeDuration(1.2345e24, {units: ['ms'], language: 'fr'}),
    '1,2345e+24 millisecondes',
  );
  assert.equal(
    humanizeDuration(1.2345e-7, {units: ['ms'], decimal: '٫'}),
    '1٫2345e-7 milliseconds',
  );
});

#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];
const scientificCases = [
  [1e21, '1e+21', '①e+②①'],
  [1.23e21, '1.23e+21', '①.②③e+②①'],
  [1e100, '1e+100', '①e+①⓪⓪'],
  [1e-7, '1e-7', '①e-⑦'],
  [1.23e-7, '1.23e-7', '①.②③e-⑦'],
  [1e-100, '1e-100', '①e-①⓪⓪'],
  [Number.MAX_VALUE, '1.7976931348623157e+308', '①.⑦⑨⑦⑥⑨③①③④⑧⑥②③①⑤⑦e+③⓪⑧'],
  [Number.MIN_VALUE, '5e-324', '⑤e-③②④'],
];

test('digit replacements preserve scientific notation and exponent signs', () => {
  for (const [duration, , replacedCount] of scientificCases) {
    assert.equal(
      humanizeDuration(duration, { units: ['ms'], digitReplacements }),
      `${replacedCount} milliseconds`,
      `duration ${duration}`,
    );
  }
});

test('scientific notation without digit replacements stays intact', () => {
  for (const [duration, count] of scientificCases) {
    assert.equal(
      humanizeDuration(duration, { units: ['ms'] }),
      `${count} milliseconds`,
    );
  }
});

test('scientific digit replacements preserve localized decimals and unit words', () => {
  assert.equal(
    humanizeDuration(1.23e21, { units: ['ms'], language: 'fr', digitReplacements }),
    '①,②③e+②① millisecondes',
  );
  assert.equal(
    humanizeDuration(1.23e-7, { units: ['ms'], language: 'fr', digitReplacements }),
    '①,②③e-⑦ milliseconde',
  );
});

test('custom decimal separators and unit text are not digit-replaced', () => {
  const options = {
    units: ['ms'],
    language: 'custom',
    languages: { custom: { ms: 'unit e+12' } },
    decimal: ' point 2 ',
    digitReplacements,
  };
  assert.equal(humanizeDuration(1.23e21, options), '① point 2 ②③e+②① unit e+12');
  assert.equal(humanizeDuration(1.23e-7, options), '① point 2 ②③e-⑦ unit e+12');
});

test('ordinary digit replacements and formatting remain supported', () => {
  assert.equal(humanizeDuration(0, { digitReplacements }), '⓪ seconds');
  assert.equal(humanizeDuration(1000, { digitReplacements }), '① second');
  assert.equal(humanizeDuration(1234567890, { units: ['ms'], digitReplacements }),
    '①②③④⑤⑥⑦⑧⑨⓪ milliseconds');
  assert.equal(humanizeDuration(1234, { digitReplacements }), '①.②③④ seconds');
  assert.equal(humanizeDuration(1234, { language: 'fr', digitReplacements }),
    '①,②③④ seconde');
  assert.equal(humanizeDuration(1234, { maxDecimalPoints: 2, digitReplacements }),
    '①.②③ seconds');
  assert.equal(humanizeDuration(1234), '1.234 seconds');
  assert.equal(humanizeDuration(1234, { language: 'fr' }), '1,234 seconde');
});

test('humanizer defaults and per-call replacement overrides preserve notation', () => {
  const humanizer = humanizeDuration.humanizer({ units: ['ms'], digitReplacements });
  assert.equal(humanizer(1.23e21), '①.②③e+②① milliseconds');
  assert.equal(humanizer(1.23e-7), '①.②③e-⑦ milliseconds');
  assert.equal(humanizer(1.23e21, { digitReplacements: undefined }),
    '1.23e+21 milliseconds');
  assert.equal(humanizer(1234), '①②③④ milliseconds');
});

test('language-provided digit replacements also preserve scientific notation', () => {
  assert.equal(humanizeDuration(1.23e21, { units: ['ms'], language: 'ar' }),
    '١,٢٣e+٢١ جزء من الثانية');
  assert.equal(humanizeDuration(1.23e-7, { units: ['ms'], language: 'ar' }),
    '١,٢٣e-٧ جزء من الثانية');
});

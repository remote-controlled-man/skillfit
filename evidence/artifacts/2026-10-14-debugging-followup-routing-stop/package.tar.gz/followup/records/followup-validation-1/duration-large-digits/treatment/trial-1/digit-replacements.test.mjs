#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];
const scientificCases = [
  [1e21, '1e+21 milliseconds', '①e+②① milliseconds'],
  [1.23e21, '1.23e+21 milliseconds', '①.②③e+②① milliseconds'],
  [1e100, '1e+100 milliseconds', '①e+①⓪⓪ milliseconds'],
  [1.23e-7, '1.23e-7 milliseconds', '①.②③e-⑦ milliseconds'],
  [Number.MIN_VALUE, '5e-324 milliseconds', '⑤e-③②④ milliseconds'],
];

for (const [duration, , expected] of scientificCases) {
  test(`digit replacements preserve scientific notation for ${duration} ms`, () => {
    assert.equal(
      humanizeDuration(duration, {units: ['ms'], digitReplacements}),
      expected,
    );
  });
}

test('scientific notation remains unchanged without digit replacements', () => {
  for (const [duration, expected] of scientificCases) {
    assert.equal(humanizeDuration(duration, {units: ['ms']}), expected);
  }
});

test('localized decimal separators and unit words are preserved', () => {
  assert.equal(
    humanizeDuration(1.23e21, {units: ['ms'], language: 'fr', digitReplacements}),
    '①,②③e+②① millisecondes',
  );
  assert.equal(
    humanizeDuration(1.23e21, {units: ['ms'], language: 'ar'}),
    '١,٢٣e+٢١ جزء من الثانية',
  );
  assert.equal(
    humanizeDuration(1.23e-7, {units: ['ms'], language: 'ar'}),
    '١,٢٣e-٧ جزء من الثانية',
  );
  assert.equal(humanizeDuration(2000, {language: 'ar'}), 'ثانيتان');
});

test('custom separators and unit words are not subjected to digit replacement', () => {
  assert.equal(
    humanizeDuration(1.23e21, {
      units: ['ms'],
      language: 'custom',
      languages: {custom: {ms: 'unité 9e+2'}},
      decimal: ' point 9e+ ',
      spacer: ' /7/ ',
      digitReplacements,
    }),
    '① point 9e+ ②③e+②① /7/ unité 9e+2',
  );
});

test('ordinary digit replacements retain their existing behavior', () => {
  const options = {units: ['ms'], digitReplacements};
  assert.equal(humanizeDuration(0, options), '⓪ milliseconds');
  assert.equal(humanizeDuration(1, options), '① millisecond');
  assert.equal(humanizeDuration(1234567890, options), '①②③④⑤⑥⑦⑧⑨⓪ milliseconds');
  assert.equal(
    humanizeDuration(1500, {units: ['s'], digitReplacements}),
    '①.⑤ seconds',
  );
  assert.equal(
    humanizeDuration(7999, {units: ['s'], maxDecimalPoints: 2, digitReplacements}),
    '⑦.⑨⑨ seconds',
  );
  assert.equal(
    humanizeDuration(1234, {
      digitReplacements: [
        'Zero', 'One', 'Two', 'Three', 'Four',
        'Five', 'Six', 'Seven', 'Eight', 'Nine',
      ],
    }),
    'One.TwoThreeFour seconds',
  );
});

test('humanizer defaults and per-call overrides retain replacement behavior', () => {
  const humanizer = humanizeDuration.humanizer({units: ['ms'], digitReplacements});
  assert.equal(humanizer(1.23e21), '①.②③e+②① milliseconds');
  assert.equal(
    humanizer(1.23e-7, {decimal: ','}),
    '①,②③e-⑦ milliseconds',
  );
  assert.equal(
    humanizer(1.23e21, {digitReplacements: undefined}),
    '1.23e+21 milliseconds',
  );
  assert.equal(
    humanizeDuration(1.23e21, {
      units: ['ms'], language: 'ar', digitReplacements: undefined,
    }),
    '1,23e+21 جزء من الثانية',
  );
});

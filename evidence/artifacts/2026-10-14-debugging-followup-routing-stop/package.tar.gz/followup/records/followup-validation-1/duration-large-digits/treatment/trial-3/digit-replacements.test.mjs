#!/usr/bin/env node
import test from "node:test";
import assert from "node:assert/strict";
import humanizeDuration from "./index.js";

const digitReplacements = ["⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"];

test("digitReplacements preserve positive exponents", () => {
  const options = { units: ["s"], digitReplacements };
  assert.equal(humanizeDuration(1e24, options), "①e+②① seconds");
  assert.equal(humanizeDuration(1.25e24, options), "①.②⑤e+②① seconds");
  assert.equal(
    humanizeDuration(1e30, { units: ["ms"], digitReplacements }),
    "①e+③⓪ milliseconds"
  );
});

test("digitReplacements preserve negative exponents", () => {
  assert.equal(
    humanizeDuration(0.000125, { units: ["s"], digitReplacements }),
    "①.②⑤e-⑦ seconds"
  );
  assert.equal(
    humanizeDuration(Number.MIN_VALUE, { units: ["ms"], digitReplacements }),
    "⑤e-③②④ milliseconds"
  );
});

test("scientific notation keeps localized decimals and unit words", () => {
  const arabic = { language: "ar", units: ["s"] };
  assert.equal(humanizeDuration(1.25e24, arabic), "١,٢٥e+٢١ ثانية");
  assert.equal(humanizeDuration(0.000125, arabic), "١,٢٥e-٧ ثانية");
  assert.equal(humanizeDuration(2000, arabic), "ثانيتان");

  const spanish = { language: "es", units: ["s"], digitReplacements };
  assert.equal(humanizeDuration(1.25e24, spanish), "①,②⑤e+②① segundos");
  assert.equal(humanizeDuration(0.000125, spanish), "①,②⑤e-⑦ segundos");
});

test("humanizer defaults and overrides leave formatting text intact", () => {
  const humanizer = humanizeDuration.humanizer({
    units: ["ms"],
    digitReplacements,
    language: "custom",
    languages: { custom: { ms: "毫秒2e+-", decimal: "٫" } },
    spacer: " | "
  });

  assert.equal(humanizer(1.25e21), "①٫②⑤e+②① | 毫秒2e+-");
  assert.equal(
    humanizer(1.25e-7, { decimal: " point 2e+- " }),
    "① point 2e+- ②⑤e-⑦ | 毫秒2e+-"
  );
  assert.equal(
    humanizer(1.25e21, { digitReplacements: undefined }),
    "1٫25e+21 | 毫秒2e+-"
  );
});

test("ordinary digit replacements remain intact", () => {
  const options = { units: ["ms"], digitReplacements };
  assert.equal(humanizeDuration(1234567890, options), "①②③④⑤⑥⑦⑧⑨⓪ milliseconds");
  assert.equal(humanizeDuration(0, options), "⓪ milliseconds");
  assert.equal(humanizeDuration(1, options), "① millisecond");
  assert.equal(humanizeDuration(12.5, options), "①②.⑤ milliseconds");
  assert.equal(
    humanizeDuration(1234, {
      units: ["s"],
      maxDecimalPoints: 2,
      decimal: ",",
      digitReplacements: ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"]
    }),
    "One,TwoThree seconds"
  );
});

test("calls without digit replacements retain their existing notation", () => {
  const seconds = { units: ["s"] };
  assert.equal(humanizeDuration(1e24, seconds), "1e+21 seconds");
  assert.equal(humanizeDuration(1.25e24, seconds), "1.25e+21 seconds");
  assert.equal(humanizeDuration(0.000125, seconds), "1.25e-7 seconds");
  assert.equal(humanizeDuration(0.0001, seconds), "1.0000000000000001e-7 seconds");
  assert.equal(humanizeDuration(Number.MIN_VALUE, { units: ["ms"] }), "5e-324 milliseconds");
  assert.equal(humanizeDuration(1.25e24, { ...seconds, language: "es" }), "1,25e+21 segundos");
  assert.equal(
    humanizeDuration(1.25e24, { ...seconds, language: "ar", digitReplacements: undefined }),
    "1,25e+21 ثانية"
  );
});

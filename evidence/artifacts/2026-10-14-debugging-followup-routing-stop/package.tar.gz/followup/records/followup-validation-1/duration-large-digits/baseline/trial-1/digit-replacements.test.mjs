#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];

const scientificCases = [
  [1e24, ['s'], '1e+21 seconds', 'Be+CB seconds'],
  [1.25e21, ['ms'], '1.25e+21 milliseconds', 'B.CFe+CB milliseconds'],
  [1e-7, ['ms'], '1e-7 milliseconds', 'Be-H milliseconds'],
  [1.25e-7, ['ms'], '1.25e-7 milliseconds', 'B.CFe-H milliseconds'],
  [Number.MAX_VALUE, ['ms'], '1.7976931348623157e+308 milliseconds',
    'B.HJHGJDBDEIGCDBFHe+DAI milliseconds'],
  [Number.MIN_VALUE, ['ms'], '5e-324 milliseconds', 'Fe-DCE milliseconds']
];

for (const [duration, units, original, replaced] of scientificCases) {
  test(`digit replacements preserve scientific notation for ${duration} ms in ${units[0]}`, () => {
    assert.equal(humanizeDuration(duration, {units}), original);
    assert.equal(humanizeDuration(duration, {units, digitReplacements}), replaced);
  });
}

test('localized unit words and decimal separators survive scientific digit replacements', () => {
  const options = {units: ['ms'], language: 'fr'};
  assert.equal(humanizeDuration(1.25e21, options), '1,25e+21 millisecondes');
  assert.equal(humanizeDuration(1.25e21, {...options, digitReplacements}),
    'B,CFe+CB millisecondes');
  assert.equal(humanizeDuration(1.25e-7, options), '1,25e-7 milliseconde');
  assert.equal(humanizeDuration(1.25e-7, {...options, digitReplacements}),
    'B,CFe-H milliseconde');
});

test('digits and exponent characters inside custom separators and unit words stay intact', () => {
  const options = {
    units: ['ms'],
    language: 'custom',
    languages: {custom: {ms: 'unit e+21-7'}},
    decimal: ' point 0e+- '
  };
  assert.equal(humanizeDuration(1.25e21, options),
    '1 point 0e+- 25e+21 unit e+21-7');
  assert.equal(humanizeDuration(1.25e21, {...options, digitReplacements}),
    'B point 0e+- CFe+CB unit e+21-7');
});

test('ordinary digit replacements retain zero, all digits, decimals and unit inflection', () => {
  const options = {units: ['ms'], digitReplacements};
  assert.equal(humanizeDuration(0, options), 'A milliseconds');
  assert.equal(humanizeDuration(9876543210, options), 'JIHGFEDCBA milliseconds');
  assert.equal(humanizeDuration(123.456, options), 'BCD.EFG milliseconds');
  assert.equal(humanizeDuration(1500, {digitReplacements}), 'B.F seconds');
  assert.equal(humanizeDuration(3602000, {units: ['h', 's'], digitReplacements}),
    'B hour, C seconds');
});

test('replacement strings are inserted once without being interpreted as notation', () => {
  const replacements = ['(0)', '1e+', '(2)', '(3)', '(4)', '(5)', '(6)', '(7)', '(8)', '(9)'];
  assert.equal(humanizeDuration(1.25e21, {units: ['ms'], digitReplacements: replacements}),
    '1e+.(2)(5)e+(2)1e+ milliseconds');
});

test('humanizer defaults and call-specific formatting work with scientific notation', () => {
  const humanizer = humanizeDuration.humanizer({units: ['ms'], language: 'fr', digitReplacements});
  assert.equal(humanizer(1.25e21), 'B,CFe+CB millisecondes');
  assert.equal(humanizer(1.25e-7, {decimal: '::'}), 'B::CFe-H milliseconde');
  assert.equal(humanizer(1.25e21, {digitReplacements: undefined}), '1,25e+21 millisecondes');
});

test('language-provided digit replacements preserve scientific notation and hidden counts', () => {
  const humanizer = humanizeDuration.humanizer({units: ['ms'], language: 'ar'});
  assert.equal(humanizer(1.25e21), '١,٢٥e+٢١ جزء من الثانية');
  assert.equal(humanizer(1.25e-7), '١,٢٥e-٧ جزء من الثانية');
  assert.equal(humanizer(2), 'جزآن من الثانية');
});

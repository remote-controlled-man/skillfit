#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];

const scientificCounts = [
  [1e21, '1e+21', '①e+②①'],
  [1.234e27, '1.234e+27', '①.②③④e+②⑦'],
  [1e-7, '1e-7', '①e-⑦'],
  [1.234e-9, '1.234e-9', '①.②③④e-⑨'],
  [Number.MAX_VALUE, '1.7976931348623157e+308', '①.⑦⑨⑦⑥⑨③①③④⑧⑥②③①⑤⑦e+③⓪⑧'],
  [Number.MIN_VALUE, '5e-324', '⑤e-③②④']
];

for (const [duration, plainCount, replacedCount] of scientificCounts) {
  test(`digit replacements preserve scientific notation for ${plainCount} ms`, () => {
    assert.equal(
      humanizeDuration(duration, {units: ['ms']}),
      `${plainCount} milliseconds`
    );
    assert.equal(
      humanizeDuration(duration, {units: ['ms'], digitReplacements}),
      `${replacedCount} milliseconds`
    );
  });
}

test('digit replacements preserve localized decimals and unit words', () => {
  const options = {units: ['ms'], language: 'fr', digitReplacements};
  assert.equal(humanizeDuration(1.234e27, options), '①,②③④e+②⑦ millisecondes');
  assert.equal(humanizeDuration(1.234e-9, options), '①,②③④e-⑨ milliseconde');
  assert.equal(
    humanizeDuration(1.234e27, {...options, decimal: ' point 0 '}),
    '① point 0 ②③④e+②⑦ millisecondes'
  );
  assert.equal(
    humanizeDuration(1.234e27, {
      ...options,
      language: 'custom',
      languages: {custom: {ms: 'millisecondes 2e+3', decimal: ','}}
    }),
    '①,②③④e+②⑦ millisecondes 2e+3'
  );
});

test('ordinary digit replacements and fixed notation remain intact', () => {
  const options = {units: ['ms'], digitReplacements};
  assert.equal(humanizeDuration(0, options), '⓪ milliseconds');
  assert.equal(humanizeDuration(9876543210, options), '⑨⑧⑦⑥⑤④③②①⓪ milliseconds');
  assert.equal(humanizeDuration(1e20, options), '①⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪ milliseconds');
  assert.equal(humanizeDuration(1e-6, options), '⓪.⓪⓪⓪⓪⓪① milliseconds');
  assert.equal(humanizeDuration(1000, {digitReplacements}), '① second');
  assert.equal(
    humanizeDuration(1234, {
      digitReplacements: ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
    }),
    'One.TwoThreeFour seconds'
  );
});

test('calls without replacements preserve ordinary and localized output', () => {
  assert.equal(humanizeDuration(1234), '1.234 seconds');
  assert.equal(humanizeDuration(1.234e27, {units: ['ms'], language: 'fr'}), '1,234e+27 millisecondes');
  assert.equal(
    humanizeDuration(1.234e-9, {units: ['ms'], decimal: ' point 0 '}),
    '1 point 0 234e-9 milliseconds'
  );
});

test('humanizers preserve exponents after unit conversion and allow disabling replacements', () => {
  const humanizer = humanizeDuration.humanizer({units: ['s'], digitReplacements});
  assert.equal(humanizer(1e24), '①e+②① seconds');
  assert.equal(
    humanizeDuration(1e-4, {units: ['s']}),
    '1.0000000000000001e-7 seconds'
  );
  assert.equal(humanizer(1e-4), '①.⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪①e-⑦ seconds');
  assert.equal(humanizer(1e24, {digitReplacements: undefined}), '1e+21 seconds');
});

test('language-provided digit replacements also preserve scientific notation', () => {
  const options = {units: ['ms'], language: 'ar'};
  assert.equal(humanizeDuration(1e21, options), '١e+٢١ جزء من الثانية');
  assert.equal(humanizeDuration(1e-7, options), '١e-٧ جزء من الثانية');
  assert.equal(humanizeDuration(1234, options), '١٢٣٤ جزء من الثانية');
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {withClock, observe, flush, gate} from './test-clock.mjs';

test('a completed cycle leaves the next debounce window pending', async () => {
	await withClock(async clock => {
		const first = gate();
		const second = gate();
		const calls = [];
		const firstContext = {};
		const secondContext = {};
		const debounced = pDebounce(async function (value) {
			calls.push({value, context: this});
			return (value === 'first' ? first : second).promise;
		}, 10);
		const firstCall = observe(debounced('ignored'));
		const firstLatest = observe(debounced.call(firstContext, 'first'));
		await clock.advance(10);
		assert.deepEqual(calls, [{value: 'first', context: firstContext}]);

		const secondCall = observe(debounced('also ignored'));
		await clock.advance(5);
		const secondLatest = observe(debounced.call(secondContext, 'second'));
		first.release('first result');
		await flush();
		for (const state of [firstCall, firstLatest]) {
			assert.deepEqual(state, {status: 'fulfilled', value: 'first result'});
		}
		for (const state of [secondCall, secondLatest]) {
			assert.deepEqual(state, {status: 'pending'});
		}

		await clock.advance(9);
		assert.equal(calls.length, 1);
		await clock.advance(1);
		assert.deepEqual(calls, [
			{value: 'first', context: firstContext},
			{value: 'second', context: secondContext},
		]);
		second.release('second result');
		await flush();
		for (const state of [secondCall, secondLatest]) {
			assert.deepEqual(state, {status: 'fulfilled', value: 'second result'});
		}
	});
});

for (const order of [[0, 1], [1, 0]]) {
	for (const rejected of [[false, false], [true, false], [false, true], [true, true]]) {
		test(`overlapping cycles settle in order ${order} with rejections ${rejected}`, async () => {
			await withClock(async clock => {
				const gates = [gate(), gate()];
				const errors = [new Error('first failure'), new Error('second failure')];
				const calls = [];
				const debounced = pDebounce(async cycle => {
					calls.push(cycle);
					await gates[cycle].promise;
					if (rejected[cycle]) {
						throw errors[cycle];
					}

					return `result ${cycle}`;
				}, 10);
				const states = [[observe(debounced('ignored')), observe(debounced(0))]];
				await clock.advance(10);
				states.push([observe(debounced('ignored')), observe(debounced(1))]);
				await clock.advance(10);
				assert.deepEqual(calls, [0, 1]);

				for (const cycle of order) {
					gates[cycle].release();
					await flush();
					for (let index = 0; index < states.length; index++) {
						const settled = index === cycle || index === order[0];
						const expected = settled
							? (rejected[index]
								? {status: 'rejected', reason: errors[index]}
								: {status: 'fulfilled', value: `result ${index}`})
							: {status: 'pending'};
						for (const state of states[index]) {
							assert.deepEqual(state, expected);
							if (settled && rejected[index]) {
								assert.strictEqual(state.reason, errors[index]);
							}
						}
					}
				}
			});
		});
	}
}

test('wrappers around the same function coalesce independently', async () => {
	await withClock(async clock => {
		const gates = [gate(), gate()];
		const calls = [];
		const function_ = async value => {
			calls.push(value);
			return gates[value].promise;
		};
		const first = pDebounce(function_, 10);
		const second = pDebounce(function_, 10);
		const firstStates = [observe(first('ignored')), observe(first(0))];
		const secondStates = [observe(second('ignored')), observe(second(1))];
		await clock.advance(10);
		assert.deepEqual(calls, [0, 1]);
		gates[1].release('second wrapper');
		await flush();
		for (const state of firstStates) {
			assert.deepEqual(state, {status: 'pending'});
		}
		for (const state of secondStates) {
			assert.deepEqual(state, {status: 'fulfilled', value: 'second wrapper'});
		}
		gates[0].release('first wrapper');
		await flush();
		for (const state of firstStates) {
			assert.deepEqual(state, {status: 'fulfilled', value: 'first wrapper'});
		}
	});
});

test('completion does not remove a later cycle\'s abort listener', async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const first = gate();
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			return first.promise;
		}, 10, {signal: controller.signal});
		const firstState = observe(debounced('first'));
		await clock.advance(10);
		const secondState = observe(debounced('second'));
		first.release('first result');
		await flush();
		assert.deepEqual(firstState, {status: 'fulfilled', value: 'first result'});
		const reason = new Error('cancel second cycle');
		controller.abort(reason);
		await flush();
		assert.equal(secondState.status, 'rejected');
		assert.strictEqual(secondState.reason, reason);
		await clock.advance(10);
		assert.deepEqual(calls, ['first']);
	});
});

test('abort settles callers in all executing cycles', async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const gates = [gate(), gate()];
		const debounced = pDebounce(value => gates[value].promise, 10, {signal: controller.signal});
		const first = observe(debounced(0));
		await clock.advance(10);
		const second = observe(debounced(1));
		await clock.advance(10);
		const reason = new Error('cancel executing cycles');
		controller.abort(reason);
		await flush();
		for (const state of [first, second]) {
			assert.equal(state.status, 'rejected');
			assert.strictEqual(state.reason, reason);
		}
		for (const completion of gates) {
			completion.release('too late');
		}
		await flush();
		for (const state of [first, second]) {
			assert.strictEqual(state.reason, reason);
		}
	});
});

test('leading cycles keep their own async outcome for coalesced callers', async () => {
	await withClock(async clock => {
		const gates = [gate(), gate()];
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			return gates[value].promise;
		}, 10, {before: true});
		const firstStates = [observe(debounced(0)), observe(debounced('ignored'))];
		await clock.advance(10);
		const secondStates = [observe(debounced(1)), observe(debounced('ignored'))];
		assert.deepEqual(calls, [0, 1]);
		gates[0].release('first leading result');
		await flush();
		for (const state of firstStates) {
			assert.deepEqual(state, {status: 'fulfilled', value: 'first leading result'});
		}
		for (const state of secondStates) {
			assert.deepEqual(state, {status: 'pending'});
		}
		await clock.advance(10);
		gates[1].release('second leading result');
		await flush();
		for (const state of secondStates) {
			assert.deepEqual(state, {status: 'fulfilled', value: 'second leading result'});
		}
	});
});

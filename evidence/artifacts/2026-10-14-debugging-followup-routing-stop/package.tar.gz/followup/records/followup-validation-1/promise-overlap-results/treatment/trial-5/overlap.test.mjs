#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {withClock, observe, flush} from './test-clock.mjs';

function deferred() {
	let resolve;
	let reject;
	const promise = new Promise((resolvePromise, rejectPromise) => {
		resolve = resolvePromise;
		reject = rejectPromise;
	});
	return {promise, resolve, reject};
}

test('a running cycle cannot settle a later cycle before its timer fires', async () => {
	await withClock(async clock => {
		const first = deferred();
		const second = deferred();
		const calls = [];
		const debounced = pDebounce(function (value, suffix) {
			calls.push({receiver: this, value, suffix});
			return value === 'first-latest' ? first.promise : second.promise;
		}, 10);
		const firstReceiver = {name: 'first'};
		const secondReceiver = {name: 'second'};
		const firstCall = observe(debounced.call(firstReceiver, 'first-old', 1));
		const firstLatest = observe(debounced.call(firstReceiver, 'first-latest', 2));
		await clock.advance(10);
		const secondCall = observe(debounced.call(secondReceiver, 'second-old', 3));
		await clock.advance(5);
		const secondLatest = observe(debounced.call(secondReceiver, 'second-latest', 4));

		first.resolve('first-result');
		await flush();
		assert.deepEqual(firstCall, {status: 'fulfilled', value: 'first-result'});
		assert.deepEqual(firstLatest, firstCall);
		assert.deepEqual(secondCall, {status: 'pending'});
		assert.deepEqual(secondLatest, {status: 'pending'});
		await clock.advance(9);
		assert.deepEqual(calls, [{receiver: firstReceiver, value: 'first-latest', suffix: 2}]);
		await clock.advance(1);
		assert.deepEqual(calls, [
			{receiver: firstReceiver, value: 'first-latest', suffix: 2},
			{receiver: secondReceiver, value: 'second-latest', suffix: 4},
		]);
		second.resolve('second-result');
		await flush();
		assert.deepEqual(secondCall, {status: 'fulfilled', value: 'second-result'});
		assert.deepEqual(secondLatest, secondCall);
	});
});

for (const order of [[0, 1], [1, 0]]) {
	for (const outcomes of [['resolve', 'resolve'], ['reject', 'resolve'], ['resolve', 'reject'], ['reject', 'reject']]) {
		test(`overlapping cycles settle independently: ${outcomes.join('/')} in order ${order.join('/')}`, async () => {
			await withClock(async clock => {
				const flights = [deferred(), deferred()];
				const results = outcomes.map((outcome, index) => outcome === 'resolve'
					? `result-${index}`
					: new Error(`error-${index}`));
				const calls = [];
				const debounced = pDebounce(value => {
					calls.push(value);
					return flights[value].promise;
				}, 10);
				const states = [[observe(debounced(0)), observe(debounced(0))]];
				await clock.advance(10);
				states.push([observe(debounced(1)), observe(debounced(1))]);
				await clock.advance(10);
				assert.deepEqual(calls, [0, 1]);

				const settled = new Set();
				for (const cycle of order) {
					flights[cycle][outcomes[cycle]](results[cycle]);
					settled.add(cycle);
					await flush();
					for (let index = 0; index < states.length; index++) {
						const expected = settled.has(index)
							? outcomes[index] === 'resolve'
								? {status: 'fulfilled', value: results[index]}
								: {status: 'rejected', reason: results[index]}
							: {status: 'pending'};
						for (const state of states[index]) {
							assert.deepEqual(state, expected);
						}
					}
				}

				const next = observe(debounced(1));
				await clock.advance(10);
				assert.deepEqual(next, states[1][0]);
				assert.deepEqual(calls, [0, 1, 1]);
			});
		});
	}
}

test('a function can start the next debounce cycle synchronously', async () => {
	await withClock(async clock => {
		const first = deferred();
		const second = deferred();
		let next;
		const calls = [];
		const debounced = pDebounce(value => {
			calls.push(value);
			if (value === 'first') {
				next = observe(debounced('second'));
				return first.promise;
			}
			return second.promise;
		}, 10);
		const original = observe(debounced('first'));
		await clock.advance(10);
		first.resolve('first-result');
		await flush();
		assert.deepEqual(original, {status: 'fulfilled', value: 'first-result'});
		assert.deepEqual(next, {status: 'pending'});
		await clock.advance(10);
		second.resolve('second-result');
		await flush();
		assert.deepEqual(next, {status: 'fulfilled', value: 'second-result'});
		assert.deepEqual(calls, ['first', 'second']);
	});
});

test('separate debounce wrappers keep independent timers and results', async () => {
	await withClock(async clock => {
		const flights = new Map([['left', deferred()], ['right', deferred()]]);
		const calls = [];
		const function_ = value => {
			calls.push(value);
			return flights.get(value).promise;
		};
		const left = pDebounce(function_, 10);
		const right = pDebounce(function_, 10);
		const leftCalls = [observe(left('ignored')), observe(left('left'))];
		await clock.advance(10);
		const rightCalls = [observe(right('ignored')), observe(right('right'))];
		await clock.advance(10);
		flights.get('right').resolve('right-result');
		await flush();
		for (const state of leftCalls) assert.deepEqual(state, {status: 'pending'});
		for (const state of rightCalls) assert.deepEqual(state, {status: 'fulfilled', value: 'right-result'});
		flights.get('left').resolve('left-result');
		await flush();
		for (const state of leftCalls) assert.deepEqual(state, {status: 'fulfilled', value: 'left-result'});
		assert.deepEqual(calls, ['left', 'right']);
	});
});

for (const order of [[0, 1], [1, 0]]) {
	test(`leading cycles retain their own async outcome in order ${order.join('/')}`, async () => {
		await withClock(async clock => {
			const flights = [deferred(), deferred()];
			const error = new Error('first leading cycle failed');
			const calls = [];
			const debounced = pDebounce(value => {
				calls.push(value);
				return flights[value].promise;
			}, 10, {before: true});
			const states = [[observe(debounced(0)), observe(debounced('ignored'))]];
			assert.deepEqual(calls, [0]);
			await clock.advance(10);
			for (const state of states[0]) assert.deepEqual(state, {status: 'pending'});
			states.push([observe(debounced(1)), observe(debounced('ignored'))]);
			assert.deepEqual(calls, [0, 1]);
			await clock.advance(10);
			const settled = new Set();
			for (const cycle of order) {
				if (cycle === 0) flights[cycle].reject(error);
				else flights[cycle].resolve('second-result');
				settled.add(cycle);
				await flush();
				for (let index = 0; index < states.length; index++) {
					const expected = settled.has(index)
						? index === 0
							? {status: 'rejected', reason: error}
							: {status: 'fulfilled', value: 'second-result'}
						: {status: 'pending'};
					for (const state of states[index]) assert.deepEqual(state, expected);
				}
			}
		});
	});
}

for (const startSecond of [false, true]) {
	test(`finishing an older cycle preserves cancellation of a ${startSecond ? 'running' : 'scheduled'} cycle`, async () => {
		await withClock(async clock => {
			const controller = new AbortController();
			const flights = [deferred(), deferred()];
			const calls = [];
			const debounced = pDebounce(value => {
				calls.push(value);
				return flights[value].promise;
			}, 10, {signal: controller.signal});
			const first = observe(debounced(0));
			await clock.advance(10);
			const second = observe(debounced(1));
			if (startSecond) await clock.advance(10);
			flights[0].resolve('first-result');
			await flush();
			assert.deepEqual(first, {status: 'fulfilled', value: 'first-result'});
			assert.deepEqual(second, {status: 'pending'});

			const reason = new Error('cancelled');
			controller.abort(reason);
			await flush();
			assert.deepEqual(second, {status: 'rejected', reason});
			await clock.advance(10);
			assert.deepEqual(calls, startSecond ? [0, 1] : [0]);
			if (startSecond) flights[1].reject(new Error('late failure after cancellation'));
			await flush();
			assert.deepEqual(first, {status: 'fulfilled', value: 'first-result'});
			assert.deepEqual(second, {status: 'rejected', reason});
			const afterAbort = observe(debounced(2));
			await flush();
			assert.deepEqual(afterAbort, {status: 'rejected', reason});
		});
	});
}

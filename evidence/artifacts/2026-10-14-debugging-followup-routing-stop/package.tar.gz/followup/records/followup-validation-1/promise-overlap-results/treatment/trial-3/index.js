const pDebounce = (function_, wait, options = {}) => {
	if (!Number.isFinite(wait)) {
		throw new TypeError('Expected `wait` to be a finite number');
	}

	let pendingBatch;

	return function (...arguments_) {
		return new Promise((resolve, reject) => {
			// Check if already aborted
			try {
				options.signal?.throwIfAborted();
			} catch (error) {
				reject(error);
				return;
			}

			const shouldCallNow = options.before && !pendingBatch;
			if (!pendingBatch) {
				pendingBatch = {resolveList: [], rejectList: []};
			}

			const batch = pendingBatch;
			const cleanup = () => {
				batch.resolveList = [];
				batch.rejectList = [];
			};

			if (!batch.onAbort) {
				batch.onAbort = () => {
					clearTimeout(batch.timeout);
					if (pendingBatch === batch) {
						pendingBatch = undefined;
					}

					try {
						options.signal?.throwIfAborted();
					} catch (error) {
						for (const rejectFunction of batch.rejectList) {
							rejectFunction(error);
						}

						cleanup();
					}
				};
			}

			clearTimeout(batch.timeout);

			batch.timeout = setTimeout(async () => {
				// Detach this cycle before calling user code or awaiting its result.
				pendingBatch = undefined;

				try {
					const result = options.before ? await batch.leadingPromise : await function_.apply(this, arguments_);

					for (const resolveFunction of batch.resolveList) {
						resolveFunction(result);
					}
				} catch (error) {
					for (const rejectFunction of batch.rejectList) {
						rejectFunction(error);
					}
				}

				cleanup();

				// Remove abort listener
				options.signal?.removeEventListener('abort', batch.onAbort);
			}, wait);

			if (shouldCallNow) {
				// Execute immediately for leading edge
				try {
					batch.leadingPromise = Promise.resolve(function_.apply(this, arguments_));
				} catch (error) {
					batch.leadingPromise = Promise.reject(error);
				}

				// eslint-disable-next-line promise/prefer-await-to-then
				batch.leadingPromise.then(resolve, reject);
			} else {
				// Add to lists for later resolution
				batch.resolveList.push(resolve);
				batch.rejectList.push(reject);

				// Set up abort listener (only once per batch)
				if (options.signal && batch.resolveList.length === 1) {
					options.signal.addEventListener('abort', batch.onAbort, {once: true});
				}
			}
		});
	};
};

pDebounce.promise = function_ => {
	let currentPromise;

	return async function (...arguments_) {
		if (currentPromise) {
			return currentPromise;
		}

		try {
			currentPromise = function_.apply(this, arguments_);
			return await currentPromise;
		} finally {
			currentPromise = undefined;
		}
	};
};

export default pDebounce;

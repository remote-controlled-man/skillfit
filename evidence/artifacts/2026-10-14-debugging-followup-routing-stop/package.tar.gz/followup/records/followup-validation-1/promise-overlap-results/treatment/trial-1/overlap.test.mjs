#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {withClock, observe, flush, gate} from './test-clock.mjs';

function outcome(kind, value) {
	return kind === 'reject'
		? {status: 'rejected', reason: new Error(value)}
		: {status: 'fulfilled', value};
}

function assertOutcome(states, expected) {
	for (const state of states) {
		assert.deepEqual(state, expected);
		if (expected.status === 'rejected') {
			assert.equal(state.reason, expected.reason);
		}
	}
}

for (const firstKind of ['fulfill', 'reject']) {
	for (const secondKind of ['fulfill', 'reject']) {
		for (const firstToFinish of [0, 1]) {
			test(`overlapping cycles: ${firstKind}/${secondKind}, cycle ${firstToFinish + 1} finishes first`, async () => {
				await withClock(async clock => {
					const gates = [gate(), gate()];
					const outcomes = [outcome(firstKind, 'first:first-latest'), outcome(secondKind, 'second:second-latest')];
					const calls = [];
					const debounced = pDebounce(async function (value) {
						const index = calls.length;
						calls.push([this.name, value]);
						await gates[index].promise;
						if (outcomes[index].status === 'rejected') {
							throw outcomes[index].reason;
						}
						return `${this.name}:${value}`;
					}, 10);
					const first = {name: 'first'};
					const second = {name: 'second'};
					const callers = [[
						observe(debounced.call({name: 'unused-first'}, 'first-initial')),
						observe(debounced.call(first, 'first-latest')),
					]];
					await clock.advance(10);
					callers.push([
						observe(debounced.call({name: 'unused-second'}, 'second-initial')),
						observe(debounced.call(second, 'second-latest')),
					]);
					await clock.advance(10);
					assert.deepEqual(calls, [['first', 'first-latest'], ['second', 'second-latest']]);
					assertOutcome(callers.flat(), {status: 'pending'});

					gates[firstToFinish].release();
					await flush();
					assertOutcome(callers[firstToFinish], outcomes[firstToFinish]);
					assertOutcome(callers[1 - firstToFinish], {status: 'pending'});
					gates[1 - firstToFinish].release();
					await flush();
					for (const index of [0, 1]) {
						assertOutcome(callers[index], outcomes[index]);
					}
				});
			});
		}
	}
}

for (const kind of ['fulfill', 'reject']) {
	test(`an older ${kind} cannot settle callers whose debounce timer is still pending`, async () => {
		await withClock(async clock => {
			const firstGate = gate();
			const expected = outcome(kind, 'first');
			const calls = [];
			const debounced = pDebounce(async value => {
				calls.push(value);
				if (value === 'first') {
					await firstGate.promise;
					if (kind === 'reject') {
						throw expected.reason;
					}
				}
				return value;
			}, 10);
			const first = observe(debounced('first'));
			await clock.advance(10);
			const second = [observe(debounced('second-initial'))];
			await clock.advance(5);
			second.push(observe(debounced('second-latest')));
			firstGate.release();
			await flush();
			assertOutcome([first], expected);
			assertOutcome(second, {status: 'pending'});
			await clock.advance(9);
			assert.deepEqual(calls, ['first']);
			await clock.advance(1);
			assert.deepEqual(calls, ['first', 'second-latest']);
			assertOutcome(second, outcome('fulfill', 'second-latest'));
			const third = observe(debounced('third'));
			await clock.advance(10);
			assertOutcome([third], outcome('fulfill', 'third'));
		});
	});
}

test('three overlapping cycles and separate wrappers keep their own callers', async () => {
	await withClock(async clock => {
		const gates = [gate(), gate(), gate(), gate()];
		const calls = [];
		const function_ = async value => {
			calls.push(value);
			await gates[value - 1].promise;
			return value;
		};
		const firstWrapper = pDebounce(function_, 10);
		const secondWrapper = pDebounce(function_, 10);
		const callers = [];
		for (const value of [1, 2, 3]) {
			callers.push(observe(firstWrapper(value)));
			await clock.advance(10);
		}
		const independent = [observe(secondWrapper(0)), observe(secondWrapper(4))];
		await clock.advance(10);
		assert.deepEqual(calls, [1, 2, 3, 4]);
		gates[3].release();
		await flush();
		assertOutcome(independent, outcome('fulfill', 4));
		assertOutcome(callers, {status: 'pending'});
		const completed = new Set();
		for (const value of [2, 1, 3]) {
			gates[value - 1].release();
			await flush();
			completed.add(value);
			for (const other of [1, 2, 3]) {
				assertOutcome([callers[other - 1]], completed.has(other) ? outcome('fulfill', other) : {status: 'pending'});
			}
		}
		assertOutcome(independent, outcome('fulfill', 4));
	});
});

for (const kind of ['fulfill', 'reject']) {
	test(`leading async cycles share their own ${kind} outcome`, async () => {
		await withClock(async clock => {
			const gates = [gate(), gate()];
			const expected = [outcome(kind, 'first'), outcome(kind, 'second')];
			const calls = [];
			const debounced = pDebounce(async value => {
				const index = calls.length;
				calls.push(value);
				await gates[index].promise;
				if (kind === 'reject') {
					throw expected[index].reason;
				}
				return value;
			}, 10, {before: true});
			const first = [observe(debounced('first')), observe(debounced('first-peer'))];
			await clock.advance(10);
			const second = [observe(debounced('second')), observe(debounced('second-peer'))];
			gates[0].release();
			await flush();
			assertOutcome(first, expected[0]);
			assertOutcome(second, {status: 'pending'});
			await clock.advance(10);
			assertOutcome(second, {status: 'pending'});
			gates[1].release();
			await flush();
			assertOutcome(second, expected[1]);
			assert.deepEqual(calls, ['first', 'second']);
		});
	});
}

test('completion of an older cycle preserves cancellation of a newer cycle', async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const firstGate = gate();
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			await firstGate.promise;
			return value;
		}, 10, {signal: controller.signal});
		const first = observe(debounced('first'));
		await clock.advance(10);
		const second = [observe(debounced('second')), observe(debounced('second-latest'))];
		firstGate.release();
		await flush();
		assertOutcome([first], outcome('fulfill', 'first'));
		assertOutcome(second, {status: 'pending'});
		const reason = new Error('cancel newer cycle');
		controller.abort(reason);
		await flush();
		assertOutcome(second, {status: 'rejected', reason});
		await clock.advance(10);
		assert.deepEqual(calls, ['first']);
		const afterAbort = observe(debounced('after-abort'));
		await flush();
		assertOutcome([afterAbort], {status: 'rejected', reason});
	});
});

test('abort still rejects callers of overlapping executions', async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const gates = [gate(), gate()];
		const debounced = pDebounce(async value => {
			await gates[value - 1].promise;
			return value;
		}, 10, {signal: controller.signal});
		const callers = [observe(debounced(1))];
		await clock.advance(10);
		callers.push(observe(debounced(2)));
		await clock.advance(10);
		const reason = new Error('cancel active cycles');
		controller.abort(reason);
		await flush();
		assertOutcome(callers, {status: 'rejected', reason});
		for (const pending of gates) {
			pending.release();
		}
		await flush();
		assertOutcome(callers, {status: 'rejected', reason});
	});
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {flush, gate, observe, withClock} from './test-clock.mjs';

test('an executing cycle cannot settle callers whose debounce timer is still pending', async () => {
	await withClock(async clock => {
		const firstGate = gate();
		const secondGate = gate();
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			await (value === 'first' ? firstGate : secondGate).promise;
			return value;
		}, 10);

		const first = observe(debounced('first'));
		await clock.advance(10);
		const second = observe(debounced('superseded'));
		await clock.advance(5);
		const latest = observe(debounced('second'));
		firstGate.release();
		await flush();

		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
		assert.deepEqual(second, {status: 'pending'});
		assert.deepEqual(latest, {status: 'pending'});
		await clock.advance(9);
		assert.deepEqual(calls, ['first']);
		await clock.advance(1);
		assert.deepEqual(calls, ['first', 'second']);
		secondGate.release();
		await flush();
		assert.deepEqual(second, {status: 'fulfilled', value: 'second'});
		assert.deepEqual(latest, {status: 'fulfilled', value: 'second'});
	});
});

for (const completionOrder of [[0, 1], [1, 0]]) {
	for (const failures of [[false, false], [true, false], [false, true], [true, true]]) {
		test(`overlapping cycles settle independently: order ${completionOrder}, failures ${failures}`, async () => {
			await withClock(async clock => {
				const gates = [gate(), gate()];
				const errors = [new Error('first cycle'), new Error('second cycle')];
				const contexts = [{cycle: 0}, {cycle: 1}];
				const calls = [];
				const debounced = pDebounce(async function (value) {
					const cycle = this.cycle;
					calls.push({context: this, value});
					await gates[cycle].promise;
					if (failures[cycle]) {
						throw errors[cycle];
					}

					return value;
				}, 10);
				const callers = [];
				for (const cycle of [0, 1]) {
					callers.push([
						observe(debounced.call(contexts[cycle], `discarded-${cycle}`)),
						observe(debounced.call(contexts[cycle], `latest-${cycle}`)),
					]);
					await clock.advance(10);
				}

				assert.deepEqual(calls, contexts.map((context, cycle) => ({context, value: `latest-${cycle}`})));
				const finished = new Set();
				for (const cycle of completionOrder) {
					gates[cycle].release();
					await flush();
					finished.add(cycle);
					for (const [index, states] of callers.entries()) {
						const expected = !finished.has(index) ? {status: 'pending'}
							: failures[index] ? {status: 'rejected', reason: errors[index]}
								: {status: 'fulfilled', value: `latest-${index}`};
						for (const state of states) {
							assert.deepEqual(state, expected);
						}
					}
				}
			});
		});
	}
}

test('a call reentered from the wrapped function belongs to the next cycle', async () => {
	await withClock(async clock => {
		let next;
		const calls = [];
		const debounced = pDebounce(value => {
			calls.push(value);
			if (value === 'first') {
				next = observe(debounced('next'));
			}

			return value;
		}, 10);
		const first = observe(debounced('first'));
		await clock.advance(10);
		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
		assert.deepEqual(next, {status: 'pending'});
		await clock.advance(10);
		assert.deepEqual(calls, ['first', 'next']);
		assert.deepEqual(next, {status: 'fulfilled', value: 'next'});
	});
});

test('independent wrappers retain separate waiting callers', async () => {
	await withClock(async clock => {
		const gates = [gate(), gate()];
		const calls = [];
		const wrapped = async value => {
			calls.push(value);
			await gates[value].promise;
			return value;
		};
		const first = observe(pDebounce(wrapped, 10)(0));
		const second = observe(pDebounce(wrapped, 10)(1));
		await clock.advance(10);
		assert.deepEqual(calls, [0, 1]);
		gates[1].release();
		await flush();
		assert.deepEqual(first, {status: 'pending'});
		assert.deepEqual(second, {status: 'fulfilled', value: 1});
		gates[0].release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: 0});
	});
});

for (const fails of [false, true]) {
	test(`overlapping leading cycles share only their own outcome: rejects ${fails}`, async () => {
		await withClock(async clock => {
			const gates = [gate(), gate()];
			const error = new Error('second leading cycle');
			const calls = [];
			const debounced = pDebounce(async value => {
				calls.push(value);
				await gates[value].promise;
				if (value === 1 && fails) {
					throw error;
				}

				return value;
			}, 10, {before: true});
			const first = [observe(debounced(0)), observe(debounced('ignored'))];
			await clock.advance(10);
			const second = [observe(debounced(1)), observe(debounced('also ignored'))];
			await clock.advance(10);
			assert.deepEqual(calls, [0, 1]);
			for (const state of [...first, ...second]) {
				assert.deepEqual(state, {status: 'pending'});
			}

			gates[1].release();
			await flush();
			for (const state of second) {
				assert.deepEqual(state, fails ? {status: 'rejected', reason: error} : {status: 'fulfilled', value: 1});
			}

			for (const state of first) {
				assert.deepEqual(state, {status: 'pending'});
			}

			gates[0].release();
			await flush();
			for (const state of first) {
				assert.deepEqual(state, {status: 'fulfilled', value: 0});
			}
		});
	});
}

test('finishing an older cycle leaves the pending cycle abortable', async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const firstGate = gate();
		const reason = new Error('cancel pending cycle');
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			await firstGate.promise;
			return value;
		}, 10, {signal: controller.signal});
		const first = observe(debounced('first'));
		await clock.advance(10);
		const second = observe(debounced('second'));
		firstGate.release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
		controller.abort(reason);
		await clock.advance(10);
		assert.deepEqual(second, {status: 'rejected', reason});
		assert.deepEqual(calls, ['first']);
		const afterAbort = observe(debounced('after abort'));
		await flush();
		assert.deepEqual(afterAbort, {status: 'rejected', reason});
	});
});

test('abort still rejects callers of every executing cycle', async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const runningGate = gate();
		const reason = new Error('cancel executing cycles');
		const debounced = pDebounce(async value => {
			await runningGate.promise;
			return value;
		}, 10, {signal: controller.signal});
		const first = observe(debounced('first'));
		await clock.advance(10);
		const second = observe(debounced('second'));
		await clock.advance(10);
		controller.abort(reason);
		await flush();
		assert.deepEqual(first, {status: 'rejected', reason});
		assert.deepEqual(second, {status: 'rejected', reason});
		runningGate.release();
		await flush();
		assert.deepEqual(first, {status: 'rejected', reason});
		assert.deepEqual(second, {status: 'rejected', reason});
	});
});

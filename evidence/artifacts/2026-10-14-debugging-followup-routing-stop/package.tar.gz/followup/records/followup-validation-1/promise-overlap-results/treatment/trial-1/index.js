const pDebounce = (function_, wait, options = {}) => {
	if (!Number.isFinite(wait)) {
		throw new TypeError('Expected `wait` to be a finite number');
	}

	let timeout;
	let pendingCycle;

	return function (...arguments_) {
		return new Promise((resolve, reject) => {
			// Check if already aborted
			try {
				options.signal?.throwIfAborted();
			} catch (error) {
				reject(error);
				return;
			}

			const shouldCallNow = options.before && !timeout;
			const cycle = pendingCycle ??= {resolveList: [], rejectList: []};

			clearTimeout(timeout);

			timeout = setTimeout(async () => {
				timeout = null;
				// Detach this cycle before invoking or awaiting user code.
				pendingCycle = undefined;

				try {
					const result = options.before ? await cycle.leadingValue : await function_.apply(this, arguments_);

					for (const resolveFunction of cycle.resolveList) {
						resolveFunction(result);
					}
				} catch (error) {
					for (const rejectFunction of cycle.rejectList) {
						rejectFunction(error);
					}
				} finally {
					// Only remove this cycle's listener; newer cycles may still be waiting.
					if (cycle.onAbort) {
						options.signal?.removeEventListener('abort', cycle.onAbort);
					}
				}
			}, wait);

			if (shouldCallNow) {
				// Execute immediately, retaining the outcome for this cycle's callers.
				cycle.leadingValue = new Promise(resolveLeading => {
					resolveLeading(function_.apply(this, arguments_));
				});
				resolve(cycle.leadingValue);
			} else {
				// Add to lists for later resolution
				cycle.resolveList.push(resolve);
				cycle.rejectList.push(reject);

				// Set up abort listener (only once per batch)
				if (options.signal && cycle.resolveList.length === 1) {
					cycle.onAbort = () => {
						if (pendingCycle === cycle) {
							clearTimeout(timeout);
							timeout = null;
							pendingCycle = undefined;
						}

						try {
							options.signal.throwIfAborted();
						} catch (error) {
							for (const rejectFunction of cycle.rejectList) {
								rejectFunction(error);
							}
						}
					};
					options.signal.addEventListener('abort', cycle.onAbort, {once: true});
				}
			}
		});
	};
};

pDebounce.promise = function_ => {
	let currentPromise;

	return async function (...arguments_) {
		if (currentPromise) {
			return currentPromise;
		}

		try {
			currentPromise = function_.apply(this, arguments_);
			return await currentPromise;
		} finally {
			currentPromise = undefined;
		}
	};
};

export default pDebounce;

const pDebounce = (function_, wait, options = {}) => {
	if (!Number.isFinite(wait)) {
		throw new TypeError('Expected `wait` to be a finite number');
	}

	let currentCycle;

	const cleanup = cycle => {
		cycle.resolveList = [];
		cycle.rejectList = [];
		if (cycle.onAbort) {
			options.signal?.removeEventListener('abort', cycle.onAbort);
		}
	};

	return function (...arguments_) {
		return new Promise((resolve, reject) => {
			// Check if already aborted
			try {
				options.signal?.throwIfAborted();
			} catch (error) {
				reject(error);
				return;
			}

			const shouldCallNow = options.before && !currentCycle;

			if (!currentCycle) {
				currentCycle = {resolveList: [], rejectList: []};
			}

			const cycle = currentCycle;
			clearTimeout(cycle.timeout);

			cycle.timeout = setTimeout(async () => {
				// New calls must start their own cycle while this one is executing.
				currentCycle = undefined;
				cycle.timeout = undefined;

				try {
					const result = options.before ? await cycle.leadingPromise : await function_.apply(this, arguments_);

					for (const resolveFunction of cycle.resolveList) {
						resolveFunction(result);
					}
				} catch (error) {
					for (const rejectFunction of cycle.rejectList) {
						rejectFunction(error);
					}
				} finally {
					cleanup(cycle);
				}
			}, wait);

			if (shouldCallNow) {
				// Execute immediately for leading edge
				try {
					cycle.leadingPromise = Promise.resolve(function_.apply(this, arguments_));
				} catch (error) {
					cycle.leadingPromise = Promise.reject(error);
				}

				// eslint-disable-next-line promise/prefer-await-to-then
				cycle.leadingPromise.then(resolve, reject);
			} else {
				// Add to lists for later resolution
				cycle.resolveList.push(resolve);
				cycle.rejectList.push(reject);

				// Set up abort listener (only once per batch)
				if (options.signal && cycle.resolveList.length === 1) {
					cycle.onAbort = () => {
						clearTimeout(cycle.timeout);
						if (currentCycle === cycle) {
							currentCycle = undefined;
						}

						try {
							options.signal?.throwIfAborted();
						} catch (error) {
							for (const rejectFunction of cycle.rejectList) {
								rejectFunction(error);
							}

							cleanup(cycle);
						}
					};
					options.signal.addEventListener('abort', cycle.onAbort, {once: true});
				}
			}
		});
	};
};

pDebounce.promise = function_ => {
	let currentPromise;

	return async function (...arguments_) {
		if (currentPromise) {
			return currentPromise;
		}

		try {
			currentPromise = function_.apply(this, arguments_);
			return await currentPromise;
		} finally {
			currentPromise = undefined;
		}
	};
};

export default pDebounce;

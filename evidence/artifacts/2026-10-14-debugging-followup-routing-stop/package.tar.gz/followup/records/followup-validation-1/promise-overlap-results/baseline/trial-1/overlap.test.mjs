#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {withClock, observe, flush, gate} from './test-clock.mjs';

test('a running trailing cycle does not settle a later cycle', async () => {
	await withClock(async clock => {
		const firstGate = gate();
		const secondGate = gate();
		const started = [];
		const debounced = pDebounce(async value => {
			started.push(value);
			await (value === 'first' ? firstGate : secondGate).promise;
			return value;
		}, 10);

		const first = observe(debounced('first'));
		await clock.advance(10);
		const second = observe(debounced('second'));
		firstGate.release();
		await flush();

		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
		assert.deepEqual(second, {status: 'pending'}, 'the later cycle must wait for its own result');
		await clock.advance(10);
		assert.deepEqual(started, ['first', 'second']);
		secondGate.release();
		await flush();
		assert.deepEqual(second, {status: 'fulfilled', value: 'second'});
	});
});

for (const firstFails of [false, true]) {
	for (const secondFails of [false, true]) {
		for (const finishOrder of [['first', 'second'], ['second', 'first']]) {
			test(`trailing cycles isolate outcomes (${firstFails ? 'reject' : 'resolve'}, ${secondFails ? 'reject' : 'resolve'}; ${finishOrder.join(' then ')})`, async () => {
				await withClock(async clock => {
					const gates = {first: gate(), second: gate()};
					const errors = {
						first: firstFails ? new Error('first failed') : undefined,
						second: secondFails ? new Error('second failed') : undefined,
					};
					const started = [];
					const debounced = pDebounce(async function (value, suffix) {
						started.push([this.label, value, suffix]);
						await gates[value].promise;
						if (errors[value]) {
							throw errors[value];
						}

						return `${this.label}:${value}:${suffix}`;
					}, 10);
					const callers = {};
					for (const value of ['first', 'second']) {
						callers[value] = [observe(debounced.call({label: 'unused'}, 'unused', 'unused'))];
						await clock.advance(4);
						callers[value].push(observe(debounced.call({label: value}, value, 'latest')));
						await clock.advance(9);
						assert.equal(started.length, value === 'first' ? 0 : 1, 'the last call restarts the wait');
						await clock.advance(1);
					}

					assert.deepEqual(started, [['first', 'first', 'latest'], ['second', 'second', 'latest']]);
					for (const value of finishOrder) {
						gates[value].release();
						await flush();
						const expected = errors[value]
							? {status: 'rejected', reason: errors[value]}
							: {status: 'fulfilled', value: `${value}:${value}:latest`};
						for (const caller of callers[value]) {
							assert.deepEqual(caller, expected);
						}

						if (value === finishOrder[0]) {
							for (const caller of callers[finishOrder[1]]) {
								assert.deepEqual(caller, {status: 'pending'}, 'another running cycle must remain pending');
							}
						}
					}
				});
			});
		}
	}
}

for (const fails of [false, true]) {
	test(`overlapping leading cycles retain their own async ${fails ? 'errors' : 'results'}`, async () => {
		await withClock(async clock => {
			const gates = {first: gate(), second: gate()};
			const errors = {first: new Error('first failed'), second: new Error('second failed')};
			const started = [];
			const debounced = pDebounce(async value => {
				started.push(value);
				await gates[value].promise;
				if (fails) {
					throw errors[value];
				}

				return value;
			}, 10, {before: true});
			const callers = {};
			for (const value of ['first', 'second']) {
				callers[value] = [observe(debounced(value)), observe(debounced('coalesced'))];
				await clock.advance(10);
				for (const caller of callers[value]) {
					assert.deepEqual(caller, {status: 'pending'}, 'leading callers must wait for the async outcome');
				}
			}

			assert.deepEqual(started, ['first', 'second']);
			for (const value of ['second', 'first']) {
				gates[value].release();
				await flush();
				for (const caller of callers[value]) {
					assert.deepEqual(caller, fails
						? {status: 'rejected', reason: errors[value]}
						: {status: 'fulfilled', value});
				}

				if (value === 'second') {
					for (const caller of callers.first) {
						assert.deepEqual(caller, {status: 'pending'});
					}
				}
			}
		});
	});
}

test('separate wrappers keep independent cycles', async () => {
	await withClock(async clock => {
		const gates = {left: gate(), right: gate()};
		const fn = async value => {
			await gates[value].promise;
			return value;
		};
		const left = pDebounce(fn, 10);
		const right = pDebounce(fn, 10);
		const leftState = observe(left('left'));
		const rightState = observe(right('right'));
		await clock.advance(10);
		gates.right.release();
		await flush();
		assert.deepEqual(rightState, {status: 'fulfilled', value: 'right'});
		assert.deepEqual(leftState, {status: 'pending'});
		gates.left.release();
		await flush();
		assert.deepEqual(leftState, {status: 'fulfilled', value: 'left'});
	});
});

for (const running of [false, true]) {
	test(`finishing an older cycle preserves abort handling for a ${running ? 'running' : 'waiting'} cycle`, async () => {
		await withClock(async clock => {
			const controller = new AbortController();
			const gates = {first: gate(), second: gate()};
			const started = [];
			const debounced = pDebounce(async value => {
				started.push(value);
				await gates[value].promise;
				return value;
			}, 10, {signal: controller.signal});
			const first = observe(debounced('first'));
			await clock.advance(10);
			const second = observe(debounced('second'));
			if (running) {
				await clock.advance(10);
			}

			gates.first.release();
			await flush();
			assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
			assert.deepEqual(second, {status: 'pending'});
			const reason = new Error('cancelled');
			controller.abort(reason);
			await flush();
			assert.deepEqual(second, {status: 'rejected', reason});
			gates.second.release();
			await clock.advance(10);
			assert.deepEqual(started, running ? ['first', 'second'] : ['first']);
			assert.deepEqual(second, {status: 'rejected', reason});
			const afterAbort = observe(debounced('unused'));
			await flush();
			assert.deepEqual(afterAbort, {status: 'rejected', reason});
		});
	});
}

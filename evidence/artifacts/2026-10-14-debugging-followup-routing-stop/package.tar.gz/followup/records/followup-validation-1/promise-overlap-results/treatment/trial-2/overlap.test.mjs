#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {flush, gate, observe, withClock} from './test-clock.mjs';

test('a completed execution cannot settle callers still waiting for the next cycle', {timeout: 1000}, async () => {
	await withClock(async clock => {
		const firstGate = gate();
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			if (value === 'first') {
				await firstGate.promise;
			}

			return value;
		}, 10);

		const first = observe(debounced('first'));
		await clock.advance(10);
		const next = observe(debounced('superseded'));
		await clock.advance(4);
		const latest = observe(debounced('latest'));
		firstGate.release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
		assert.deepEqual(next, {status: 'pending'});
		assert.deepEqual(latest, {status: 'pending'});
		await clock.advance(9);
		assert.deepEqual(calls, ['first']);
		await clock.advance(1);
		assert.deepEqual(calls, ['first', 'latest']);
		assert.deepEqual(next, {status: 'fulfilled', value: 'latest'});
		assert.deepEqual(latest, {status: 'fulfilled', value: 'latest'});
	});
});

for (const order of [[0, 1], [1, 0]]) {
	for (const outcomes of [['fulfilled', 'fulfilled'], ['rejected', 'fulfilled'], ['fulfilled', 'rejected'], ['rejected', 'rejected']]) {
		test(`overlapping cycles keep their ${outcomes.join('/')} outcomes when cycle ${order[0] + 1} finishes first`, {timeout: 1000}, async () => {
			await withClock(async clock => {
				const gates = [gate(), gate()];
				const errors = [new Error('first failure'), new Error('second failure')];
				const calls = [];
				const debounced = pDebounce(async function (cycle, value) {
					calls.push({cycle, value, context: this});
					await gates[cycle].promise;
					if (outcomes[cycle] === 'rejected') {
						throw errors[cycle];
					}

					return value;
				}, 10);
				const contexts = [{cycle: 0}, {cycle: 1}];
				const callers = [];
				for (let cycle = 0; cycle < 2; cycle++) {
					callers.push([
						observe(debounced.call({}, cycle, 'superseded')),
						observe(debounced.call(contexts[cycle], cycle, `value ${cycle}`)),
					]);
					await clock.advance(10);
				}

				assert.deepEqual(calls, contexts.map((context, cycle) => ({cycle, value: `value ${cycle}`, context})));
				for (const cycle of order) {
					gates[cycle].release();
					await flush();
					for (const caller of callers[cycle]) {
						assert.equal(caller.status, outcomes[cycle]);
						if (outcomes[cycle] === 'rejected') {
							assert.equal(caller.reason, errors[cycle]);
						} else {
							assert.equal(caller.value, `value ${cycle}`);
						}
					}

					if (cycle === order[0]) {
						for (const caller of callers[order[1]]) {
							assert.deepEqual(caller, {status: 'pending'});
						}
					}
				}
			});
		});
	}
}

test('wrappers around the same async function have independent cycles', {timeout: 1000}, async () => {
	await withClock(async clock => {
		const gates = [gate(), gate()];
		const calls = [];
		const function_ = async value => {
			calls.push(value);
			await gates[value].promise;
			return value;
		};
		const firstWrapper = pDebounce(function_, 10);
		const secondWrapper = pDebounce(function_, 10);
		const first = observe(firstWrapper(0));
		const second = observe(secondWrapper(1));
		await clock.advance(10);
		assert.deepEqual(calls, [0, 1]);
		gates[1].release();
		await flush();
		assert.deepEqual(first, {status: 'pending'});
		assert.deepEqual(second, {status: 'fulfilled', value: 1});
		gates[0].release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: 0});
	});
});

for (const rejected of [false, true]) {
	test(`leading cycles retain their own async ${rejected ? 'errors' : 'values'}`, {timeout: 1000}, async () => {
		await withClock(async clock => {
			const gates = [gate(), gate()];
			const errors = [new Error('first leading failure'), new Error('second leading failure')];
			const calls = [];
			const debounced = pDebounce(async value => {
				calls.push(value);
				await gates[value].promise;
				if (rejected) {
					throw errors[value];
				}

				return value;
			}, 10, {before: true});
			const callers = [];
			for (let cycle = 0; cycle < 2; cycle++) {
				callers.push([observe(debounced(cycle)), observe(debounced('coalesced'))]);
				await clock.advance(10);
				assert.deepEqual(callers[cycle], [{status: 'pending'}, {status: 'pending'}]);
			}

			assert.deepEqual(calls, [0, 1]);
			for (const cycle of [1, 0]) {
				gates[cycle].release();
				await flush();
				for (const caller of callers[cycle]) {
					if (rejected) {
						assert.equal(caller.status, 'rejected');
						assert.equal(caller.reason, errors[cycle]);
					} else {
						assert.deepEqual(caller, {status: 'fulfilled', value: cycle});
					}
				}

				if (cycle === 1) {
					assert.deepEqual(callers[0], [{status: 'pending'}, {status: 'pending'}]);
				}
			}
		});
	});
}

test('finishing an older cycle keeps the newer cycle cancellable', {timeout: 1000}, async () => {
	await withClock(async clock => {
		const controller = new AbortController();
		const firstGate = gate();
		const calls = [];
		const debounced = pDebounce(async value => {
			calls.push(value);
			await firstGate.promise;
			return value;
		}, 10, {signal: controller.signal});
		const first = observe(debounced('first'));
		await clock.advance(10);
		const next = observe(debounced('next'));
		firstGate.release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
		const reason = new Error('cancel next cycle');
		controller.abort(reason);
		await flush();
		assert.equal(next.status, 'rejected');
		assert.equal(next.reason, reason);
		await clock.advance(10);
		assert.deepEqual(calls, ['first']);
		const afterAbort = observe(debounced('already aborted'));
		await flush();
		assert.equal(afterAbort.status, 'rejected');
		assert.equal(afterAbort.reason, reason);
	});
});

test('a synchronous error in the next cycle cannot reject an earlier execution', {timeout: 1000}, async () => {
	await withClock(async clock => {
		const firstGate = gate();
		const error = new Error('synchronous failure');
		const debounced = pDebounce(value => {
			if (value === 'first') {
				return firstGate.promise.then(() => value);
			}

			throw error;
		}, 10);
		const first = observe(debounced('first'));
		await clock.advance(10);
		const next = observe(debounced('next'));
		await clock.advance(10);
		assert.equal(next.status, 'rejected');
		assert.equal(next.reason, error);
		assert.deepEqual(first, {status: 'pending'});
		firstGate.release();
		await flush();
		assert.deepEqual(first, {status: 'fulfilled', value: 'first'});
	});
});

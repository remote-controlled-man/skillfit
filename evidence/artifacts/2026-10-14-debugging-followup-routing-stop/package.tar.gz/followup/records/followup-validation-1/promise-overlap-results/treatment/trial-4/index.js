const pDebounce = (function_, wait, options = {}) => {
	if (!Number.isFinite(wait)) {
		throw new TypeError('Expected `wait` to be a finite number');
	}

	let currentBatch;

	const cleanup = batch => {
		batch.resolveList = [];
		batch.rejectList = [];
		options.signal?.removeEventListener('abort', batch.onAbort);
	};

	return function (...arguments_) {
		return new Promise((resolve, reject) => {
			// Check if already aborted
			try {
				options.signal?.throwIfAborted();
			} catch (error) {
				reject(error);
				return;
			}

			const shouldCallNow = options.before && !currentBatch;
			const batch = currentBatch ?? {resolveList: [], rejectList: []};

			if (!currentBatch) {
				currentBatch = batch;
				batch.onAbort = () => {
					clearTimeout(batch.timeout);
					if (currentBatch === batch) {
						currentBatch = undefined;
					}

					try {
						options.signal?.throwIfAborted();
					} catch (error) {
						for (const rejectFunction of batch.rejectList) {
							rejectFunction(error);
						}

						cleanup(batch);
					}
				};
				options.signal?.addEventListener('abort', batch.onAbort, {once: true});
			}

			batch.resolveList.push(resolve);
			batch.rejectList.push(reject);
			clearTimeout(batch.timeout);

			batch.timeout = setTimeout(async () => {
				// New calls belong to a new batch, even while this one is executing.
				if (currentBatch === batch) {
					currentBatch = undefined;
				}

				try {
					const result = options.before ? await batch.leadingPromise : await function_.apply(this, arguments_);

					for (const resolveFunction of batch.resolveList) {
						resolveFunction(result);
					}
				} catch (error) {
					for (const rejectFunction of batch.rejectList) {
						rejectFunction(error);
					}
				}

				cleanup(batch);
			}, wait);

			if (shouldCallNow) {
				// Execute immediately for leading edge
				try {
					batch.leadingPromise = Promise.resolve(function_.apply(this, arguments_));
				} catch (error) {
					batch.leadingPromise = Promise.reject(error);
				}

				// eslint-disable-next-line promise/prefer-await-to-then
				batch.leadingPromise.then(resolve, reject);
			}
		});
	};
};

pDebounce.promise = function_ => {
	let currentPromise;

	return async function (...arguments_) {
		if (currentPromise) {
			return currentPromise;
		}

		try {
			currentPromise = function_.apply(this, arguments_);
			return await currentPromise;
		} finally {
			currentPromise = undefined;
		}
	};
};

export default pDebounce;

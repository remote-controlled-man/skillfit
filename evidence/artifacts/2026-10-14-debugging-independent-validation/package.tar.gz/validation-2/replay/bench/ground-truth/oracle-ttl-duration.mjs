import {copyFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
for(const file of ['index.js','regression.test.mjs']) copyFileSync(fileURLToPath(new URL('./ttl-duration/'+file,import.meta.url)),join(process.argv[2],file));

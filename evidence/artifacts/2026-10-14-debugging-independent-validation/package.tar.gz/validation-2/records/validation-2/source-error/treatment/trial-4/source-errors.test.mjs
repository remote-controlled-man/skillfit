#!/usr/bin/env node
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import test from 'node:test';
import pMap, {pMapSkip} from './index.js';

function createSource(asynchronous, next) {
	return asynchronous ? {
		[Symbol.asyncIterator]() {
			return this;
		},
		async next() {
			return next();
		},
	} : {
		[Symbol.iterator]() {
			return this;
		},
		next,
	};
}

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

for (const asynchronous of [false, true]) {
	const sourceType = asynchronous ? 'async' : 'sync';

	for (const precedingOutcome of ['resolved', 'input rejected', 'mapper rejected']) {
		test(`${sourceType} source failure after ${precedingOutcome} rejects directly and stops pulling`, {timeout: 2000}, async () => {
			const sourceError = new Error('Source failed');
			const laterError = new Error('Source was pulled again');
			const itemError = new Error('Input or mapper failed');
			let pulls = 0;
			const mappedIndexes = [];
			const source = createSource(asynchronous, () => {
				pulls++;
				if (pulls === 1) {
					return {done: false, value: precedingOutcome === 'input rejected' ? Promise.reject(itemError) : 1};
				}

				throw pulls === 2 ? sourceError : laterError;
			});

			const reason = await pMap(source, (value, index) => {
				mappedIndexes.push(index);
				if (precedingOutcome === 'mapper rejected') {
					throw itemError;
				}

				return Promise.resolve(value * 2);
			}, {concurrency: 1, stopOnError: false}).catch(error => error);

			await setImmediate();
			assert.equal(reason, sourceError);
			assert.equal(pulls, 2);
			assert.deepEqual(mappedIndexes, precedingOutcome === 'input rejected' ? [] : [0]);
		});
	}

	test(`${sourceType} iterator-result failure rejects directly after a mapper resolves`, {timeout: 2000}, async () => {
		const sourceError = new Error('Reading done failed');
		let pulls = 0;
		const source = createSource(asynchronous, () => {
			pulls++;
			return pulls === 1 ? {done: false, value: 1} : {
				get done() {
					throw sourceError;
				},
			};
		});
		const reason = await pMap(source, value => Promise.resolve(value), {
			concurrency: 1,
			stopOnError: false,
		}).catch(error => error);

		assert.equal(reason, sourceError);
		assert.equal(pulls, 2);
	});

	test(`${sourceType} initial source failure rejects directly`, {timeout: 2000}, async () => {
		const sourceError = new Error('Initial source failure');
		let pulls = 0;
		const source = createSource(asynchronous, () => {
			pulls++;
			throw sourceError;
		});
		const reason = await pMap(source, () => assert.fail('Mapper must not run'), {
			concurrency: 2,
			stopOnError: false,
		}).catch(error => error);

		assert.equal(reason, sourceError);
		assert.equal(pulls, 1);
	});

	test(`${sourceType} source failure does not wait for an active mapper`, {timeout: 2000}, async () => {
		const activeMapper = deferred();
		const sourceError = new Error('Source failed while a mapper was active');
		const laterError = new Error('Source was pulled again');
		let pulls = 0;
		const mappedIndexes = [];
		const source = createSource(asynchronous, () => {
			pulls++;
			if (pulls <= 2) {
				return {done: false, value: pulls - 1};
			}

			throw pulls === 3 ? sourceError : laterError;
		});

		try {
			const reason = await pMap(source, (value, index) => {
				mappedIndexes.push(index);
				return value === 0 ? activeMapper.promise : Promise.resolve(value);
			}, {concurrency: 2, stopOnError: false}).catch(error => error);

			await setImmediate();
			assert.equal(reason, sourceError);
			assert.equal(pulls, 3);
			assert.deepEqual(mappedIndexes, [0, 1]);
		} finally {
			activeMapper.resolve(0);
		}
	});
}

test('a source result already in flight is ignored after a source failure', {timeout: 2000}, async () => {
	const pendingRead = deferred();
	const sourceError = new Error('Source failed with another read in flight');
	let pulls = 0;
	let valueReads = 0;
	const mappedValues = [];
	const source = createSource(true, () => {
		pulls++;
		if (pulls === 1) {
			return {done: false, value: 1};
		}

		if (pulls === 2) {
			return pendingRead.promise;
		}

		throw sourceError;
	});

	try {
		const reason = await pMap(source, value => {
			mappedValues.push(value);
			return Promise.resolve(value);
		}, {concurrency: 2, stopOnError: false}).catch(error => error);

		assert.equal(reason, sourceError);
	} finally {
		pendingRead.resolve({
			done: false,
			get value() {
				valueReads++;
				return 2;
			},
		});
	}

	await setImmediate();
	assert.equal(pulls, 3);
	assert.equal(valueReads, 0);
	assert.deepEqual(mappedValues, [1]);
});

test('input and mapper errors aggregate after all work settles', {timeout: 2000}, async () => {
	const inputError = new Error('Input rejected');
	const syncMapperError = new Error('Mapper threw');
	const asyncMapperError = new Error('Mapper rejected');
	const activeMapper = deferred();
	const mappedIndexes = [];
	let settled = false;
	const outcome = pMap([Promise.reject(inputError), 1, 2, 3, 4], (value, index) => {
		mappedIndexes.push(index);
		if (value === 1) {
			throw syncMapperError;
		}

		if (value === 2) {
			return Promise.reject(asyncMapperError);
		}

		return value === 3 ? activeMapper.promise : pMapSkip;
	}, {concurrency: 2, stopOnError: false}).then(value => {
		settled = true;
		return value;
	}, error => {
		settled = true;
		return error;
	});

	try {
		await setImmediate();
		assert.equal(settled, false);
		assert.deepEqual(mappedIndexes, [1, 2, 3, 4]);
	} finally {
		activeMapper.resolve(3);
	}

	const reason = await outcome;
	assert.ok(reason instanceof AggregateError);
	assert.deepEqual(reason.errors, [inputError, syncMapperError, asyncMapperError]);
});

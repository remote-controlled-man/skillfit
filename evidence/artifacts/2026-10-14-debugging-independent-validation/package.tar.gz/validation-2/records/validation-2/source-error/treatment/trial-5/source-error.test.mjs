#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import pMap from './index.js';

function source(kind, next) {
	const iterator = {next: kind === 'sync' ? next : async () => next()};
	const symbol = kind === 'sync' ? Symbol.iterator : Symbol.asyncIterator;
	return {[symbol]: () => iterator};
}

function observe(promise) {
	return promise.then(value => ({value}), error => ({error}));
}

function deferred() {
	let resolve;
	let reject;
	const promise = new Promise((resolve_, reject_) => {
		resolve = resolve_;
		reject = reject_;
	});
	return {promise, resolve, reject};
}

async function settleThisTurn(promise) {
	return Promise.race([
		observe(promise),
		setImmediate().then(() => ({pending: true})),
	]);
}

function assertSourceError(outcome, error) {
	assert.ok(Object.hasOwn(outcome, 'error'), 'pMap must reject without waiting for more input or mappers');
	assert.equal(outcome.error, error);
}

for (const kind of ['sync', 'async']) {
	for (const recovers of [false, true]) {
		test(`${kind} source failure after mapper success stops at the original error (recovers: ${recovers})`, async () => {
			const sourceError = new Error('source failed');
			const laterError = new Error('source was read again');
			let pulls = 0;
			const mapped = [];
			const iterable = source(kind, () => {
				pulls++;
				if (pulls === 1) {
					return {done: false, value: 1};
				}

				if (pulls === 2) {
					throw sourceError;
				}

				if (!recovers) {
					throw laterError;
				}

				return pulls === 3 ? {done: false, value: 2} : {done: true};
			});
			const outcome = await settleThisTurn(pMap(iterable, async value => {
				mapped.push(value);
				return value * 2;
			}, {concurrency: 1, stopOnError: false}));

			assertSourceError(outcome, sourceError);
			assert.equal(pulls, 2);
			assert.deepEqual(mapped, [1]);
		});
	}

	for (const failure of ['input', 'mapper']) {
		test(`${kind} source failure after ${failure} rejection overrides aggregation`, async () => {
			const itemError = new Error(`${failure} failed`);
			const sourceError = new Error('source failed');
			let pulls = 0;
			const mapped = [];
			const iterable = source(kind, () => {
				pulls++;
				if (pulls === 1) {
					return {done: false, value: failure === 'input' ? Promise.reject(itemError) : 1};
				}

				if (pulls === 2) {
					throw sourceError;
				}

				return {done: true};
			});
			const outcome = await settleThisTurn(pMap(iterable, async value => {
				mapped.push(value);
				throw itemError;
			}, {concurrency: 1, stopOnError: false}));

			assertSourceError(outcome, sourceError);
			assert.equal(pulls, 2);
			assert.deepEqual(mapped, failure === 'input' ? [] : [1]);
		});
	}

	for (const concurrency of [1, 2, Number.POSITIVE_INFINITY]) {
		test(`${kind} input and mapper errors still aggregate (concurrency: ${concurrency})`, async () => {
			const inputError = new Error('input rejected');
			const mapperError = new Error('mapper threw');
			const mapperRejection = new Error('mapper rejected');
			let pulls = 0;
			const mapped = [];
			const iterable = source(kind, () => {
				const index = pulls++;
				if (index >= 4) {
					return {done: true};
				}

				return {done: false, value: index === 0 ? Promise.reject(inputError) : index};
			});

			await assert.rejects(pMap(iterable, (value, index) => {
				mapped.push([value, index]);
				if (value === 1) {
					throw mapperError;
				}

				if (value === 2) {
					return Promise.reject(mapperRejection);
				}

				return value * 2;
			}, {concurrency, stopOnError: false}), error => {
				assert.ok(error instanceof AggregateError);
				assert.equal(error.errors.length, 3);
				assert.deepEqual(new Set(error.errors), new Set([inputError, mapperError, mapperRejection]));
				return true;
			});

			assert.ok(pulls >= 5, 'the source must be exhausted despite input and mapper failures');
			assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3]]);
		});
	}

	test(`${kind} source failure rejects while another mapper is pending and stops later pulls`, async () => {
		const sourceError = new Error('source failed');
		const pendingMapperError = new Error('pending mapper failed');
		const pendingMapper = deferred();
		const secondMapperStarted = deferred();
		let pulls = 0;
		const mapped = [];
		const iterable = source(kind, () => {
			pulls++;
			if (pulls <= 2) {
				return {done: false, value: pulls};
			}

			if (pulls === 3) {
				throw sourceError;
			}

			return {done: true};
		});
		const mapping = pMap(iterable, async value => {
			mapped.push(value);
			if (value === 1) {
				await secondMapperStarted.promise;
				return value;
			}

			secondMapperStarted.resolve();
			return pendingMapper.promise;
		}, {concurrency: 2, stopOnError: false});

		try {
			const outcome = await settleThisTurn(mapping);
			assertSourceError(outcome, sourceError);
			assert.equal(pulls, 3);
			assert.deepEqual(mapped, [1, 2]);
		} finally {
			pendingMapper.reject(pendingMapperError);
			await setImmediate();
		}

		assert.equal(pulls, 3, 'settling an in-flight mapper must not resume the failed source');
	});
}

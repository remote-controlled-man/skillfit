我会使用 diagnosing-bugs 技能，先检查错误传播和两条执行路径，再修改 `index.js`，添加通过公共 API 验证的 Node 回归测试。全程只在当前目录工作，不访问网络。

已定位根因：mapper 成功后，补取输入的 `await next()` 仍在 mapper 的 `try/catch` 内。迭代器抛错会被当成 mapper 错误聚合，活动计数也会再次递减，随后还会继续取输入，导致错误被替换或 Promise 无法结束。我会让源码迭代错误在取输入处直接拒绝，并验证 mapper 成功后和输入／mapper 失败后的两条续取路径。

修复后，成功映射和输入／mapper 失败都会进入同一个续取分支：活动计数只递减一次，迭代器错误直接拒绝，输入与 mapper 错误仍按原规则聚合。修改前回归测试有 5 项失败；修改后 `npm test` 的 14 项全部通过，包括并发 mapper 尚未结束时立即拒绝、后续不再取输入的检查。

已修复 [index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/source-error/treatment/trial-3/index.js:128) 中成功与失败后的两条续取路径。

根因是 mapper 成功后的 `next()` 位于 mapper 错误捕获范围内，导致源错误被聚合、活动计数重复递减，并继续取输入。现在源迭代错误立即以原错误拒绝；输入与 mapper 错误仍正常聚合。

新增可执行的 `source-errors.test.mjs`，通过公共 API 覆盖同步／异步源、停止取值、并发未完成 mapper 和错误聚合。

实际验证：修改前回归测试 5 项失败；修改后 `npm test` 全部 14 项通过，`git diff --check` 通过。已有测试、元数据和文档均未修改，未访问网络。
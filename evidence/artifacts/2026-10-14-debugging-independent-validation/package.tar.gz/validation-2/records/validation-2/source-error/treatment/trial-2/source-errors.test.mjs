#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import pMap from './index.js';

const options = {concurrency: 1, stopOnError: false};

function sourceWithNext(kind, next) {
	if (kind === 'sync') {
		return {[Symbol.iterator]: () => ({next})};
	}

	return {[Symbol.asyncIterator]: () => ({next: async () => next()})};
}

for (const kind of ['sync', 'async']) {
	for (const outcome of ['success', 'input rejection', 'mapper rejection']) {
		test(`${kind} source failure after ${outcome} rejects with the source error and stops pulling`, {timeout: 2000}, async () => {
			const sourceError = new Error('Source failed');
			const itemError = new Error('Item failed');
			const extraPullError = new Error('Source was pulled after failure');
			let pulls = 0;
			const mapped = [];
			const source = sourceWithNext(kind, () => {
				pulls++;
				if (pulls === 1) {
					return {
						done: false,
						value: outcome === 'input rejection' ? Promise.reject(itemError) : 1,
					};
				}

				throw pulls === 2 ? sourceError : extraPullError;
			});

			await assert.rejects(pMap(source, value => {
				mapped.push(value);
				if (outcome === 'mapper rejection') {
					return Promise.reject(itemError);
				}

				return Promise.resolve(value);
			}, options), error => {
				assert.strictEqual(error, sourceError);
				return true;
			});

			await setImmediate();
			assert.equal(pulls, 2);
			assert.deepEqual(mapped, outcome === 'input rejection' ? [] : [1]);
		});
	}

	test(`${kind} source failure on the first pull rejects directly without mapping`, {timeout: 2000}, async () => {
		const sourceError = new Error('Source failed at startup');
		let pulls = 0;
		let mapperCalls = 0;
		const source = sourceWithNext(kind, () => {
			pulls++;
			throw sourceError;
		});

		await assert.rejects(pMap(source, () => {
			mapperCalls++;
		}, {...options, concurrency: 3}), error => {
			assert.strictEqual(error, sourceError);
			return true;
		});

		await setImmediate();
		assert.equal(pulls, 1);
		assert.equal(mapperCalls, 0);
	});

	test(`${kind} source failure rejects before an active mapper settles and prevents later pulls`, {timeout: 2000}, async t => {
		const sourceError = new Error('Source failed with a mapper pending');
		let releaseMapper;
		const pendingMapper = new Promise(resolve => {
			releaseMapper = resolve;
		});
		t.after(() => releaseMapper(0));
		let pulls = 0;
		const mapped = [];
		const source = sourceWithNext(kind, () => {
			pulls++;
			if (pulls <= 2) {
				return {done: false, value: pulls - 1};
			}

			throw pulls === 3 ? sourceError : new Error('Unexpected extra pull');
		});

		await assert.rejects(pMap(source, value => {
			mapped.push(value);
			return value === 0 ? pendingMapper : Promise.resolve(value);
		}, {...options, concurrency: 2}), error => {
			assert.strictEqual(error, sourceError);
			return true;
		});

		assert.equal(pulls, 3);
		releaseMapper(0);
		await setImmediate();
		assert.equal(pulls, 3);
		assert.deepEqual(mapped, [0, 1]);
	});

	test(`${kind} source still aggregates input and mapper rejections and processes later values`, {timeout: 2000}, async () => {
		const inputError = new Error('Input rejected');
		const mapperError = new Error('Mapper rejected');
		const values = [Promise.reject(inputError), 1, 2, 3];
		const iterator = values[Symbol.iterator]();
		const source = sourceWithNext(kind, () => iterator.next());
		const mapped = [];

		await assert.rejects(pMap(source, (value, index) => {
			mapped.push([value, index]);
			if (value === 1) {
				throw mapperError;
			}

			return value * 2;
		}, options), error => {
			assert.ok(error instanceof AggregateError);
			assert.deepEqual(error.errors, [inputError, mapperError]);
			return true;
		});

		assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3]]);
	});
}

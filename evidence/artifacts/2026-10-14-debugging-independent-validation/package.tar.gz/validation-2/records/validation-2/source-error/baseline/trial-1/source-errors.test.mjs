#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pMap, {pMapSkip} from './index.js';

const nextTurn = () => new Promise(resolve => setImmediate(resolve));

function createSource(asynchronous, next) {
	return asynchronous
		? {[Symbol.asyncIterator]: () => ({next: async () => next()})}
		: {[Symbol.iterator]: () => ({next})};
}

async function immediateRejection(mapping) {
	const outcome = await Promise.race([
		mapping.then(
			value => ({status: 'fulfilled', value}),
			reason => ({status: 'rejected', reason}),
		),
		nextTurn().then(() => ({status: 'pending'})),
	]);
	assert.equal(outcome.status, 'rejected', 'source failure must reject without waiting for other work');
	return outcome.reason;
}

for (const asynchronous of [false, true]) {
	const kind = asynchronous ? 'async' : 'sync';

	test(`${kind} source fails during startup`, async () => {
		const sourceError = new Error('source failed');
		let pulls = 0;
		let mapperCalls = 0;
		const source = createSource(asynchronous, () => {
			pulls++;
			throw sourceError;
		});

		const reason = await immediateRejection(pMap(source, () => mapperCalls++, {
			concurrency: 2,
			stopOnError: false,
		}));
		assert.strictEqual(reason, sourceError);
		await nextTurn();
		assert.equal(pulls, 1);
		assert.equal(mapperCalls, 0);
	});

	for (const afterFailure of ['throws', 'finishes']) {
		test(`${kind} source fails after a mapper resolves; later iteration ${afterFailure}`, async () => {
			const sourceError = new Error('source failed');
			const laterSourceError = new Error('source should not be read again');
			const mapped = [];
			let pulls = 0;
			const source = createSource(asynchronous, () => {
				pulls++;
				if (pulls === 1) {
					return {value: 1, done: false};
				}

				if (pulls === 2) {
					assert.deepEqual(mapped, [1]);
					throw sourceError;
				}

				if (afterFailure === 'throws') {
					throw laterSourceError;
				}

				return {done: true};
			});
			const reason = await immediateRejection(pMap(source, value => {
				mapped.push(value);
				return value;
			}, {concurrency: 1, stopOnError: false}));

			assert.strictEqual(reason, sourceError, `source error must be preserved (pulled ${pulls} times)`);
			await nextTurn();
			assert.equal(pulls, 2, 'source must not be consumed after its error');
			assert.deepEqual(mapped, [1]);
		});
	}

	for (const failure of ['input', 'mapper']) {
		test(`${kind} source fails after ${failure} rejection`, async () => {
			const sourceError = new Error('source failed');
			const itemError = new Error(`${failure} failed`);
			let pulls = 0;
			let mapperCalls = 0;
			const source = createSource(asynchronous, () => {
				pulls++;
				if (pulls === 1) {
					return {value: failure === 'input' ? Promise.reject(itemError) : 1, done: false};
				}

				throw sourceError;
			});

			const reason = await immediateRejection(pMap(source, async () => {
				mapperCalls++;
				throw itemError;
			}, {concurrency: 1, stopOnError: false}));
			assert.strictEqual(reason, sourceError);
			await nextTurn();
			assert.equal(pulls, 2);
			assert.equal(mapperCalls, failure === 'input' ? 0 : 1);
		});
	}

	test(`${kind} source failure rejects while another mapper is pending`, async () => {
		const sourceError = new Error('source failed');
		const laterError = new Error('source should not be read again');
		let finishMapper;
		const pendingMapper = new Promise(resolve => {
			finishMapper = resolve;
		});
		let pulls = 0;
		const mapped = [];
		const source = createSource(asynchronous, () => {
			pulls++;
			if (pulls <= 2) {
				return {value: pulls, done: false};
			}

			throw pulls === 3 ? sourceError : laterError;
		});

		try {
			const reason = await immediateRejection(pMap(source, value => {
				mapped.push(value);
				return value === 1 ? pendingMapper : Promise.resolve(value);
			}, {concurrency: 2, stopOnError: false}));
			assert.strictEqual(reason, sourceError);
		} finally {
			finishMapper(1);
		}

		await nextTurn();
		assert.equal(pulls, 3);
		assert.deepEqual(mapped, [1, 2]);
	});

	test(`${kind} input and mapper errors aggregate after all work settles`, async () => {
		const inputError = new Error('input failed');
		const thrownMapperError = new Error('mapper threw');
		const rejectedMapperError = new Error('mapper rejected');
		let finishMapper;
		const pendingMapper = new Promise(resolve => {
			finishMapper = resolve;
		});
		let pulls = 0;
		const mapped = [];
		const source = createSource(asynchronous, () => {
			const index = pulls++;
			if (index === 0) {
				return {value: Promise.reject(inputError), done: false};
			}

			return {value: index, done: index === 5};
		});
		let settled = false;
		const mapping = pMap(source, (value, index) => {
			mapped.push([value, index]);
			if (value === 1) {
				throw thrownMapperError;
			}

			if (value === 2) {
				return Promise.reject(rejectedMapperError);
			}

			return value === 3 ? pMapSkip : pendingMapper;
		}, {concurrency: 1, stopOnError: false}).then(
			value => {
				settled = true;
				return {value};
			},
			reason => {
				settled = true;
				return {reason};
			},
		);

		try {
			await nextTurn();
			assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3], [4, 4]]);
			assert.equal(settled, false, 'aggregation must wait for the pending mapper');
		} finally {
			finishMapper(8);
		}

		const {reason} = await mapping;
		assert.ok(reason instanceof AggregateError);
		assert.equal(reason.errors.length, 3);
		assert.strictEqual(reason.errors[0], inputError);
		assert.strictEqual(reason.errors[1], thrownMapperError);
		assert.strictEqual(reason.errors[2], rejectedMapperError);
		assert.equal(pulls, 6);
	});
}

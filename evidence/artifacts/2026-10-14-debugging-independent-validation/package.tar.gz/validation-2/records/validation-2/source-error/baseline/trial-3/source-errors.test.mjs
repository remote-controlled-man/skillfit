#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pMap from './index.js';

const createSource = (asynchronous, next) => asynchronous
	? {[Symbol.asyncIterator]: () => ({next: async () => next()})}
	: {[Symbol.iterator]: () => ({next})};

const deferred = () => {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
};

for (const asynchronous of [false, true]) {
	const kind = asynchronous ? 'async' : 'sync';

	test(`${kind} source error after a mapper resolves rejects unchanged and stops input`, {timeout: 1000}, async () => {
		const sourceError = new Error('source failed');
		let nextCalls = 0;
		const mapped = [];
		const next = () => {
			nextCalls++;
			if (nextCalls === 2) {
				throw sourceError;
			}

			return {value: nextCalls, done: nextCalls > 3};
		};
		const source = createSource(asynchronous, next);

		await assert.rejects(pMap(source, async value => {
			mapped.push(value);
			return value;
		}, {concurrency: 1, stopOnError: false}), error => {
			assert.equal(error, sourceError);
			return true;
		});
		assert.equal(nextCalls, 2);
		assert.deepEqual(mapped, [1]);
	});

	test(`${kind} source error is not replaced by a later iteration error`, {timeout: 1000}, async () => {
		const sourceError = new Error('first source failure');
		const laterError = new Error('later source failure');
		let nextCalls = 0;
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls > 1) {
				throw nextCalls === 2 ? sourceError : laterError;
			}

			return {value: 1, done: false};
		});

		await assert.rejects(pMap(source, async value => value, {
			concurrency: 1,
			stopOnError: false,
		}), error => error === sourceError);
		assert.equal(nextCalls, 2);
	});

	for (const failure of ['input', 'sync mapper', 'async mapper']) {
		test(`${kind} source error after ${failure} failure rejects without aggregation`, {timeout: 1000}, async () => {
			const itemError = new Error(`${failure} failed`);
			const sourceError = new Error('source failed');
			let nextCalls = 0;
			const source = createSource(asynchronous, () => {
				nextCalls++;
				if (nextCalls > 1) {
					throw sourceError;
				}

				return {value: failure === 'input' ? Promise.reject(itemError) : 1, done: false};
			});
			let mapperCalls = 0;
			const mapper = () => {
				mapperCalls++;
				if (failure === 'sync mapper') {
					throw itemError;
				}

				return Promise.reject(itemError);
			};

			await assert.rejects(pMap(source, mapper, {
				concurrency: 1,
				stopOnError: false,
			}), error => error === sourceError);
			assert.equal(nextCalls, 2);
			assert.equal(mapperCalls, failure === 'input' ? 0 : 1);
		});
	}

	for (const stopOnError of [false, true]) {
		test(`${kind} initial source error rejects directly with stopOnError:${stopOnError}`, {timeout: 1000}, async () => {
			const sourceError = new Error('initial source failure');
			let nextCalls = 0;
			let mapperCalls = 0;
			const source = createSource(asynchronous, () => {
				nextCalls++;
				throw sourceError;
			});

			await assert.rejects(pMap(source, () => {
				mapperCalls++;
			}, {concurrency: 2, stopOnError}), error => error === sourceError);
			assert.equal(nextCalls, 1);
			assert.equal(mapperCalls, 0);
		});
	}

	test(`${kind} source error rejects while another mapper is pending`, {timeout: 1000}, async () => {
		const sourceError = new Error('source failed');
		const first = deferred();
		const second = deferred();
		const bothStarted = deferred();
		let nextCalls = 0;
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls > 2) {
				throw sourceError;
			}

			return {value: nextCalls, done: false};
		});
		const mapped = [];
		const operation = pMap(source, value => {
			mapped.push(value);
			if (value === 2) {
				bothStarted.resolve();
			}

			return value === 1 ? first.promise : second.promise;
		}, {concurrency: 2, stopOnError: false});
		const rejection = assert.rejects(operation, error => error === sourceError);

		await bothStarted.promise;
		first.resolve(1);
		try {
			await rejection;
			assert.equal(nextCalls, 3);
		} finally {
			second.resolve(2);
		}

		await new Promise(resolve => setImmediate(resolve));
		assert.equal(nextCalls, 3);
		assert.deepEqual(mapped, [1, 2]);
	});

	for (const concurrency of [1, 2, Number.POSITIVE_INFINITY]) {
		test(`${kind} input and mapper errors aggregate at concurrency ${concurrency}`, {timeout: 1000}, async () => {
			const inputError = new Error('input failed');
			const syncMapperError = new Error('sync mapper failed');
			const asyncMapperError = new Error('async mapper failed');
			let nextCalls = 0;
			const source = createSource(asynchronous, () => {
				const index = nextCalls++;
				return {value: index === 0 ? Promise.reject(inputError) : index, done: index >= 4};
			});
			const mapped = [];
			await assert.rejects(pMap(source, (value, index) => {
				mapped.push([value, index]);
				if (value === 1) {
					throw syncMapperError;
				}

				if (value === 2) {
					return Promise.reject(asyncMapperError);
				}

				return value;
			}, {concurrency, stopOnError: false}), error => {
				assert.ok(error instanceof AggregateError);
				assert.equal(error.errors.length, 3);
				assert.deepEqual(new Set(error.errors), new Set([inputError, syncMapperError, asyncMapperError]));
				return true;
			});
			assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3]]);
		});
	}

	test(`${kind} aggregation waits for a pending mapper and continues input`, {timeout: 1000}, async () => {
		const inputError = new Error('input failed');
		const mapperError = new Error('mapper failed');
		const pending = deferred();
		const pendingStarted = deferred();
		let nextCalls = 0;
		const source = createSource(asynchronous, () => {
			const index = nextCalls++;
			return {value: index === 0 ? Promise.reject(inputError) : index, done: index >= 3};
		});
		const operation = pMap(source, value => {
			if (value === 1) {
				throw mapperError;
			}

			pendingStarted.resolve();
			return pending.promise;
		}, {concurrency: 2, stopOnError: false});
		let settled = false;
		const observed = operation.then(() => {
			settled = true;
		}, () => {
			settled = true;
		});

		await pendingStarted.promise;
		await new Promise(resolve => setImmediate(resolve));
		try {
			assert.equal(settled, false);
		} finally {
			pending.resolve(2);
		}

		await assert.rejects(operation, error => {
			assert.ok(error instanceof AggregateError);
			assert.deepEqual(error.errors, [inputError, mapperError]);
			return true;
		});
		await observed;
		assert.ok(nextCalls >= 4);
	});
}

test('an async pull already pending at source rejection cannot resume consumption', {timeout: 1000}, async () => {
	const sourceError = new Error('source failed');
	const firstMapper = deferred();
	const pendingPull = deferred();
	const pullStarted = deferred();
	let nextCalls = 0;
	let valueReads = 0;
	const source = createSource(true, () => {
		nextCalls++;
		if (nextCalls === 1) {
			return {value: 1, done: false};
		}

		if (nextCalls === 2) {
			pullStarted.resolve();
			return pendingPull.promise;
		}

		throw sourceError;
	});
	const mapped = [];
	const operation = pMap(source, value => {
		mapped.push(value);
		return firstMapper.promise;
	}, {concurrency: 2, stopOnError: false});
	const rejection = assert.rejects(operation, error => error === sourceError);

	await pullStarted.promise;
	firstMapper.resolve(1);
	try {
		await rejection;
		assert.equal(nextCalls, 3);
	} finally {
		pendingPull.resolve({
			done: false,
			get value() {
				valueReads++;
				return 2;
			},
		});
	}

	await new Promise(resolve => setImmediate(resolve));
	assert.equal(nextCalls, 3);
	assert.equal(valueReads, 0);
	assert.deepEqual(mapped, [1]);
});

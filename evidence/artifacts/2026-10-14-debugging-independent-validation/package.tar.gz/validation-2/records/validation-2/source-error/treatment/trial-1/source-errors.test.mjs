#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pMap from './index.js';

function source(next, asynchronous) {
	if (asynchronous) {
		return {
			[Symbol.asyncIterator]() {
				return {async next() { return next(); }};
			},
		};
	}

	return {
		[Symbol.iterator]() {
			return {next};
		},
	};
}

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

for (const asynchronous of [false, true]) {
	const kind = asynchronous ? 'async' : 'sync';

	for (const path of ['startup', 'mapper fulfillment', 'input rejection', 'mapper rejection']) {
		test(`${kind} source error rejects directly after ${path}`, {timeout: 2000}, async () => {
			const sourceError = new Error('source failed');
			const retryError = new Error('source was pulled again');
			const inputError = new Error('input failed');
			const mapperError = new Error('mapper failed');
			const expectedPulls = path === 'startup' ? 1 : 2;
			const mapped = [];
			let pulls = 0;
			const input = source(() => {
				pulls++;
				if (pulls === 1 && path !== 'startup') {
					return {done: false, value: path === 'input rejection' ? Promise.reject(inputError) : 0};
				}

				throw pulls === expectedPulls ? sourceError : retryError;
			}, asynchronous);

			await assert.rejects(pMap(input, value => {
				mapped.push(value);
				if (path === 'mapper rejection') {
					throw mapperError;
				}

				return value;
			}, {concurrency: 1, stopOnError: false}), error => {
				assert.strictEqual(error, sourceError);
				return true;
			});
			assert.equal(pulls, expectedPulls);
			assert.deepEqual(mapped, path === 'startup' || path === 'input rejection' ? [] : [0]);
		});
	}

	for (const pending of ['input', 'mapper']) {
		test(`${kind} source error rejects before a pending ${pending} settles`, {timeout: 2000}, async () => {
			const sourceError = new Error('source failed');
			const release = deferred();
			const heldMapperStarted = deferred();
			const heldMapperFinished = deferred();
			const mapped = [];
			let pulls = 0;
			let heldMapperSettled = false;
			const input = source(() => {
				pulls++;
				if (pulls === 1) {
					return {done: false, value: pending === 'input' ? release.promise : 0};
				}

				if (pulls === 2) {
					return {done: false, value: 1};
				}

				throw sourceError;
			}, asynchronous);

			const mapping = pMap(input, async value => {
				mapped.push(value);
				if (value === 0) {
					heldMapperStarted.resolve();
					await release.promise;
					heldMapperSettled = true;
					heldMapperFinished.resolve();
				} else if (pending === 'mapper') {
					await heldMapperStarted.promise;
				}

				return value;
			}, {concurrency: 2, stopOnError: false});

			try {
				await assert.rejects(mapping, error => {
					assert.strictEqual(error, sourceError);
					return true;
				});
				assert.equal(pulls, 3);
				assert.equal(heldMapperSettled, false);
			} finally {
				release.resolve(0);
			}

			if (pending === 'mapper') {
				await heldMapperFinished.promise;
			}

			// Let already-started work finish before checking that nothing else was pulled or mapped.
			await new Promise(resolve => setImmediate(resolve));
			assert.equal(pulls, 3);
			assert.deepEqual(mapped, pending === 'input' ? [1] : [0, 1]);
		});
	}

	test(`${kind} input and mapper errors still aggregate and consume all input`, {timeout: 2000}, async () => {
		const inputError = new Error('input failed');
		const syncMapperError = new Error('mapper threw');
		const asyncMapperError = new Error('mapper rejected');
		const expectedErrors = [inputError, syncMapperError, asyncMapperError];
		const mapped = [];
		let pulls = 0;
		const input = source(() => {
			const index = pulls++;
			return index < 5
				? {done: false, value: index === 0 ? Promise.reject(inputError) : index}
				: {done: true};
		}, asynchronous);

		await assert.rejects(pMap(input, (value, index) => {
			mapped.push([value, index]);
			if (value === 1) {
				throw syncMapperError;
			}

			if (value === 2) {
				return Promise.reject(asyncMapperError);
			}

			return value * 2;
		}, {concurrency: 3, stopOnError: false}), error => {
			assert.ok(error instanceof AggregateError);
			assert.equal(error.errors.length, expectedErrors.length);
			for (const expected of expectedErrors) {
				assert.ok(error.errors.includes(expected));
			}

			return true;
		});
		assert.ok(pulls >= 6);
		assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3], [4, 4]]);
	});
}

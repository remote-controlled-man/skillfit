#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pMap, {pMapSkip} from './index.js';

function deferred() {
	let resolve;
	let reject;
	const promise = new Promise((resolve_, reject_) => {
		resolve = resolve_;
		reject = reject_;
	});
	return {promise, resolve, reject};
}

async function bounded(promise) {
	let timer;
	try {
		return await Promise.race([
			promise,
			new Promise((resolve, reject) => {
				timer = setTimeout(() => reject(new Error('pMap did not settle')), 1000);
			}),
		]);
	} finally {
		clearTimeout(timer);
	}
}

const drain = () => new Promise(resolve => setImmediate(resolve));

for (const asynchronous of [false, true]) {
	const sourceKind = asynchronous ? 'async' : 'sync';
	const iteratorSymbol = asynchronous ? Symbol.asyncIterator : Symbol.iterator;

	for (const outcome of ['resolve', 'skip', 'mapper rejection', 'input rejection']) {
		test(`${sourceKind} source error after ${outcome} rejects with the original error and stops pulling`, async () => {
			const sourceError = new Error('source failed');
			const laterError = new Error('source was pulled again');
			const itemError = new Error('item failed');
			let pulls = 0;
			const mapped = [];
			const next = () => {
				pulls++;
				if (pulls === 1) {
					return {
						done: false,
						value: outcome === 'input rejection' ? Promise.reject(itemError) : 1,
					};
				}

				throw pulls === 2 ? sourceError : laterError;
			};
			const source = {
				[iteratorSymbol]() {
					return {next: asynchronous ? async () => next() : next};
				},
			};
			const mapping = pMap(source, async (value, index) => {
				mapped.push([value, index]);
				if (outcome === 'mapper rejection') {
					throw itemError;
				}

				return outcome === 'skip' ? pMapSkip : value * 2;
			}, {concurrency: 1, stopOnError: false});

			await assert.rejects(bounded(mapping), error => error === sourceError);
			await drain();
			assert.equal(pulls, 2);
			assert.deepEqual(mapped, outcome === 'input rejection' ? [] : [[1, 0]]);
		});
	}

	test(`${sourceKind} source error on the initial pull rejects directly`, async () => {
		const sourceError = new Error('initial pull failed');
		let pulls = 0;
		let mapperCalls = 0;
		const next = () => {
			pulls++;
			throw sourceError;
		};
		const source = {
			[iteratorSymbol]() {
				return {next: asynchronous ? async () => next() : next};
			},
		};

		await assert.rejects(bounded(pMap(source, () => {
			mapperCalls++;
		}, {concurrency: 3, stopOnError: false})), error => error === sourceError);
		assert.equal(pulls, 1);
		assert.equal(mapperCalls, 0);
	});
}

test('source error rejects while another mapper is pending and late mappers stop pulling', async () => {
	for (const lateFailure of [false, true]) {
		const sourceError = new Error('source failed');
		const itemError = new Error('late mapper failed');
		const firstMapper = deferred();
		const lateMapper = deferred();
		const bothStarted = deferred();
		let pulls = 0;
		const mapped = [];
		const source = {
			[Symbol.iterator]() {
				return {
					next() {
						pulls++;
						if (pulls <= 2) {
							return {done: false, value: pulls};
						}

						throw sourceError;
					},
				};
			},
		};
		const mapping = pMap(source, (value, index) => {
			mapped.push([value, index]);
			if (mapped.length === 2) {
				bothStarted.resolve();
			}

			return index === 0 ? firstMapper.promise : lateMapper.promise;
		}, {concurrency: 2, stopOnError: false});

		try {
			await bounded(bothStarted.promise);
			firstMapper.resolve('first');
			await assert.rejects(bounded(mapping), error => error === sourceError);
			assert.equal(pulls, 3);
			assert.deepEqual(mapped, [[1, 0], [2, 1]]);
		} finally {
			if (lateFailure) {
				lateMapper.reject(itemError);
			} else {
				lateMapper.resolve('late');
			}

			await drain();
		}

		assert.equal(pulls, 3);
	}
});

test('input and mapper errors still aggregate after the remaining inputs finish', async () => {
	const inputError = new Error('input failed');
	const mapperError = new Error('mapper failed');
	const finalValue = deferred();
	const finalStarted = deferred();
	const mapped = [];
	const source = {
		* [Symbol.iterator]() {
			yield Promise.reject(inputError);
			yield 1;
			yield 2;
			yield 3;
			yield 4;
		},
	};
	const mapping = pMap(source, async (value, index) => {
		mapped.push([value, index]);
		if (value === 1) {
			throw mapperError;
		}

		if (value === 3) {
			return pMapSkip;
		}

		if (value === 4) {
			finalStarted.resolve();
			return finalValue.promise;
		}

		return value * 2;
	}, {concurrency: 1, stopOnError: false});
	let settled = false;
	mapping.then(() => { settled = true; }, () => { settled = true; });

	try {
		await bounded(finalStarted.promise);
		assert.equal(settled, false);
		assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3], [4, 4]]);
	} finally {
		finalValue.resolve('last');
	}

	await assert.rejects(bounded(mapping), error => {
		assert.ok(error instanceof AggregateError);
		assert.deepEqual(error.errors, [inputError, mapperError]);
		return true;
	});
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import pMap from './index.js';

function createSource(next, asynchronous) {
	return {
		[asynchronous ? Symbol.asyncIterator : Symbol.iterator]() {
			return this;
		},
		next: asynchronous ? async () => next() : next,
	};
}

for (const asynchronous of [false, true]) {
	const kind = asynchronous ? 'async' : 'sync';

	for (const preceding of ['mapper resolves', 'mapper rejects', 'input rejects']) {
		test(`${kind} source failure after ${preceding} rejects directly and stops pulling`, {timeout: 1000}, async () => {
			const sourceError = new Error('source failed');
			const extraPullError = new Error('source read after failure');
			const itemError = new Error(preceding);
			let pulls = 0;
			const mapped = [];
			const source = createSource(() => {
				pulls++;
				if (pulls === 1) {
					return {value: preceding === 'input rejects' ? Promise.reject(itemError) : 1, done: false};
				}

				throw pulls === 2 ? sourceError : extraPullError;
			}, asynchronous);

			const error = await pMap(source, async value => {
				mapped.push(value);
				if (preceding === 'mapper rejects') {
					throw itemError;
				}

				return value;
			}, {concurrency: 1, stopOnError: false}).then(
				() => assert.fail('expected source failure'),
				error => error,
			);
			await setImmediate();

			assert.strictEqual(error, sourceError);
			assert.equal(pulls, 2);
			assert.deepEqual(mapped, preceding === 'input rejects' ? [] : [1]);
		});
	}

	test(`${kind} source failure followed by done does not leave the map pending`, {timeout: 1000}, async () => {
		const sourceError = new Error('source failed');
		let pulls = 0;
		const source = createSource(() => {
			pulls++;
			if (pulls === 1) {
				return {value: 1, done: false};
			}

			if (pulls === 2) {
				throw sourceError;
			}

			return {done: true};
		}, asynchronous);

		await assert.rejects(pMap(source, value => value, {concurrency: 1, stopOnError: false}), error => error === sourceError);
		await setImmediate();
		assert.equal(pulls, 2);
	});

	test(`${kind} initial source failure rejects directly and stops startup runners`, {timeout: 1000}, async () => {
		const sourceError = new Error('initial source failed');
		let pulls = 0;
		const mapped = [];
		const source = createSource(() => {
			pulls++;
			throw sourceError;
		}, asynchronous);

		await assert.rejects(pMap(source, value => {
			mapped.push(value);
			return value;
		}, {concurrency: 3, stopOnError: false}), error => error === sourceError);
		await setImmediate();
		assert.equal(pulls, 1);
		assert.deepEqual(mapped, []);
	});

	test(`${kind} source failure rejects without waiting for an active mapper`, {timeout: 1000}, async () => {
		const sourceError = new Error('source failed while mapping');
		let finishMapper;
		const mapperResult = new Promise(resolve => {
			finishMapper = resolve;
		});
		let pulls = 0;
		const mapped = [];
		const source = createSource(() => {
			pulls++;
			if (pulls === 1) {
				return {value: 1, done: false};
			}

			throw sourceError;
		}, asynchronous);

		try {
			await assert.rejects(pMap(source, value => {
				mapped.push(value);
				return mapperResult;
			}, {concurrency: 2, stopOnError: false}), error => error === sourceError);
			assert.equal(pulls, 2);
			assert.deepEqual(mapped, [1]);
		} finally {
			finishMapper(1);
			await setImmediate();
		}

		assert.equal(pulls, 2);
		assert.deepEqual(mapped, [1]);
	});

	test(`${kind} input and mapper rejections still aggregate after all items settle`, {timeout: 1000}, async () => {
		const inputError = new Error('input rejected');
		const mapperError = new Error('mapper rejected');
		let pulls = 0;
		const mapped = [];
		const source = createSource(() => {
			pulls++;
			if (pulls === 1) {
				return {value: Promise.reject(inputError), done: false};
			}

			return {value: pulls, done: pulls > 3};
		}, asynchronous);

		await assert.rejects(pMap(source, async value => {
			mapped.push(value);
			if (value === 2) {
				throw mapperError;
			}

			await setImmediate();
			return value;
		}, {concurrency: 1, stopOnError: false}), error => {
			assert.ok(error instanceof AggregateError);
			assert.equal(error.errors.length, 2);
			assert.strictEqual(error.errors[0], inputError);
			assert.strictEqual(error.errors[1], mapperError);
			assert.deepEqual(mapped, [2, 3]);
			assert.equal(pulls, 4);
			return true;
		});
	});
}

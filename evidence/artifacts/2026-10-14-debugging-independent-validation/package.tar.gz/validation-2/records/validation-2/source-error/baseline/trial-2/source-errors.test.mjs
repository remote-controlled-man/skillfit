#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pMap, {pMapSkip} from './index.js';

const options = {concurrency: 1, stopOnError: false};
const flush = () => new Promise(resolve => setImmediate(resolve));

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

function source(kind, read) {
	return {
		[kind === 'sync' ? Symbol.iterator : Symbol.asyncIterator]() {
			return this;
		},
		next: kind === 'sync' ? read : async () => read(),
	};
}

function isSameError(expected) {
	return actual => {
		assert.equal(actual, expected);
		return true;
	};
}

for (const recovery of ['exhaustion', 'more input']) {
	test(`a source error followed by ${recovery} rejects without reading again`, {timeout: 1000}, async () => {
		const sourceError = new Error('source failed');
		let nextCalls = 0;
		const mapped = [];
		const input = source('sync', () => {
			nextCalls++;
			if (nextCalls === 2) {
				throw sourceError;
			}

			return {value: nextCalls, done: nextCalls > (recovery === 'exhaustion' ? 2 : 3)};
		});

		await assert.rejects(pMap(input, async value => {
			mapped.push(value);
			return value;
		}, options), isSameError(sourceError));
		await flush();
		assert.equal(nextCalls, 2);
		assert.deepEqual(mapped, [1]);
	});
}

for (const kind of ['sync', 'async']) {
	for (const outcome of ['value', 'skip', 'input rejection', 'mapper rejection']) {
		test(`${kind} source failure after ${outcome} preserves the first error and stops reading`, {timeout: 1000}, async () => {
			const sourceError = new Error('first source failure');
			const laterError = new Error('later source failure');
			const itemError = new Error(outcome);
			let nextCalls = 0;
			const mapped = [];
			const input = source(kind, () => {
				nextCalls++;
				if (nextCalls === 1) {
					return {value: outcome === 'input rejection' ? Promise.reject(itemError) : 1, done: false};
				}

				throw nextCalls === 2 ? sourceError : laterError;
			});

			await assert.rejects(pMap(input, async value => {
				mapped.push(value);
				if (outcome === 'mapper rejection') {
					throw itemError;
				}

				return outcome === 'skip' ? pMapSkip : value;
			}, options), isSameError(sourceError));
			await flush();
			assert.equal(nextCalls, 2);
			assert.deepEqual(mapped, outcome === 'input rejection' ? [] : [1]);
		});
	}

	for (const stopOnError of [false, true]) {
		test(`${kind} source failure on the first read rejects immediately (stopOnError: ${stopOnError})`, {timeout: 1000}, async () => {
			const sourceError = new Error('initial source failure');
			let nextCalls = 0;
			let mapperCalls = 0;
			const input = source(kind, () => {
				nextCalls++;
				throw sourceError;
			});

			await assert.rejects(pMap(input, () => {
				mapperCalls++;
			}, {concurrency: 3, stopOnError}), isSameError(sourceError));
			await flush();
			assert.equal(nextCalls, 1);
			assert.equal(mapperCalls, 0);
		});
	}

	for (const failDuringStartup of [true, false]) {
		test(`${kind} source failure during ${failDuringStartup ? 'startup' : 'mapper continuation'} does not wait for pending mappers`, {timeout: 1000}, async t => {
			const sourceError = new Error('source failure with a pending mapper');
			const pendingMapper = deferred();
			t.after(() => pendingMapper.resolve());
			let pendingMapperFinished = false;
			let nextCalls = 0;
			const failureCall = failDuringStartup ? 2 : 3;
			const mapped = [];
			const input = source(kind, () => {
				nextCalls++;
				if (nextCalls >= failureCall) {
					throw nextCalls === failureCall ? sourceError : new Error('unexpected extra read');
				}

				return {value: nextCalls, done: false};
			});

			await assert.rejects(pMap(input, async value => {
				mapped.push(value);
				if (value === 1) {
					await pendingMapper.promise;
					pendingMapperFinished = true;
				}

				return value;
			}, {concurrency: 2, stopOnError: false}), isSameError(sourceError));
			assert.equal(pendingMapperFinished, false);
			assert.equal(nextCalls, failureCall);
			pendingMapper.resolve();
			await flush();
			assert.equal(pendingMapperFinished, true);
			assert.equal(nextCalls, failureCall);
			assert.deepEqual(mapped, failDuringStartup ? [1] : [1, 2]);
		});
	}

	for (const concurrency of [1, 2]) {
		test(`${kind} input and mapper rejections still aggregate (concurrency: ${concurrency})`, {timeout: 1000}, async () => {
			const inputError = new Error('input rejected');
			const mapperError = new Error('mapper rejected');
			let nextCalls = 0;
			const mapped = [];
			const input = source(kind, () => {
				const value = nextCalls++;
				return {value: value === 0 ? Promise.reject(inputError) : value, done: value >= 4};
			});

			await assert.rejects(pMap(input, async (value, index) => {
				mapped.push([value, index]);
				if (value === 1) {
					throw mapperError;
				}

				return value === 2 ? pMapSkip : value;
			}, {concurrency, stopOnError: false}), error => {
				assert.ok(error instanceof AggregateError);
				assert.equal(error.errors.length, 2);
				assert.deepEqual(new Set(error.errors), new Set([inputError, mapperError]));
				return true;
			});
			assert.deepEqual(mapped, [[1, 1], [2, 2], [3, 3]]);
			assert.ok(nextCalls >= 5);
		});
	}
}

test('a pending source read cannot start a mapper after another read fails', {timeout: 1000}, async t => {
	const sourceError = new Error('source failed while another read was pending');
	const pendingRead = deferred();
	const readStarted = deferred();
	const pendingMapper = deferred();
	const mapperStarted = deferred();
	t.after(() => {
		pendingRead.resolve({value: 2, done: false});
		pendingMapper.resolve();
	});
	let nextCalls = 0;
	const mapped = [];
	const input = source('async', () => {
		nextCalls++;
		if (nextCalls === 1) {
			return {value: 1, done: false};
		}

		if (nextCalls === 2) {
			readStarted.resolve();
			return pendingRead.promise;
		}

		throw sourceError;
	});
	const operation = pMap(input, async value => {
		mapped.push(value);
		mapperStarted.resolve();
		await pendingMapper.promise;
		return value;
	}, {concurrency: 2, stopOnError: false});
	const rejection = assert.rejects(operation, isSameError(sourceError));
	await Promise.all([readStarted.promise, mapperStarted.promise]);
	pendingMapper.resolve();
	await rejection;
	assert.equal(nextCalls, 3);
	pendingRead.resolve({value: 2, done: false});
	await flush();
	assert.deepEqual(mapped, [1]);
	assert.equal(nextCalls, 3);
});

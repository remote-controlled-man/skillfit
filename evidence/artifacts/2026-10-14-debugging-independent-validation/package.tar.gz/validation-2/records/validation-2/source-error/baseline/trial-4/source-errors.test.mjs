#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import pMap, {pMapIterable} from './index.js';

function createSource(asynchronous, next) {
	return asynchronous
		? {[Symbol.asyncIterator]: () => ({next: async () => next()})}
		: {[Symbol.iterator]: () => ({next})};
}

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

const drainTasks = () => new Promise(resolve => setImmediate(resolve));

for (const asynchronous of [false, true]) {
	const sourceType = asynchronous ? 'async' : 'sync';

	test(`pMap rejects an initial ${sourceType} source error without mapping`, {timeout: 1000}, async () => {
		const sourceError = new Error('initial source failure');
		let nextCalls = 0;
		let mapperCalls = 0;
		const source = createSource(asynchronous, () => {
			nextCalls++;
			throw sourceError;
		});

		await assert.rejects(pMap(source, () => {
			mapperCalls++;
		}, {concurrency: 2, stopOnError: false}), error => error === sourceError);
		assert.equal(nextCalls, 1);
		assert.equal(mapperCalls, 0);
	});

	test(`pMap rejects a ${sourceType} source error after a mapper resolves`, {timeout: 1000}, async () => {
		const sourceError = new Error('source failed');
		const laterError = new Error('source was pulled again');
		let nextCalls = 0;
		const mappedValues = [];
		const next = () => {
			nextCalls++;
			if (nextCalls === 1) {
				return {value: 1, done: false};
			}

			throw nextCalls === 2 ? sourceError : laterError;
		};
		const source = createSource(asynchronous, next);

		await assert.rejects(pMap(source, async value => {
			mappedValues.push(value);
			return value;
		}, {concurrency: 1, stopOnError: false}), error => error === sourceError);
		assert.equal(nextCalls, 2);
		assert.deepEqual(mappedValues, [1]);
	});

	test(`pMap stops consuming a ${sourceType} source even if the iterator can recover`, {timeout: 1000}, async () => {
		const sourceError = new Error('temporary source failure');
		let nextCalls = 0;
		const mappedValues = [];
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls === 2) {
				throw sourceError;
			}

			return nextCalls < 4 ? {value: nextCalls, done: false} : {done: true};
		});

		await assert.rejects(pMap(source, async value => {
			mappedValues.push(value);
			return value;
		}, {concurrency: 1, stopOnError: false}), error => error === sourceError);
		await drainTasks();
		assert.equal(nextCalls, 2);
		assert.deepEqual(mappedValues, [1]);
	});

	test(`pMap rejects a ${sourceType} source error while another mapper is pending`, {timeout: 1000}, async t => {
		const sourceError = new Error('source failed with pending work');
		const pendingMapper = deferred();
		t.after(() => pendingMapper.resolve(1));
		let nextCalls = 0;
		const mappedValues = [];
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls <= 2) {
				return {value: nextCalls, done: false};
			}

			throw nextCalls === 3 ? sourceError : new Error('source was pulled again');
		});

		await assert.rejects(pMap(source, value => {
			mappedValues.push(value);
			return value === 1 ? pendingMapper.promise : Promise.resolve(value);
		}, {concurrency: 2, stopOnError: false}), error => error === sourceError);
		assert.equal(nextCalls, 3);
		assert.deepEqual(mappedValues, [1, 2]);

		pendingMapper.resolve(1);
		await drainTasks();
		assert.equal(nextCalls, 3);
	});

	test(`pMap gives a ${sourceType} source error priority over collected input and mapper errors`, {timeout: 1000}, async () => {
		const inputError = new Error('input failed');
		const mapperError = new Error('mapper failed');
		const sourceError = new Error('source failed');
		let nextCalls = 0;
		const mappedValues = [];
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls === 1) {
				return {value: Promise.reject(inputError), done: false};
			}

			if (nextCalls === 2) {
				return {value: 2, done: false};
			}

			throw nextCalls === 3 ? sourceError : new Error('source was pulled again');
		});

		await assert.rejects(pMap(source, async value => {
			mappedValues.push(value);
			throw mapperError;
		}, {concurrency: 1, stopOnError: false}), error => error === sourceError);
		assert.equal(nextCalls, 3);
		assert.deepEqual(mappedValues, [2]);
	});

	test(`pMap still aggregates ${sourceType} input and mapper errors after all work settles`, {timeout: 1000}, async t => {
		const inputError = new Error('input failed');
		const mapperError = new Error('mapper failed');
		const pendingMapper = deferred();
		const mapperStarted = deferred();
		t.after(() => pendingMapper.resolve(3));
		let nextCalls = 0;
		let settled = false;
		const mappedValues = [];
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls === 1) {
				return {value: Promise.reject(inputError), done: false};
			}

			return nextCalls <= 3 ? {value: nextCalls, done: false} : {done: true};
		});
		const mapping = pMap(source, value => {
			mappedValues.push(value);
			if (value === 2) {
				throw mapperError;
			}

			mapperStarted.resolve();
			return pendingMapper.promise;
		}, {concurrency: 1, stopOnError: false});
		const rejection = assert.rejects(mapping, error => {
			settled = true;
			assert.ok(error instanceof AggregateError);
			assert.deepEqual(error.errors, [inputError, mapperError]);
			return true;
		});

		await mapperStarted.promise;
		await drainTasks();
		assert.equal(settled, false);
		assert.deepEqual(mappedValues, [2, 3]);
		pendingMapper.resolve(3);
		await rejection;
		assert.equal(nextCalls, 4);
	});

	test(`pMapIterable preserves a ${sourceType} source error and stops pulling`, {timeout: 1000}, async () => {
		const sourceError = new Error('iterable source failed');
		let nextCalls = 0;
		const source = createSource(asynchronous, () => {
			nextCalls++;
			if (nextCalls === 1) {
				return {value: 1, done: false};
			}

			throw nextCalls === 2 ? sourceError : new Error('source was pulled again');
		});
		const mappedValues = [];
		const output = pMapIterable(source, async value => {
			mappedValues.push(value);
			return value;
		}, {concurrency: 1});
		await assert.rejects(async () => {
			for await (const value of output) {
				assert.equal(value, 1);
			}
		}, error => error === sourceError);
		assert.equal(nextCalls, 2);
		assert.deepEqual(mappedValues, [1]);
	});
}

test('pMap stops other runners immediately when a sync source throws', {timeout: 1000}, async t => {
	const sourceError = new Error('source failed while mappers finished together');
	const mapperGate = deferred();
	const bothMappersStarted = deferred();
	t.after(() => mapperGate.resolve());
	let nextCalls = 0;
	const mappedValues = [];
	const source = createSource(false, () => {
		nextCalls++;
		if (nextCalls === 3) {
			throw sourceError;
		}

		return nextCalls < 5 ? {value: nextCalls, done: false} : {done: true};
	});
	const mapping = pMap(source, value => {
		mappedValues.push(value);
		if (mappedValues.length === 2) {
			bothMappersStarted.resolve();
		}

		return mapperGate.promise;
	}, {concurrency: 2, stopOnError: false});
	const rejection = assert.rejects(mapping, error => error === sourceError);

	await bothMappersStarted.promise;
	mapperGate.resolve();
	await rejection;
	await drainTasks();
	assert.equal(nextCalls, 3);
	assert.deepEqual(mappedValues, [1, 2]);
});

test('pMap still rejects the first mapper error with stopOnError:true', async () => {
	const mapperError = new Error('mapper failed');
	const mappedValues = [];
	await assert.rejects(pMap([1, 2], async value => {
		mappedValues.push(value);
		throw mapperError;
	}, {concurrency: 1, stopOnError: true}), error => error === mapperError);
	assert.deepEqual(mappedValues, [1]);
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(t) {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	return milliseconds => {
		now += milliseconds;
	};
}

for (const maxAge of [undefined, 10, 100, Number.POSITIVE_INFINITY]) {
	test(`per-item duration overrides constructor maxAge ${maxAge}`, t => {
		const advance = mockClock(t);
		const cache = new QuickLRU({maxSize: 3, maxAge});
		advance(20);
		cache.set('key', 'value', {maxAge: 50});
		assert.equal(cache.get('key'), 'value');
		advance(49);
		assert.equal(cache.has('key'), true);
		assert.equal(cache.peek('key'), 'value');
		advance(1);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.has('key'), false);
	});
}

test('replacement starts a new per-item duration at the write', t => {
	const advance = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'old');
	advance(80);
	cache.set('key', 'new', {maxAge: 50});
	assert.equal(cache.get('key'), 'new');
	advance(20);
	assert.equal(cache.get('key'), 'new');
	advance(29);
	assert.equal(cache.peek('key'), 'new');
	assert.deepEqual(evictions, []);
	advance(1);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'new']]);
});

test('replacement after cache rotation uses the new write time', t => {
	const advance = mockClock(t);
	const cache = new QuickLRU({maxSize: 2, maxAge: 100});
	cache.set('key', 'old');
	cache.set('other', 'value');
	advance(80);
	cache.set('key', 'new', {maxAge: 50});
	assert.equal(cache.get('key'), 'new');
	advance(49);
	assert.equal(cache.peek('key'), 'new');
	advance(1);
	assert.equal(cache.get('key'), undefined);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('other'), undefined);
});

for (const [description, options] of [
	['omitted options', undefined],
	['empty options', {}],
	['undefined maxAge', {maxAge: undefined}]
]) {
	test(`constructor duration remains the default for ${description}`, t => {
		const advance = mockClock(t);
		const cache = new QuickLRU({maxSize: 4, maxAge: 100});
		advance(20);
		cache.set('inserted', 'value', options);
		cache.set('key', 'old', options);
		advance(80);
		assert.equal(cache.get('inserted'), 'value');
		cache.set('key', 'new', options);
		advance(19);
		assert.equal(cache.peek('inserted'), 'value');
		advance(1);
		assert.equal(cache.get('inserted'), undefined);
		assert.equal(cache.get('key'), 'new');
		advance(79);
		assert.equal(cache.peek('key'), 'new');
		advance(1);
		assert.equal(cache.has('key'), false);
	});
}

test('default and constructor Infinity entries remain non-expiring on insert and replacement', t => {
	const advance = mockClock(t);
	const caches = [
		new QuickLRU({maxSize: 3}),
		new QuickLRU({maxSize: 3, maxAge: Number.POSITIVE_INFINITY})
	];
	for (const cache of caches) {
		cache.set('key', 'old');
	}
	advance(1_000_000);
	for (const cache of caches) {
		assert.equal(cache.get('key'), 'old');
		cache.set('key', 'new');
	}
	advance(1_000_000);
	for (const cache of caches) {
		assert.equal(cache.has('key'), true);
		assert.equal(cache.get('key'), 'new');
	}
});

test('per-item Infinity overrides a finite default on insert and replacement', t => {
	const advance = mockClock(t);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('inserted', 'forever', {maxAge: Number.POSITIVE_INFINITY});
	cache.set('replaced', 'old');
	advance(50);
	cache.set('replaced', 'forever', {maxAge: Number.POSITIVE_INFINITY});
	advance(1_000_000);
	assert.equal(cache.get('inserted'), 'forever');
	assert.equal(cache.get('replaced'), 'forever');
	cache.set('replaced', 'temporary', {maxAge: 50});
	assert.equal(cache.get('replaced'), 'temporary');
	advance(50);
	assert.equal(cache.has('replaced'), false);
	assert.equal(cache.get('inserted'), 'forever');
});

test('a zero per-item duration expires at the write on insert and replacement', t => {
	mockClock(t);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('inserted', 'value', {maxAge: 0});
	assert.equal(cache.get('inserted'), undefined);
	cache.set('replaced', 'old');
	cache.set('replaced', 'new', {maxAge: 0});
	assert.equal(cache.peek('replaced'), undefined);
	assert.equal(cache.has('replaced'), false);
});

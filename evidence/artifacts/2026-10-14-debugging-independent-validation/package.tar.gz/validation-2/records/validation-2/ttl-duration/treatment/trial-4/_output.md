我会使用 diagnosing-bugs 技能，在本地定位 `maxAge` 的过期计算问题，修复写入和替换路径，并用公共 API 添加回归测试。

已定位原因：`set()` 只在使用默认值时计算 `Date.now() + maxAge`，显式传入的 `maxAge` 会直接被当作过期时间戳，因此普通毫秒时长会立即过期。接下来先用受控时钟测试复现，再让插入和替换路径共用时长转换逻辑，验证默认 TTL 和 `Infinity`。

修复前，回归测试有 7 项失败；修复后，`npm test` 的 14 项测试全部通过。新增测试覆盖精确过期边界、当前及旧缓存中的替换、默认 TTL 和不失效条目。现在检查最终差异与文件权限，确认原测试、元数据和文档未改动。

已修复 [index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/ttl-duration/treatment/trial-4/index.js:113)。原实现只转换默认 `maxAge`，显式传入的时长却被当作绝对时间戳。现在插入和替换均按 `Date.now() + maxAge` 计算，保留默认 TTL 和 `Infinity` 行为。

新增可执行的 `ttl-duration.test.mjs`，使用 `node:test`、受控时钟及公共 API，覆盖替换、过期边界和非过期条目。

验证：修复前回归测试复现 7 项失败；修复后 `npm test` 全部 14 项通过，`git diff --check` 通过。原测试、元数据及文档未改动，全程未联网。
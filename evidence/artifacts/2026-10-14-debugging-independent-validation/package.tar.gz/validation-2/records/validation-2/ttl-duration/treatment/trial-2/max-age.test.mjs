#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(context) {
	let now = 1_700_000_000_000;
	context.mock.method(Date, 'now', () => now);
	return milliseconds => {
		now += milliseconds;
	};
}

for (const maxAge of [undefined, 500]) {
	test(`insert uses a per-item duration with constructor maxAge=${maxAge}`, context => {
		const advance = mockClock(context);
		const evictions = [];
		const value = {message: 'cached value'};
		const cache = new QuickLRU({
			maxSize: 3,
			maxAge,
			onEviction: (key, item) => evictions.push([key, item])
		});

		cache.set('key', value, {maxAge: 100});
		assert.equal(cache.get('key'), value);
		advance(99);
		assert.equal(cache.has('key'), true);
		assert.equal(cache.peek('key'), value);
		assert.deepEqual([...cache], [['key', value]]);
		assert.deepEqual(evictions, []);

		advance(1);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.has('key'), false);
		assert.equal(cache.peek('key'), undefined);
		assert.equal(cache.size, 0);
		assert.deepEqual(evictions, [['key', value]]);
	});
}

for (const generation of ['recent', 'old']) {
	for (const sameValue of [true, false]) {
		test(`replacement resets the duration in the ${generation} generation (${sameValue ? 'same' : 'different'} value)`, context => {
			const advance = mockClock(context);
			const evictions = [];
			const original = {message: 'original'};
			const replacement = sameValue ? original : {message: 'replacement'};
			const cache = new QuickLRU({
				maxSize: 3,
				onEviction: (key, value) => evictions.push([key, value])
			});

			cache.set('key', original, {maxAge: 100});
			if (generation === 'old') {
				cache.set('filler-1', 1);
				cache.set('filler-2', 2);
			}

			advance(60);
			cache.set('key', replacement, {maxAge: 200});
			assert.equal(cache.get('key'), replacement);
			advance(40);
			assert.equal(cache.get('key'), replacement);
			advance(159);
			assert.equal(cache.peek('key'), replacement);
			assert.deepEqual(evictions, []);

			advance(1);
			assert.equal(cache.has('key'), false);
			assert.equal(cache.get('key'), undefined);
			assert.equal(cache.peek('key'), undefined);
			assert.deepEqual(evictions, [['key', replacement]]);
		});
	}
}

test('reading an older entry preserves its original expiration', context => {
	const advance = mockClock(context);
	const cache = new QuickLRU({maxSize: 2});
	cache.set('key', 'value', {maxAge: 100});
	cache.set('filler', 'value');
	advance(60);
	assert.equal(cache.get('key'), 'value');
	advance(39);
	assert.equal(cache.peek('key'), 'value');
	advance(1);
	assert.equal(cache.peek('key'), undefined);
	assert.equal(cache.has('key'), false);
});

for (const [description, options] of [['no options', undefined], ['empty options', {}], ['undefined maxAge', {maxAge: undefined}]]) {
	test(`omitted duration uses the constructor default (${description})`, context => {
		const advance = mockClock(context);
		const cache = new QuickLRU({maxSize: 3, maxAge: 100});
		advance(500);
		cache.set('key', 'original', options);
		assert.equal(cache.get('key'), 'original');
		advance(60);
		cache.set('key', 'replacement', options);
		advance(40);
		assert.equal(cache.get('key'), 'replacement');
		advance(59);
		assert.equal(cache.peek('key'), 'replacement');
		advance(1);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.has('key'), false);
	});
}

test('default and explicit Infinity entries remain non-expiring', context => {
	const advance = mockClock(context);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 5,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('default', 'default value');
	cache.set('infinite', 'infinite value', {maxAge: Infinity});
	cache.set('replaced', 'temporary', {maxAge: 100});
	advance(50);
	cache.set('replaced', 'permanent');
	advance(1_000_000_000);
	assert.equal(cache.get('default'), 'default value');
	assert.equal(cache.get('infinite'), 'infinite value');
	assert.equal(cache.get('replaced'), 'permanent');
	assert.equal(cache.size, 3);
	assert.deepEqual(evictions, []);
});

test('Infinity overrides a finite constructor default on insert and replacement', context => {
	const advance = mockClock(context);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('inserted', 'permanent', {maxAge: Infinity});
	cache.set('replaced', 'temporary');
	advance(50);
	cache.set('replaced', 'permanent', {maxAge: Infinity});
	advance(1_000_000_000);
	assert.equal(cache.get('inserted'), 'permanent');
	assert.equal(cache.get('replaced'), 'permanent');
	assert.equal(cache.size, 2);
});

test('zero duration expires at the write on insert and replacement', context => {
	mockClock(context);
	const cache = new QuickLRU({maxSize: 3});
	cache.set('inserted', 'value', {maxAge: 0});
	assert.equal(cache.get('inserted'), undefined);
	cache.set('replaced', 'original');
	cache.set('replaced', 'replacement', {maxAge: 0});
	assert.equal(cache.get('replaced'), undefined);
	assert.equal(cache.has('replaced'), false);
});

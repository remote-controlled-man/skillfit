#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

const withClock = callback => {
	const originalNow = Date.now;
	let now = 1_000_000;
	Date.now = () => now;
	try {
		callback(value => {
			now = value;
		});
	} finally {
		Date.now = originalNow;
	}
};

test('a new entry expires maxAge milliseconds after its write', () => {
	withClock(setTime => {
		const cache = new QuickLRU({maxSize: 3});
		cache.set('key', 'value', {maxAge: 50});
		assert.equal(cache.get('key'), 'value');
		setTime(1_000_049);
		assert.equal(cache.get('key'), 'value');
		setTime(1_000_050);
		assert.equal(cache.get('key'), undefined);
	});
});

test('a replacement expires maxAge milliseconds after its write', () => {
	withClock(setTime => {
		const cache = new QuickLRU({maxSize: 3});
		cache.set('key', 'original', {maxAge: 100});
		setTime(1_000_075);
		cache.set('key', 'replacement', {maxAge: 50});
		assert.equal(cache.get('key'), 'replacement');
		setTime(1_000_100);
		assert.equal(cache.get('key'), 'replacement');
		setTime(1_000_124);
		assert.equal(cache.get('key'), 'replacement');
		setTime(1_000_125);
		assert.equal(cache.get('key'), undefined);
	});
});

test('replacing an entry in the old generation uses the replacement write time', () => {
	withClock(setTime => {
		const cache = new QuickLRU({maxSize: 2});
		cache.set('key', 'original');
		cache.set('filler', 'filler');
		setTime(1_000_100);
		cache.set('key', 'replacement', {maxAge: 50});
		assert.equal(cache.get('key'), 'replacement');
		setTime(1_000_149);
		assert.equal(cache.peek('key'), 'replacement');
		setTime(1_000_150);
		assert.equal(cache.has('key'), false);
		assert.equal(cache.get('key'), undefined);
	});
});

test('promoting an entry keeps the expiry from its original write', () => {
	withClock(setTime => {
		const cache = new QuickLRU({maxSize: 2});
		cache.set('key', 'value', {maxAge: 50});
		cache.set('filler', 'filler');
		setTime(1_000_020);
		assert.equal(cache.get('key'), 'value');
		setTime(1_000_049);
		assert.equal(cache.get('key'), 'value');
		setTime(1_000_050);
		assert.equal(cache.get('key'), undefined);
	});
});

test('per-item durations override a finite constructor duration on insert and replacement', () => {
	for (const replace of [false, true]) {
		for (const maxAge of [20, 200]) {
			withClock(setTime => {
				const cache = new QuickLRU({maxSize: 3, maxAge: 100});
				if (replace) {
					cache.set('key', 'original');
				}

				setTime(1_000_075);
				cache.set('key', 'value', {maxAge});
				assert.equal(cache.get('key'), 'value');
				setTime(1_000_075 + maxAge - 1);
				assert.equal(cache.get('key'), 'value');
				setTime(1_000_075 + maxAge);
				assert.equal(cache.get('key'), undefined);
			});
		}
	}
});

test('omitted and undefined per-item durations use the constructor duration from each write', () => {
	for (const replace of [false, true]) {
		for (const options of [undefined, {}, {maxAge: undefined}]) {
			withClock(setTime => {
				const cache = new QuickLRU({maxSize: 3, maxAge: 100});
				if (replace) {
					cache.set('key', 'original', {maxAge: 20});
				}

				setTime(1_000_075);
				cache.set('key', 'value', options);
				setTime(1_000_174);
				assert.equal(cache.get('key'), 'value');
				setTime(1_000_175);
				assert.equal(cache.get('key'), undefined);
			});
		}
	}
});

test('non-expiring defaults remain non-expiring on insert and replacement', () => {
	for (const replace of [false, true]) {
		for (const constructorOptions of [{maxSize: 3}, {maxSize: 3, maxAge: Infinity}]) {
			for (const options of [undefined, {}, {maxAge: undefined}]) {
				withClock(setTime => {
					const cache = new QuickLRU(constructorOptions);
					if (replace) {
						cache.set('key', 'original', {maxAge: 20});
					}

					setTime(1_000_075);
					cache.set('key', 'value', options);
					setTime(9_000_000_000_000);
					assert.equal(cache.get('key'), 'value');
					assert.equal(cache.has('key'), true);
				});
			}
		}
	}
});

test('an explicit Infinity overrides a finite constructor duration on insert and replacement', () => {
	for (const replace of [false, true]) {
		withClock(setTime => {
			const cache = new QuickLRU({maxSize: 3, maxAge: 100});
			if (replace) {
				cache.set('key', 'original');
			}

			setTime(1_000_075);
			cache.set('key', 'value', {maxAge: Infinity});
			setTime(9_000_000_000_000);
			assert.equal(cache.peek('key'), 'value');
			assert.equal(cache.has('key'), true);
		});
	}
});

test('a zero per-item duration expires immediately on insert and replacement', () => {
	for (const replace of [false, true]) {
		withClock(() => {
			const cache = new QuickLRU({maxSize: 3});
			if (replace) {
				cache.set('key', 'original');
			}

			cache.set('key', 'value', {maxAge: 0});
			assert.equal(cache.get('key'), undefined);
			assert.equal(cache.has('key'), false);
		});
	}
});

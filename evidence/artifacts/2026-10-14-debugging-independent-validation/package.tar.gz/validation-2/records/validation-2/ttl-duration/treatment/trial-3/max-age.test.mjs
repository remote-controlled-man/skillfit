#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(t) {
	const start = 1_700_000_000_000;
	let now = start;
	t.mock.method(Date, 'now', () => now);
	return elapsed => {
		now = start + elapsed;
	};
}

function assertPresent(cache, key, value) {
	assert.equal(cache.has(key), true);
	assert.equal(cache.peek(key), value);
	assert.equal(cache.get(key), value);
}

test('per-item maxAge is a duration from insertion and overrides the global duration', t => {
	const advanceTo = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 10,
		onEviction: (key, value) => evictions.push([key, value])
	});
	const value = {name: 'value'};
	advanceTo(100);
	cache.set('key', value, {maxAge: 50});
	assertPresent(cache, 'key', value);
	advanceTo(149);
	assertPresent(cache, 'key', value);
	assert.deepEqual(evictions, []);
	advanceTo(150);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('key'), undefined);
	assert.equal(cache.peek('key'), undefined);
	assert.equal(cache.size, 0);
	assert.deepEqual(evictions, [['key', value]]);
});

for (const generation of ['recent', 'old']) {
	for (const value of ['original', 'replacement']) {
		test(`replacement in the ${generation} cache restarts the duration with ${value} value`, t => {
			const advanceTo = mockClock(t);
			const evictions = [];
			const cache = new QuickLRU({
				maxSize: 2,
				onEviction: (key, value) => evictions.push([key, value])
			});
			cache.set('key', 'original', {maxAge: 20});
			if (generation === 'old') {
				cache.set('filler', 'filler');
			}

			advanceTo(10);
			cache.set('key', value, {maxAge: 50});
			assertPresent(cache, 'key', value);
			advanceTo(59);
			assertPresent(cache, 'key', value);
			assert.deepEqual(evictions, []);
			advanceTo(60);
			assert.equal(cache.peek('key'), undefined);
			assert.equal(cache.has('key'), false);
			assert.equal(cache.get('key'), undefined);
			assert.deepEqual(evictions, [['key', value]]);
		});
	}
}

test('promotion and iteration preserve the per-item deadline', t => {
	const advanceTo = mockClock(t);
	const cache = new QuickLRU({maxSize: 2});
	cache.set('key', 'value', {maxAge: 50});
	cache.set('filler', 'filler');
	advanceTo(25);
	assert.equal(cache.get('key'), 'value');
	advanceTo(49);
	assert.deepEqual([...cache.entriesAscending()], [['filler', 'filler'], ['key', 'value']]);
	advanceTo(50);
	assert.deepEqual([...cache], [['filler', 'filler']]);
	assert.equal(cache.has('key'), false);
});

for (const [description, options] of [
	['omitted options', undefined],
	['empty options', {}],
	['undefined maxAge', {maxAge: undefined}]
]) {
	test(`global maxAge applies to insertion and replacement with ${description}`, t => {
		const advanceTo = mockClock(t);
		const cache = new QuickLRU({maxSize: 3, maxAge: 50});
		cache.set('key', 'original', options);
		advanceTo(49);
		assertPresent(cache, 'key', 'original');
		cache.set('key', 'replacement', options);
		advanceTo(98);
		assertPresent(cache, 'key', 'replacement');
		advanceTo(99);
		assert.equal(cache.get('key'), undefined);
		cache.set('new', 'value', options);
		advanceTo(149);
		assert.equal(cache.has('new'), false);
	});
}

for (const globalMaxAge of [undefined, Number.POSITIVE_INFINITY, 10]) {
	test(`non-expiring entries survive insertion and replacement with global maxAge ${globalMaxAge}`, t => {
		const advanceTo = mockClock(t);
		const cache = new QuickLRU({maxSize: 4, maxAge: globalMaxAge});
		const options = globalMaxAge === 10 ? {maxAge: Number.POSITIVE_INFINITY} : undefined;
		cache.set('inserted', 'value', options);
		cache.set('replaced', 'temporary', {maxAge: 5});
		advanceTo(1);
		cache.set('replaced', 'permanent', options);
		advanceTo(1_000_000);
		assertPresent(cache, 'inserted', 'value');
		assertPresent(cache, 'replaced', 'permanent');
		assert.equal(cache.size, 2);
	});
}

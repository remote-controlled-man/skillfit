#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

test('per-item maxAge measures a duration from insertion', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3});

	cache.set('key', 'value', {maxAge: 50});
	assert.equal(cache.get('key'), 'value');
	now += 49;
	assert.equal(cache.get('key'), 'value');
	now += 1;
	assert.equal(cache.get('key'), undefined);
});

test('per-item maxAge measures a duration from replacement', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3});
	cache.set('key', 'original');
	now += 100;

	cache.set('key', 'replacement', {maxAge: 50});
	assert.equal(cache.get('key'), 'replacement');
	now += 49;
	assert.equal(cache.get('key'), 'replacement');
	now += 1;
	assert.equal(cache.get('key'), undefined);
});

for (const read of ['peek', 'has']) {
	test(`${read} observes the per-item duration and expiration boundary`, t => {
		let now = 1_000_000;
		t.mock.method(Date, 'now', () => now);
		const cache = new QuickLRU({maxSize: 3});

		cache.set('key', 'value', {maxAge: 50});
		assert.equal(cache[read]('key'), read === 'has' ? true : 'value');
		now += 49;
		assert.equal(cache[read]('key'), read === 'has' ? true : 'value');
		now += 1;
		assert.equal(cache[read]('key'), read === 'has' ? false : undefined);
	});
}

test('replacement resets the duration even when the key is in the older cache', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 2});
	cache.set('key', 'original', {maxAge: 30});
	cache.set('filler', 'value');
	now += 20;

	cache.set('key', 'replacement', {maxAge: 50});
	assert.equal(cache.get('key'), 'replacement');
	now += 10;
	assert.equal(cache.get('key'), 'replacement');
	now += 39;
	assert.equal(cache.get('key'), 'replacement');
	now += 1;
	assert.equal(cache.get('key'), undefined);
});

test('moving an entry to the recent cache preserves its write-time expiration', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'value', {maxAge: 50});
	cache.set('filler', 'value');
	now += 20;
	assert.equal(cache.get('key'), 'value');
	assert.deepEqual(evictions, []);
	now += 29;
	assert.equal(cache.peek('key'), 'value');
	now += 1;
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', 'value']]);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'value']]);
});

for (const [name, options] of [
	['omitted options', undefined],
	['empty options', {}],
	['undefined maxAge', {maxAge: undefined}]
]) {
	test(`constructor maxAge starts at each write with ${name}`, t => {
		let now = 1_000_000;
		t.mock.method(Date, 'now', () => now);
		const cache = new QuickLRU({maxSize: 3, maxAge: 100});
		now += 1_000;

		cache.set('key', 'value', options);
		now += 99;
		assert.equal(cache.get('key'), 'value');
		now += 1;
		assert.equal(cache.get('key'), undefined);

		cache.set('key', 'original', options);
		now += 40;
		cache.set('key', 'replacement', options);
		now += 60;
		assert.equal(cache.get('key'), 'replacement');
		now += 39;
		assert.equal(cache.get('key'), 'replacement');
		now += 1;
		assert.equal(cache.get('key'), undefined);
	});
}

test('per-item durations override shorter and longer constructor defaults', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('short', 'short value', {maxAge: 50});
	cache.set('long', 'long value', {maxAge: 150});
	now += 49;
	assert.equal(cache.get('short'), 'short value');
	assert.equal(cache.get('long'), 'long value');
	now += 1;
	assert.equal(cache.get('short'), undefined);
	now += 50;
	assert.equal(cache.get('long'), 'long value');
	now += 49;
	assert.equal(cache.get('long'), 'long value');
	now += 1;
	assert.equal(cache.get('long'), undefined);
});

test('the non-expiring default applies to insertions and replacements', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3});
	cache.set('inserted', 'value');
	cache.set('replaced', 'original', {maxAge: 50});
	now += 20;
	cache.set('replaced', 'replacement');
	now += 1_000_000;
	assert.equal(cache.get('inserted'), 'value');
	assert.equal(cache.get('replaced'), 'replacement');
	assert.equal(cache.has('inserted'), true);
	assert.equal(cache.has('replaced'), true);
});

test('Infinity overrides finite defaults on insertions and replacements', t => {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3, maxAge: 50});
	cache.set('inserted', 'value', {maxAge: Infinity});
	cache.set('replaced', 'original');
	now += 20;
	cache.set('replaced', 'replacement', {maxAge: Infinity});
	now += 1_000_000;
	assert.equal(cache.get('inserted'), 'value');
	assert.equal(cache.get('replaced'), 'replacement');
	assert.deepEqual([...cache], [['inserted', 'value'], ['replaced', 'replacement']]);
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

test('an inserted item expires maxAge milliseconds after its write', t => {
	let now = 1_000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 10,
		onEviction: (key, value) => evictions.push([key, value])
	});

	cache.set('item', 'value', {maxAge: 50});
	assert.equal(cache.get('item'), 'value');
	now = 1_049;
	assert.equal(cache.get('item'), 'value');
	assert.deepEqual(evictions, []);
	now = 1_050;
	assert.equal(cache.has('item'), false);
	assert.deepEqual(evictions, [['item', 'value']]);
	assert.equal(cache.get('item'), undefined);
	assert.deepEqual(evictions, [['item', 'value']]);
});

test('a replacement expires maxAge milliseconds after the replacement write', t => {
	let now = 1_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 10});
	cache.set('item', 'original', {maxAge: 120});

	now = 1_100;
	cache.set('item', 'replacement', {maxAge: 50});
	assert.equal(cache.get('item'), 'replacement');
	now = 1_149;
	assert.equal(cache.get('item'), 'replacement');
	now = 1_150;
	assert.equal(cache.has('item'), false);
});

test('a replacement after cache rotation uses the replacement write time', t => {
	let now = 1_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 2});
	cache.set('item', 'original', {maxAge: 120});
	cache.set('other', 'value');

	now = 1_100;
	cache.set('item', 'replacement', {maxAge: 50});
	assert.equal(cache.peek('item'), 'replacement');
	now = 1_149;
	assert.equal(cache.peek('item'), 'replacement');
	now = 1_150;
	assert.equal(cache.has('item'), false);
});

test('reading an item after cache rotation preserves its original expiry', t => {
	let now = 1_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 2});
	cache.set('item', 'value', {maxAge: 50});
	cache.set('other', 'value');

	now = 1_020;
	assert.equal(cache.get('item'), 'value');
	now = 1_049;
	assert.equal(cache.get('item'), 'value');
	now = 1_050;
	assert.equal(cache.has('item'), false);
});

for (const [label, options] of [
	['omitted options', undefined],
	['empty options', {}],
	['undefined maxAge', {maxAge: undefined}]
]) {
	test(`constructor maxAge applies to inserts and replacements with ${label}`, t => {
		let now = 1_000;
		t.mock.method(Date, 'now', () => now);
		const cache = new QuickLRU({maxSize: 10, maxAge: 100});

		now = 1_100;
		cache.set('inserted', 'value', options);
		cache.set('replaced', 'original', options);
		assert.equal(cache.get('inserted'), 'value');
		now = 1_150;
		cache.set('replaced', 'replacement', options);
		now = 1_199;
		assert.equal(cache.get('inserted'), 'value');
		now = 1_200;
		assert.equal(cache.has('inserted'), false);
		assert.equal(cache.get('replaced'), 'replacement');
		now = 1_249;
		assert.equal(cache.get('replaced'), 'replacement');
		now = 1_250;
		assert.equal(cache.has('replaced'), false);
	});
}

test('per-item durations override a finite constructor maxAge', t => {
	let now = 1_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 10, maxAge: 100});
	cache.set('short', 'short', {maxAge: 50});
	cache.set('default', 'default');
	cache.set('long', 'long', {maxAge: 150});

	now = 1_049;
	assert.equal(cache.get('short'), 'short');
	now = 1_050;
	assert.equal(cache.has('short'), false);
	assert.equal(cache.get('default'), 'default');
	assert.equal(cache.get('long'), 'long');
	now = 1_100;
	assert.equal(cache.has('default'), false);
	assert.equal(cache.get('long'), 'long');
	now = 1_149;
	assert.equal(cache.get('long'), 'long');
	now = 1_150;
	assert.equal(cache.has('long'), false);
});

test('Infinity overrides a finite default on insertion and replacement', t => {
	let now = 1_000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 10, maxAge: 100});
	cache.set('inserted', 'value', {maxAge: Infinity});
	cache.set('replaced', 'original');

	now = 1_050;
	cache.set('replaced', 'replacement', {maxAge: Infinity});
	now = 1_000_000;
	assert.equal(cache.get('inserted'), 'value');
	assert.equal(cache.get('replaced'), 'replacement');
	assert.equal(cache.has('inserted'), true);
	assert.equal(cache.has('replaced'), true);
});

for (const [label, constructorOptions] of [
	['an omitted constructor maxAge', {}],
	['an infinite constructor maxAge', {maxAge: Infinity}]
]) {
	test(`default entries never expire with ${label}`, t => {
		let now = 1_000;
		t.mock.method(Date, 'now', () => now);
		const cache = new QuickLRU({maxSize: 10, ...constructorOptions});
		cache.set('omitted', 'value');
		cache.set('empty', 'value', {});
		cache.set('undefined', 'value', {maxAge: undefined});
		cache.set('replaced', 'original', {maxAge: 50});

		now = 1_020;
		cache.set('replaced', 'replacement');
		now = 1_000_000;
		for (const key of ['omitted', 'empty', 'undefined']) {
			assert.equal(cache.get(key), 'value');
			assert.equal(cache.has(key), true);
		}

		assert.equal(cache.get('replaced'), 'replacement');
		assert.equal(cache.has('replaced'), true);
	});
}

test('a zero per-item duration expires at the write time', t => {
	t.mock.method(Date, 'now', () => 1_000);
	const cache = new QuickLRU({maxSize: 10, maxAge: 100});
	cache.set('item', 'value', {maxAge: 0});

	assert.equal(cache.get('item'), undefined);
	assert.equal(cache.has('item'), false);
});

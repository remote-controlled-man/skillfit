我会用 diagnosing-bugs 技能定位过期时间的计算问题，修复插入和替换路径，并添加仅使用 Node 和公开 API 的回归测试；全程只检查本地文件。

原因已定位：`set()` 只在省略 `maxAge` 时计算“写入时间 + 时长”，显式传入的值则直接作为到期时间戳存储，因此会立即过期；插入和替换路径都有这个问题。接下来先用固定时钟复现，再统一计算到期时间，验证默认时长和 `Infinity` 仍保持原有行为。

已修复 [index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/ttl-duration/treatment/trial-3/index.js:113)：原先显式 `maxAge` 被直接当作到期时间戳；现在插入和替换均按“写入时间 + 毫秒时长”计算，保留全局默认值及 `Infinity` 不过期行为。

新增可执行 `max-age.test.mjs`，使用 `node:test`、固定时钟和公开 API，覆盖插入、两代缓存替换、过期边界、回调及默认值。

实际验证：修复前 6 项回归失败；修复后 `npm test` **14/14 通过**，`git diff --check` 通过。原测试、元数据和文档未改动，全程未联网。
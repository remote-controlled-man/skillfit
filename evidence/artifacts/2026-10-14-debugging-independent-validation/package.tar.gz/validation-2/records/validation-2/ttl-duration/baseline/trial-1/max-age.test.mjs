#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(t) {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	return milliseconds => {
		now += milliseconds;
	};
}

test('per-item maxAge expires from the insertion time, including the exact boundary', t => {
	const advance = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});

	cache.set('item', 'value', {maxAge: 100});
	assert.equal(cache.get('item'), 'value');
	advance(99);
	assert.equal(cache.peek('item'), 'value');
	assert.equal(cache.has('item'), true);
	assert.deepEqual(evictions, []);

	advance(1);
	assert.equal(cache.get('item'), undefined);
	assert.equal(cache.has('item'), false);
	assert.deepEqual([...cache], []);
	assert.deepEqual(evictions, [['item', 'value']]);
});

test('replacing a recent entry starts its per-item duration at the replacement write', t => {
	const advance = mockClock(t);
	const cache = new QuickLRU({maxSize: 3, maxAge: 50});
	cache.set('item', 'before');
	advance(25);
	cache.set('item', 'after', {maxAge: 100});
	assert.equal(cache.get('item'), 'after');

	advance(25);
	assert.equal(cache.get('item'), 'after');
	advance(74);
	assert.equal(cache.peek('item'), 'after');
	advance(1);
	assert.equal(cache.has('item'), false);
});

test('replacing an older entry starts its per-item duration at the replacement write', t => {
	const advance = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		maxAge: 50,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('item', 'before');
	cache.set('filler', 'filler');
	advance(25);
	cache.set('item', 'after', {maxAge: 100});
	assert.equal(cache.get('item'), 'after');

	advance(25);
	assert.equal(cache.get('item'), 'after');
	advance(74);
	assert.equal(cache.peek('item'), 'after');
	advance(1);
	assert.equal(cache.peek('item'), undefined);
	assert.equal(cache.get('item'), undefined);
	assert.equal(cache.has('item'), false);
	assert.deepEqual(evictions, [['item', 'after']]);
});

for (const [globalMaxAge, itemMaxAge] of [[50, 100], [100, 50]]) {
	test(`per-item maxAge ${itemMaxAge} overrides global maxAge ${globalMaxAge}`, t => {
		const advance = mockClock(t);
		const cache = new QuickLRU({maxSize: 3, maxAge: globalMaxAge});
		cache.set('default', 'default');
		cache.set('override', 'override', {maxAge: itemMaxAge});

		advance(Math.min(globalMaxAge, itemMaxAge) - 1);
		assert.equal(cache.peek('default'), 'default');
		assert.equal(cache.peek('override'), 'override');
		advance(1);
		assert.equal(cache.has('default'), globalMaxAge > itemMaxAge);
		assert.equal(cache.has('override'), itemMaxAge > globalMaxAge);
		advance(Math.abs(globalMaxAge - itemMaxAge));
		assert.equal(cache.has('default'), false);
		assert.equal(cache.has('override'), false);
	});
}

test('omitted and undefined maxAge use the global duration for every write', t => {
	const advance = mockClock(t);
	const cache = new QuickLRU({maxSize: 10, maxAge: 100});
	const options = [undefined, {}, {maxAge: undefined}];
	advance(500);
	for (const [key, option] of options.entries()) {
		cache.set(key, 'before', option);
	}
	advance(75);
	for (const [key, option] of options.entries()) {
		assert.equal(cache.get(key), 'before');
		cache.set(key, 'after', option);
	}

	advance(25);
	for (const key of options.keys()) {
		assert.equal(cache.get(key), 'after');
	}
	advance(74);
	for (const key of options.keys()) {
		assert.equal(cache.peek(key), 'after');
	}
	advance(1);
	for (const key of options.keys()) {
		assert.equal(cache.has(key), false);
	}
});

test('the default non-expiring duration survives insertion and replacement', t => {
	const advance = mockClock(t);
	const cache = new QuickLRU({maxSize: 4});
	cache.set('default', 'default');
	cache.set('undefined', 'undefined', {maxAge: undefined});
	cache.set('replacement', 'temporary', {maxAge: 10});
	assert.equal(cache.get('replacement'), 'temporary');
	advance(5);
	cache.set('replacement', 'permanent');

	advance(1_000_000);
	assert.equal(cache.get('default'), 'default');
	assert.equal(cache.peek('undefined'), 'undefined');
	assert.equal(cache.get('replacement'), 'permanent');
	assert.equal(cache.has('replacement'), true);
});

test('explicit Infinity overrides a finite global duration on insertion and replacement', t => {
	const advance = mockClock(t);
	const cache = new QuickLRU({maxSize: 4, maxAge: 50});
	cache.set('insert', 'permanent', {maxAge: Number.POSITIVE_INFINITY});
	cache.set('replacement', 'temporary');
	advance(25);
	cache.set('replacement', 'permanent', {maxAge: Number.POSITIVE_INFINITY});

	advance(1_000_000);
	assert.equal(cache.get('insert'), 'permanent');
	assert.equal(cache.peek('replacement'), 'permanent');
	assert.equal(cache.has('replacement'), true);
	assert.deepEqual([...cache.entriesAscending()], [
		['insert', 'permanent'],
		['replacement', 'permanent']
	]);
});

我会先检查 `maxAge` 在插入和替换时的处理，使用 diagnosing-bugs 技能定位原因，再修改 `index.js` 并添加基于公开 API 的回归测试，全程只在本地操作。

最小复现已失败：把时间固定为 `1,000,000`，写入 `{maxAge: 50}` 后立即读取，得到 `undefined`；预期应存活 50 毫秒。

我会依次核查三个原因：单项时长被直接当成到期时间；显式选项走了错误的默认值分支；替换或缓存迁移沿用了旧期限。前两项会影响新插入，第三项应只影响已有条目。回归测试会固定时钟，检查写入后、到期前及到期边界。

根因已确认：`set()` 只在未指定单项 `maxAge` 时加上 `Date.now()`；显式传入的时长则直接存进 `expiry`，随后被当作绝对时间戳比较。插入和替换分支都存在这个问题。

我会统一在写入时计算到期时间，并测试替换后重新计时、缓存轮换后的写入、构造器默认时长，以及默认和显式 `Infinity` 条目。

修复后，`npm test` 的 14 项测试全部通过；新增文件直接执行时，12 项回归测试也全部通过。默认时长和不失效条目的检查均通过，原有测试、元数据和文档未改动。我会再运行最初的最小复现，确认它也已恢复正常。

已修复 [index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/ttl-duration/baseline/trial-5/index.js:113)。根因是显式 `maxAge` 被直接当作到期时间戳；现在插入和替换统一按 `Date.now() + maxAge` 计算，保留默认时长和 `Infinity` 行为。

新增可执行的 [ttl-duration.test.mjs](<RUNS>/pmap-quicklru-original-v4-validation-2/ttl-duration/baseline/trial-5/ttl-duration.test.mjs)，使用 `node:test`、固定时钟和公开 API。

实际验证：

- 修复前回归测试有 8 项失败；修复后全部通过。
- `npm test`：14/14 通过。
- 直接执行新增测试：12/12 通过。
- 最初的最小复现及 `git diff --check` 通过。

原有测试、元数据和文档未改动，全程未联网。
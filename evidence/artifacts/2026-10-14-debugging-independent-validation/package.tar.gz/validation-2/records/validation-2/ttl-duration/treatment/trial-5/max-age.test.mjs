#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

const start = 1_700_000_000_000;

function clock(t) {
	let now = start;
	t.mock.method(Date, 'now', () => now);
	return elapsed => {
		now = start + elapsed;
	};
}

test('per-item maxAge starts at insertion and overrides the constructor duration', t => {
	const advance = clock(t);
	const evictions = [];
	const value = {name: 'item'};
	const cache = new QuickLRU({
		maxSize: 4,
		maxAge: 50,
		onEviction: (key, item) => evictions.push([key, item])
	});
	cache.set('item', value, {maxAge: 100});
	cache.set('default', 'default value');
	assert.equal(cache.get('item'), value);
	assert.equal(cache.has('item'), true);
	assert.equal(cache.peek('item'), value);

	advance(50);
	assert.equal(cache.has('default'), false);
	assert.equal(cache.get('item'), value);
	advance(99);
	assert.deepEqual([...cache], [['item', value]]);
	assert.equal(cache.peek('item'), value);
	advance(100);
	assert.equal(cache.get('item'), undefined);
	assert.equal(cache.has('item'), false);
	assert.equal(cache.peek('item'), undefined);
	assert.equal(cache.size, 0);
	assert.deepEqual(evictions, [['default', 'default value'], ['item', value]]);
});

for (const generation of ['recent', 'older']) {
	for (const replacement of ['same', 'different']) {
		test(`replacing a ${generation} entry with the ${replacement} value restarts its duration`, t => {
			const advance = clock(t);
			const evictions = [];
			const original = {name: 'original'};
			const value = replacement === 'same' ? original : {name: 'replacement'};
			const cache = new QuickLRU({
				maxSize: 2,
				onEviction: (key, item) => evictions.push([key, item])
			});
			cache.set('item', original, {maxAge: 100});
			if (generation === 'older') {
				cache.set('filler', 'filler value');
			}

			advance(75);
			cache.set('item', value, {maxAge: 200});
			assert.equal(cache.peek('item'), value);
			advance(100);
			assert.equal(cache.get('item'), value);
			advance(274);
			assert.equal(cache.has('item'), true);
			assert.deepEqual(evictions, []);
			advance(275);
			assert.equal(cache.has('item'), false);
			assert.equal(cache.get('item'), undefined);
			assert.equal(cache.peek('item'), undefined);
			assert.equal(cache.has('item'), false);
			assert.deepEqual(evictions, [['item', value]]);
		});
	}
}

test('omitted, empty and undefined options use the constructor duration on each write', t => {
	const advance = clock(t);
	const cache = new QuickLRU({maxSize: 4, maxAge: 100});
	cache.set('omitted', 'original');
	cache.set('empty', 'original', {});
	cache.set('undefined', 'original', {maxAge: undefined});
	advance(99);
	assert.deepEqual([...cache.values()], ['original', 'original', 'original']);
	advance(100);
	assert.deepEqual([...cache], []);

	cache.set('omitted', 'original');
	cache.set('empty', 'original', {});
	cache.set('undefined', 'original', {maxAge: undefined});
	advance(150);
	cache.set('omitted', 'replacement');
	cache.set('empty', 'replacement', {});
	cache.set('undefined', 'replacement', {maxAge: undefined});
	advance(200);
	assert.deepEqual([...cache.values()], ['replacement', 'replacement', 'replacement']);
	advance(249);
	assert.equal(cache.get('omitted'), 'replacement');
	advance(250);
	assert.deepEqual([...cache], []);
});

test('default and explicit Infinity entries remain non-expiring after insertion and replacement', t => {
	const advance = clock(t);
	const evictions = [];
	for (const options of [{maxSize: 4}, {maxSize: 4, maxAge: Infinity}, {maxSize: 4, maxAge: 100}]) {
		advance(0);
		const cache = new QuickLRU({
			...options,
			onEviction: (key, value) => evictions.push([key, value])
		});
		const defaultOptions = options.maxAge === 100 ? {maxAge: Infinity} : undefined;
		cache.set('default', 'original', defaultOptions);
		cache.set('explicit', 'original', {maxAge: Infinity});
		cache.set('replaced', 'original', {maxAge: 50});
		advance(25);
		cache.set('default', 'replacement', defaultOptions);
		cache.set('explicit', 'replacement', {maxAge: Infinity});
		cache.set('replaced', 'replacement', defaultOptions);
		advance(1_000_000_000_000);
		assert.equal(cache.get('default'), 'replacement');
		assert.equal(cache.peek('explicit'), 'replacement');
		assert.equal(cache.has('replaced'), true);
		assert.deepEqual([...cache.values()], ['replacement', 'replacement', 'replacement']);
	}
	assert.deepEqual(evictions, []);
});

test('a zero per-item duration expires on the write timestamp', t => {
	clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('item', 'value', {maxAge: 0});
	assert.equal(cache.get('item'), undefined);
	assert.equal(cache.has('item'), false);
	assert.deepEqual(evictions, [['item', 'value']]);
});

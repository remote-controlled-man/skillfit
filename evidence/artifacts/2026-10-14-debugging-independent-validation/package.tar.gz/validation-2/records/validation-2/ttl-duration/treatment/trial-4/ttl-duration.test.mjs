#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(t) {
	const clock = {now: 1_700_000_000_000};
	t.mock.method(Date, 'now', () => clock.now);
	return clock;
}

for (const maxAge of [undefined, 25]) {
	test(`an inserted item uses its own duration with constructor maxAge ${maxAge}`, t => {
		const clock = mockClock(t);
		const evictions = [];
		const cache = new QuickLRU({maxSize: 4, maxAge, onEviction: (...entry) => evictions.push(entry)});
		const value = {version: 'inserted'};
		cache.set('key', value, {maxAge: 100});

		assert.equal(cache.has('key'), true);
		assert.equal(cache.peek('key'), value);
		assert.equal(cache.get('key'), value);
		clock.now += 99;
		assert.equal(cache.get('key'), value);
		assert.deepEqual([...cache], [['key', value]]);
		assert.deepEqual(evictions, []);

		clock.now += 1;
		assert.equal(cache.has('key'), false);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.peek('key'), undefined);
		assert.deepEqual([...cache], []);
		assert.equal(cache.size, 0);
		assert.deepEqual(evictions, [['key', value]]);
	});
}

test('promotion from the older generation preserves the write deadline', t => {
	const clock = mockClock(t);
	const cache = new QuickLRU({maxSize: 2});
	cache.set('key', 'value', {maxAge: 100});
	cache.set('filler', 'filler');

	clock.now += 60;
	assert.equal(cache.peek('key'), 'value');
	assert.equal(cache.get('key'), 'value');
	clock.now += 39;
	assert.equal(cache.get('key'), 'value');
	clock.now += 1;
	assert.equal(cache.get('key'), undefined);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('filler'), 'filler');
});

for (const olderGeneration of [false, true]) {
	for (const sameValue of [false, true]) {
		test(`replacement resets the duration (older generation: ${olderGeneration}, same value: ${sameValue})`, t => {
			const clock = mockClock(t);
			const evictions = [];
			const cache = new QuickLRU({maxSize: 2, onEviction: (...entry) => evictions.push(entry)});
			const original = {version: 'original'};
			const replacement = sameValue ? original : {version: 'replacement'};
			cache.set('key', original, {maxAge: 20});
			if (olderGeneration) {
				cache.set('filler', 'filler');
			}

			clock.now += 10;
			cache.set('key', replacement, {maxAge: 80});
			assert.equal(cache.get('key'), replacement);
			clock.now += 10;
			assert.equal(cache.peek('key'), replacement);
			clock.now += 69;
			assert.equal(cache.has('key'), true);
			assert.equal(cache.get('key'), replacement);
			assert.deepEqual(evictions, []);

			clock.now += 1;
			assert.equal(cache.peek('key'), undefined);
			assert.equal(cache.has('key'), false);
			assert.equal(cache.get('key'), undefined);
			assert.equal(cache.get('key'), undefined);
			assert.deepEqual(evictions, [['key', replacement]]);
		});
	}
}

for (const [label, options] of [['omitted', undefined], ['empty', {}], ['undefined maxAge', {maxAge: undefined}]]) {
	test(`constructor duration applies to insertion and replacement with ${label} options`, t => {
		const clock = mockClock(t);
		const cache = new QuickLRU({maxSize: 4, maxAge: 100});
		cache.set('key', 'original', options);
		clock.now += 99;
		assert.equal(cache.get('key'), 'original');
		clock.now += 1;
		assert.equal(cache.get('key'), undefined);

		cache.set('key', 'before replacement', options);
		clock.now += 50;
		cache.set('key', 'replacement', options);
		clock.now += 50;
		assert.equal(cache.get('key'), 'replacement');
		clock.now += 49;
		assert.equal(cache.get('key'), 'replacement');
		clock.now += 1;
		assert.equal(cache.get('key'), undefined);
	});
}

test('default entries remain non-expiring on insertion and replacement', t => {
	const clock = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 4, onEviction: (...entry) => evictions.push(entry)});
	cache.set('omitted', 'initial');
	cache.set('empty options', 'initial', {});
	cache.set('undefined', 'initial', {maxAge: undefined});
	clock.now += 1_000_000_000;
	for (const key of ['omitted', 'empty options', 'undefined']) {
		assert.equal(cache.get(key), 'initial');
	}

	cache.set('omitted', 'replacement');
	cache.set('empty options', 'replacement', {});
	cache.set('undefined', 'replacement', {maxAge: undefined});
	clock.now += 1_000_000_000;
	assert.deepEqual([...cache.values()], ['replacement', 'replacement', 'replacement']);
	assert.deepEqual(evictions, []);
});

test('explicit Infinity overrides a finite constructor duration on insertion and replacement', t => {
	const clock = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 4, maxAge: 100, onEviction: (...entry) => evictions.push(entry)});
	cache.set('inserted', 'permanent', {maxAge: Infinity});
	cache.set('replaced', 'temporary');
	clock.now += 50;
	cache.set('replaced', 'permanent', {maxAge: Infinity});
	clock.now += 1_000_000_000;
	assert.equal(cache.has('inserted'), true);
	assert.equal(cache.get('inserted'), 'permanent');
	assert.equal(cache.peek('replaced'), 'permanent');
	assert.deepEqual([...cache], [['inserted', 'permanent'], ['replaced', 'permanent']]);
	assert.deepEqual(evictions, []);
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(t) {
	let now = 1_700_000_000_000;
	t.mock.method(Date, 'now', () => now);
	return milliseconds => {
		now += milliseconds;
	};
}

for (const history of ['insert', 'replace same value', 'replace different value', 'replace older entry']) {
	test(`per-item maxAge is a duration on ${history}`, t => {
		const advance = mockClock(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: history === 'replace older entry' ? 2 : 4,
			maxAge: 20,
			onEviction: (key, value) => evictions.push([key, value])
		});
		const original = {version: 'original'};
		const value = history === 'replace same value' ? original : {version: 'new'};

		if (history !== 'insert') {
			cache.set('key', original);
		}

		if (history === 'replace older entry') {
			cache.set('filler', 'keep', {maxAge: Infinity});
		}

		advance(10);
		cache.set('key', value, {maxAge: 50});
		assert.equal(cache.get('key'), value);
		assert.equal(cache.peek('key'), value);
		assert.equal(cache.has('key'), true);
		assert.deepEqual(evictions, []);

		advance(49);
		assert.equal(cache.peek('key'), value);
		assert.equal(cache.has('key'), true);

		advance(1);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.peek('key'), undefined);
		assert.equal(cache.has('key'), false);
		assert.deepEqual(evictions, [['key', value]]);
	});
}

test('reading an older entry preserves its original per-item deadline', t => {
	const advance = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'value', {maxAge: 50});
	cache.set('filler', 'keep');
	advance(20);
	assert.equal(cache.get('key'), 'value');
	advance(29);
	assert.equal(cache.peek('key'), 'value');
	advance(1);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('key'), undefined);
	assert.equal(cache.get('filler'), 'keep');
	assert.deepEqual(evictions, [['key', 'value']]);
});

for (const [label, options] of [
	['omitted options', undefined],
	['empty options', {}],
	['undefined maxAge', {maxAge: undefined}]
]) {
	for (const replace of [false, true]) {
		test(`constructor maxAge applies with ${label} on ${replace ? 'replacement' : 'insert'}`, t => {
			const advance = mockClock(t);
			const cache = new QuickLRU({maxSize: 4, maxAge: 50});
			if (replace) {
				cache.set('key', 'original');
			}

			advance(20);
			cache.set('key', 'value', options);
			advance(49);
			assert.equal(cache.get('key'), 'value');
			advance(1);
			assert.equal(cache.peek('key'), undefined);
			assert.equal(cache.has('key'), false);
		});
	}
}

for (const [label, constructorOptions, options] of [
	['default Infinity', {}, undefined],
	['constructor Infinity', {maxAge: Infinity}, {}],
	['per-item Infinity', {maxAge: 50}, {maxAge: Infinity}]
]) {
	for (const replace of [false, true]) {
		test(`${label} remains non-expiring on ${replace ? 'replacement' : 'insert'}`, t => {
			const advance = mockClock(t);
			const evictions = [];
			const cache = new QuickLRU({
				maxSize: 4,
				...constructorOptions,
				onEviction: (key, value) => evictions.push([key, value])
			});
			if (replace) {
				cache.set('key', 'original', {maxAge: 50});
			}

			advance(20);
			cache.set('key', 'value', options);
			advance(1_000_000);
			assert.equal(cache.get('key'), 'value');
			assert.equal(cache.peek('key'), 'value');
			assert.equal(cache.has('key'), true);
			assert.deepEqual([...cache], [['key', 'value']]);
			assert.deepEqual(evictions, []);
		});
	}
}

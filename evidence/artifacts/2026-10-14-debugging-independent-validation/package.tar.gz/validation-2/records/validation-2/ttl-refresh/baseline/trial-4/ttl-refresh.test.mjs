#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

test('updating an existing key renews its lifetime and expires the new value', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});

	cache.set('key', 'original', {maxAge: 100});
	now = 1050;
	cache.set('key', 'updated', {maxAge: 200});
	now = 1100;
	assert.equal(cache.get('key'), 'updated');
	assert.deepEqual(evictions, []);
	now = 1249;
	assert.equal(cache.peek('key'), 'updated');
	now = 1250;
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'updated']]);
});

test('an explicit maxAge is a lifetime measured from insertion', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 3, onEviction: (key, value) => evictions.push([key, value])});

	cache.set('key', 'value', {maxAge: 100});
	assert.equal(cache.get('key'), 'value');
	now = 1099;
	assert.equal(cache.peek('key'), 'value');
	assert.deepEqual(evictions, []);
	now = 1100;
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'value']]);
});

const expirationChecks = [
	['get', cache => assert.equal(cache.get('key'), undefined)],
	['peek', cache => assert.equal(cache.peek('key'), undefined)],
	['has', cache => assert.equal(cache.has('key'), false)],
	['iteration', (cache, entries) => assert.deepEqual([...cache].sort(), entries)],
	['entriesAscending', (cache, entries) => assert.deepEqual([...cache.entriesAscending()].sort(), entries)],
	['entriesDescending', (cache, entries) => assert.deepEqual([...cache.entriesDescending()].sort(), entries)],
	['keys', (cache, entries) => assert.deepEqual([...cache.keys()].sort(), entries.map(([key]) => key))],
	['values', (cache, entries) => assert.deepEqual([...cache.values()].sort(), entries.map(([, value]) => value))],
	['resize', cache => {
		cache.resize(4);
		assert.equal(cache.has('key'), false);
	}]
];

for (const generation of ['recent', 'older']) {
	for (const [name, checkExpiration] of expirationChecks) {
		test(`${name} expires a refreshed ${generation} entry once and preserves other entries`, t => {
			let now = 1000;
			t.mock.method(Date, 'now', () => now);
			const evictions = [];
			const cache = new QuickLRU({
				maxSize: 3,
				maxAge: 100,
				onEviction: (key, value) => evictions.push([key, value])
			});
			const survivors = [['keep', 'keep value']];
			cache.set('key', 'original');
			cache.set('keep', 'keep value', {maxAge: Infinity});
			now = 1050;
			cache.set('key', 'updated');
			if (generation === 'older') {
				cache.set('other', 'other value', {maxAge: Infinity});
				survivors.push(['other', 'other value']);
			}

			now = 1100;
			assert.equal(cache.peek('key'), 'updated');
			assert.deepEqual(evictions, []);
			now = 1150;
			checkExpiration(cache, survivors);
			assert.equal(cache.has('key'), false);
			assert.deepEqual(evictions, [['key', 'updated']]);
			for (const [key, value] of survivors) {
				assert.equal(cache.peek(key), value);
			}
			assert.equal(cache.size, survivors.length);
			assert.deepEqual([...cache].sort(), survivors);
			assert.deepEqual(evictions, [['key', 'updated']]);
		});
	}
}

test('refreshing an older key does not evict its stale value during rotation', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 2, maxAge: 100, onEviction: (key, value) => evictions.push([key, value])});
	cache.set('key', 'original');
	cache.set('other', 'other value', {maxAge: Infinity});
	now = 1050;
	cache.set('key', 'updated', {maxAge: 200});
	assert.equal(cache.peek('other'), 'other value');
	assert.deepEqual(evictions, []);
	cache.set('keep', 'keep value', {maxAge: Infinity});
	assert.deepEqual(evictions, [['other', 'other value']]);
	now = 1100;
	assert.equal(cache.get('key'), 'updated');
	now = 1249;
	assert.equal(cache.peek('key'), 'updated');
	now = 1250;
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['other', 'other value'], ['key', 'updated']]);
	assert.equal(cache.get('keep'), 'keep value');
	assert.equal(cache.size, 1);
	assert.deepEqual(evictions, [['other', 'other value'], ['key', 'updated']]);
});

test('updates can shorten a lifetime, disable expiration, and restore the default lifetime', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 3, maxAge: 100, onEviction: (key, value) => evictions.push([key, value])});
	cache.set('key', 'original', {maxAge: 1000});
	now = 1050;
	cache.set('key', 'shorter', {maxAge: 20});
	now = 1069;
	assert.equal(cache.peek('key'), 'shorter');
	now = 1070;
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', 'shorter']]);

	cache.set('key', 'finite');
	now = 1080;
	cache.set('key', 'permanent', {maxAge: Infinity});
	now = 2000;
	assert.equal(cache.get('key'), 'permanent');
	assert.deepEqual(evictions, [['key', 'shorter']]);
	cache.set('key', 'default lifetime');
	now = 2099;
	assert.equal(cache.peek('key'), 'default lifetime');
	now = 2100;
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', 'shorter'], ['key', 'default lifetime']]);
});

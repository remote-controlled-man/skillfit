#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function controlTime(t) {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	return time => {
		now = time;
	};
}

for (const sameValue of [false, true]) {
	test(`updating a current key renews the default lifetime (${sameValue ? 'same' : 'new'} value)`, t => {
		const advanceTo = controlTime(t);
		const evictions = [];
		const original = {version: 1};
		const updated = sameValue ? original : {version: 2};
		const survivor = {unrelated: true};
		const cache = new QuickLRU({
			maxSize: 4,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('target', original);
		cache.set('survivor', survivor, {maxAge: Infinity});
		advanceTo(1050);
		cache.set('target', updated);
		advanceTo(1100);
		assert.equal(cache.get('target'), updated);
		assert.deepEqual(evictions, []);
		advanceTo(1149);
		assert.equal(cache.peek('target'), updated);
		advanceTo(1150);
		assert.equal(cache.get('target'), undefined);
		assert.equal(cache.has('target'), false);
		assert.equal(cache.peek('target'), undefined);
		assert.deepEqual(evictions, [['target', updated]]);
		assert.equal(cache.get('survivor'), survivor);
		assert.equal(cache.size, 1);
	});
}

test('per-entry maxAge is a duration from each set, overriding the default', t => {
	const advanceTo = controlTime(t);
	const evictions = [];
	const key = {};
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 10,
		onEviction: (evictedKey, value) => evictions.push([evictedKey, value])
	});
	cache.set(key, 'original', {maxAge: 100});
	cache.set('survivor', 'keep', {maxAge: Infinity});
	advanceTo(1050);
	assert.equal(cache.peek(key), 'original');
	cache.set(key, 'updated', {maxAge: 200});
	advanceTo(1100);
	assert.equal(cache.get(key), 'updated');
	advanceTo(1249);
	assert.equal(cache.has(key), true);
	assert.deepEqual(evictions, []);
	advanceTo(1250);
	assert.equal(cache.has(key), false);
	assert.equal(cache.get(key), undefined);
	assert.deepEqual(evictions, [[key, 'updated']]);
	assert.equal(cache.get('survivor'), 'keep');
	assert.equal(cache.size, 1);
});

for (const promoteBeforeUpdate of [false, true]) {
	test(`renewed old-generation keys have no stale eviction (${promoteBeforeUpdate ? 'promoted' : 'direct'} update)`, t => {
		const advanceTo = controlTime(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 2,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('target', 'original');
		cache.set('older', 'older-value', {maxAge: Infinity});
		advanceTo(1050);
		if (promoteBeforeUpdate) {
			assert.equal(cache.get('target'), 'original');
		}

		cache.set('target', 'updated');
		cache.set('survivor', 'keep', {maxAge: Infinity});
		assert.deepEqual(evictions, [['older', 'older-value']]);
		advanceTo(1100);
		assert.equal(cache.peek('target'), 'updated');
		advanceTo(1150);
		assert.equal(cache.get('target'), undefined);
		assert.equal(cache.has('target'), false);
		assert.deepEqual(evictions, [['older', 'older-value'], ['target', 'updated']]);
		assert.equal(cache.get('survivor'), 'keep');
		assert.equal(cache.size, 1);
	});
}

const readers = {
	get: cache => cache.get('target'),
	peek: cache => cache.peek('target'),
	has: cache => cache.has('target'),
	iterator: cache => [...cache],
	keys: cache => [...cache.keys()],
	values: cache => [...cache.values()],
	entriesAscending: cache => [...cache.entriesAscending()],
	entriesDescending: cache => [...cache.entriesDescending()]
};

for (const [name, read] of Object.entries(readers)) {
	test(`${name} expires a refreshed value once and preserves unrelated entries`, t => {
		const advanceTo = controlTime(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 4,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('target', 'original');
		cache.set('survivor', 'keep', {maxAge: Infinity});
		advanceTo(1050);
		cache.set('target', 'updated');
		advanceTo(1150);
		const expected = name === 'has' ? false
			: name === 'get' || name === 'peek' ? undefined
				: name === 'keys' ? ['survivor']
					: name === 'values' ? ['keep'] : [['survivor', 'keep']];
		assert.deepEqual(read(cache), expected);
		assert.deepEqual(read(cache), expected);
		assert.deepEqual(evictions, [['target', 'updated']]);
		assert.equal(cache.get('survivor'), 'keep');
		assert.equal(cache.size, 1);
	});
}

test('capacity eviction reports the renewed value once', t => {
	const advanceTo = controlTime(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('target', 'original');
	cache.set('older', 'older-value', {maxAge: Infinity});
	advanceTo(1050);
	cache.set('target', 'updated');
	cache.set('recent', 'recent-value', {maxAge: Infinity});
	cache.set('survivor-a', 'a', {maxAge: Infinity});
	cache.set('survivor-b', 'b', {maxAge: Infinity});
	assert.deepEqual(evictions, [
		['older', 'older-value'],
		['target', 'updated'],
		['recent', 'recent-value']
	]);
	advanceTo(1150);
	assert.equal(cache.get('target'), undefined);
	assert.equal(cache.has('target'), false);
	assert.equal(evictions.length, 3);
	assert.deepEqual([...cache], [['survivor-a', 'a'], ['survivor-b', 'b']]);
	assert.equal(cache.size, 2);
});

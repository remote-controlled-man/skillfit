#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function mockClock(t) {
	let now = 1_000_000;
	t.mock.method(Date, 'now', () => now);
	return milliseconds => {
		now += milliseconds;
	};
}

const readers = [
	['get', cache => cache.get('target'), undefined],
	['peek', cache => cache.peek('target'), undefined],
	['has', cache => cache.has('target'), false],
	['iterator', cache => [...cache], [['other', 'keep']]],
	['keys', cache => [...cache.keys()], ['other']],
	['values', cache => [...cache.values()], ['keep']],
	['entriesAscending', cache => [...cache.entriesAscending()], [['other', 'keep']]],
	['entriesDescending', cache => [...cache.entriesDescending()], [['other', 'keep']]]
];

for (const [name, read, expiredResult] of readers) {
	test(`default maxAge renews on update and expires through ${name}`, t => {
		const advance = mockClock(t);
		const evictions = [];
		const updated = {version: 2};
		const cache = new QuickLRU({
			maxSize: 4,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('target', {version: 1});
		cache.set('other', 'keep', {maxAge: Infinity});
		advance(40);
		cache.set('target', updated);
		advance(60);
		assert.equal(cache.get('target'), updated, 'survives the original deadline');
		assert.deepEqual(evictions, []);
		advance(39);
		assert.equal(cache.peek('target'), updated);
		advance(1);
		assert.deepEqual(read(cache), expiredResult);
		assert.deepEqual(evictions, [['target', updated]]);
		assert.equal(evictions[0][1], updated, 'callback receives the application value');
		assert.equal(cache.size, 1);
		assert.equal(cache.get('other'), 'keep');
		assert.deepEqual(read(cache), expiredResult);
		assert.equal(cache.delete('target'), false);
		assert.deepEqual(evictions, [['target', updated]], 'expiration fires only once');
	});
}

for (const previous of [undefined, 'same', 'different']) {
	test(`per-entry maxAge is relative for an initial or updated value (${previous})`, t => {
		const advance = mockClock(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 4,
			maxAge: 10,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('other', 'keep', {maxAge: Infinity});
		if (previous !== undefined) {
			cache.set('target', previous, {maxAge: 50});
			assert.equal(cache.peek('target'), previous);
		}

		advance(20);
		cache.set('target', 'same', {maxAge: 80});
		advance(79);
		assert.equal(cache.get('target'), 'same');
		assert.deepEqual(evictions, []);
		advance(1);
		assert.equal(cache.has('target'), false);
		assert.deepEqual(evictions, [['target', 'same']]);
		assert.equal(cache.get('other'), 'keep');
		assert.equal(cache.size, 1);
	});
}

for (const promote of [false, true]) {
	test(`renewal survives an older generation${promote ? ' after get promotion' : ''}`, t => {
		const advance = mockClock(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('target', 'old');
		cache.set('a', 'keep a', {maxAge: Infinity});
		cache.set('b', 'keep b', {maxAge: Infinity});
		advance(40);
		if (promote) {
			assert.equal(cache.get('target'), 'old');
		}

		cache.set('target', 'updated', {maxAge: 100});
		advance(60);
		assert.equal(cache.peek('target'), 'updated');
		advance(40);
		assert.equal(cache.get('target'), undefined);
		assert.deepEqual(evictions, [['target', 'updated']]);
		assert.equal(cache.peek('a'), 'keep a');
		assert.equal(cache.peek('b'), 'keep b');
		assert.equal(cache.size, 2);
		assert.deepEqual([...cache.entriesAscending()], [['a', 'keep a'], ['b', 'keep b']]);
		assert.deepEqual(evictions, [['target', 'updated']]);
	});
}

for (const resize of [false, true]) {
	test(`eviction after renewal passes the updated value during ${resize ? 'resize' : 'capacity rotation'}`, t => {
		const advance = mockClock(t);
		const evictions = [];
		const updated = {version: 2};
		const cache = new QuickLRU({
			maxSize: 2,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('target', {version: 1});
		advance(40);
		cache.set('target', updated);
		cache.set('other', 'keep', {maxAge: Infinity});
		advance(60);
		assert.equal(cache.peek('target'), updated);
		assert.deepEqual(evictions, []);
		if (resize) {
			cache.resize(1);
		} else {
			assert.equal(cache.get('other'), 'keep');
			cache.set('new', 'keep new', {maxAge: Infinity});
		}

		assert.deepEqual(evictions, [['target', updated]]);
		assert.equal(evictions[0][1], updated);
		assert.equal(cache.has('target'), false);
		assert.equal(cache.peek('other'), 'keep');
		assert.equal(cache.size, resize ? 1 : 2);
	});
}

test('a per-entry update can shorten a lifetime without a constructor maxAge', t => {
	const advance = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('target', 'old', {maxAge: 100});
	cache.set('other', 'keep');
	advance(40);
	cache.set('target', 'updated', {maxAge: 20});
	advance(19);
	assert.equal(cache.get('target'), 'updated');
	assert.deepEqual(evictions, []);
	advance(1);
	assert.equal(cache.peek('target'), undefined);
	assert.deepEqual(evictions, [['target', 'updated']]);
	assert.equal(cache.get('other'), 'keep');
	assert.equal(cache.size, 1);
});

test('updates can replace finite and infinite lifetimes, including an undefined value', t => {
	const advance = mockClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('target', 'old');
	cache.set('other', 'keep', {maxAge: Infinity});
	advance(40);
	cache.set('target', 'unlimited', {maxAge: Infinity});
	advance(1_000);
	assert.equal(cache.get('target'), 'unlimited');
	assert.deepEqual(evictions, []);
	cache.set('target', undefined, {maxAge: 20});
	advance(19);
	assert.equal(cache.has('target'), true);
	assert.equal(cache.get('target'), undefined);
	advance(1);
	assert.equal(cache.has('target'), false);
	assert.deepEqual(evictions, [['target', undefined]]);
	assert.equal(cache.get('other'), 'keep');
	assert.equal(cache.size, 1);
});

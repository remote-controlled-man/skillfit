#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

test('updating an existing key renews its lifetime and expires the new value', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value]),
	});

	cache.set('key', 'original', {maxAge: 100});
	cache.set('unrelated', 'retained');
	now = 1050;
	cache.set('key', 'updated', {maxAge: 100});
	now = 1100;
	assert.equal(cache.get('key'), 'updated');
	assert.deepEqual(evictions, []);
	now = 1150;
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.equal(cache.get('unrelated'), 'retained');
	assert.equal(cache.size, 1);
});

test('an explicit maxAge is a lifetime measured from insertion', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 1000,
		onEviction: (key, value) => evictions.push([key, value]),
	});

	cache.set('key', 'value', {maxAge: 50});
	assert.equal(cache.peek('key'), 'value');
	now = 1049;
	assert.equal(cache.peek('key'), 'value');
	assert.deepEqual(evictions, []);
	now = 1050;
	assert.equal(cache.peek('key'), undefined);
	assert.deepEqual(evictions, [['key', 'value']]);
});

const readers = [
	['get', cache => cache.get('key') === 'updated'],
	['peek', cache => cache.peek('key') === 'updated'],
	['has', cache => cache.has('key')],
	['iteration', cache => [...cache].some(([key]) => key === 'key')],
	['keys', cache => [...cache.keys()].includes('key')],
	['values', cache => [...cache.values()].includes('updated')],
	['entriesAscending', cache => [...cache.entriesAscending()].some(([key]) => key === 'key')],
	['entriesDescending', cache => [...cache.entriesDescending()].some(([key]) => key === 'key')],
];

for (const [name, read] of readers) {
	test(`a default lifetime is renewed and expires exactly once through ${name}`, t => {
		let now = 1000;
		t.mock.method(Date, 'now', () => now);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value]),
		});

		cache.set('key', 'original');
		cache.set('unrelated', 'retained', {maxAge: Infinity});
		now = 1050;
		cache.set('key', 'updated');
		now = 1100;
		assert.equal(read(cache), true);
		now = 1149;
		assert.equal(read(cache), true);
		assert.deepEqual(evictions, []);
		now = 1150;
		assert.equal(read(cache), false);
		assert.deepEqual(evictions, [['key', 'updated']]);
		assert.equal(cache.has('key'), false);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.peek('key'), undefined);
		assert.deepEqual([...cache], [['unrelated', 'retained']]);
		assert.equal(cache.size, 1);
		assert.deepEqual(evictions, [['key', 'updated']]);
	});
}

for (const promote of [false, true]) {
	test(`an older key ${promote ? 'promoted before updating' : 'updated directly'} retains its renewed expiration`, t => {
		let now = 1000;
		t.mock.method(Date, 'now', () => now);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value]),
		});

		cache.set('key', 'original');
		cache.set('unrelated-a', 'a', {maxAge: Infinity});
		cache.set('unrelated-b', 'b', {maxAge: Infinity});
		now = 1050;
		if (promote) {
			assert.equal(cache.get('key'), 'original');
		}

		cache.set('key', 'updated');
		now = 1100;
		assert.equal(cache.peek('key'), 'updated');
		assert.deepEqual(evictions, []);
		now = 1150;
		assert.equal(cache.peek('key'), undefined);
		assert.deepEqual([...cache.entriesAscending()], [['unrelated-a', 'a'], ['unrelated-b', 'b']]);
		assert.equal(cache.size, 2);
		assert.deepEqual(evictions, [['key', 'updated']]);
	});
}

test('rotation evicts only the unreplaced older value, and the replacement later expires', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		maxAge: 1000,
		onEviction: (key, value) => evictions.push([key, value]),
	});

	cache.set('key', 'original');
	cache.set('older', 'evicted normally', {maxAge: Infinity});
	now = 1050;
	cache.set('key', 'updated', {maxAge: 100});
	assert.deepEqual(evictions, []);
	cache.set('unrelated', 'retained', {maxAge: Infinity});
	assert.deepEqual(evictions, [['older', 'evicted normally']]);
	now = 1149;
	assert.equal(cache.peek('key'), 'updated');
	now = 1150;
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('unrelated'), 'retained');
	assert.equal(cache.size, 1);
	assert.deepEqual(evictions, [['older', 'evicted normally'], ['key', 'updated']]);
});

for (const options of [undefined, {maxAge: Infinity}]) {
	test(`${options ? 'explicit' : 'default'} Infinity removes the previous finite lifetime on update`, t => {
		let now = 1000;
		t.mock.method(Date, 'now', () => now);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			onEviction: (key, value) => evictions.push([key, value]),
		});

		cache.set('key', 'original', {maxAge: 100});
		now = 1050;
		cache.set('key', 'updated', options);
		now = 100000;
		assert.equal(cache.get('key'), 'updated');
		assert.deepEqual(evictions, []);
	});
}

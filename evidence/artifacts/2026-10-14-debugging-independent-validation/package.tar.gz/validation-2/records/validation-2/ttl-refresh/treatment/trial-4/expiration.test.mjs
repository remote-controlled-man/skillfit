#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function clock(t) {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	return time => {
		now = time;
	};
}

const readers = [
	['get', cache => cache.get('target'), value => value, undefined],
	['peek', cache => cache.peek('target'), value => value, undefined],
	['has', cache => cache.has('target'), () => true, false],
	['iterator', cache => [...cache], value => [['stable', 'untouched'], ['target', value]], [['stable', 'untouched']]],
	['keys', cache => [...cache.keys()], () => ['stable', 'target'], ['stable']],
	['values', cache => [...cache.values()], value => ['untouched', value], ['untouched']],
	['entriesAscending', cache => [...cache.entriesAscending()], value => [['stable', 'untouched'], ['target', value]], [['stable', 'untouched']]],
	['entriesDescending', cache => [...cache.entriesDescending()], value => [['target', value], ['stable', 'untouched']], [['stable', 'untouched']]],
];

for (const [name, read, present, absent] of readers) {
	test(`updating a recent key renews its default lifetime through ${name}`, t => {
		const advance = clock(t);
		const evictions = [];
		const cache = new QuickLRU({maxSize: 4, maxAge: 100, onEviction: (...entry) => evictions.push(entry)});
		const replacement = {version: 2};
		cache.set('stable', 'untouched', {maxAge: Infinity});
		cache.set('target', {version: 1});
		advance(1075);
		cache.set('target', replacement);

		advance(1100);
		assert.deepEqual(read(cache), present(replacement));
		advance(1174);
		assert.deepEqual(read(cache), present(replacement));
		assert.deepEqual(evictions, []);
		advance(1175);
		assert.deepEqual(read(cache), absent);
		assert.deepEqual(evictions, [['target', replacement]]);
		assert.equal(cache.size, 1);
		assert.equal(cache.get('target'), undefined);
		assert.equal(cache.has('target'), false);
		assert.equal(cache.peek('stable'), 'untouched');
		assert.deepEqual(evictions, [['target', replacement]]);
	});
}

for (const history of ['new', 'same value', 'different value']) {
	test(`per-entry maxAge is a duration for a ${history} key`, t => {
		const advance = clock(t);
		const evictions = [];
		const cache = new QuickLRU({maxSize: 4, maxAge: 500, onEviction: (...entry) => evictions.push(entry)});
		const replacement = {version: 2};
		cache.set('stable', 'untouched');
		if (history !== 'new') {
			const previous = history === 'same value' ? replacement : {version: 1};
			cache.set('target', previous, {maxAge: 100});
			assert.equal(cache.get('target'), previous);
		}

		advance(1075);
		cache.set('target', replacement, {maxAge: 200});
		advance(1100);
		assert.equal(cache.get('target'), replacement);
		advance(1274);
		assert.equal(cache.peek('target'), replacement);
		assert.deepEqual(evictions, []);
		advance(1275);
		assert.equal(cache.get('target'), undefined);
		assert.deepEqual(evictions, [['target', replacement]]);
		assert.equal(cache.peek('stable'), 'untouched');
		advance(1500);
		assert.equal(cache.has('stable'), false);
		assert.deepEqual(evictions, [['target', replacement], ['stable', 'untouched']]);
	});
}

test('a refreshed older key survives rotation without a stale eviction callback', t => {
	const advance = clock(t);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 3, maxAge: 100, onEviction: (...entry) => evictions.push(entry)});
	const replacement = {version: 2};
	cache.set('target', {version: 1});
	cache.set('victim', 'old', {maxAge: Infinity});
	cache.set('stable', 'untouched', {maxAge: Infinity});
	advance(1075);
	cache.set('target', replacement);
	assert.equal(cache.get('stable'), 'untouched');
	cache.set('newcomer', 'new', {maxAge: Infinity});
	assert.deepEqual(evictions, [['victim', 'old']]);
	advance(1100);
	assert.equal(cache.get('target'), replacement);
	advance(1175);
	assert.equal(cache.get('target'), undefined);
	assert.deepEqual(evictions, [['victim', 'old'], ['target', replacement]]);
	assert.deepEqual([...cache.entriesAscending()], [['stable', 'untouched'], ['newcomer', 'new']]);
	assert.equal(cache.size, 2);
});

test('resize evicts the refreshed value and preserves unrelated entries', t => {
	const advance = clock(t);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 4, maxAge: 100, onEviction: (...entry) => evictions.push(entry)});
	cache.set('target', 'before');
	cache.set('stable', 'untouched', {maxAge: Infinity});
	advance(1075);
	cache.set('target', 'after');
	advance(1100);
	cache.resize(1);
	assert.deepEqual(evictions, [['target', 'after']]);
	assert.equal(cache.has('target'), false);
	assert.equal(cache.get('stable'), 'untouched');
	advance(1175);
	assert.equal(cache.has('target'), false);
	assert.deepEqual(evictions, [['target', 'after']]);
});

test('updates can change between finite and infinite lifetimes without a callback', t => {
	const advance = clock(t);
	const evictions = [];
	const cache = new QuickLRU({maxSize: 4, onEviction: (...entry) => evictions.push(entry)});
	cache.set('target', 'finite', {maxAge: 100});
	advance(1075);
	cache.set('target', 'default infinity');
	advance(5000);
	assert.equal(cache.get('target'), 'default infinity');
	cache.set('target', 'finite again', {maxAge: 100});
	advance(5099);
	assert.equal(cache.get('target'), 'finite again');
	cache.set('target', 'explicit infinity', {maxAge: Infinity});
	advance(10000);
	assert.equal(cache.get('target'), 'explicit infinity');
	assert.deepEqual(evictions, []);
	cache.set('target', 'last finite', {maxAge: 100});
	advance(10100);
	assert.equal(cache.get('target'), undefined);
	assert.deepEqual(evictions, [['target', 'last finite']]);
});

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

test('updating an existing key renews its lifetime and expires the new value', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});

	cache.set('key', 'original', {maxAge: 100});
	now = 1050;
	cache.set('key', 'updated', {maxAge: 100});

	now = 1100;
	assert.equal(cache.get('key'), 'updated');
	assert.deepEqual(evictions, []);

	now = 1150;
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.size, 0);
});

test('per-entry maxAge is a lifetime from insertion', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'value', {maxAge: 100});

	now = 1099;
	assert.equal(cache.peek('key'), 'value');
	assert.deepEqual(evictions, []);
	now = 1100;
	assert.equal(cache.peek('key'), undefined);
	assert.deepEqual(evictions, [['key', 'value']]);
});

test('an update without options renews the constructor maxAge', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('key', 'original');
	now = 1050;
	cache.set('key', 'updated');

	now = 1100;
	assert.equal(cache.get('key'), 'updated');
	now = 1149;
	assert.equal(cache.peek('key'), 'updated');
	now = 1150;
	assert.equal(cache.has('key'), false);
});

const readers = [
	['get', cache => cache.get('key'), undefined],
	['peek', cache => cache.peek('key'), undefined],
	['has', cache => cache.has('key'), false],
	['iterator', cache => [...cache], [['unrelated', 'retained']]],
	['keys', cache => [...cache.keys()], ['unrelated']],
	['values', cache => [...cache.values()], ['retained']],
	['entriesAscending', cache => [...cache.entriesAscending()], [['unrelated', 'retained']]],
	['entriesDescending', cache => [...cache.entriesDescending()], [['unrelated', 'retained']]]
];

for (const [name, read, expected] of readers) {
	test(`${name} expires the renewed value once and preserves unrelated entries`, t => {
		let now = 1000;
		t.mock.method(Date, 'now', () => now);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('key', 'original');
		cache.set('unrelated', 'retained', {maxAge: Infinity});
		now = 1050;
		cache.set('key', 'updated', {maxAge: 100});

		now = 1150;
		assert.deepEqual(read(cache), expected);
		assert.deepEqual(evictions, [['key', 'updated']]);
		assert.deepEqual(read(cache), expected);
		assert.deepEqual(evictions, [['key', 'updated']]);
		assert.equal(cache.peek('unrelated'), 'retained');
		assert.equal(cache.size, 1);
	});
}

test('updating an old-generation key preserves its unrelated neighbors', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'original');
	cache.set('first', 1, {maxAge: Infinity});
	cache.set('second', 2, {maxAge: Infinity});
	now = 1050;
	cache.set('key', 'updated', {maxAge: 100});

	now = 1100;
	assert.equal(cache.peek('key'), 'updated');
	assert.deepEqual(evictions, []);
	now = 1150;
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.deepEqual([...cache.entriesAscending()], [['first', 1], ['second', 2]]);
	assert.equal(cache.size, 2);
});

test('rotation evicts only displaced entries, then expires the refreshed value', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'original');
	cache.set('displaced', 'old neighbor');
	now = 1050;
	cache.set('key', 'updated', {maxAge: 100});
	cache.set('unrelated', 'retained');

	assert.deepEqual(evictions, [['displaced', 'old neighbor']]);
	now = 1149;
	assert.equal(cache.get('key'), 'updated');
	assert.equal(cache.peek('unrelated'), 'retained');
	now = 1150;
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['displaced', 'old neighbor'], ['key', 'updated']]);
	assert.equal(cache.get('unrelated'), 'retained');
	assert.equal(cache.size, 1);
});

test('refreshing to Infinity and back replaces the previous expiration', t => {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('key', 'original');
	now = 1050;
	cache.set('key', 'permanent', {maxAge: Infinity});
	now = 1200;
	assert.equal(cache.peek('key'), 'permanent');
	cache.set('key', 'temporary', {maxAge: 100});
	now = 1299;
	assert.equal(cache.peek('key'), 'temporary');
	now = 1300;
	assert.equal(cache.peek('key'), undefined);
});

for (const name of ['get', 'peek']) {
	test(`${name} handles an immediate expiration at timestamp zero`, t => {
		t.mock.method(Date, 'now', () => 0);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('key', 'value', {maxAge: 0});
		assert.equal(cache[name]('key'), undefined);
		assert.deepEqual(evictions, [['key', 'value']]);
		assert.equal(cache.has('key'), false);
	});
}

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function useClock(t) {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	return time => {
		now = time;
	};
}

test('updating a key renews its lifetime and expires the new value', t => {
	const setTime = useClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 10,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'original', {maxAge: 100});
	cache.set('unrelated', 'preserved');
	setTime(1050);
	cache.set('key', 'updated', {maxAge: 200});
	setTime(1100);
	assert.equal(cache.get('key'), 'updated');
	assert.deepEqual(evictions, []);
	setTime(1249);
	assert.equal(cache.peek('key'), 'updated');
	setTime(1250);
	assert.equal(cache.get('key'), undefined);
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.equal(cache.get('unrelated'), 'preserved');
	assert.equal(cache.size, 1);
});

test('an explicit maxAge is a duration from insertion', t => {
	const setTime = useClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 10,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'value', {maxAge: 100});
	assert.equal(cache.peek('key'), 'value');
	setTime(1099);
	assert.equal(cache.get('key'), 'value');
	setTime(1100);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'value']]);
});

test('updates also renew the constructor maxAge', t => {
	const setTime = useClock(t);
	const cache = new QuickLRU({maxSize: 10, maxAge: 100});
	cache.set('key', 'original');
	setTime(1050);
	cache.set('key', 'updated');
	setTime(1100);
	assert.equal(cache.get('key'), 'updated');
	setTime(1149);
	assert.equal(cache.get('key'), 'updated');
	setTime(1150);
	assert.equal(cache.get('key'), undefined);
});

test('updates can switch between finite and infinite lifetimes', t => {
	const setTime = useClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 10,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'original');
	cache.set('unrelated', 'preserved', {maxAge: Infinity});
	setTime(1050);
	cache.set('key', 'immortal', {maxAge: Infinity});
	setTime(2000);
	assert.equal(cache.get('key'), 'immortal');
	assert.deepEqual(evictions, []);
	cache.set('key', 'finite', {maxAge: 50});
	setTime(2049);
	assert.equal(cache.get('key'), 'finite');
	setTime(2050);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'finite']]);
	assert.equal(cache.get('unrelated'), 'preserved');
});

test('renewing a key in the older generation does not resurrect its old value', t => {
	const setTime = useClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'original', {maxAge: 100});
	cache.set('unrelated-a', 'a');
	cache.set('unrelated-b', 'b');
	setTime(1050);
	cache.set('key', 'updated', {maxAge: 200});
	setTime(1100);
	assert.equal(cache.peek('key'), 'updated');
	assert.deepEqual(evictions, []);
	setTime(1250);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.deepEqual([...cache.entriesAscending()], [['unrelated-a', 'a'], ['unrelated-b', 'b']]);
	assert.equal(cache.size, 2);
	cache.set('new-a', 'new a');
	cache.set('new-b', 'new b');
	assert.equal(cache.peek('unrelated-a'), 'a');
	assert.equal(cache.peek('unrelated-b'), 'b');
	assert.deepEqual(evictions, [['key', 'updated']]);
});

test('capacity eviction reports the updated value once', t => {
	const setTime = useClock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'original', {maxAge: 100});
	setTime(1050);
	cache.set('key', 'updated', {maxAge: 200});
	cache.set('companion', 'companion value');
	cache.set('new-a', 'a');
	cache.set('new-b', 'b');
	assert.deepEqual(evictions, [['key', 'updated'], ['companion', 'companion value']]);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.get('new-a'), 'a');
	assert.equal(cache.get('new-b'), 'b');
	assert.deepEqual(evictions, [['key', 'updated'], ['companion', 'companion value']]);
});

const readers = [
	['has', cache => cache.has('key')],
	['iterator', cache => [...cache].some(([key, value]) => key === 'key' && value === 'updated')],
	['keys', cache => [...cache.keys()].includes('key')],
	['values', cache => [...cache.values()].includes('updated')],
	['entriesAscending', cache => [...cache.entriesAscending()].some(([key, value]) => key === 'key' && value === 'updated')],
	['entriesDescending', cache => [...cache.entriesDescending()].some(([key, value]) => key === 'key' && value === 'updated')]
];

for (const [name, read] of readers) {
	test(`${name} expires a renewed key once and preserves unrelated entries`, t => {
		const setTime = useClock(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 10,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('key', 'original', {maxAge: 100});
		cache.set('unrelated', 'preserved');
		setTime(1050);
		cache.set('key', 'updated', {maxAge: 200});
		setTime(1249);
		assert.equal(read(cache), true);
		assert.deepEqual(evictions, []);
		setTime(1250);
		assert.equal(read(cache), false);
		assert.equal(read(cache), false);
		assert.deepEqual(evictions, [['key', 'updated']]);
		assert.equal(cache.peek('unrelated'), 'preserved');
		assert.equal(cache.size, 1);
	});
}

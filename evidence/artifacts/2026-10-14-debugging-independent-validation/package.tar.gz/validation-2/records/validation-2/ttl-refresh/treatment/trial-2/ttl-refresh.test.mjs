#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function clock(t) {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	return time => {
		now = time;
	};
}

const expirationReads = [
	['get', cache => assert.equal(cache.get('key'), undefined)],
	['peek', cache => assert.equal(cache.peek('key'), undefined)],
	['has', cache => assert.equal(cache.has('key'), false)],
	['iterator', cache => assert.deepEqual([...cache], [['other', 'stable']])],
	['keys', cache => assert.deepEqual([...cache.keys()], ['other'])],
	['values', cache => assert.deepEqual([...cache.values()], ['stable'])],
	['ascending entries', cache => assert.deepEqual([...cache.entriesAscending()], [['other', 'stable']])],
	['descending entries', cache => assert.deepEqual([...cache.entriesDescending()], [['other', 'stable']])],
	['resize', cache => {
		cache.resize(8);
		assert.deepEqual([...cache], [['other', 'stable']]);
	}]
];

for (const [name, read] of expirationReads) {
	test(`renewed constructor lifetime expires through ${name}`, t => {
		const at = clock(t);
		const evictions = [];
		const initial = {version: 1};
		const updated = {version: 2};
		const cache = new QuickLRU({
			maxSize: 8,
			maxAge: 100,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('other', 'stable', {maxAge: Infinity});
		cache.set('key', initial);
		at(1060);
		cache.set('key', updated);
		at(1100);
		assert.equal(cache.get('key'), updated);
		assert.deepEqual(evictions, []);
		at(1159);
		assert.equal(cache.peek('key'), updated);
		at(1160);
		read(cache);
		assert.deepEqual(evictions, [['key', updated]]);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.peek('key'), undefined);
		assert.equal(cache.has('key'), false);
		assert.equal(cache.delete('key'), false);
		assert.equal(cache.get('other'), 'stable');
		assert.equal(cache.size, 1);
		assert.deepEqual(evictions, [['key', updated]]);
	});
}

test('per-entry maxAge is a duration and each update renews it', t => {
	const at = clock(t);
	const evictions = [];
	const key = {};
	const cache = new QuickLRU({
		maxSize: 4,
		maxAge: 20,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('other', 'stable', {maxAge: Infinity});
	cache.set(key, 'first', {maxAge: 100});
	at(1059);
	assert.equal(cache.get(key), 'first');
	at(1060);
	cache.set(key, 'updated', {maxAge: 200});
	at(1259);
	assert.equal(cache.peek(key), 'updated');
	cache.set(key, 'updated', {maxAge: 50});
	at(1260);
	assert.equal(cache.has(key), true);
	at(1308);
	assert.equal(cache.get(key), 'updated');
	at(1309);
	assert.equal(cache.has(key), false);
	assert.deepEqual(evictions, [[key, 'updated']]);
	assert.equal(cache.get('other'), 'stable');
	assert.equal(cache.size, 1);
});

test('updating an old-generation key preserves its renewed expiration', t => {
	const at = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'first');
	cache.set('other', 'stable', {maxAge: Infinity});
	at(1060);
	cache.set('key', 'updated');
	assert.equal(cache.get('other'), 'stable');
	assert.deepEqual(evictions, []);
	at(1100);
	assert.equal(cache.get('key'), 'updated');
	at(1159);
	assert.equal(cache.peek('key'), 'updated');
	at(1160);
	assert.equal(cache.get('key'), undefined);
	assert.deepEqual(evictions, [['key', 'updated']]);
	assert.equal(cache.get('other'), 'stable');
	assert.equal(cache.size, 1);
});

test('capacity eviction reports the updated value once and keeps recent entries', () => {
	const evictions = [];
	const updated = {version: 2};
	const cache = new QuickLRU({
		maxSize: 2,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', {version: 1});
	cache.set('other', 'stable');
	cache.set('key', updated);
	assert.equal(cache.get('other'), 'stable');
	assert.deepEqual(evictions, []);
	cache.set('recent', 'recent value');
	cache.set('newest', 'newest value');
	assert.deepEqual(evictions, [['key', updated], ['other', 'stable']]);
	assert.equal(cache.has('key'), false);
	assert.equal(cache.has('other'), false);
	assert.equal(cache.get('recent'), 'recent value');
	assert.equal(cache.get('newest'), 'newest value');
	assert.equal(cache.size, 2);
});

test('updates can remove a lifetime or restore the constructor default', t => {
	const at = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 4,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('key', 'first');
	at(1060);
	cache.set('key', 'persistent', {maxAge: Infinity});
	at(2000);
	assert.equal(cache.get('key'), 'persistent');
	cache.set('key', undefined);
	at(2099);
	assert.equal(cache.has('key'), true);
	at(2100);
	assert.equal(cache.has('key'), false);
	assert.deepEqual(evictions, [['key', undefined]]);
});

for (const replacement of ['absent', 'same', 'different']) {
	test(`expiration callback may delete the key and leave it ${replacement}`, t => {
		const at = clock(t);
		const evictions = [];
		const initial = {version: 1};
		const updated = replacement === 'same' ? initial : {version: 2};
		const cache = new QuickLRU({
			maxSize: 4,
			maxAge: 100,
			onEviction(key, value) {
				evictions.push([key, value]);
				cache.delete(key);
				if (evictions.length === 1 && replacement !== 'absent') {
					cache.set(key, updated);
				}
			}
		});
		cache.set('key', initial);
		cache.set('other', 'stable', {maxAge: Infinity});
		at(1100);
		assert.equal(cache.get('key'), undefined);
		assert.deepEqual(evictions, [['key', initial]]);
		assert.equal(cache.has('key'), replacement !== 'absent');
		assert.equal(cache.peek('key'), replacement === 'absent' ? undefined : updated);
		assert.equal(cache.get('other'), 'stable');
		assert.equal(cache.size, replacement === 'absent' ? 1 : 2);
		at(1200);
		assert.equal(cache.get('key'), undefined);
		assert.deepEqual(evictions, replacement === 'absent' ? [['key', initial]] : [['key', initial], ['key', updated]]);
		assert.equal(cache.has('key'), false);
		assert.equal(cache.get('other'), 'stable');
		assert.equal(cache.size, 1);
	});
}

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

function clock(t) {
	let now = 1000;
	t.mock.method(Date, 'now', () => now);
	return time => {
		now = time;
	};
}

test('updating a recent key renews its default lifetime and expires the new value', t => {
	const advanceTo = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 4,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	const oldValue = {version: 1};
	const newValue = {version: 2};
	cache.set('renewed', oldValue);
	cache.set('unrelated', 'keep', {maxAge: Infinity});
	advanceTo(1050);
	cache.set('renewed', newValue);
	advanceTo(1100);
	assert.equal(cache.get('renewed'), newValue);
	assert.deepEqual(evictions, []);
	advanceTo(1149);
	assert.equal(cache.peek('renewed'), newValue);
	advanceTo(1150);
	assert.equal(cache.get('renewed'), undefined);
	assert.equal(cache.has('renewed'), false);
	assert.equal(cache.peek('renewed'), undefined);
	assert.deepEqual(evictions, [['renewed', newValue]]);
	assert.equal(cache.get('unrelated'), 'keep');
	assert.equal(cache.size, 1);
});

test('an explicit maxAge is a lifetime measured from each set', t => {
	const advanceTo = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 4,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('renewed', 'old', {maxAge: 100});
	assert.equal(cache.peek('renewed'), 'old');
	advanceTo(1050);
	cache.set('renewed', 'new', {maxAge: 200});
	advanceTo(1100);
	assert.equal(cache.peek('renewed'), 'new');
	advanceTo(1249);
	assert.equal(cache.has('renewed'), true);
	advanceTo(1250);
	assert.equal(cache.peek('renewed'), undefined);
	assert.equal(cache.has('renewed'), false);
	assert.deepEqual(evictions, [['renewed', 'new']]);
});

const readers = [
	['get', cache => cache.get('renewed'), undefined],
	['peek', cache => cache.peek('renewed'), undefined],
	['has', cache => cache.has('renewed'), false],
	['iteration', cache => [...cache], [['unrelated', 'keep']]],
	['entriesAscending', cache => [...cache.entriesAscending()], [['unrelated', 'keep']]],
	['entriesDescending', cache => [...cache.entriesDescending()], [['unrelated', 'keep']]],
	['keys', cache => [...cache.keys()], ['unrelated']],
	['values', cache => [...cache.values()], ['keep']],
	['resize', cache => {
		cache.resize(1);
		return [...cache];
	}, [['unrelated', 'keep']]]
];

for (const generation of ['recent', 'older']) {
	for (const [name, read, expected] of readers) {
		test(`${name} expires a renewed ${generation} entry once and preserves unrelated entries`, t => {
			const advanceTo = clock(t);
			const evictions = [];
			const cache = new QuickLRU({
				maxSize: 4,
				maxAge: 100,
				onEviction: (key, value) => evictions.push([key, value])
			});
			const newValue = {version: 2};
			cache.set('renewed', {version: 1});
			cache.set('unrelated', 'keep', {maxAge: Infinity});
			advanceTo(1050);
			assert.equal(cache.set('renewed', newValue), cache);
			if (generation === 'older') {
				cache.resize(2);
			}

			advanceTo(1100);
			assert.equal(cache.peek('renewed'), newValue);
			assert.deepEqual(evictions, []);
			advanceTo(1150);
			assert.deepEqual(read(cache), expected);
			assert.deepEqual(evictions, [['renewed', newValue]]);
			assert.equal(cache.get('renewed'), undefined);
			assert.equal(cache.has('renewed'), false);
			assert.equal(cache.get('unrelated'), 'keep');
			assert.equal(cache.size, 1);
			assert.deepEqual(evictions, [['renewed', newValue]]);
		});
	}
}

test('updating an older key expires only its latest value and keeps other lifetimes', t => {
	const advanceTo = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		onEviction: (key, value) => evictions.push([key, value])
	});
	const key = {};
	const newValue = {version: 2};
	cache.set(key, {version: 1}, {maxAge: 100});
	cache.set('unrelated', 'keep');
	cache.set('other-expiring', 'independent', {maxAge: 300});
	advanceTo(1050);
	assert.equal(cache.set(key, newValue, {maxAge: 200}), cache);
	advanceTo(1100);
	assert.equal(cache.peek(key), newValue);
	advanceTo(1249);
	assert.equal(cache.has(key), true);
	advanceTo(1250);
	assert.equal(cache.get(key), undefined);
	assert.deepEqual([...cache], [['unrelated', 'keep'], ['other-expiring', 'independent']]);
	assert.equal(cache.size, 2);
	assert.deepEqual(evictions, [[key, newValue]]);
	advanceTo(1300);
	assert.equal(cache.has('other-expiring'), false);
	assert.equal(cache.get('unrelated'), 'keep');
	assert.deepEqual(evictions, [[key, newValue], ['other-expiring', 'independent']]);
});

for (const history of ['first set', 'same value', 'different value', 'undefined value']) {
	test(`set returns the cache and applies a finite lifetime with ${history}`, t => {
		const advanceTo = clock(t);
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			onEviction: (key, value) => evictions.push([key, value])
		});
		const value = history === 'undefined value' ? undefined : {version: 2};
		if (history !== 'first set') {
			cache.set('renewed', history === 'same value' ? value : {version: 1});
		}

		advanceTo(1050);
		assert.equal(cache.set('renewed', value, {maxAge: 100}), cache);
		advanceTo(1149);
		assert.equal(cache.has('renewed'), true);
		assert.equal(cache.get('renewed'), value);
		advanceTo(1150);
		assert.equal(cache.has('renewed'), false);
		assert.deepEqual(evictions, [['renewed', value]]);
	});
}

test('Infinity cancels a previous deadline and a later finite lifetime still expires', t => {
	const advanceTo = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 3,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	cache.set('renewed', 'old');
	advanceTo(1050);
	cache.set('renewed', 'unlimited', {maxAge: Infinity});
	advanceTo(2000);
	assert.equal(cache.get('renewed'), 'unlimited');
	assert.deepEqual(evictions, []);
	cache.set('renewed', 'finite');
	advanceTo(2099);
	assert.equal(cache.peek('renewed'), 'finite');
	advanceTo(2100);
	assert.equal(cache.get('renewed'), undefined);
	assert.deepEqual(evictions, [['renewed', 'finite']]);
});

test('renewed entries expire without an eviction callback', t => {
	const advanceTo = clock(t);
	const cache = new QuickLRU({maxSize: 3, maxAge: 100});
	cache.set('renewed', 'old');
	cache.set('unrelated', 'keep', {maxAge: Infinity});
	advanceTo(1050);
	cache.set('renewed', 'new');
	advanceTo(1150);
	assert.equal(cache.get('renewed'), undefined);
	assert.equal(cache.size, 1);
	assert.equal(cache.get('unrelated'), 'keep');
});

test('capacity eviction reports the updated application value before its deadline', t => {
	const advanceTo = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 2,
		maxAge: 100,
		onEviction: (key, value) => evictions.push([key, value])
	});
	const newValue = {version: 2};
	cache.set('renewed', {version: 1});
	advanceTo(1050);
	cache.set('renewed', newValue);
	cache.set('old-unrelated', 'old');
	cache.set('retained-a', 'a', {maxAge: Infinity});
	cache.set('retained-b', 'b', {maxAge: Infinity});
	assert.deepEqual(evictions, [['renewed', newValue], ['old-unrelated', 'old']]);
	assert.equal(cache.has('renewed'), false);
	assert.deepEqual([...cache], [['retained-a', 'a'], ['retained-b', 'b']]);
	assert.equal(cache.size, 2);
	advanceTo(1150);
	assert.equal(cache.has('renewed'), false);
	assert.equal(evictions.length, 2);
});

test('expiration preserves entries inserted by its eviction callback', t => {
	const advanceTo = clock(t);
	const evictions = [];
	const cache = new QuickLRU({
		maxSize: 4,
		maxAge: 100,
		onEviction: (key, value) => {
			evictions.push([key, value]);
			cache.set('from-callback', 'added', {maxAge: Infinity});
		}
	});
	cache.set('renewed', 'old');
	cache.set('unrelated', 'keep', {maxAge: Infinity});
	advanceTo(1050);
	cache.set('renewed', 'new');
	advanceTo(1150);
	assert.equal(cache.get('renewed'), undefined);
	assert.deepEqual(evictions, [['renewed', 'new']]);
	assert.deepEqual([...cache], [['unrelated', 'keep'], ['from-callback', 'added']]);
	assert.equal(cache.size, 2);
});

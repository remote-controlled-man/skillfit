我会先按 diagnosing-bugs 技能检查过期与淘汰逻辑，再修改 `index.js` 并新增使用公开 API 的回归测试；全程只在当前工作区操作，不访问网络。
已发现两个直接原因：更新已有键时写入的是 `maxAge` 字段，而过期检查读取 `expiry`；显式传入的 `maxAge` 还被当作绝对时间戳，导致新键可能立即过期。我会先用可控时钟复现，再检查续期后的过期回调、容量淘汰回调和其他缓存项。
原有 2 项测试通过；新增的 15 项回归测试在修复前有 13 项失败，复现了更新后不再过期、显式寿命被误作时间戳的问题。修复将统一按每次 `set` 的时间计算 `expiry`，并验证过期回调只触发一次、传入更新后的值，且其他键仍然保留。
已修复 [index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/ttl-refresh/treatment/trial-1/index.js:113)。原更新分支写入 `maxAge`，但过期检查读取 `expiry`；显式 `maxAge` 也被误作绝对时间戳。现在每次 `set` 都从当前时间计算截止时间，新值在续期后正常过期。

新增可执行 [expiration.test.mjs](<RUNS>/pmap-quicklru-original-v4-validation-2/ttl-refresh/treatment/trial-1/expiration.test.mjs)，通过公开 API 验证续期、回调只触发一次并收到新值、容量淘汰及无关条目保留。

实际检查：修复前 13 项回归失败；修复后 `npm test` 全部 19 项通过，直接执行新增文件全部 17 项通过。原测试、元数据及文档未改，未使用网络。
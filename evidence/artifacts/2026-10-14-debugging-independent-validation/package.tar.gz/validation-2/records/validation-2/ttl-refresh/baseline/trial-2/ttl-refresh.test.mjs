#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import QuickLRU from './index.js';

const withClock = callback => {
	const originalNow = Date.now;
	let now = 1000;
	Date.now = () => now;
	try {
		callback(time => {
			now = time;
		});
	} finally {
		Date.now = originalNow;
	}
};

test('updating a key renews its lifetime and expires the new value once', () => {
	withClock(setTime => {
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 8,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('updated', 'old', {maxAge: 10});
		cache.set('unrelated', 'keep');
		setTime(1005);
		cache.set('updated', 'new', {maxAge: 20});
		setTime(1010);
		assert.equal(cache.get('updated'), 'new');
		assert.deepEqual(evictions, []);
		setTime(1024);
		assert.equal(cache.peek('updated'), 'new');
		setTime(1025);
		assert.equal(cache.get('updated'), undefined);
		assert.equal(cache.has('updated'), false);
		assert.equal(cache.peek('updated'), undefined);
		assert.deepEqual(evictions, [['updated', 'new']]);
		assert.equal(cache.get('unrelated'), 'keep');
		assert.equal(cache.size, 1);
	});
});

test('an explicit maxAge is a lifetime measured from insertion', () => {
	withClock(setTime => {
		const cache = new QuickLRU({maxSize: 8});
		cache.set('key', 'value', {maxAge: 20});
		assert.equal(cache.get('key'), 'value');
		setTime(1019);
		assert.equal(cache.peek('key'), 'value');
		setTime(1020);
		assert.equal(cache.has('key'), false);
	});
});

test('updates renew the default lifetime without rotating unrelated entries', () => {
	withClock(setTime => {
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 3,
			maxAge: 10,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('key', 'old');
		cache.set('unrelated', 'keep', {maxAge: Infinity});
		setTime(1005);
		for (let i = 0; i < 10; i++) {
			cache.set('key', i);
		}
		setTime(1010);
		assert.equal(cache.get('key'), 9);
		assert.equal(cache.peek('unrelated'), 'keep');
		assert.equal(cache.size, 2);
		assert.deepEqual(evictions, []);
		setTime(1015);
		assert.equal(cache.get('key'), undefined);
		assert.deepEqual(evictions, [['key', 9]]);
		assert.equal(cache.get('unrelated'), 'keep');
		assert.equal(cache.size, 1);
	});
});

test('updating an old-generation key does not evict its superseded value', () => {
	withClock(setTime => {
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 2,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('key', 'old', {maxAge: 10});
		cache.set('unrelated', 'keep');
		setTime(1005);
		cache.set('key', 'new', {maxAge: 20});
		assert.equal(cache.peek('unrelated'), 'keep');
		assert.deepEqual(evictions, []);
		cache.set('other', 'other value');
		assert.deepEqual(evictions, [['unrelated', 'keep']]);
		setTime(1010);
		assert.equal(cache.peek('key'), 'new');
		setTime(1025);
		assert.equal(cache.get('key'), undefined);
		assert.equal(cache.has('key'), false);
		assert.deepEqual(evictions, [['unrelated', 'keep'], ['key', 'new']]);
		assert.equal(cache.peek('other'), 'other value');
		assert.equal(cache.size, 1);
	});
});

const expirationReaders = [
	['get', cache => cache.get('key'), undefined],
	['has', cache => cache.has('key'), false],
	['peek', cache => cache.peek('key'), undefined],
	['iteration', cache => [...cache], [['unrelated', 'keep']]],
	['keys', cache => [...cache.keys()], ['unrelated']],
	['values', cache => [...cache.values()], ['keep']],
	['entriesAscending', cache => [...cache.entriesAscending()], [['unrelated', 'keep']]],
	['entriesDescending', cache => [...cache.entriesDescending()], [['unrelated', 'keep']]]
];

for (const [name, read, expected] of expirationReaders) {
	test(`${name} expires an updated key and reports only its new value`, () => {
		withClock(setTime => {
			const evictions = [];
			const cache = new QuickLRU({
				maxSize: 3,
				onEviction: (key, value) => evictions.push([key, value])
			});
			cache.set('key', 'old', {maxAge: 10});
			cache.set('unrelated', 'keep');
			setTime(1005);
			cache.set('key', 'new', {maxAge: 20});
			setTime(1025);
			assert.deepEqual(read(cache), expected);
			assert.deepEqual(read(cache), expected);
			assert.deepEqual(evictions, [['key', 'new']]);
			assert.equal(cache.get('unrelated'), 'keep');
			assert.equal(cache.size, 1);
		});
	});
}

test('an update can override or remove the default expiration', () => {
	withClock(setTime => {
		const evictions = [];
		const cache = new QuickLRU({
			maxSize: 8,
			maxAge: 10,
			onEviction: (key, value) => evictions.push([key, value])
		});
		cache.set('finite', 'old');
		cache.set('infinite', 'old');
		setTime(1005);
		cache.set('finite', 'new', {maxAge: 20});
		cache.set('infinite', 'new', {maxAge: Infinity});
		setTime(1015);
		assert.equal(cache.get('finite'), 'new');
		assert.equal(cache.get('infinite'), 'new');
		setTime(1025);
		assert.equal(cache.get('finite'), undefined);
		setTime(2000);
		assert.equal(cache.get('infinite'), 'new');
		assert.deepEqual(evictions, [['finite', 'new']]);
	});
});

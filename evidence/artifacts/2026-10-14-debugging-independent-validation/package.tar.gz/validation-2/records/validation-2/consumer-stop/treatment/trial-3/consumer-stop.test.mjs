#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import {pMapIterable, pMapSkip} from './index.js';

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

for (const asynchronous of [false, true]) {
	for (const stop of ['break', 'return', 'throw']) {
		test(`${stop} stops pulls when pending mappers skip (${asynchronous ? 'async' : 'sync'} input)`, {timeout: 2000}, async () => {
			const pendingMappers = deferred();
			let pulls = 0;
			const mapped = [];
			const input = {
				[asynchronous ? Symbol.asyncIterator : Symbol.iterator]() {
					return this;
				},
				next() {
					const value = pulls++;
					const result = {done: value >= 20, value};
					return asynchronous ? Promise.resolve(result) : result;
				},
			};
			const iterator = pMapIterable(input, async (value, index) => {
				mapped.push({value, index});
				if (value === 0) {
					return 'first';
				}

				await pendingMappers.promise;
				return pMapSkip;
			}, {concurrency: 3, backpressure: 3})[Symbol.asyncIterator]();
			const consumerError = new Error('consumer stopped');
			let pullsAtStop;
			let mappedAtStop;
			const recordStop = value => {
				assert.equal(value, 'first');
				pullsAtStop = pulls;
				mappedAtStop = [...mapped];
				assert.ok(mappedAtStop.length > 1, 'other mappers must be pending');
			};

			try {
				if (stop === 'return') {
					const result = await iterator.next();
					assert.equal(result.done, false);
					recordStop(result.value);
					assert.deepEqual(await iterator.return('stopped'), {done: true, value: 'stopped'});
				} else if (stop === 'break') {
					for await (const value of iterator) {
						recordStop(value);
						break;
					}
				} else {
					await assert.rejects(async () => {
						for await (const value of iterator) {
							recordStop(value);
							throw consumerError;
						}
					}, error => error === consumerError);
				}

				assert.equal(pulls, pullsAtStop);
				pendingMappers.resolve();
				// Let the released mapper continuations and their scheduling finish.
				await setImmediate();
				assert.equal(pulls, pullsAtStop, 'settling skipped mappers must not pull more input');
				assert.deepEqual(mapped, mappedAtStop, 'settling skipped mappers must not start more mappers');
				assert.deepEqual(await iterator.next(), {done: true, value: undefined});
			} finally {
				pendingMappers.resolve();
				await iterator.return();
			}
		});
	}
}

test('an input pull already pending at return does not restart mapping', {timeout: 2000}, async () => {
	const pendingPulls = deferred();
	let pulls = 0;
	const mapped = [];
	const input = {
		[Symbol.asyncIterator]() {
			return this;
		},
		async next() {
			const value = pulls++;
			if (value > 0) {
				await pendingPulls.promise;
			}

			return {done: value >= 20, value};
		},
	};
	const iterator = pMapIterable(input, value => {
		mapped.push(value);
		return value === 0 ? 'first' : pMapSkip;
	}, {concurrency: 2, backpressure: 2})[Symbol.asyncIterator]();

	try {
		assert.deepEqual(await iterator.next(), {done: false, value: 'first'});
		assert.ok(pulls > 1, 'an input pull must be pending');
		const pullsAtStop = pulls;
		assert.deepEqual(await iterator.return(), {done: true, value: undefined});
		pendingPulls.resolve();
		await setImmediate();
		assert.equal(pulls, pullsAtStop, 'a completed pending pull must not cause another pull');
		assert.deepEqual(mapped, [0], 'a completed pending pull must not start a mapper after return');
		assert.deepEqual(await iterator.next(), {done: true, value: undefined});
	} finally {
		pendingPulls.resolve();
		await iterator.return();
	}
});

test('continued iteration skips values and preserves output order and mapper indexes', {timeout: 2000}, async () => {
	const mapped = [];
	const values = [];
	for await (const value of pMapIterable([0, 1, 2, 3, 4], (value, index) => {
		mapped.push({value, index});
		return value % 2 === 0 ? value : pMapSkip;
	}, {concurrency: 2, backpressure: 3})) {
		values.push(value);
	}

	assert.deepEqual(values, [0, 2, 4]);
	assert.deepEqual(mapped, [0, 1, 2, 3, 4].map(value => ({value, index: value})));
});

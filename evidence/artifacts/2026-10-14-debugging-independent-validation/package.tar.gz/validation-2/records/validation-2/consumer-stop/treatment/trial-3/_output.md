我会先按 diagnosing-bugs 技能检查迭代终止和 `pMapSkip` 的补充调度路径，再修改 `index.js`，添加使用公开 API 的回归测试，并运行本地检查。

调度器只在 mapper 报错时设置 `isDone`，消费者退出却没有更新这个状态。待完成的 mapper 返回 `pMapSkip` 后会释放缓冲位置，再次触发 `trySpawn()`。我会用可控 Promise 复现退出后的额外拉取，同时检查正在等待的异步输入在退出后完成的情况。

回归测试已复现：消费者退出时输入拉取次数为 4，释放待完成的 skip mapper 后增至 22。修复通过 `finally` 标记迭代已终止，并在等待中的 `next()` 完成后检查终止状态。`npm test` 现已全部通过（10 项）；我正在核对最终改动范围和测试文件的可执行权限。

已修复 `index.js`。根因是消费者退出时未设置 `isDone`；待完成的 mapper 返回 `pMapSkip` 后会再次触发调度，继续拉取输入。现在通过 `finally` 标记终止，并在等待中的 `next()` 完成后检查状态。已启动的 mapper 可以结算，退出后不会再拉取输入。

新增可执行的 `consumer-stop.test.mjs`，使用 `node:test` 和公开 API，覆盖同步／异步输入、`break`、`return()`、消费者抛错及待完成的输入拉取。

实际检查：修复前 7 项回归失败；修复后 `npm test` 全部 10 项通过。`git diff --check` 和可执行权限检查通过。原有测试、元数据和文档未修改，全程未使用网络。
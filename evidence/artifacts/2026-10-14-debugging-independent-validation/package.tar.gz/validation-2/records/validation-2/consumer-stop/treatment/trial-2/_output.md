我会使用 diagnosing-bugs 技能，在当前目录检查停止迭代后的调度逻辑，补充公共 API 回归测试并修复；全程不访问网络。

已定位原因：`trySpawn()` 会检查 `isDone`，但消费者 `break` 或调用 `return()` 关闭生成器时，该标志没有更新。随后，待完成的 mapper 返回 `pMapSkip`，移除缓冲项并再次触发调度。我会先用受控 Promise 复现，再补上关闭时的清理逻辑。

已修复。根因是消费者关闭生成器时未设置 `isDone`；待完成 mapper 返回 `pMapSkip` 后，会释放缓冲并再次触发 `trySpawn()`。

`index.js` 现在通过 `finally` 设置停止标志。已启动的 mapper 可以完成，但不会再拉取输入。

新增可执行的 `consumer-stop.test.mjs`，通过公共 API 覆盖同步、异步输入的 `break`、`return()`、`throw()`，以及正常跳过和顺序。

实际验证：修复前 6 个终止用例失败；修复后 `npm test` 全部 10 项通过，`git diff --check` 通过。原有测试、元数据和文档未修改，全程未联网。
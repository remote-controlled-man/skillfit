#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import {pMapIterable, pMapSkip} from './index.js';

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

function pendingSkips(asynchronous) {
	const gate = deferred();
	const pulls = [];
	const mapped = [];
	const settled = [];
	const input = {
		[asynchronous ? Symbol.asyncIterator : Symbol.iterator]() {
			return {
				next() {
					const value = pulls.length;
					pulls.push(value);
					// Bound a failed regression so it cannot drain an infinite source.
					const result = {value, done: value >= 12};
					return asynchronous ? Promise.resolve(result) : result;
				},
			};
		},
	};
	const output = pMapIterable(input, async (value, index) => {
		mapped.push([value, index]);
		if (value === 0) {
			return 'first';
		}

		await gate.promise;
		settled.push(value);
		return pMapSkip;
	}, {concurrency: 3, backpressure: 3});

	return {output, gate, pulls, mapped, settled};
}

for (const asynchronous of [false, true]) {
	for (const stop of ['break', 'return', 'throw']) {
		test(`${stop} stops pulls after pending skips settle (${asynchronous ? 'async' : 'sync'} input)`, {timeout: 3000}, async t => {
			const {output, gate, pulls, mapped, settled} = pendingSkips(asynchronous);
			t.after(() => gate.resolve());
			const values = [];

			if (stop === 'break') {
				for await (const value of output) {
					values.push(value);
					break;
				}
			} else if (stop === 'return') {
				const iterator = output[Symbol.asyncIterator]();
				assert.deepEqual(await iterator.next(), {done: false, value: 'first'});
				values.push('first');
				assert.deepEqual(await iterator.return('stopped'), {done: true, value: 'stopped'});
				assert.deepEqual(await iterator.return(), {done: true, value: undefined});
				assert.deepEqual(await iterator.next(), {done: true, value: undefined});
			} else {
				const error = new Error('consumer stopped');
				await assert.rejects(async () => {
					for await (const value of output) {
						values.push(value);
						throw error;
					}
				}, reason => reason === error);
			}

			assert.deepEqual(values, ['first']);
			// Drain continuations for pulls requested before the consumer stopped.
			await setImmediate();
			assert.deepEqual(pulls, [0, 1, 2, 3]);
			assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3]]);
			const stoppedPulls = [...pulls];
			const stoppedMappers = [...mapped];

			gate.resolve();
			await setImmediate();

			assert.deepEqual(pulls, stoppedPulls, 'settling a skip must not pull more input');
			assert.deepEqual(mapped, stoppedMappers, 'settling a skip must not start more mappers');
			assert.deepEqual(settled, [1, 2, 3]);
		});
	}
}

test('continued iteration preserves ordered values and skips', {timeout: 3000}, async () => {
	const values = [];
	for await (const value of pMapIterable(
		[Promise.resolve(4), 1, 3, 2, 0],
		value => value % 2 === 1 ? pMapSkip : value * 2,
		{concurrency: 2, backpressure: 3},
	)) {
		values.push(value);
	}

	assert.deepEqual(values, [8, 4, 0]);
});

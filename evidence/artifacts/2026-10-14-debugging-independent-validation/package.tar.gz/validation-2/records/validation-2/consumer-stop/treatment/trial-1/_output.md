我会使用 `diagnosing-bugs` 技能，检查消费者停止后 `pMapSkip` 的补位逻辑，添加公开 API 回归测试，并在本地修复和验证。

根因已经定位：`trySpawn()` 依赖 `isDone` 阻止后续拉取，但消费者通过 `break`、`return()` 或异常退出时没有设置它。尚未完成的 mapper 返回 `pMapSkip` 后会移除队列项，并继续补位拉取输入。我会先用可控 Promise 复现，再补上迭代器退出时的终止处理。

修复前，6 个回归场景全部复现了停止后继续拉取的行为。现在生成器退出时通过 `finally` 设置 `isDone`，已启动的 mapper 可以完成，但不能再触发补位拉取。`npm test` 的 9 项测试全部通过；我会再检查最终差异和新测试的可执行权限。

已修复。[index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/consumer-stop/treatment/trial-1/index.js:259) 在生成器退出时通过 `finally` 设置 `isDone`。原先消费者退出没有更新该标志，待完成的 mapper 返回 `pMapSkip` 后会继续补位拉取；现在已启动的 mapper 可以完成，但不会触发新增拉取。

新增可执行的 `consumer-stop.test.mjs`，使用 `node:test` 和公开 API，覆盖同步／异步输入的 `break`、`return()`、消费者异常退出，以及正常跳过和输出顺序。

实际验证：修复前 6 个停止场景全部失败；修复后 `npm test` 全部 9 项通过，`git diff --check` 通过。原测试、元数据和文档保持原样，全程未访问网络。
我会先检查 `pMapIterable` 的终止路径和本地测试方式，使用 `diagnosing-bugs` 技能定位原因，再修改 `index.js` 并新增公开 API 回归测试。全程只在当前工作区操作，不访问网络。

原因已定位：消费者退出时，异步生成器没有设置终止标志。待完成的 mapper 返回 `pMapSkip` 后会移除缓冲项，再调用 `trySpawn()`，因此继续拉取输入。我会先用受控 Promise 复现，并检查 `break`、显式 `return()` 和消费者异常退出。

回归测试确认：修复前，8 种退出场景都会把输入拉取次数从 4 增加到 22。现在生成器在 `finally` 中设置终止标志，待完成的 mapper 仍可结束，但不能再启动拉取。`npm test` 已通过全部 11 项测试；我会再检查文件差异和新增测试的可执行性。

已修复 [index.js](<RUNS>/pmap-quicklru-original-v4-validation-2/consumer-stop/treatment/trial-5/index.js:259)。原因是消费者退出后没有设置终止标志，待完成 mapper 返回 `pMapSkip` 时仍会调用 `trySpawn()`。现在通过 `finally` 标记终止，允许已启动 mapper 完成，并阻止新增拉取。

新增可执行的 `consumer-stop.test.mjs`，通过公开 API 覆盖同步／异步输入及四种退出方式。原测试、元数据和文档未改动，全程未访问网络。

实际验证：

- 修复前：8 项退出回归失败，拉取次数从 4 增至 22。
- 修复后：`npm test` 全部 11 项通过。
- 直接执行新增测试：9 项通过。
- `git diff --check` 通过。
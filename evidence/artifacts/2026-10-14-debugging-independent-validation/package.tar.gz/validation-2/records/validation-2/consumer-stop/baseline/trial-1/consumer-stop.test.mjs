#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {pMapIterable, pMapSkip} from './index.js';

function deferred() {
	let resolve;
	const promise = new Promise(resolvePromise => {
		resolve = resolvePromise;
	});
	return {promise, resolve};
}

for (const inputType of ['sync', 'async']) {
	for (const stop of ['break', 'return', 'throw']) {
		test(`${stop} stops ${inputType} input pulls when pending mappers return pMapSkip`, async () => {
			const mapperGate = deferred();
			let pulls = 0;
			const mapped = [];
			const settled = [];
			const input = {
				[inputType === 'async' ? Symbol.asyncIterator : Symbol.iterator]() {
					return {
						next() {
							const value = pulls++;
							const result = value < 4 ? {value, done: false} : {done: true};
							return inputType === 'async' ? Promise.resolve(result) : result;
						},
					};
				},
			};
			const output = pMapIterable(input, async value => {
				mapped.push(value);
				if (value === 0) {
					return value;
				}

				await mapperGate.promise;
				settled.push(value);
				return pMapSkip;
			}, {concurrency: 2, backpressure: 2});

			if (stop === 'break') {
				for await (const value of output) {
					assert.equal(value, 0);
					break;
				}
			} else {
				const consumer = output[Symbol.asyncIterator]();
				assert.deepEqual(await consumer.next(), {value: 0, done: false});
				if (stop === 'return') {
					assert.deepEqual(await consumer.return(), {value: undefined, done: true});
				} else {
					const error = new Error('consumer stopped');
					await assert.rejects(consumer.throw(error), thrown => thrown === error);
				}
			}

			const pullsAtStop = pulls;
			const mappedAtStop = [...mapped];
			assert.ok(pullsAtStop < 4, 'input must not be exhausted at consumer stop');
			assert.ok(mappedAtStop.length > 1, 'a mapper must still be pending at consumer stop');
			mapperGate.resolve();
			await new Promise(resolve => setImmediate(resolve));

			assert.equal(pulls, pullsAtStop, 'consumer stop must prevent additional input pulls');
			assert.deepEqual(mapped, mappedAtStop, 'consumer stop must prevent additional mapper calls');
			assert.deepEqual(settled, mappedAtStop.slice(1), 'already started mappers may settle');
		});
	}
}

test('pending async input pulls cannot restart pulling after consumer return', async () => {
	const nextGate = deferred();
	const mapperGate = deferred();
	let pulls = 0;
	const input = {
		[Symbol.asyncIterator]() {
			return {
				next() {
					const value = pulls++;
					if (value > 0) {
						return nextGate.promise.then(() => value < 4 ? {value, done: false} : {done: true});
					}

					return Promise.resolve({value, done: false});
				},
			};
		},
	};
	const consumer = pMapIterable(input, async value => {
		if (value === 0) {
			return value;
		}

		await mapperGate.promise;
		return pMapSkip;
	}, {concurrency: 2, backpressure: 2})[Symbol.asyncIterator]();

	assert.deepEqual(await consumer.next(), {value: 0, done: false});
	await consumer.return();
	assert.equal(pulls, 3, 'two input pulls must be pending at consumer stop');
	nextGate.resolve();
	mapperGate.resolve();
	await new Promise(resolve => setImmediate(resolve));
	assert.equal(pulls, 3, 'settling existing input pulls must not start another pull');
});

test('active iteration still skips values and yields results in input order', async () => {
	const values = [];
	for await (const value of pMapIterable([0, 1, 2, 3, 4], value => (
		value % 2 === 0 ? pMapSkip : value * 2
	), {concurrency: 2, backpressure: 2})) {
		values.push(value);
	}

	assert.deepEqual(values, [2, 6]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import test from 'node:test';
import {pMapIterable, pMapSkip} from './index.js';

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});

	return {promise, resolve};
}

for (const inputType of ['sync', 'async']) {
	for (const stop of ['break', 'return', 'consumer error', 'throw']) {
		test(`${inputType} input: ${stop} prevents pending skips from pulling more input`, {timeout: 5000}, async t => {
			const releaseSkips = deferred();
			const mappersStarted = deferred();
			const mapped = [];
			const settled = [];
			let pulls = 0;
			const input = {
				[inputType === 'sync' ? Symbol.iterator : Symbol.asyncIterator]() {
					return {
						next() {
							const value = pulls++;
							const result = {done: value >= 20, value};
							return inputType === 'sync' ? result : Promise.resolve(result);
						},
					};
				},
			};

			t.after(() => releaseSkips.resolve());

			const iterator = pMapIterable(input, async (value, index) => {
				mapped.push([value, index]);
				if (mapped.length === 4) {
					mappersStarted.resolve();
				}

				if (value === 0) {
					return value;
				}

				await releaseSkips.promise;
				settled.push(value);
				return pMapSkip;
			}, {concurrency: 3, backpressure: 3})[Symbol.asyncIterator]();
			const consumerError = new Error('consumer stopped');

			if (stop === 'break' || stop === 'consumer error') {
				const consume = async () => {
					for await (const value of iterator) {
						assert.equal(value, 0);
						await mappersStarted.promise;
						if (stop === 'consumer error') {
							throw consumerError;
						}

						break;
					}
				};

				if (stop === 'consumer error') {
					await assert.rejects(consume(), error => error === consumerError);
				} else {
					await consume();
				}
			} else {
				assert.deepEqual(await iterator.next(), {done: false, value: 0});
				await mappersStarted.promise;
				if (stop === 'return') {
					assert.deepEqual(await iterator.return('stopped'), {done: true, value: 'stopped'});
				} else {
					await assert.rejects(iterator.throw(consumerError), error => error === consumerError);
				}
			}

			assert.equal(pulls, 4);
			assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3]]);
			releaseSkips.resolve();
			// Drain mapper continuations before checking for any replacement pulls.
			await setImmediate();
			assert.equal(pulls, 4, 'stopping must prevent additional iterator.next() calls');
			assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3]]);
			assert.deepEqual(settled, [1, 2, 3], 'already started mappers may settle');
			assert.deepEqual(await iterator.next(), {done: true, value: undefined});
			assert.deepEqual(await iterator.return(), {done: true, value: undefined});
		});
	}
}

test('full consumption still preserves order, mapper indexes, and skips', {timeout: 5000}, async () => {
	const first = deferred();
	const laterMapperStarted = deferred();
	const mapped = [];
	const consume = async () => {
		const values = [];
		for await (const value of pMapIterable([Promise.resolve(0), 1, 2, 3], async (value, index) => {
			mapped.push([value, index]);
			if (value === 0) {
				await first.promise;
			}

			if (value === 2) {
				laterMapperStarted.resolve();
			}

			return value === 1 ? pMapSkip : value * 2;
		}, {concurrency: 3, backpressure: 3})) {
			values.push(value);
		}

		return values;
	};
	const result = consume();
	await laterMapperStarted.promise;
	first.resolve();
	assert.deepEqual(await result, [0, 4, 6]);
	assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3]]);
});

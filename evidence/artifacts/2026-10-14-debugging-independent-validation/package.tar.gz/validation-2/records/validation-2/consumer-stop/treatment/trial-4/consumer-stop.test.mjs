#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import {pMapIterable, pMapSkip} from './index.js';

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

for (const asyncInput of [false, true]) {
	for (const stop of ['break', 'return', 'throw']) {
		test(`${stop} prevents further pulls after pending skips (${asyncInput ? 'async' : 'sync'} input)`, {timeout: 5000}, async () => {
			const gates = Array.from({length: 3}, deferred);
			const started = deferred();
			const mapped = [];
			const settled = [];
			let pulls = 0;
			const input = {
				[asyncInput ? Symbol.asyncIterator : Symbol.iterator]() {
					return {
						next() {
							const value = pulls++;
							// Bound the faulty implementation's extra work so the regression fails promptly.
							const result = value < 10 ? {value, done: false} : {done: true};
							return asyncInput ? Promise.resolve(result) : result;
						},
					};
				},
			};
			const output = pMapIterable(input, async (value, index) => {
				mapped.push([value, index]);
				if (value === 0) {
					return value;
				}

				if (value <= gates.length) {
					if (value === gates.length) {
						started.resolve();
					}

					const result = await gates[value - 1].promise;
					settled.push(value);
					return result;
				}

				return pMapSkip;
			}, {concurrency: 3, backpressure: 3});

			try {
				if (stop === 'break') {
					const values = [];
					for await (const value of output) {
						values.push(value);
						await started.promise;
						break;
					}

					assert.deepEqual(values, [0]);
				} else {
					const iterator = output[Symbol.asyncIterator]();
					assert.deepEqual(await iterator.next(), {value: 0, done: false});
					await started.promise;
					if (stop === 'return') {
						assert.deepEqual(await iterator.return('closed'), {value: 'closed', done: true});
					} else {
						const error = new Error('consumer stopped');
						await assert.rejects(iterator.throw(error), reason => reason === error);
					}

					assert.deepEqual(await iterator.next(), {value: undefined, done: true});
				}

				assert.equal(pulls, 4);
				const mappedBeforeStop = [...mapped];
				assert.deepEqual(mappedBeforeStop, [[0, 0], [1, 1], [2, 2], [3, 3]]);

				// Settle a non-head skip first: removing it used to reopen a backpressure slot.
				const released = [];
				for (const value of [2, 1, 3]) {
					gates[value - 1].resolve(pMapSkip);
					released.push(value);
					await setImmediate();
					assert.deepEqual(settled, released, 'already started mappers may settle');
					assert.equal(pulls, 4, 'stopping must prevent additional input pulls');
					assert.deepEqual(mapped, mappedBeforeStop, 'no further input should be mapped');
				}
			} finally {
				for (const gate of gates) {
					gate.resolve(pMapSkip);
				}

				await setImmediate();
			}
		});
	}
}

test('active iteration still refills after skips and yields values in order', {timeout: 5000}, async () => {
	const indexes = [];
	const values = [];
	for await (const value of pMapIterable([0, 1, 2, 3, 4, 5], (value, index) => {
		indexes.push(index);
		return value % 2 === 0 ? value : pMapSkip;
	}, {concurrency: 2, backpressure: 3})) {
		values.push(value);
	}

	assert.deepEqual(values, [0, 2, 4]);
	assert.deepEqual(indexes, [0, 1, 2, 3, 4, 5]);
});

我会使用 diagnosing-bugs 技能，在本地复现停止迭代后仍继续拉取输入的问题，修复终止逻辑，并用公开 API 添加回归测试。

已找到原因：消费者退出时，异步生成器没有设置 `isDone`。未完成的 mapper 返回 `pMapSkip` 后会移除缓冲项，再调用 `trySpawn()`，因此继续拉取输入。我会先用受控 Promise 复现，再让生成器退出时设置终止标记，阻止后续拉取。

修复前，6 个停止场景都复现了额外拉取：调用次数从 4 增加到 11。加入 `finally` 设置 `isDone` 后，`npm test` 的全部 9 项测试通过，覆盖同步与异步输入、`break`、`return()`、`throw()`，以及正常跳过和有序输出。接下来检查最终差异和测试文件的可执行权限。

已修复 `index.js`：生成器退出时通过 `finally` 设置 `isDone`，阻止后续拉取；已启动的 mapper 仍可完成。

根因是退出未设置终止标记，pending mapper 返回 `pMapSkip` 后释放缓冲位置，再次触发 `trySpawn()`。

新增可执行的 `consumer-stop.test.mjs`，使用 `node:test` 和公开 API，覆盖同步/异步输入的 `break`、`return()`、`throw()`，以及正常跳过与有序输出。

实际检查：修复前 6 个回归场景失败；修复后 `npm test` 全部 9 项通过，`git diff --check` 通过。原有测试、元数据和文档未改，未访问网络。
#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {setImmediate} from 'node:timers/promises';
import {pMapIterable, pMapSkip} from './index.js';

function deferred() {
	let resolve;
	const promise = new Promise(resolve_ => {
		resolve = resolve_;
	});
	return {promise, resolve};
}

for (const [kind, iteratorSymbol] of [
	['sync', Symbol.iterator],
	['async', Symbol.asyncIterator],
]) {
	for (const stop of ['break', 'return', 'throw']) {
		test(`${kind} input: ${stop} prevents pending skips from pulling more input`, {timeout: 1000}, async () => {
			const releaseMappers = deferred();
			const pendingMappersStarted = deferred();
			const mapped = [];
			const settled = [];
			let pulls = 0;
			let inputIndex = 0;
			const input = {
				[iteratorSymbol]() {
					return {
						next() {
							pulls++;
							const result = inputIndex < 12
								? {done: false, value: inputIndex++}
								: {done: true};
							return kind === 'async' ? Promise.resolve(result) : result;
						},
					};
				},
			};
			const output = pMapIterable(input, async (value, index) => {
				mapped.push([value, index]);
				if (value === 0) {
					return value;
				}

				if (mapped.length === 4) {
					pendingMappersStarted.resolve();
				}

				await releaseMappers.promise;
				settled.push(value);
				return pMapSkip;
			}, {concurrency: 3, backpressure: 3})[Symbol.asyncIterator]();

			try {
				if (stop === 'break') {
					const values = [];
					for await (const value of output) {
						values.push(value);
						await pendingMappersStarted.promise;
						break;
					}

					assert.deepEqual(values, [0]);
				} else {
					assert.deepEqual(await output.next(), {done: false, value: 0});
					await pendingMappersStarted.promise;
					if (stop === 'return') {
						assert.deepEqual(await output.return('closed'), {done: true, value: 'closed'});
					} else {
						const error = new Error('Consumer stopped');
						await assert.rejects(output.throw(error), actual => actual === error);
					}
				}

				assert.equal(pulls, 4);
				assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3]]);
				assert.deepEqual(settled, []);
				assert.deepEqual(await output.next(), {done: true, value: undefined});
			} finally {
				releaseMappers.resolve();
			}

			// Drain the released mapper continuations before checking for extra scheduling.
			await setImmediate();
			assert.deepEqual(settled, [1, 2, 3]);
			assert.equal(pulls, 4);
			assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3]]);
		});
	}

	test(`${kind} input: continued iteration skips values and preserves mapper indexes`, {timeout: 1000}, async () => {
		const input = {
			* [iteratorSymbol]() {
				yield* [0, 1, 2, 3, 4];
			},
		};
		const mapped = [];
		const values = [];
		for await (const value of pMapIterable(input, (value, index) => {
			mapped.push([value, index]);
			return value % 2 === 1 ? pMapSkip : value * 2;
		}, {concurrency: 3, backpressure: 4})) {
			values.push(value);
		}

		assert.deepEqual(values, [0, 4, 8]);
		assert.deepEqual(mapped, [[0, 0], [1, 1], [2, 2], [3, 3], [4, 4]]);
	});
}

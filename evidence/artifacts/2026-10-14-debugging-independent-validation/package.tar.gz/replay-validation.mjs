// Offline replay only; never starts an agent or model API.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),index=JSON.parse(readFileSync(join(root,'package-index.json')));
for(const f of index.files)assert.equal(createHash('sha256').update(readFileSync(join(root,f.path))).digest('hex'),f.sha256,f.path);
const result=JSON.parse(execFileSync(process.execPath,[join(root,'validation-2/replay/scripts/replay-cohorts.mjs')],{encoding:'utf8',maxBuffer:16*1024*1024}));
assert.equal(result.agentCliInvocations,80);assert.equal(result.regradedDeliveries,80);
assert.equal(result.cohorts[0].recordedEfficiencyMatch,true);assert.equal(result.cohorts[0].recordedCostChangesMatch,true);
const assessment=JSON.parse(readFileSync(join(root,'validation-2/validation-2-assessment.json')));
assert.equal(assessment.acceptance.decision,'inconclusive');assert.equal(assessment.acceptance.eligibleForUpgrade,false);assert.equal(assessment.acceptance.automaticUpgrade,false);
const prior=JSON.parse(readFileSync(join(root,'previous-study-spending.json'))),metrics=['input','cachedInput','uncachedInput','output','durationSeconds'];
const total={cliExecutions:prior.cliExecutions+result.agentCliInvocations,missingFinalUsage:prior.missingFinalUsage,knownLowerBound:Object.fromEntries(metrics.map(metric=>[metric,Number((prior.knownLowerBound[metric]+result.totalRecordedSpending[metric].knownTotal).toFixed(3))]))};
assert.equal(total.cliExecutions,125);assert.equal(total.missingFinalUsage,4);
assert.equal(total.knownLowerBound.input-total.knownLowerBound.cachedInput,total.knownLowerBound.uncachedInput);
console.log(JSON.stringify({schemaVersion:1,indexedFiles:index.files.length,modelCallsMadeByReplay:0,regradedDeliveries:80,agentCliInvocations:80,qualityStatsMatch:result.cohorts[0].qualityStatsMatch,costsMatch:result.cohorts[0].costsMatch,efficiency:result.cohorts[0].efficiency,acceptance:assessment.acceptance,validationSpending:result.totalRecordedSpending,studyThroughValidation2:total,scope:'The validation cohort is regraded here; previous spending is retained arithmetic from linked earlier archives. Platform counters remain separate and cannot be summed into CLI tokens or billing.',automaticUpgrade:false},null,2));

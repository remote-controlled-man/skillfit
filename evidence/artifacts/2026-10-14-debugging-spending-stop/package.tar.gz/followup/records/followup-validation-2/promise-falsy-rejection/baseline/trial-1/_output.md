我会先按 `diagnosing-bugs` 技能检查共享调用与 `after: true` 的结算路径，再修改 `index.js` 并添加公开 API 的回归测试；全程只在本地操作。

`node --test promise-falsy-rejection.test.mjs` 已连续两次复现：两个共享调用都把 `undefined` 拒绝误判为成功。

候选原因依次是：`initialError` 的真值判断丢失 falsy 拒绝、排队调用影响初次调用的结果、共享状态未在结算后清理。我会用全部六种拒绝原因、`after: true` 排队场景和后续调用检验这些路径。

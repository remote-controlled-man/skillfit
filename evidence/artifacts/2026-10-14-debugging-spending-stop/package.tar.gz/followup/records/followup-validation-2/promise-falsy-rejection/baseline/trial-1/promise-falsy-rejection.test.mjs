#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pDebounce from './index.js';
import {gate} from './test-clock.mjs';

test('shared callers preserve an undefined rejection reason', async () => {
	const pending = gate();
	let calls = 0;
	const debounced = pDebounce.promise(async () => {
		calls++;
		await pending.promise;
		throw undefined;
	});
	const results = Promise.allSettled([debounced(), debounced()]);
	pending.release();
	assert.deepEqual(await results, [
		{status: 'rejected', reason: undefined},
		{status: 'rejected', reason: undefined},
	]);
	assert.equal(calls, 1);
});

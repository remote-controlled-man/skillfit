import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createController, assertReceipt} from './controller.mjs';
const p = JSON.parse(readFileSync(new URL('./proposal.json', import.meta.url)));
const receipt = () => ({executorInvoked: true, error: null, passed: true, usageStatus: 'final',
  checks: Array.from({length: 6}, (_, i) => ({name: String(i), pass: true})),
  tokens: {input: 197021, cachedInput: 172800, output: 5912}, durationSeconds: 184.285,
  timing: {execution: {timeoutMs: 600000, anomaly: null, timeoutFiredAfterMs: null}}, skillTriggered: true});
const extra = {receiver: {tests: 18, passing: 18, noSkips: true}};
const trace = row => [
  {type:'thread.started',thread_id:'mock-thread'},
  {type:'turn.completed',usage:{input_tokens:row.tokens.input,cached_input_tokens:row.tokens.cachedInput,output_tokens:row.tokens.output}},
].map(JSON.stringify).join('\n');
async function exercise(change = () => {}, options = {}) {
  let calls = 0; const order = [], records = [];
  const invoke = async item => {calls++;order.push(item.arm);const row = receipt();if (calls===1)change(row);records.push(row);return row;};
  const controller = createController(p);
  const result = await controller({invoke, after: async (_,row) => {assertReceipt(row, trace(row)); return options.extra ?? extra;},
    review: async () => options.audit ?? {skillRead:'observed',mechanism:'observed'}, before: options.before});
  return {result,calls,order,controller};
}
test('Positive gated route runs candidate then control exactly once', async () => {
  const r=await exercise();assert.deepEqual(r.order,['candidate','control']);assert.equal(r.result.status,'completed');assert.equal(r.calls,2);
  await assert.rejects(r.controller({invoke:()=>assert.fail()}), /SINGLE_USE/);
});
test('Candidate task failure stops before control and keeps spending', async () => {
  const r=await exercise(row=>{row.passed=false;row.checks[0].pass=false;});assert.equal(r.calls,1);assert.match(r.result.reason,/FUNCTIONAL/);assert.equal(r.result.rows[0].tokens.input,197021);
});
test('Candidate extra receiver failure stops even after original 6/6', async () => {
  const r=await exercise(()=>{}, {extra:{receiver:{tests:18,passing:17,noSkips:true}}});assert.equal(r.calls,1);assert.match(r.result.reason,/RECEIVER/);
});
for (const key of ['skillRead','mechanism']) for (const status of ['not-observed','unknown']) {
  test(`${key} ${status} prevents control`, async () => {
    const r=await exercise(()=>{}, {audit:{skillRead:'observed',mechanism:'observed',[key]:status}});assert.equal(r.calls,1);assert.match(r.result.reason,/MECHANISM/);
  });
}
test('No detected Skill read prevents even the review handoff', async () => {
  const r=await exercise(row=>{row.skillTriggered=false;});assert.equal(r.calls,1);assert.match(r.result.reason,/SKILL_READ/);
});
const reserve = {
  input:r=>{r.tokens.input=300000;r.tokens.cachedInput=250000;},
  cachedInput:r=>{r.tokens.input=250001;r.tokens.cachedInput=250000;},
  uncachedInput:r=>{r.tokens.input=50001;r.tokens.cachedInput=1;},
  output:r=>{r.tokens.output=10000;},durationSeconds:r=>{r.durationSeconds=600;},
};
for (const [key,change] of Object.entries(reserve)) test(`Equality at ${key} reserve blocks control`, async () => {
  const r=await exercise(change);assert.equal(r.calls,1);assert.match(r.result.reason,/RESERVE/);
});
for (const [name,change] of Object.entries({
  partial:r=>{r.usageStatus='partial';},missing:r=>{r.tokens=null;},invalid:r=>{r.tokens.cachedInput=r.tokens.input+1;},
  executor:r=>{r.error='route error';},timing:r=>{r.timing.execution.anomaly='clock jump';},timeout:r=>{r.timing.execution.timeoutFiredAfterMs=600000;},deadline:r=>{r.timing.execution.timeoutMs=1200000;},
})) test(`${name} evidence anomaly stops with one retained call`, async () => {
  const r=await exercise(change);assert.equal(r.calls,1);assert.equal(r.result.status,'stopped');assert.equal(r.result.rows.length,1);
});
test('Setup/power guard prevents first invocation', async () => {
  const r=await exercise(()=>{}, {before:async()=>{throw Error('power lost');}});assert.equal(r.calls,0);assert.match(r.result.reason,/power/);
});
test('Changed inputs after candidate review cannot start the control', async () => {
  const r=await exercise(()=>{}, {before:async item=>{if(item.phase==='after-review')throw Error('frozen input changed');}});assert.equal(r.calls,1);assert.match(r.result.reason,/frozen/);
});
test('Routing, turn errors and mismatched footer counters fail receipt checks', () => {
  const r=receipt();assert.throws(()=>assertReceipt(r,'{}'),/ROUTING/);
  assert.throws(()=>assertReceipt(r,trace(r)+'\n'+JSON.stringify({type:'turn.failed'})),/ROUTING_OR_TURN/);
  const broken=trace(r).replace('197021','197022');assert.throws(()=>assertReceipt(r,broken),/COUNTER_MISMATCH/);
});
test('Throwing review fails closed without a replacement', async () => {
  let calls=0;const r=await createController(p)({invoke:async()=>{calls++;return receipt();},after:async()=>extra,review:async()=>{throw Error('review interrupted');}});
  assert.equal(calls,1);assert.equal(r.status,'stopped');assert.match(r.reason,/review interrupted/);
});

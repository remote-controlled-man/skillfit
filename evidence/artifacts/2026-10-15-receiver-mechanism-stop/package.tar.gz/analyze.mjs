// Offline replay of saved deliveries, order, guards and cost receipts only.
import assert from 'node:assert/strict';
import {cpSync,existsSync,mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {join,dirname,relative} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {runVerifier} from './runner/dist/harness/runner.js';
import {sha256File,hashFileSet,listFilesRecursive} from './runner/dist/harness/hash.js';
import {summarizeCosts,COST_METRICS} from './runner/dist/harness/costs.js';
import {spendingBudgetState} from './runner/dist/harness/eval-budget.js';
import {assertReceipt,reserveReason} from './controller.mjs';
import {inspectDelivery} from './inspect.mjs';
const root=dirname(fileURLToPath(import.meta.url)),packaged=process.argv.includes('--package');
const json=p=>JSON.parse(readFileSync(join(root,p))),readLines=p=>readFileSync(join(root,p),'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
const p=json('proposal.json'),decl=json('declaration.json'),session=json('records/mechanism-1/_session.json');
const group=join(root,'records/mechanism-1'),seal=json('records/mechanism-1/_artifacts.json');
if(packaged){for(const f of json('package-index.json').files)assert.equal(sha256File(join(root,f.path)),f.sha256,f.path);}
else{for(const [file,hash] of Object.entries(seal.files))assert.equal(sha256File(join(group,file)),hash,file);}
assert.equal(hashFileSet(join(root,'runner/dist'),listFilesRecursive(join(root,'runner/dist'))),decl.runtimeSha256);
const ledger=readLines('records/mechanism-1/_calls.jsonl'),starts=ledger.filter(e=>e.event==='started');
assert.ok(starts.length>=1&&starts.length<=2);assert.equal(starts.length,session.callsStarted);
assert.deepEqual(starts.map(e=>e.workdir.split('/').slice(-3).join('/')),
  ['treatment','baseline'].slice(0,starts.length).map(c=>`${p.task.id}/${c}/trial-1`));
const arms={baseline:[],treatment:[]},rows=[],outcomes=[],qualification={baseline:[],treatment:[]};
for(const [index,start] of starts.entries()){
  const condition=index===0?'treatment':'baseline',arm=index===0?'candidate':'control';
  const rel=`records/mechanism-1/${p.task.id}/${condition}/trial-1`,row=json(rel+'/_result.json');
  assert.equal(row.executorInvoked,true);arms[condition].push(row);outcomes.push(row);
  let receiptError=null,evidence=null,replayed=false;
  try{assertReceipt(row,readFileSync(join(root,rel,'_transcript.jsonl'),'utf8'));}catch(e){receiptError=e.message;}
  if(!receiptError){
    const scratch=mkdtempSync(join(tmpdir(),'skillfit-mechanism-regrade-'));
    try{
      cpSync(join(root,rel),scratch,{recursive:true,filter:file=>!relative(join(root,rel),file).split(/[\\/]/).some(s=>s==='.git'||s.startsWith('_'))});
      const r=await runVerifier(join(root,'inputs/bench'),p.task.verifier,scratch),v=JSON.parse(r.output.trim().split('\n').at(-1));
      assert.equal(r.exitCode,row.verifierExitCode);assert.equal(v.passed,row.passed);assert.equal(v.score,row.score);
      assert.deepEqual(v.checks.map(({name,pass})=>({name,pass})),row.checks.map(({name,pass})=>({name,pass})));replayed=true;
    }finally{rmSync(scratch,{recursive:true,force:true});}
    evidence=inspectDelivery(root,{...row,runDir:join(root,rel)},arm,row.skillDelivery.installDir);
    const saved=json(`inspection-${index+1}.json`);
    assert.deepEqual(evidence.receiver,saved.receiver);
  }
  qualification[condition].push({...row,passed:!receiptError&&row.passed&&evidence?.receiver?.passing===18});
  rows.push({ordinal:index+1,arm,condition,receiptError,nativePassed:row.passed,score:row.score,
    originalChecks:row.checks?.map(({name,pass})=>({name,pass}))??null,
    receiver:evidence?.receiver??null,skillTriggered:row.skillTriggered??null,gradeReplayed:replayed,
    tokens:row.tokens,usageStatus:row.usageStatus,durationSeconds:row.durationSeconds});
}
const budget=readLines('records/mechanism-1/_budget.jsonl');let finished=0;
for(const e of budget){
  if(e.phase==='after-call')finished++;
  assert.deepEqual(e.state,spendingBudgetState(p.budget.stopLines,outcomes.slice(0,finished)));
}
assert.equal(finished,outcomes.length);
const costs=summarizeCosts(arms,{baseline:[],treatment:[]}),behaviorCosts=summarizeCosts(qualification,{baseline:[],treatment:[]});
const perSuccess=population=>Object.fromEntries(COST_METRICS.map(m=>[m,population.passes?population.metrics[m].knownTotal/population.passes:null]));
const totals=Object.fromEntries(COST_METRICS.map(m=>[m,costs.attempts.baseline.metrics[m].knownTotal+costs.attempts.treatment.metrics[m].knownTotal]));
const costChanges=starts.length===2?Object.fromEntries(COST_METRICS.map(m=>{const a=costs.attempts.baseline.metrics[m].knownTotal,b=costs.attempts.treatment.metrics[m].knownTotal;return[m,{control:a,candidate:b,delta:b-a,fraction:a?(b-a)/a:null}];})):null;
const review=existsSync(join(root,'candidate-mechanism-review.json'))?json('candidate-mechanism-review.json'):null;
const postStopAudit=existsSync(join(root,'post-stop-mechanism-audit.json'))?json('post-stop-mechanism-audit.json'):null;
const {diagnostic}=await import('./diagnostics/new-regression-matrix.mjs');
const power=json('power.json');assert.equal(power.released,true);
let conclusion=rows[0].nativePassed&&rows[0].receiver?.passing===18?'functional-pass-mechanism-unobserved':'candidate-failed';
if(starts.length===2){
  assert.equal(reserveReason(p,[outcomes[0]]),null);assert.equal(review?.skillRead,'observed');assert.equal(review?.mechanism,'observed');
  conclusion=rows[1].nativePassed&&rows[1].receiver?.passing===18?'both-functionally-pass-no-discriminating-contrast':'control-review-required';
}
const result={schemaVersion:1,kind:'skillfit.receiver-mechanism-saved-analysis',realCalls:starts.length,maximumCalls:2,
  cumulativeStudyCalls:194+starts.length,historicalUnknownPublicFinalUsages:7,newIncompleteUsage:rows.filter(r=>r.usageStatus!=='final'||r.receiptError).length,
  purpose:'development',independentValidation:false,automaticUpgrade:false,automaticExpansion:false,
  nativeSession:session.status,stopReason:json('outcome.json').reason,conclusion,
  candidateMechanism:review?{skillRead:review.skillRead,mechanism:review.mechanism,rationale:review.rationale,
    skillReadEvidence:review.skillReadEvidence,mechanismEvidence:review.mechanismEvidence}:null,
  postStopMechanismAudit:postStopAudit?{skillRead:postStopAudit.skillRead,mechanism:postStopAudit.mechanism,rationale:postStopAudit.rationale,partialObservableChanges:postStopAudit.partialObservableChanges,sameWrongSourceBytes:postStopAudit.sameWrongSourceBytes}:null,
  newRegressionDiagnostic:diagnostic,
  rows,costs,allBehaviorPassingCosts:behaviorCosts,knownTotals:totals,pairedCostChanges:costChanges,
  nativePerSuccess:{control:perSuccess(costs.attempts.baseline),candidate:perSuccess(costs.attempts.treatment)},
  allBehaviorPerSuccess:{control:perSuccess(behaviorCosts.attempts.baseline),candidate:perSuccess(behaviorCosts.attempts.treatment)},
  finalBudgetState:spendingBudgetState(p.budget.stopLines,outcomes),power:{released:power.released,anomalies:power.anomalies},
  costScope:'All actual executor invocations, including failures. No provider bill or full conversational/orchestration authoring bill is measured. Missing usage remains unknown.',
  auditScope:'Conditional native session and deterministic derivative replay; no complete native eval-component manifest or independent adoption audit is fabricated.'};
if(packaged)assert.deepEqual(result,json('analysis.json'));
console.log(JSON.stringify(result,null,2));

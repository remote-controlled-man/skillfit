import assert from 'node:assert/strict';
import {spendingBudgetState} from './runner/dist/harness/eval-budget.js';

export function assertReceipt(row, trace, timeoutMs = 600000) {
  assert.equal(row.executorInvoked, true, 'EXECUTOR_NOT_INVOKED');
  assert.equal(row.error, null, 'EXECUTION_ERROR');
  assert.equal(row.usageStatus, 'final', 'FINAL_USAGE_MISSING');
  for (const key of ['input', 'cachedInput', 'output']) assert.ok(Number.isSafeInteger(row.tokens?.[key]) && row.tokens[key] >= 0, 'INVALID_FINAL_USAGE');
  assert.ok(row.tokens.cachedInput <= row.tokens.input, 'INVALID_CACHE_PARTITION');
  assert.ok(Number.isFinite(row.durationSeconds) && row.durationSeconds >= 0, 'INVALID_DURATION');
  assert.equal(row.timing?.execution?.timeoutMs, timeoutMs, 'WRONG_DEADLINE');
  assert.equal(row.timing.execution.anomaly, null, 'TIMING_ANOMALY');
  assert.equal(row.timing.execution.timeoutFiredAfterMs, null, 'EXECUTION_TIMEOUT');
  const events = trace.trim().split('\n').filter(Boolean).map(JSON.parse);
  assert.ok(events.some(e => e.type === 'thread.started' && typeof e.thread_id === 'string'), 'ROUTING_MISSING');
  assert.ok(!events.some(e => ['error', 'turn.failed'].includes(e.type)), 'ROUTING_OR_TURN_ERROR');
  const turns = events.filter(e => e.type === 'turn.completed');
  assert.ok(turns.length > 0, 'FINAL_TURN_MISSING');
  for (const [key, wire] of [['input','input_tokens'], ['cachedInput','cached_input_tokens'], ['output','output_tokens']]) {
    assert.ok(turns.every(e => Number.isSafeInteger(e.usage?.[wire]) && e.usage[wire] >= 0), 'FINAL_COUNTER_MISSING');
    assert.equal(turns.reduce((sum, e) => sum + e.usage[wire], 0), row.tokens[key], 'FINAL_COUNTER_MISMATCH');
  }
}

export function reserveReason(proposal, rows) {
  const state = spendingBudgetState(proposal.budget.stopLines, rows);
  if (state.reason) return state.reason;
  const limits = proposal.budget.secondCallAdmission.firstReceiptMustBeStrictlyBelow;
  const reached = Object.keys(limits).filter(key => state.metrics[key].knownTotal >= limits[key]);
  return reached.length ? 'SECOND_CALL_RESERVE_REACHED:' + reached.join(',') : null;
}

export function createController(proposal) {
  assert.equal(proposal.plannedMaximumExecutorCalls, 2);
  assert.deepEqual(proposal.execution.order.map(row => row.arm), ['candidate', 'control']);
  let used = false;
  return async function run({invoke, before = async () => {}, after = async () => {}, review}) {
    assert.equal(used, false, 'SINGLE_USE_CONTROLLER'); used = true;
    const rows = [], extras = []; let attempts = 0;
    const stop = reason => ({status: 'stopped', reason, attempts, rows, extras, automaticUpgrade: false});
    try {
      for (const item of proposal.execution.order) {
        assert.ok(attempts < 2, 'TWO_CALL_CEILING');
        const state = spendingBudgetState(proposal.budget.stopLines, rows);
        if (state.reason) return stop(state.reason);
        await before(item, rows, state);
        attempts++;
        const row = await invoke(item); rows.push(row);
        const extra = await after(item, row, rows); extras.push(extra);
        const next = spendingBudgetState(proposal.budget.stopLines, rows);
        if (next.reason === 'EXECUTION_FAILED' || next.incomplete.length) return stop(next.reason);
        if (item.arm === 'candidate') {
          if (!row.passed || row.checks?.length !== 6 || row.checks.some(c => c.pass !== true)) return stop('CANDIDATE_FUNCTIONAL_FAILURE');
          if (extra?.receiver?.tests !== 18 || extra.receiver.passing !== 18 || extra.receiver.noSkips !== true) return stop('CANDIDATE_RECEIVER_FAILURE');
          const reason = reserveReason(proposal, rows); if (reason) return stop(reason);
          if (row.skillTriggered !== true) return stop('SKILL_READ_NOT_OBSERVED');
          const audit = await review(item, row, extra);
          if (audit?.skillRead !== 'observed' || audit?.mechanism !== 'observed') return stop('MECHANISM_NOT_OBSERVED_OR_UNKNOWN');
          await before({...item, phase: 'after-review'}, rows, spendingBudgetState(proposal.budget.stopLines, rows));
        }
      }
      return {status: 'completed', reason: spendingBudgetState(proposal.budget.stopLines, rows).reason,
        attempts, rows, extras, automaticUpgrade: false};
    } catch (error) { return stop(String(error.message)); }
  };
}

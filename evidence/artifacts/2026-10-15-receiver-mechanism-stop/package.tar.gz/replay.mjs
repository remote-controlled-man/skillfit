// Public offline derivative replay only. Does not execute live.mjs.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {sha256File} from './runner/dist/harness/hash.js';
const root=dirname(fileURLToPath(import.meta.url)),json=p=>JSON.parse(readFileSync(join(root,p)));
for(const f of json('package-index.json').files)assert.equal(sha256File(join(root,f.path)),f.sha256,f.path);
const provenance=json('export-provenance.json'),audit=json('post-stop-mechanism-audit.json');
for(const [suffix,expected] of [['_result.json',audit.receiptSha256],['_transcript.jsonl',audit.traceSha256]]){
  const path=`records/mechanism-1/timeout-custom-timers/treatment/trial-1/${suffix}`;
  assert.equal(provenance.files.find(f=>f.path===path)?.sourceSha256,expected);
}
const events=readFileSync(join(root,'records/mechanism-1/timeout-custom-timers/treatment/trial-1/_transcript.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
assert.ok(events.every(e=>e.item?.type!=='reasoning'));
const command=events.find(e=>e.type==='item.completed'&&e.item?.id==='item_2').item;
assert.equal(command.exit_code,0);assert.equal(command.aggregated_output,readFileSync(join(root,'inputs/candidate/SKILL.md'),'utf8'));
assert.equal(audit.sameWrongSourceBytes,true);assert.equal(audit.mechanism,'not-observed');
const analysis=JSON.parse(execFileSync(process.execPath,[join(root,'analyze.mjs'),'--package'],{encoding:'utf8',timeout:120000,maxBuffer:4*1024*1024}));
const checks=execFileSync(process.execPath,['--test',join(root,'controller.test.mjs')],{encoding:'utf8',timeout:30000});
assert.match(checks,/pass 24/);assert.match(checks,/fail 0/);assert.match(checks,/skipped 0/);
assert.equal(analysis.realCalls,1);assert.equal(analysis.stopReason,'CANDIDATE_FUNCTIONAL_FAILURE');
assert.equal(analysis.rows[0].originalChecks.filter(c=>c.pass).length,4);assert.equal(analysis.rows[0].receiver.passing,8);
assert.equal(analysis.cumulativeStudyCalls,195);assert.equal(analysis.pairedCostChanges,null);
console.log(JSON.stringify({modelCalls:0,savedActualCalls:analysis.realCalls,controlExecuted:false,
  originalPassingChecks:4,originalChecks:6,receiverPassing:8,receiverChecks:18,controllerTests:24,
  actualSkillRead:true,sameWrongProductionCode:true,regressionDiagnostic:true,costsAndBudgetReplayed:true,
  knownTotals:analysis.knownTotals,cumulativeStudyCalls:195,historicalUnknownPublicFinalUsages:7,
  automaticUpgrade:false,decision:'candidate-failed',completeNativeComponentAudit:false,derivedExport:true}));

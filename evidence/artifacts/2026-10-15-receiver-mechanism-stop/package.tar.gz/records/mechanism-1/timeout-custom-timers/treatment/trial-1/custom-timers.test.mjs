#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pTimeout, {TimeoutError} from './index.js';
import {flush, gate, observe, withClock} from './test-clock.mjs';

// Model saved global functions: detached and global calls are compatible,
// but an unrelated configuration object is not a valid host receiver.
function receiverChecked(timer) {
	const calls = [];
	function checked(...args) {
		if (this !== undefined && this !== globalThis) {
			throw new TypeError('Illegal invocation');
		}

		const result = Reflect.apply(timer, globalThis, args);
		calls.push({args, result});
		return result;
	}

	return Object.assign(checked, {calls});
}

test('timer fixture accepts detached and global calls', async () => {
	await withClock(async clock => {
		const setTimeout = receiverChecked(globalThis.setTimeout);
		const clearTimeout = receiverChecked(globalThis.clearTimeout);
		const customTimers = {setTimeout, clearTimeout};
		const detachedHandle = setTimeout(() => {}, 10);
		clearTimeout(detachedHandle);
		const globalHandle = setTimeout.call(globalThis, () => {}, 10);
		clearTimeout.call(globalThis, globalHandle);
		assert.throws(() => customTimers.setTimeout(() => {}, 10), TypeError);
		assert.throws(() => customTimers.clearTimeout(globalHandle), TypeError);
		assert.equal(clock.pending, 0);
	});
});

test('saved custom setTimeout preserves timeout and cancellation behavior', async () => {
	await withClock(async clock => {
		const setTimeout = receiverChecked(globalThis.setTimeout);
		const clearTimeout = receiverChecked(globalThis.clearTimeout);
		const input = gate();
		let cancellations = 0;
		input.promise.cancel = () => { cancellations++; };
		const state = observe(pTimeout(input.promise, {
			milliseconds: 25,
			customTimers: {setTimeout, clearTimeout: (...args) => clearTimeout(...args)},
		}));
		await flush();
		assert.deepEqual(state, {status: 'pending'});
		assert.equal(setTimeout.calls.length, 1);
		assert.equal(setTimeout.calls[0].args[1], 25);
		await clock.advance(24);
		assert.deepEqual(state, {status: 'pending'});
		assert.equal(cancellations, 0);
		await clock.advance(1);
		assert.equal(state.status, 'rejected');
		assert.ok(state.reason instanceof TimeoutError);
		assert.equal(state.reason.message, 'Promise timed out after 25 milliseconds');
		assert.equal(cancellations, 1);
		assert.deepEqual(clearTimeout.calls[0].args, [setTimeout.calls[0].result]);
		assert.equal(clock.pending, 0);
	});
});

for (const status of ['fulfilled', 'rejected']) {
	test(`saved custom clearTimeout preserves the input's ${status} result`, async () => {
		await withClock(async clock => {
			const clearTimeout = receiverChecked(globalThis.clearTimeout);
			const result = status === 'fulfilled' ? {value: 7} : new Error('input failed');
			const input = status === 'fulfilled' ? Promise.resolve(result) : Promise.reject(result);
			const state = observe(pTimeout(input, {
				milliseconds: 25,
				customTimers: {setTimeout: globalThis.setTimeout, clearTimeout},
			}));
			await flush();
			assert.equal(state.status, status);
			assert.equal(status === 'fulfilled' ? state.value : state.reason, result);
			assert.equal(clearTimeout.calls.length, 1);
			assert.notEqual(clearTimeout.calls[0].args[0], undefined);
			assert.equal(clock.pending, 0);
		});
	});
}

test('clear can be repeated with saved custom timers without settling the input', async () => {
	await withClock(async clock => {
		const setTimeout = receiverChecked(globalThis.setTimeout);
		const clearTimeout = receiverChecked(globalThis.clearTimeout);
		const input = gate();
		const promise = pTimeout(input.promise, {milliseconds: 25, customTimers: {setTimeout, clearTimeout}});
		const state = observe(promise);
		assert.equal(promise.clear(), undefined);
		assert.equal(promise.clear(), undefined);
		assert.deepEqual(clearTimeout.calls.map(call => call.args), [[setTimeout.calls[0].result], [undefined]]);
		assert.equal(clock.pending, 0);
		await clock.advance(50);
		assert.deepEqual(state, {status: 'pending'});
		const value = {completed: true};
		input.release(value);
		await flush();
		assert.deepEqual(state, {status: 'fulfilled', value});
		assert.equal(state.value, value);
		assert.deepEqual(clearTimeout.calls[2].args, [undefined]);
	});
});

test('abort preserves its reason and clears the custom timer', async () => {
	await withClock(async clock => {
		const clearTimeout = receiverChecked(globalThis.clearTimeout);
		const controller = new AbortController();
		const reason = new Error('stop waiting');
		const state = observe(pTimeout(gate().promise, {
			milliseconds: 25,
			signal: controller.signal,
			customTimers: {setTimeout: globalThis.setTimeout, clearTimeout},
		}));
		controller.abort(reason);
		await flush();
		assert.equal(state.status, 'rejected');
		assert.equal(state.reason, reason);
		assert.equal(clearTimeout.calls.length, 1);
		assert.equal(clock.pending, 0);
	});
});

test('explicitly bound custom timers retain their receiver', async () => {
	await withClock(async clock => {
		const schedule = globalThis.setTimeout;
		const clear = globalThis.clearTimeout;
		const owner = {
			handle: undefined,
			setTimeout(callback, milliseconds) {
				assert.equal(this, owner);
				assert.equal(milliseconds, 25);
				this.handle = schedule(callback, milliseconds);
				return this.handle;
			},
			clearTimeout(handle) {
				assert.equal(this, owner);
				assert.equal(handle, this.handle);
				clear(handle);
			},
		};
		let fallbacks = 0;
		const value = {fallback: true};
		const state = observe(pTimeout(gate().promise, {
			milliseconds: 25,
			fallback: () => { fallbacks++; return value; },
			customTimers: {
				setTimeout: owner.setTimeout.bind(owner),
				clearTimeout: owner.clearTimeout.bind(owner),
			},
		}));
		await clock.advance(25);
		assert.deepEqual(state, {status: 'fulfilled', value});
		assert.equal(state.value, value);
		assert.equal(fallbacks, 1);
		assert.equal(clock.pending, 0);
	});
});

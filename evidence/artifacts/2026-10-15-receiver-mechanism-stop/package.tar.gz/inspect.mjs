import assert from 'node:assert/strict';
import {cpSync, readFileSync, writeFileSync, mkdtempSync, rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {assertReceipt} from './controller.mjs';
import {hashFileSet,listFilesRecursive,sha256File} from './runner/dist/harness/hash.js';
import {testRun} from './inputs/bench/verifiers/regression-evidence.mjs';

export function inspectDelivery(root, row, arm, installDir) {
  const traceFile=join(row.runDir,'_transcript.jsonl'),trace=readFileSync(traceFile,'utf8');
  assertReceipt(row,trace);
  const skill=join(row.runDir,installDir,'diagnosing-bugs');
  const deliveredSkillSha256=hashFileSet(skill,listFilesRecursive(skill));
  const proposal=JSON.parse(readFileSync(join(root,'proposal.json')));
  assert.equal(deliveredSkillSha256,proposal.arms[arm].sha256,'Delivered Skill changed');
  const commands=trace.trim().split('\n').filter(Boolean).map(JSON.parse).flatMap((e,i)=>
    e.type==='item.completed'&&e.item?.type==='command_execution'?[{line:i+1,...e.item}]:[]);
  const scratch=mkdtempSync(join(tmpdir(),'skillfit-live-receiver-probes-'));
  let receiver;
  try {
    cpSync(join(root,'inputs/bench/fixtures/timeout-custom-timers'),scratch,{recursive:true});
    cpSync(join(row.runDir,'index.js'),join(scratch,'index.js'));
    cpSync(join(root,'receiver-contract.test.mjs'),join(scratch,'receiver-contract.test.mjs'));
    const r=testRun(scratch,['receiver-contract.test.mjs']);
    const records=r.records.filter(r=>r.registered&&r.leaf);
    receiver={completed:r.completed,passed:r.passed,tests:records.length,passing:records.filter(r=>r.pass).length,
      noSkips:r.noSkips,counts:r.counts,checks:records.map(r=>({path:r.path,pass:r.pass,failureType:r.failureType??null}))};
    assert.equal(receiver.completed,true,'Receiver probe did not complete');
    assert.equal(receiver.tests,18,'Receiver probe registration mismatch');
    assert.equal(receiver.noSkips,true,'Receiver probe skipped or cancelled a check');
  } finally {rmSync(scratch,{recursive:true,force:true});}
  return {arm,receiptSha256:sha256File(join(row.runDir,'_result.json')),traceSha256:sha256File(traceFile),
    sourceSha256:sha256File(join(row.runDir,'index.js')),deliveredSkillSha256,
    originalVerifier:{passed:row.passed,score:row.score,checks:row.checks},receiver,commands};
}

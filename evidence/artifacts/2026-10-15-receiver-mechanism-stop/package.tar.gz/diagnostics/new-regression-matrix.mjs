// Post-result fixture diagnostic only; zero model calls or extra scored tasks.
import assert from 'node:assert/strict';
import {cpSync,mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {join,dirname} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {testRun} from '../inputs/bench/verifiers/regression-evidence.mjs';
const root=join(dirname(fileURLToPath(import.meta.url)),'..');
const fixture=join(root,'inputs/bench/fixtures/timeout-custom-timers');
const delivery=join(root,'records/mechanism-1/timeout-custom-timers/treatment/trial-1');
const sources={original:join(fixture,'index.js'),historicalWrongV4:join(root,'diagnostics/historical-v4-index.js'),
  candidateDelivery:join(delivery,'index.js'),maintainer:join(root,'inputs/bench/ground-truth/timeout-custom-timers/index.js')};
const rows=[];
for(const [variant,source] of Object.entries(sources)){
  const scratch=mkdtempSync(join(tmpdir(),'skillfit-new-regression-control-'));
  try {
    cpSync(fixture,scratch,{recursive:true});cpSync(source,join(scratch,'index.js'));
    cpSync(join(delivery,'custom-timers.test.mjs'),join(scratch,'custom-timers.test.mjs'));
    const r=testRun(scratch,['custom-timers.test.mjs']),records=r.records.filter(r=>r.registered&&r.leaf);
    assert.equal(r.completed,true);assert.equal(r.noSkips,true);assert.equal(records.length,7);
    assert.equal(records.filter(r=>r.pass).length,variant==='original'?2:7);
    rows.push({variant,tests:records.length,passing:records.filter(r=>r.pass).length,
      failing:records.filter(r=>!r.pass).map(r=>r.path)});
  } finally {rmSync(scratch,{recursive:true,force:true});}
}
assert.ok(readFileSync(sources.historicalWrongV4).equals(readFileSync(sources.candidateDelivery)));
export const diagnostic={kind:'skillfit.new-regression-receiver-diagnostic',modelCalls:0,extraScoredTasks:0,
  wrongSourceByteIdentical:true,rows,conclusion:'The new regression admits both the known wrong globalThis repair and the maintainer repair; it cannot discriminate between them.'};

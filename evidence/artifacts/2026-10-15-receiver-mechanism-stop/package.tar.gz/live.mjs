import assert from 'node:assert/strict';
import {appendFileSync,existsSync,readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {spawn,execFileSync} from 'node:child_process';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {runTrial} from './runner/dist/harness/runner.js';
import {loadBench} from './runner/dist/harness/bench.js';
import {CliExecutor} from './runner/dist/harness/executors/cli.js';
import {ExperimentSession} from './runner/dist/harness/experiment-session.js';
import {collectInstalledSkillTarget,assertInstalledSkillFixtures} from './runner/dist/harness/installed-skill.js';
import {hashFileSet,listFilesRecursive,sha256File} from './runner/dist/harness/hash.js';
import {nativeDiffDescriptor,snapshotNativeDiffTool,assertNativeDiffFixtures} from './runner/dist/harness/native-diff.js';
import {getAgent} from './runner/dist/agents.js';
import {createController} from './controller.mjs';
import {inspectDelivery} from './inspect.mjs';
const root=dirname(fileURLToPath(import.meta.url)),json=p=>JSON.parse(readFileSync(p));
const save=(name,value)=>writeFileSync(join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const declaration=json(join(root,'declaration.json')),proposal=json(join(root,'proposal.json'));
const guard=()=>{
  assert.equal(process.version,declaration.nodeVersion);
  assert.equal(hashFileSet(join(root,'runner/dist'),listFilesRecursive(join(root,'runner/dist'))),declaration.runtimeSha256);
  for(const pin of declaration.pins)assert.equal(sha256File(pin.path),pin.sha256,pin.path);
};
guard();
const bench=loadBench(join(root,'inputs/bench')),target=collectInstalledSkillTarget(join(root,'inputs/candidate')),
  baselineTarget=collectInstalledSkillTarget(join(root,'inputs/control'));
assert.equal(bench.tasks.length,1);assert.equal(bench.contentSha256,declaration.benchSha256);
assert.equal(target.sha256,proposal.arms.candidate.sha256);assert.equal(baselineTarget.sha256,proposal.arms.control.sha256);
const agent=getAgent('codex'),installDir=agent.skills.projectDirs[0];
assertInstalledSkillFixtures(bench,target,installDir,agent.skills.projectDirs);assertNativeDiffFixtures(bench);
const executor=CliExecutor.forAgent('codex',{timeoutMs:600000,triggerSkillName:target.name});
assert.deepEqual(executor.describe(),declaration.executor);
const group=join(root,'records/mechanism-1');assert.equal(existsSync(group),false,'Single-use run group; never resume');
if(process.argv[2]!=='--execute'){
  assert.ok(process.argv.length===2||(process.argv.length===3&&process.argv[2]==='--dry-run'));
  save('dry-run.json',{modelCalls:0,maximumCalls:2,order:proposal.execution.order,executor:executor.describe(),declarationSha256:sha256File(join(root,'declaration.json'))});
  process.exit(0);
}
assert.equal(process.argv.length,3);
assert.equal(declaration.authorizedMaximumCalls,2);
save('launch.json',{at:new Date().toISOString(),maximumCalls:2,priorStudyCalls:194,noRetry:true,declarationSha256:sha256File(join(root,'declaration.json'))});
save('power-latch.json',{healthy:true});
const workspaces=['treatment','baseline'].map(condition=>join(group,proposal.task.id,condition,'trial-1'));
const session=new ExperimentSession({bench,target,baselineTarget,groupDir:group,workspaces,plannedCalls:2,maxCalls:2,agent:'codex',injected:false,
  guardFiles:[...declaration.pins.map(p=>({...p,label:'receiver mechanism pin'})),{label:'declaration',path:join(root,'declaration.json'),sha256:sha256File(join(root,'declaration.json'))},{label:'power latch',path:join(root,'power-latch.json'),sha256:sha256File(join(root,'power-latch.json'))}],
  details:{mode:'installed',inputMode:'workspace',purpose:'development',pairOrder:'conditional-candidate-first',trials:1,
    executorTimeoutSeconds:600,executor:executor.describe(),nativeDiffTool:nativeDiffDescriptor(),spendingBudget:proposal.budget.stopLines,
    secondCallAdmission:proposal.budget.secondCallAdmission,judge:null,mechanismProposalSha256:declaration.proposalSha256,automaticUpgrade:false}});
snapshotNativeDiffTool(group);
const nativePlan=json(join(group,'_plan.json'));
const assertEnvironment=()=>{assert.deepEqual(nativePlan.configuredSettings,proposal.execution.configuredSettings,'Configured settings changed');assert.equal(nativePlan.cliVersion,declaration.cliVersion,'CLI version changed');};
save('environment.json',{nodeVersion:nativePlan.nodeVersion,cliVersion:nativePlan.cliVersion,configuredSettings:nativePlan.configuredSettings,
  servedModel:nativePlan.servedModel,warnings:nativePlan.warnings,originalNativePlanSha256:session.planSha256});
const readPower=()=>({source:execFileSync('pmset',['-g','batt'],{encoding:'utf8'}).split('\n')[0],
  lid:execFileSync('ioreg',['-r','-k','AppleClamshellState','-d','4'],{encoding:'utf8'}).split('\n').find(l=>l.includes('AppleClamshellState'))??null});
let awake,awakeError,monitor,outcome,failure;
const power={startedAt:new Date().toISOString(),asserted:false,released:false,anomalies:[],beforeCalls:[]};
const assertPower=()=>{
  if(awakeError)throw awakeError;
  assert.equal(awake.exitCode,null);assert.equal(awake.signalCode,null);
  const state=readPower();assert.ok(state.source.includes("'AC Power'"),'AC power lost');assert.ok(/= No\s*$/.test(state.lid??''),'Lid closed or unobservable');
  const lines=execFileSync('pmset',['-g','assertions'],{encoding:'utf8'}).split('\n').filter(l=>l.includes('pid '+awake.pid+'(caffeinate)'));
  assert.ok(lines.some(l=>l.includes('PreventUserIdleSystemSleep'))&&lines.some(l=>l.includes('PreventSystemSleep')),'Owned sleep assertion absent');
  return state;
};
const latch=error=>{
  if(power.anomalies.length)return;
  const event={at:new Date().toISOString(),error:error.message};power.anomalies.push(event);
  copyFileSync(join(root,'power-latch.json'),join(root,'power-latch.before-error.json'));
  writeFileSync(join(root,'power-latch.json'),JSON.stringify({healthy:false,...event})+'\n');
};
const budgetEvent=(phase,item,state)=>appendFileSync(join(group,'_budget.jsonl'),JSON.stringify({phase,...item,state})+'\n');
try {
  assertEnvironment();
  awake=spawn('caffeinate',['-i','-s','-w',String(process.pid)],{stdio:'ignore'});awake.on('error',e=>{awakeError=e;});
  for(let i=0;i<25;i++){
    await new Promise(r=>setTimeout(r,200));
    try{power.startState=assertPower();power.asserted=true;break;}catch(e){if(i===24)throw e;}
  }
  monitor=setInterval(()=>{try{appendFileSync(join(root,'power-observations.jsonl'),JSON.stringify({at:new Date().toISOString(),...assertPower()})+'\n');}catch(e){latch(e);}},30000);
  const plan={bench,target,baselineTarget,executor:session.wrap(executor,'agent'),session,inputMode:'workspace',
    skillInstallDir:installDir,skillSearchDirs:agent.skills.projectDirs,judge:null,trials:1,runsRoot:join(root,'records'),runGroup:'mechanism-1'};
  outcome=await createController(proposal)({
    before:async(item,rows,state)=>{
      guard();session.check();assert.equal(power.anomalies.length,0,'Power anomaly latched');const current=assertPower();
      if(!item.phase){budgetEvent('before-call',item,state);save(`before-call-${item.ordinal}.json`,{...item,at:new Date().toISOString(),power:current,spending:state});
        power.beforeCalls.push({ordinal:item.ordinal,arm:item.arm,power:current});console.error(`Starting ${item.ordinal}/2: ${item.arm}`);}
    },
    invoke:item=>runTrial(plan,proposal.task.id,item.arm==='candidate'?'treatment':'baseline',1),
    after:async(item,row,rows)=>{
      const {spendingBudgetState}=await import('./runner/dist/harness/eval-budget.js');
      budgetEvent('after-call',item,spendingBudgetState(proposal.budget.stopLines,rows));
      const evidence=inspectDelivery(root,row,item.arm,installDir);save(`inspection-${item.ordinal}.json`,evidence);
      guard();session.check();assertPower();assert.equal(power.anomalies.length,0);
      return evidence;
    },
    review:async(item,row,evidence)=>{
      save('awaiting-candidate-review.json',{at:new Date().toISOString(),ordinal:item.ordinal,receiptSha256:evidence.receiptSha256,
        traceSha256:evidence.traceSha256,inspection:'inspection-1.json',gate:'Public command evidence review only; no judge call; no automatic positive decision'});
      console.error('Candidate functional/budget gates passed; waiting for the predeclared public-command review.');
      const start=performance.now(),reviewPath=join(root,'candidate-mechanism-review.json');
      while(!existsSync(reviewPath)){
        guard();session.check();assertPower();assert.equal(power.anomalies.length,0);
        assert.ok(performance.now()-start<600000,'PUBLIC_REVIEW_DEADLINE; no further call');
        await new Promise(r=>setTimeout(r,1000));
      }
      const audit=json(reviewPath);assert.equal(audit.receiptSha256,evidence.receiptSha256);assert.equal(audit.traceSha256,evidence.traceSha256);
      assert.equal(audit.inspectedPublicEvidenceOnly,true);
      for(const ref of [...(audit.skillReadEvidence??[]),...(audit.mechanismEvidence??[])]) {
        assert.ok(evidence.commands.some(c=>c.id===ref.itemId&&c.exit_code===0&&c.aggregated_output?.length>0),'Invalid public command evidence reference');
      }
      if(audit.skillRead==='observed')assert.ok(audit.skillReadEvidence?.length>0);
      if(audit.mechanism==='observed')assert.ok(audit.mechanismEvidence?.length>0);
      save('accepted-review-fingerprint.json',{sha256:sha256File(reviewPath),review:audit});return audit;
    },
  });
  save('outcome.json',{...outcome,at:new Date().toISOString(),realCalls:session.summary().callsStarted,cumulativeStudyCalls:194+session.summary().callsStarted});
  if(outcome.status!=='completed')failure=new Error(outcome.reason);
  console.log(JSON.stringify({status:outcome.status,reason:outcome.reason,realCalls:session.summary().callsStarted,automaticUpgrade:false}));
} catch(error) {
  failure=error;save('fatal-error.json',{at:new Date().toISOString(),error:error.message,calls:session.summary().callsStarted,noRetry:true});console.error(error.message);
} finally {
  if(monitor)clearInterval(monitor);
  if(failure)process.exitCode=2;
  session.finish(failure);
  try{power.finishState=readPower();}catch(e){power.finishReadError=e.message;}
  if(awake){awake.kill();await new Promise(r=>{if(awake.exitCode!==null||awake.signalCode!==null)return r();
    const t=setTimeout(()=>{awake.kill('SIGKILL');r();},2000);awake.once('exit',()=>{clearTimeout(t);r();});});power.released=awake.exitCode!==null||awake.signalCode!==null;}else power.released=true;
  power.finishedAt=new Date().toISOString();save('power.json',power);
}

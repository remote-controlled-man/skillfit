import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');
const completionEvents = ['end', 'prefinish', 'finish'];

const assertCompletionListenersRemoved = stream => {
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0, `${event} listeners are removed`);
};

test('pre-registered completion handlers run in order and only once', () => {
  const stream = new Minipass();
  const calls = [];
  for (const event of completionEvents) {
    assert.equal(stream.on(event, function () {
      assert.equal(this, stream);
      calls.push(`${event}:on`);
    }), stream);
    assert.equal(stream.once(event, () => calls.push(`${event}:once`)), stream);
  }

  assert.equal(stream.end(() => calls.push('end:callback')), stream);
  const expected = [
    'end:on', 'end:once', 'end:callback',
    'prefinish:on', 'prefinish:once',
    'finish:on', 'finish:once'
  ];
  assert.deepEqual(calls, expected);
  assert.equal(stream.emittedEnd, true);
  assert.equal(stream.readable, false);
  assert.equal(stream.writable, false);
  assertCompletionListenersRemoved(stream);

  assert.equal(stream.end(), stream);
  assert.equal(stream.read(), null);
  stream.resume();
  for (const event of completionEvents)
    stream.emit(event);
  assert.deepEqual(calls, expected);
  assertCompletionListenersRemoved(stream);
});

test('buffered data is delivered before all completion events', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const calls = [];
  for (const event of completionEvents)
    stream.on(event, () => calls.push(event));

  assert.equal(stream.end('payload'), stream);
  assert.equal(stream.bufferLength, 7);
  assert.equal(stream.writable, false);
  assert.equal(stream.readable, true);
  assert.equal(stream.emittedEnd, false);
  assert.deepEqual(calls, []);

  assert.equal(stream.on('data', chunk => calls.push(`data:${chunk}`)), stream);
  const expected = ['data:payload', ...completionEvents];
  assert.deepEqual(calls, expected);
  assert.equal(stream.bufferLength, 0);
  assert.equal(stream.readable, false);
  assertCompletionListenersRemoved(stream);
  assert.equal(stream.read(), null);
  stream.resume();
  assert.deepEqual(calls, expected);
});

test('late on, addListener and once handlers run synchronously without replaying old handlers', () => {
  const stream = new Minipass();
  stream.end();
  const calls = [];
  const expected = [];

  for (const event of completionEvents) {
    for (const method of ['on', 'addListener', 'once']) {
      const label = `${event}:${method}`;
      assert.equal(stream[method](event, function () {
        assert.equal(this, stream);
        calls.push(label);
      }), stream);
      expected.push(label);
      assert.deepEqual(calls, expected);
      assertCompletionListenersRemoved(stream);
    }
  }

  stream.end();
  stream.resume();
  for (const event of completionEvents)
    stream.emit(event);
  assert.deepEqual(calls, expected);
});

for (const during of ['end', 'prefinish']) {
  test(`a late end handler added during ${during} preserves pending completion handlers`, () => {
    const stream = new Minipass();
    const calls = [];
    for (const event of completionEvents) {
      stream.once(event, () => {
        calls.push(event);
        if (event === during) {
          assert.equal(stream.once('end', () => calls.push('late:end')), stream);
          assert.equal(calls.at(-1), 'late:end');
        }
      });
    }

    stream.end();
    const expected = during === 'end'
      ? ['end', 'late:end', 'prefinish', 'finish']
      : ['end', 'prefinish', 'late:end', 'finish'];
    assert.deepEqual(calls, expected);
    assertCompletionListenersRemoved(stream);
    stream.end();
    stream.resume();
    assert.deepEqual(calls, expected);
  });
}

test('adding a prefinish handler during end preserves synchronous replay and finish delivery', () => {
  const stream = new Minipass();
  const calls = [];
  stream.once('end', () => {
    calls.push('end');
    stream.once('prefinish', () => calls.push('late:prefinish'));
    assert.deepEqual(calls, ['end', 'prefinish', 'late:prefinish']);
  });
  stream.on('prefinish', () => calls.push('prefinish'));
  stream.on('finish', () => calls.push('finish'));

  stream.end();
  assert.deepEqual(calls, ['end', 'prefinish', 'late:prefinish', 'finish']);
  assertCompletionListenersRemoved(stream);
});

test('explicit completion emission preserves arguments, return values and other event listeners', () => {
  const stream = new Minipass();
  const calls = [];
  const payload = {complete: true};
  for (const event of completionEvents)
    stream.on(event, (...args) => calls.push([event, ...args]));
  const onCustom = () => {};
  stream.on('custom', onCustom);

  for (let i = 0; i < completionEvents.length; i++) {
    const event = completionEvents[i];
    assert.equal(stream.emit(event, payload, 'extra'), true);
    assert.equal(stream.listenerCount(event), 0);
    for (const pending of completionEvents.slice(i + 1))
      assert.equal(stream.listenerCount(pending), 1);
  }

  const expected = completionEvents.map(event => [event, payload, 'extra']);
  assert.deepEqual(calls, expected);
  assert.deepEqual(stream.listeners('custom'), [onCustom]);
  assert.equal(stream.emit('end', payload, 'extra'), undefined);
  assert.equal(stream.emit('prefinish', payload, 'extra'), false);
  assert.equal(stream.emit('finish', payload, 'extra'), false);
  assert.deepEqual(calls, expected);
  assertCompletionListenersRemoved(stream);
});

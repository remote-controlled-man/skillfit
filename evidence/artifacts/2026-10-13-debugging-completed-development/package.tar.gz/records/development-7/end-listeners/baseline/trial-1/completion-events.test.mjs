import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');
const completionEvents = ['end', 'prefinish', 'finish'];

for (const method of ['on', 'once']) {
  test(`${method} delivers every completion event once and in order`, () => {
    const stream = new Minipass();
    const calls = [];
    let endCallbacks = 0;
    let otherCalls = 0;

    stream.on('other', () => otherCalls++);
    for (const event of completionEvents) {
      stream[method](event, () => calls.push(`${event}:first`));
      stream[method](event, () => calls.push(`${event}:second`));
    }

    assert.equal(stream.end(() => endCallbacks++), stream);
    const expected = completionEvents.flatMap(event => [
      `${event}:first`, `${event}:second`,
    ]);
    assert.deepEqual(calls, expected);
    assert.equal(endCallbacks, 1);
    assert.equal(stream.emittedEnd, true);
    assert.equal(stream.readable, false);
    assert.equal(stream.writable, false);
    for (const event of completionEvents)
      assert.equal(stream.listenerCount(event), 0);

    stream.end();
    stream.resume();
    assert.equal(stream.read(), null);
    for (const event of completionEvents)
      stream.emit(event);
    assert.deepEqual(calls, expected);
    assert.equal(endCallbacks, 1);

    stream.emit('other');
    assert.equal(otherCalls, 1);
  });
}

test('buffered completion waits for the last read and delivers all events', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const calls = [];
  for (const event of completionEvents)
    stream.on(event, () => calls.push(event));

  stream.end('payload');
  assert.deepEqual(calls, []);
  assert.equal(stream.emittedEnd, false);
  assert.equal(stream.read(2), 'pa');
  assert.deepEqual(calls, []);
  assert.equal(stream.read(), 'yload');
  assert.deepEqual(calls, completionEvents);
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0);

  stream.resume();
  stream.end();
  assert.deepEqual(calls, completionEvents);
});

for (const method of ['on', 'addListener', 'once']) {
  test(`${method} replays completion synchronously only for new listeners`, () => {
    const stream = new Minipass();
    const calls = [];
    const expected = [];
    stream.end();

    for (let round = 0; round < 2; round++) {
      for (const event of completionEvents) {
        const label = `${round}:${event}`;
        expected.push(label);
        assert.equal(stream[method](event, () => calls.push(label)), stream);
        assert.deepEqual(calls, expected);
        assert.equal(stream.listenerCount(event), 0);
      }
    }

    stream.end();
    stream.resume();
    for (const event of completionEvents)
      stream.emit(event);
    assert.deepEqual(calls, expected);
  });
}

test('completion replay during end preserves pending finish listeners', () => {
  const stream = new Minipass();
  const calls = [];
  stream.on('end', () => {
    calls.push('end');
    stream.on('prefinish', () => calls.push('late prefinish'));
    assert.deepEqual(calls, ['end', 'prefinish', 'late prefinish']);
    assert.equal(stream.listenerCount('prefinish'), 0);
    assert.equal(stream.listenerCount('finish'), 1);
  });
  stream.on('prefinish', () => calls.push('prefinish'));
  stream.on('finish', () => calls.push('finish'));

  stream.end();
  assert.deepEqual(calls, ['end', 'prefinish', 'late prefinish', 'finish']);
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0);
});

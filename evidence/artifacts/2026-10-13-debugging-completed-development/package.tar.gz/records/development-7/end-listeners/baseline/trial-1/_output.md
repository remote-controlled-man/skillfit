我会使用 diagnosing-bugs 技能，先检查完成事件的分发路径和现有测试，再修复并添加回归覆盖；全程只使用本地源码。

已定位到清理逻辑：`emit('end')` 返回时会同时删除 `end`、`prefinish` 和 `finish` 的监听器，因此后两个事件触发时已没有处理函数。我会先用回归测试复现，并覆盖单次调用、缓冲数据读完后完成，以及完成后添加监听器的同步回放行为。

修复后，正常分发和晚注册回放都只清理当前事件的监听器，保留其他完成事件的处理函数。修复前新增测试有 4 项失败；修复后 `npm test` 的 9 项测试全部通过，包括原有测试。接下来检查最终差异和文件范围。

已修复 [index.js](<TEMP_RUNS>/minipass-v3-v4-development-7-deadline1200/end-listeners/baseline/trial-1/index.js)。根因是 `end` 分发后的清理逻辑同时删除了三个完成事件的监听器，导致后续 `prefinish`、`finish` 无处理函数可调用。现在只清理当前事件，保留单次调用及晚注册监听器的同步回放行为。

新增 [completion-events.test.mjs](<TEMP_RUNS>/minipass-v3-v4-development-7-deadline1200/end-listeners/baseline/trial-1/completion-events.test.mjs)，覆盖事件顺序、重复完成、缓冲读取和晚注册行为。

验证：修复前新增测试有 4 项失败；修复后 `npm test` 全部 **9 项通过**，`git diff --check` 通过。全程离线，原有测试、runtime、元数据、文档和 vendor 文件均未修改。
import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createRequire } from 'node:module';
import { Writable } from 'node:stream';
import { finished } from 'node:stream/promises';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

// Forward writes unchanged, but let the cache's drain reach the tee later.
class SlowDrainProxy extends EventEmitter {
  constructor(cache) {
    super();
    this.cache = cache;
    cache.on('drain', () => setImmediate(() => this.emit('drain')));
  }

  write(chunk, encoding, cb) {
    return this.cache.write(chunk, encoding, cb);
  }

  end() {
    this.cache.end();
  }
}

// A public stream facade with separate input and output stages. Reading the
// facade resumes its output; writes and backpressure travel through its input.
class Pipeline extends Minipass {
  constructor(input, output, options) {
    super(options);
    this.input = input;
    this.on('resume', () => output.resume());
    output.on('data', chunk => {
      if (!super.write(chunk)) output.pause();
    });
    output.on('end', () => super.end());
  }

  write(chunk, encoding, cb) {
    return this.input.write(chunk, encoding, cb);
  }

  end() {
    this.input.end();
    return this;
  }
}

class CacheTee extends Minipass {
  constructor(proxy, options) {
    super(options);
    this.proxy = proxy;
    this.cacheAttached = false;
  }

  write(chunk, encoding, cb) {
    if (!this.cacheAttached) {
      this.cacheAttached = true;
      this.pipe(this.proxy);
    }
    return super.write(chunk, encoding, cb);
  }
}

test('tee pipeline preserves output order through a slow cache drain proxy',
  { timeout: 2000 }, async () => {
    const options = { encoding: 'utf8' };
    const input = new Minipass(options);
    const tee = new Minipass(options);
    const output = new Minipass(options);
    const cached = [];
    const cache = new Writable({
      highWaterMark: 1,
      write(chunk, encoding, cb) {
        cached.push(chunk.toString());
        setImmediate(cb);
      }
    });
    const cacheDone = finished(cache);
    tee.pipe(new SlowDrainProxy(cache));
    tee.pipe(output);
    input.pipe(tee);
    const pipeline = new Pipeline(input, output, options);
    const chunks = ['a', 'b', 'c', 'd'];

    assert.deepEqual(chunks.map(chunk => pipeline.write(chunk)),
      [false, false, false, false]);
    assert.equal(pipeline.bufferLength, 1);
    assert.equal(input.paused, true);
    pipeline.end();

    const destination = new Minipass(options);
    const result = destination.concat();
    assert.equal(pipeline.pipe(destination), destination);
    const actual = await result;
    await cacheDone;
    assert.equal(actual, chunks.join(''));
    assert.deepEqual(cached, chunks);
  });

test('adding the cache pipe during a tee write does not resume an active flush',
  { timeout: 2000 }, async () => {
    const options = { encoding: 'utf8' };
    const input = new Minipass(options);
    const output = new Minipass(options);
    const cached = [];
    const cache = new Writable({
      highWaterMark: 1,
      write(chunk, encoding, cb) {
        cached.push(chunk.toString());
        setImmediate(cb);
      }
    });
    const cacheDone = finished(cache);
    const tee = new CacheTee(new SlowDrainProxy(cache), options);
    tee.pipe(output);
    const pipeline = new Pipeline(input, output, options);
    const destination = new Minipass(options);
    const result = destination.concat();
    pipeline.pipe(destination);

    const chunks = ['a', 'b', 'c', 'd'];
    assert.deepEqual(chunks.map(chunk => pipeline.write(chunk)),
      [false, false, false, false]);
    assert.equal(input.pipe(tee), tee);
    assert.equal(input.paused, true);
    pipeline.end();

    const actual = await result;
    await cacheDone;
    assert.equal(actual, chunks.join(''));
    assert.deepEqual(cached, chunks);
  });

for (const { name, options, chunks } of [
  { name: 'strings', options: { encoding: 'utf8' }, chunks: ['a', 'b', 'c', 'd'] },
  { name: 'buffers', options: {},
    chunks: ['a', 'b', 'c', 'd'].map(value => Buffer.from(value)) },
  { name: 'objects', options: { objectMode: true },
    chunks: [1, 2, 3, 4].map(value => ({ value })) }
]) {
  test(`a reentrant ${name} write respects backpressure from older buffered data`, () => {
    const stream = new Minipass(options);
    const destination = new EventEmitter();
    const received = [];
    let blocked = true;
    let callbacks = 0;
    let drains = 0;
    let reentrantReturn;
    destination.write = chunk => {
      received.push(chunk);
      return !blocked;
    };
    destination.end = () => {};
    stream.on('drain', () => drains++);
    assert.equal(stream.write(chunks[0]), false);
    assert.equal(stream.write(chunks[1]), false);
    stream.once('resume', () => {
      reentrantReturn = stream.write(chunks[2], () => callbacks++);
    });

    assert.equal(stream.pipe(destination), destination);
    assert.equal(reentrantReturn, false);
    assert.equal(callbacks, 1);
    assert.deepEqual(received, chunks.slice(0, 1));
    assert.equal(stream.bufferLength, 2);
    assert.equal(stream.flowing, false);
    assert.equal(stream.paused, true);
    assert.equal(drains, 0);

    blocked = false;
    destination.emit('drain');
    assert.deepEqual(received, chunks.slice(0, 3));
    assert.equal(stream.bufferLength, 0);
    assert.equal(drains, 1);
    assert.equal(stream.write(chunks[3], () => callbacks++), true);
    assert.equal(callbacks, 2);
    assert.deepEqual(received, chunks);
    stream.end();
  });
}

test('flushing older data during write does not signal drain before that write', () => {
  const stream = new Minipass({ encoding: 'utf8' });
  const destination = new Minipass({ encoding: 'utf8' });
  const received = [];
  destination.on('data', chunk => received.push(chunk));
  assert.equal(stream.write('a'), false);
  stream.once('resume', () => assert.equal(stream.write('b'), true));
  stream.once('drain', () => assert.equal(stream.write('c'), true));
  stream.pipe(destination, { end: false });
  stream.end();
  assert.deepEqual(received, ['a', 'b', 'c']);
  assert.equal(destination.writable, true);
  destination.end();
});

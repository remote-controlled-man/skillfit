import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createRequire } from 'node:module';
import { Transform } from 'node:stream';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

class SlowProxy extends Transform {
  constructor(objectMode) {
    super({ objectMode, highWaterMark: 1 });
    this.writeReturns = [];
  }

  _transform(chunk, encoding, callback) {
    setImmediate(() => {
      this.push(chunk);
      callback();
    });
  }

  write(...args) {
    const result = super.write(...args);
    this.writeReturns.push(result);
    return result;
  }
}

for (const [objectMode, cacheFirst] of [[false, true], [false, false], [true, true], [true, false]]) {
  test(`tee, slow proxy and cache preserve order (${objectMode ? 'objects' : 'bytes'}, ${cacheFirst ? 'cache' : 'proxy'} first)`,
    { timeout: 2000 }, async t => {
      const options = objectMode ? { objectMode: true } : { encoding: 'utf8' };
      const input = new Minipass(options);
      const tee = new Minipass(options);
      const cache = new Minipass(options);
      const proxy = new SlowProxy(objectMode);
      const output = new Minipass(options);
      const chunks = Array.from({ length: 10 }, (_, i) =>
        objectMode ? { sequence: i } : String.fromCharCode(97 + i));
      const cached = [];

      t.after(() => {
        proxy.destroy();
        for (const stream of [input, tee, cache, output]) stream.destroy();
      });
      proxy.on('error', error => output.destroy(error));
      cache.on('readable', () => {
        let chunk;
        while ((chunk = cache.read()) !== null) cached.push(chunk);
      });
      const result = objectMode ? output.collect() : output.concat();
      const finished = Promise.all([result, input.promise(), tee.promise(), cache.promise()]);
      // Cleanup may reject these promises after an earlier assertion failed.
      finished.catch(() => {});
      // Connect both tee branches before letting the buffered input flow.
      for (const destination of cacheFirst ? [cache, proxy] : [proxy, cache])
        assert.equal(tee.pipe(destination), destination);
      proxy.pipe(output);
      for (const chunk of chunks) assert.equal(input.write(chunk), false);
      assert.equal(input.pipe(tee), tee);

      // The proxy has accepted only one chunk and has not drained yet.
      const initialWriteReturns = proxy.writeReturns.slice();
      const inputWasFlowing = input.flowing;
      const teeWasFlowing = tee.flowing;
      const initialBufferLength = input.bufferLength;
      input.end();

      const [actual] = await finished;
      if (objectMode) {
        assert.deepEqual(actual, chunks);
        assert.deepEqual(cached, chunks);
      } else {
        assert.equal(actual, chunks.join(''));
        assert.equal(cached.join(''), chunks.join(''));
      }
      assert.deepEqual(initialWriteReturns, [false]);
      assert.equal(inputWasFlowing, false);
      assert.equal(teeWasFlowing, false);
      assert.equal(initialBufferLength, chunks.length - 1);
      assert.deepEqual(proxy.writeReturns, chunks.map(() => false));
      assert.equal(input.bufferLength, 0);
      assert.equal(tee.bufferLength, 0);
      assert.equal(cache.bufferLength, 0);
    });
}

test('pipe and drain only resume a stream that is not already flowing', () => {
  const source = new Minipass({ objectMode: true });
  const destination = new EventEmitter();
  destination.write = () => true;
  destination.end = () => {};
  source.resume();
  let resumes = 0;
  let drains = 0;
  source.on('resume', () => resumes++);
  source.on('drain', () => drains++);

  assert.equal(source.pipe(destination), destination);
  destination.emit('drain');
  assert.equal(resumes, 0);
  assert.equal(drains, 0);
  source.pause();
  destination.emit('drain');
  assert.equal(source.flowing, true);
  assert.equal(resumes, 1);
  assert.equal(drains, 1);
  source.end();
  assert.equal(destination.listenerCount('drain'), 0);
});

test('a write during resume flushes older chunks without announcing an early drain', () => {
  const source = new Minipass({ objectMode: true });
  const destination = new EventEmitter();
  const received = [];
  destination.write = chunk => { received.push(chunk); return true; };
  destination.end = () => {};
  assert.equal(source.write(1), false);
  assert.equal(source.write(2), false);
  let callbacks = 0;
  let writeReturn;
  source.once('resume', () => {
    writeReturn = source.write(3, () => callbacks++);
  });
  source.once('drain', () => assert.equal(source.write(4), true));

  source.pipe(destination);
  assert.deepEqual(received, [1, 2, 3, 4]);
  assert.equal(writeReturn, true);
  assert.equal(callbacks, 1);
  assert.equal(source.bufferLength, 0);
  source.end();
});

test('flushing older writes stops at backpressure and buffers the new write last', () => {
  const source = new Minipass({ objectMode: true });
  const destination = new EventEmitter();
  const received = [];
  let blocked = true;
  let ended = false;
  destination.write = chunk => { received.push(chunk); return !blocked; };
  destination.end = () => { ended = true; };
  source.write(1);
  source.write(2);
  let writeReturn;
  source.once('resume', () => { writeReturn = source.write(3); });
  let drains = 0;
  source.on('drain', () => drains++);

  source.pipe(destination);
  assert.deepEqual(received, [1]);
  assert.equal(writeReturn, false);
  assert.equal(source.flowing, false);
  assert.equal(source.bufferLength, 2);
  assert.equal(drains, 0);
  source.end();
  assert.equal(ended, false);
  blocked = false;
  destination.emit('drain');
  assert.deepEqual(received, [1, 2, 3]);
  assert.equal(source.bufferLength, 0);
  assert.equal(ended, true);
});

test('a write that pauses during resume does not announce drain with an empty buffer', () => {
  const source = new Minipass({ objectMode: true });
  const destination = new EventEmitter();
  const received = [];
  let ended = false;
  destination.write = chunk => { received.push(chunk); return false; };
  destination.end = () => { ended = true; };
  let writeReturn;
  source.once('resume', () => { writeReturn = source.write(1); });
  let drains = 0;
  source.on('drain', () => drains++);

  source.pipe(destination);
  assert.deepEqual(received, [1]);
  assert.equal(writeReturn, false);
  assert.equal(source.flowing, false);
  assert.equal(source.bufferLength, 0);
  assert.equal(drains, 0);
  source.end();
  assert.equal(ended, false);
  destination.emit('drain');
  assert.equal(ended, true);
});

for (const chunk of ['value', '']) {
  test(`write returns the flow state after its callback (${chunk ? 'data' : 'empty'})`, () => {
    const source = new Minipass({ encoding: 'utf8' });
    const received = [];
    source.on('data', value => received.push(value));
    let callbacks = 0;
    assert.equal(source.write(chunk, () => {
      callbacks++;
      source.pause();
    }), false);
    assert.equal(source.flowing, false);
    assert.equal(source.write(chunk, 'utf8', () => {
      callbacks++;
      source.resume();
    }), true);
    assert.equal(source.flowing, true);
    assert.equal(callbacks, 2);
    assert.deepEqual(received, chunk ? [chunk, chunk] : []);
    source.end();
  });
}

test('write returns the flow state after a readable listener consumes the buffer', () => {
  const source = new Minipass({ encoding: 'utf8' });
  const received = [];
  source.on('readable', () => source.resume());
  // A resume consumes the data synchronously, without a data listener starting flow early.
  source.on('resume', () => source.once('data', chunk => received.push(chunk)));
  assert.equal(source.write('value'), true);
  assert.deepEqual(received, ['value']);
  assert.equal(source.bufferLength, 0);
  source.end();
});

我会先读取项目规则、诊断技能和现有实现，定位缓冲数据未触发 `readable` 的原因，再添加回归测试并运行本地检查。全程不使用网络。

我会按 `diagnosing-bugs` 技能先用公开 API 复现故障，再做最小修复，并验证流动模式和空流的行为。

原因已定位：`write()` 在写入时同步发出 `readable`，但 `on()` 注册监听器时没有检查已有缓冲数据。那次通知发生在监听器注册之前，因此不会被收到。我会在注册后补发通知，并验证它不会自动恢复流动或给空缓冲发出通知。

修复前，7 个涉及晚注册监听器的用例失败；加入两行缓冲检查后，`npm test` 的 12 个测试全部通过。回归测试覆盖了 Buffer、字符串、对象、`addListener`/`once`、暂停状态、已有数据的结束流程，以及流动模式和空流。现在检查最终差异，确认改动范围。

已修复 [index.js](<TEMP_RUNS>/minipass-v3-v4-development-7-deadline1200/buffered-readable/baseline/trial-1/index.js:370)。原因是 `write()` 同步发出 `readable` 时监听器尚未注册，而注册时没有检查已有缓冲。现在注册后若缓冲非空，就立即通知。

新增 [buffered-readable.test.mjs](<TEMP_RUNS>/minipass-v3-v4-development-7-deadline1200/buffered-readable/baseline/trial-1/buffered-readable.test.mjs)，覆盖晚注册、不同数据模式、`once`/`addListener`、暂停与结束流程，并验证普通流动和空流行为。

验证：修复前 7 个回归用例失败；修复后 `npm test` 全部 12 项通过，`git diff --check` 通过。原有测试、运行时、元数据、文档及 vendor 均未修改，全程离线。
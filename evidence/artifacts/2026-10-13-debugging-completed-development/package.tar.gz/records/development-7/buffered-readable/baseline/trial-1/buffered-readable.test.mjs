import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

for (const {name, options, chunks, expected} of [
  {
    name: 'buffers',
    chunks: [Buffer.from('already '), Buffer.from('available')],
    expected: [Buffer.from('already available')],
  },
  {
    name: 'decoded strings',
    options: {encoding: 'utf8'},
    chunks: ['already ', 'available'],
    expected: ['already available'],
  },
  {
    name: 'objects',
    options: {objectMode: true},
    chunks: [{id: 1}, {id: 2}],
    expected: [{id: 1}, {id: 2}],
  },
]) {
  test(`late readable listener consumes buffered ${name} without another write`, () => {
    const stream = new Minipass(options);
    for (const chunk of chunks)
      stream.write(chunk);

    const received = [];
    let notifications = 0;
    const result = stream.on('readable', function () {
      assert.equal(this, stream);
      notifications++;
      let chunk;
      while ((chunk = this.read()) !== null)
        received.push(chunk);
    });

    assert.equal(notifications, 1);
    assert.deepEqual(received, expected);
    assert.equal(result, stream);
    assert.equal(stream.bufferLength, 0);
    assert.equal(stream.flowing, false);
  });
}

test('readable notification preserves paused state and leaves data until read', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.pause();
  stream.write('buffered');

  let notifications = 0;
  stream.on('readable', () => notifications++);

  assert.equal(notifications, 1);
  assert.equal(stream.bufferLength, 'buffered'.length);
  assert.equal(stream.flowing, false);
  assert.equal(stream.paused, true);
  assert.equal(stream.read(), 'buffered');
  stream.write('later');
  assert.equal(notifications, 2);
  assert.equal(stream.read(), 'later');
});

for (const method of ['addListener', 'once']) {
  test(`${method} receives an immediate notification for buffered data`, () => {
    const stream = new Minipass({encoding: 'utf8'});
    stream.write('buffered');

    const received = [];
    const result = stream[method]('readable', () => received.push(stream.read()));
    assert.equal(result, stream);
    assert.deepEqual(received, ['buffered']);

    stream.write('later');
    if (method === 'once') {
      assert.deepEqual(received, ['buffered']);
      assert.equal(stream.listenerCount('readable'), 0);
      assert.equal(stream.read(), 'later');
    } else {
      assert.deepEqual(received, ['buffered', 'later']);
    }
  });
}

test('late readable listener drains an ended stream and allows end to fire', () => {
  const stream = new Minipass({encoding: 'utf8'});
  let ends = 0;
  stream.on('end', () => ends++);
  stream.end('buffered');
  assert.equal(ends, 0);

  const received = [];
  stream.on('readable', () => received.push(stream.read()));

  assert.deepEqual(received, ['buffered']);
  assert.equal(ends, 1);
  assert.equal(stream.emittedEnd, true);
});

test('data listeners still resume and deliver buffered and subsequent writes', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.write('buffered');

  const received = [];
  stream.on('data', chunk => received.push(chunk));
  assert.deepEqual(received, ['buffered']);
  assert.equal(stream.flowing, true);
  assert.equal(stream.bufferLength, 0);

  let notifications = 0;
  stream.on('readable', () => notifications++);
  stream.write('later');
  stream.end('last');

  assert.deepEqual(received, ['buffered', 'later', 'last']);
  assert.equal(notifications, 0);
  assert.equal(stream.emittedEnd, true);
});

test('empty streams do not emit readable and still end immediately', () => {
  const stream = new Minipass();
  let notifications = 0;
  let ends = 0;
  stream.on('readable', () => notifications++);
  stream.on('end', () => ends++);
  stream.write('');
  stream.write(Buffer.alloc(0));
  assert.equal(notifications, 0);
  assert.equal(stream.flowing, false);
  stream.end();
  stream.on('readable', () => notifications++);
  assert.equal(notifications, 0);
  assert.equal(ends, 1);
});

test('a drained stream waits for new buffered data before notifying', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.write('old');
  assert.equal(stream.read(), 'old');

  const received = [];
  stream.on('readable', () => received.push(stream.read()));
  assert.deepEqual(received, []);
  stream.write('new');
  assert.deepEqual(received, ['new']);
});

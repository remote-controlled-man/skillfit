import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

const bufferedCases = [
  {
    name: 'buffers',
    options: {},
    chunks: [Buffer.from('first'), Buffer.from('second')],
    expected: [Buffer.from('firstsecond')],
  },
  {
    name: 'decoded strings',
    options: {encoding: 'utf8'},
    chunks: ['first', 'second'],
    expected: ['firstsecond'],
  },
  {
    name: 'objects',
    options: {objectMode: true},
    chunks: [{value: 1}, {value: 2}],
    expected: [{value: 1}, {value: 2}],
  },
];

for (const {name, options, chunks, expected} of bufferedCases) {
  test(`late readable listener immediately consumes buffered ${name}`, () => {
    const stream = new Minipass(options);
    for (const chunk of chunks)
      assert.equal(stream.write(chunk), false);
    assert.ok(stream.bufferLength > 0);

    const received = [];
    let notifications = 0;
    let drains = 0;
    stream.on('drain', () => drains++);
    const result = stream.on('readable', function () {
      assert.equal(this, stream);
      assert.equal(stream.flowing, false);
      notifications++;
      let chunk;
      while ((chunk = stream.read()) !== null)
        received.push(chunk);
    });

    assert.equal(result, stream);
    assert.equal(notifications, 1);
    assert.deepEqual(received, expected);
    if (options.objectMode)
      received.forEach((chunk, index) => assert.equal(chunk, chunks[index]));
    assert.equal(drains, 1);
    assert.equal(stream.bufferLength, 0);
    assert.equal(stream.read(), null);
    assert.equal(stream.flowing, false);
    assert.equal(stream.paused, false);
  });
}

for (const method of ['addListener', 'once']) {
  test(`${method} observes existing data and retains its listener semantics`, () => {
    const stream = new Minipass({encoding: 'utf8'});
    assert.equal(stream.write('buffered'), false);
    const received = [];
    assert.equal(stream[method]('readable', function () {
      assert.equal(this, stream);
      received.push(stream.read());
    }), stream);

    assert.deepEqual(received, ['buffered']);
    assert.equal(stream.listenerCount('readable'), method === 'once' ? 0 : 1);
    assert.equal(stream.write('later'), false);
    assert.deepEqual(received, method === 'once' ? ['buffered'] : ['buffered', 'later']);
    assert.equal(stream.bufferLength, method === 'once' ? 5 : 0);
  });
}

for (const paused of [false, true]) {
  test(`readable registration preserves buffered data and paused=${paused}`, () => {
    const stream = new Minipass({encoding: 'utf8'});
    if (paused)
      stream.pause();
    stream.write('available');
    let resumes = 0;
    let drains = 0;
    let first = 0;
    let second = 0;
    stream.on('resume', () => resumes++);
    stream.on('drain', () => drains++);

    assert.equal(stream.on('readable', () => first++), stream);
    assert.equal(first, 1);
    assert.equal(stream.on('readable', () => second++), stream);
    assert.equal(first, 2);
    assert.equal(second, 1);
    assert.equal(stream.bufferLength, 9);
    assert.equal(stream.flowing, false);
    assert.equal(stream.paused, paused);
    assert.equal(resumes, 0);
    assert.equal(drains, 0);
    assert.equal(stream.read(), 'available');
    assert.equal(drains, 1);
  });
}

test('late readable consumer drains an ended buffer and emits completion once', () => {
  const stream = new Minipass({encoding: 'utf8'});
  assert.equal(stream.end('last'), stream);
  assert.equal(stream.writable, false);
  assert.equal(stream.emittedEnd, false);
  const events = [];
  for (const event of ['end', 'prefinish', 'finish'])
    stream.on(event, () => events.push(event));

  const received = [];
  assert.equal(stream.on('readable', () => {
    events.push('readable');
    received.push(stream.read());
  }), stream);

  assert.deepEqual(received, ['last']);
  assert.deepEqual(events, ['readable', 'end', 'prefinish', 'finish']);
  assert.equal(stream.bufferLength, 0);
  assert.equal(stream.readable, false);
  assert.equal(stream.emittedEnd, true);
  assert.equal(stream.read(), null);
  assert.deepEqual(events, ['readable', 'end', 'prefinish', 'finish']);
});

const emptyCases = [
  ['fresh', () => {}],
  ['zero-length writes', stream => {
    stream.write('');
    stream.write(Buffer.alloc(0));
  }],
  ['already consumed', stream => {
    stream.write('consumed');
    stream.read();
  }],
  ['ended', stream => stream.end()],
  ['destroyed', stream => {
    stream.write('discarded');
    stream.destroy();
  }],
];

for (const [name, prepare] of emptyCases) {
  test(`readable registration emits nothing for an empty ${name} stream`, () => {
    const stream = new Minipass();
    prepare(stream);
    let notifications = 0;
    assert.equal(stream.bufferLength, 0);
    const state = [stream.flowing, stream.paused, stream.readable, stream.emittedEnd];
    assert.equal(stream.on('readable', () => notifications++), stream);
    assert.equal(notifications, 0);
    assert.deepEqual([stream.flowing, stream.paused, stream.readable, stream.emittedEnd], state);
    assert.equal(stream.read(), null);
  });
}

test('an incomplete decoded character is not readable until completed', () => {
  const stream = new Minipass({encoding: 'utf8'});
  assert.equal(stream.write(Buffer.from([0xe2])), false);
  assert.equal(stream.bufferLength, 0);
  const received = [];
  stream.on('readable', () => received.push(stream.read()));
  assert.deepEqual(received, []);
  assert.equal(stream.write(Buffer.from([0x82, 0xac])), false);
  assert.deepEqual(received, ['€']);
  assert.equal(stream.bufferLength, 0);
});

test('listeners registered before writes still receive one notification per write', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const received = [];
  let callbacks = 0;
  stream.on('readable', () => received.push(stream.read()));
  assert.deepEqual(received, []);
  assert.equal(stream.write('first', () => callbacks++), false);
  assert.equal(stream.write('second', () => callbacks++), false);
  assert.deepEqual(received, ['first', 'second']);
  assert.equal(callbacks, 2);
  assert.equal(stream.flowing, false);
  assert.equal(stream.bufferLength, 0);
});

test('ordinary flowing delivery emits data without readable notifications', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const received = [];
  let notifications = 0;
  let ends = 0;
  assert.equal(stream.on('data', chunk => received.push(chunk)), stream);
  stream.on('end', () => ends++);
  stream.on('readable', () => notifications++);
  assert.equal(stream.flowing, true);
  assert.equal(stream.write('first'), true);
  assert.equal(stream.end('last'), stream);
  assert.deepEqual(received, ['first', 'last']);
  assert.equal(notifications, 0);
  assert.equal(stream.bufferLength, 0);
  assert.equal(ends, 1);
});

test('adding a data listener still resumes and flushes an explicitly paused buffer', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.pause();
  assert.equal(stream.write('buffered'), false);
  let notifications = 0;
  let resumes = 0;
  stream.on('readable', () => notifications++);
  stream.on('resume', () => resumes++);
  const received = [];
  assert.equal(stream.on('data', chunk => received.push(chunk)), stream);
  assert.deepEqual(received, ['buffered']);
  assert.equal(stream.flowing, true);
  assert.equal(stream.paused, false);
  assert.equal(resumes, 1);
  assert.equal(stream.bufferLength, 0);
  assert.equal(stream.write('later'), true);
  assert.deepEqual(received, ['buffered', 'later']);
  assert.equal(notifications, 1);
});

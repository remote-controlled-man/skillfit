import test from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Writable } from 'node:stream';
import { setImmediate as nextTurn } from 'node:timers/promises';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

const recordingDestination = (options = {}) => {
  const chunks = [];
  const operations = [];
  const destination = new Writable({
    ...options,
    write(chunk, encoding, callback) {
      chunks.push(chunk);
      operations.push('write');
      callback();
    },
  });
  const end = destination.end;
  let endCalls = 0;
  destination.end = function (...args) {
    endCalls++;
    operations.push('end');
    return end.apply(this, args);
  };
  return { destination, chunks, operations, get endCalls() { return endCalls; } };
};

test('repeated async end finalizes an empty pipe once', { timeout: 1000 }, async () => {
  const source = new Minipass({ async: true });
  const target = recordingDestination();
  let endEvents = 0;
  let callbacks = 0;
  source.on('end', () => endEvents++);
  assert.equal(source.pipe(target.destination), target.destination);

  for (let i = 0; i < 3; i++)
    assert.equal(source.end(() => callbacks++), source);

  assert.equal(source.writable, false);
  assert.equal(source.readable, true);
  assert.equal(source.emittedEnd, false);
  assert.equal(target.endCalls, 0);
  assert.equal(callbacks, 0);
  await nextTurn();

  assert.equal(target.endCalls, 1);
  assert.deepEqual(target.chunks, []);
  assert.equal(endEvents, 1);
  assert.equal(callbacks, 3);
  assert.equal(source.readable, false);
  assert.equal(source.emittedEnd, true);
  assert.equal(target.destination.writableFinished, true);
  assert.equal(target.destination.listenerCount('drain'), 0);

  // End stays idempotent after completion; late listeners still get replayed.
  assert.equal(source.end(), source);
  let lateEnds = 0;
  source.on('end', () => lateEnds++);
  await nextTurn();
  assert.equal(lateEnds, 1);
  assert.equal(endEvents, 1);
  assert.equal(target.endCalls, 1);
});

for (const flowing of [false, true]) {
  test(`repeated async end preserves ${flowing ? 'queued' : 'buffered'} bytes`, { timeout: 1000 }, async () => {
    const source = new Minipass({ async: true });
    const target = recordingDestination();
    source.pipe(target.destination);
    if (flowing)
      await nextTurn();

    assert.equal(source.write(Buffer.from('first:')), flowing);
    assert.equal(source.end(Buffer.from('last')), source);
    assert.equal(source.end(), source);
    assert.equal(source.end(), source);
    assert.deepEqual(target.chunks, []);
    assert.equal(target.endCalls, 0);
    await nextTurn();

    assert.equal(Buffer.concat(target.chunks).toString(), 'first:last');
    assert.deepEqual(target.operations, ['write', 'write', 'end']);
    assert.equal(target.endCalls, 1);
    assert.equal(source.bufferLength, 0);
    assert.equal(target.destination.writableFinished, true);
  });
}

test('a pipe attached while async end is pending receives queued data', { timeout: 1000 }, async () => {
  const source = new Minipass({ async: true });
  const target = recordingDestination();
  const observed = [];
  source.on('data', chunk => observed.push(chunk));
  source.end('pending');
  source.end();
  assert.equal(source.emittedEnd, false);
  assert.equal(source.pipe(target.destination), target.destination);
  assert.deepEqual(observed, []);
  assert.equal(target.endCalls, 0);
  await nextTurn();

  assert.equal(Buffer.concat(observed).toString(), 'pending');
  assert.equal(Buffer.concat(target.chunks).toString(), 'pending');
  assert.deepEqual(target.operations, ['write', 'end']);
  assert.equal(target.endCalls, 1);
});

test('repeated async end flushes the decoder tail before ending', { timeout: 1000 }, async () => {
  const source = new Minipass({ async: true, encoding: 'utf8' });
  const target = recordingDestination();
  source.pipe(target.destination);
  await nextTurn();
  source.write(Buffer.from([0x61, 0xe2, 0x82]));
  source.end();
  source.end();
  await nextTurn();

  assert.equal(Buffer.concat(target.chunks).toString(), 'a\ufffd');
  assert.deepEqual(target.operations, ['write', 'write', 'end']);
  assert.equal(target.endCalls, 1);
});

test('repeated async end honors end:false on one of multiple object pipes', { timeout: 1000 }, async () => {
  const source = new Minipass({ async: true, objectMode: true });
  const closing = recordingDestination({ objectMode: true });
  const open = recordingDestination({ objectMode: true });
  const first = { value: 1 };
  const last = { value: 2 };
  source.pipe(closing.destination);
  source.pipe(open.destination, { end: false });
  source.write(first);
  source.end(last);
  source.end();
  source.end();
  await nextTurn();

  for (const target of [closing, open]) {
    assert.deepEqual(target.chunks, [first, last]);
    assert.equal(target.chunks[0], first);
    assert.equal(target.chunks[1], last);
    assert.equal(target.destination.listenerCount('drain'), 0);
  }
  assert.equal(closing.endCalls, 1);
  assert.equal(closing.destination.writableFinished, true);
  assert.equal(open.endCalls, 0);
  assert.equal(open.destination.writableEnded, false);
  assert.equal(open.destination.write({ value: 3 }), true);
  assert.deepEqual(open.chunks, [first, last, { value: 3 }]);

  // Piping an already ended source must also keep end:false intact.
  const late = recordingDestination({ objectMode: true });
  source.pipe(late.destination, { end: false });
  assert.equal(late.endCalls, 0);
  assert.equal(late.destination.writableEnded, false);
  open.destination.end();
  late.destination.end();
});

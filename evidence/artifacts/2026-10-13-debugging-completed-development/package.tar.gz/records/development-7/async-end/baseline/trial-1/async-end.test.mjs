import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {Writable} from 'node:stream';
import {setImmediate as settle} from 'node:timers/promises';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

class RecordingWritable extends Writable {
  constructor(options) {
    super(options);
    this.chunks = [];
    this.endCalls = 0;
    this.chunksAtEnd = [];
  }

  _write(chunk, encoding, callback) {
    this.chunks.push(chunk);
    callback();
  }

  end(...args) {
    this.endCalls++;
    this.chunksAtEnd.push([...this.chunks]);
    return super.end(...args);
  }
}

const text = chunks => Buffer.concat(chunks).toString('utf8');

test('repeated async end calls end an empty destination once', {timeout: 1000}, async () => {
  const source = new Minipass({async: true});
  const destination = new RecordingWritable();
  let ends = 0;
  let callbacks = 0;
  source.on('end', () => ends++);
  source.pipe(destination);

  for (let i = 0; i < 3; i++)
    assert.equal(source.end(() => callbacks++), source);

  assert.equal(source.emittedEnd, false);
  assert.equal(destination.endCalls, 0);
  assert.equal(callbacks, 0);
  await settle();

  assert.equal(destination.endCalls, 1);
  assert.equal(ends, 1);
  assert.equal(callbacks, 3);
  assert.equal(source.emittedEnd, true);
  assert.equal(destination.listenerCount('drain'), 0);
});

for (const flowing of [false, true]) {
  test(`repeated async end preserves ${flowing ? 'flowing' : 'buffered'} data`, {timeout: 1000}, async () => {
    const source = new Minipass({async: true});
    const destination = new RecordingWritable();
    source.pipe(destination);
    if (flowing)
      await settle();

    source.write('first');
    source.end('last');
    source.end();
    source.end();
    assert.equal(destination.endCalls, 0);
    await settle();

    assert.equal(destination.endCalls, 1);
    assert.equal(text(destination.chunks), 'firstlast');
    assert.equal(text(destination.chunksAtEnd[0]), 'firstlast');
    assert.equal(destination.writableFinished, true);
  });
}

test('a pipe added while async end is pending receives queued data', {timeout: 1000}, async () => {
  const source = new Minipass({async: true});
  const first = new RecordingWritable();
  const second = new RecordingWritable();
  source.pipe(first);
  await settle();

  source.write('first');
  source.end('last');
  source.end();
  source.pipe(second);
  assert.equal(first.endCalls, 0);
  assert.equal(second.endCalls, 0);
  await settle();

  for (const destination of [first, second]) {
    assert.equal(destination.endCalls, 1);
    assert.equal(text(destination.chunks), 'firstlast');
    assert.equal(text(destination.chunksAtEnd[0]), 'firstlast');
  }
});

test('async end flushes the decoder tail before ending the destination', {timeout: 1000}, async () => {
  const source = new Minipass({async: true, encoding: 'utf8'});
  const destination = new RecordingWritable();
  source.pipe(destination);
  await settle();

  source.write('prefix');
  source.end(Buffer.from([0xe2, 0x82]));
  source.end();
  source.end();
  await settle();

  assert.equal(destination.endCalls, 1);
  assert.equal(text(destination.chunks), 'prefix\ufffd');
  assert.equal(text(destination.chunksAtEnd[0]), 'prefix\ufffd');
});

test('repeated async end preserves object identity and order', {timeout: 1000}, async () => {
  const source = new Minipass({async: true, objectMode: true});
  const destination = new RecordingWritable({objectMode: true});
  const first = {value: 1};
  const last = {value: 2};
  source.pipe(destination);
  await settle();

  source.write(first);
  source.end(last);
  source.end();
  source.end();
  await settle();

  assert.equal(destination.endCalls, 1);
  assert.deepEqual(destination.chunks, [first, last]);
  assert.equal(destination.chunks[0], first);
  assert.equal(destination.chunks[1], last);
  assert.deepEqual(destination.chunksAtEnd[0], [first, last]);
});

test('end: false keeps the destination writable and removes its drain listener', {timeout: 1000}, async () => {
  const source = new Minipass({async: true});
  const destination = new RecordingWritable();
  source.pipe(destination, {end: false});
  await settle();

  source.write('first');
  source.end('last');
  source.end();
  source.end();
  await settle();

  assert.equal(text(destination.chunks), 'firstlast');
  assert.equal(destination.endCalls, 0);
  assert.equal(destination.writableEnded, false);
  assert.equal(destination.listenerCount('drain'), 0);
  destination.write('more');
  assert.equal(text(destination.chunks), 'firstlastmore');
  destination.end();
});

test('repeated synchronous end still ends the destination once', {timeout: 1000}, async () => {
  const source = new Minipass();
  const destination = new RecordingWritable();
  source.pipe(destination);
  source.end('data');
  source.end();
  source.end();

  assert.equal(destination.endCalls, 1);
  assert.equal(text(destination.chunksAtEnd[0]), 'data');
  assert.equal(source.emittedEnd, true);
  await settle();
  assert.equal(destination.writableFinished, true);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

const modes = [
  {
    name: 'buffers',
    options: {},
    chunks: [Buffer.from('already '), Buffer.from('buffered')],
    expected: [Buffer.from('already buffered')],
  },
  {
    name: 'encoded strings',
    options: {encoding: 'utf8'},
    chunks: ['already ', 'buffered'],
    expected: ['already buffered'],
  },
  {
    name: 'objects including falsy values',
    options: {objectMode: true},
    chunks: [0, false, {value: 'buffered'}],
    expected: [0, false, {value: 'buffered'}],
  },
];

for (const {name, options, chunks, expected} of modes) {
  for (const method of ['on', 'addListener', 'once']) {
    test(`${method} immediately notifies a late readable consumer of ${name}`, () => {
      const stream = new Minipass(options);
      for (const chunk of chunks)
        assert.equal(stream.write(chunk), false);

      const received = [];
      let notifications = 0;
      const result = stream[method]('readable', function () {
        assert.equal(this, stream);
        notifications++;
        let chunk;
        while ((chunk = stream.read()) !== null)
          received.push(chunk);
      });

      assert.equal(result, stream);
      assert.equal(notifications, 1, 'buffered data must notify during registration');
      assert.deepEqual(received, expected);
      assert.equal(stream.bufferLength, 0);
      assert.equal(stream.flowing, false);
      if (method === 'once')
        assert.equal(stream.listenerCount('readable'), 0);
    });
  }
}

test('readable registration preserves buffered data and an explicit pause', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.write('buffered');
  stream.pause();
  let notifications = 0;
  let resumes = 0;
  stream.on('resume', () => resumes++);
  stream.on('readable', () => notifications++);

  assert.equal(notifications, 1);
  assert.equal(resumes, 0);
  assert.equal(stream.flowing, false);
  assert.equal(stream.paused, true);
  assert.equal(stream.bufferLength, 'buffered'.length);
  assert.equal(stream.read(), 'buffered');
});

test('a late readable consumer can drain data after the producer has ended', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.end('buffered');
  assert.equal(stream.emittedEnd, false);
  let ends = 0;
  stream.on('end', () => ends++);
  const received = [];
  stream.on('readable', () => received.push(stream.read()));

  assert.deepEqual(received, ['buffered']);
  assert.equal(ends, 1);
  assert.equal(stream.bufferLength, 0);
  assert.equal(stream.emittedEnd, true);
});

test('empty readable registration waits for a write and once fires only once', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const received = [];
  stream.once('readable', () => received.push(stream.read()));
  assert.deepEqual(received, []);
  assert.equal(stream.flowing, false);
  stream.write('first');
  stream.write('second');

  assert.deepEqual(received, ['first']);
  assert.equal(stream.read(), 'second');
});

test('an incomplete decoded character does not trigger a late readable listener', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.write(Buffer.from([0xe2, 0x82]));
  assert.equal(stream.bufferLength, 0);
  const received = [];
  stream.on('readable', () => received.push(stream.read()));
  assert.deepEqual(received, []);
  stream.write(Buffer.from([0xac]));
  assert.deepEqual(received, ['€']);
});

test('readable listeners preserve ordinary flowing data delivery', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.write('buffered');
  const received = [];
  stream.on('data', chunk => received.push(chunk));
  assert.deepEqual(received, ['buffered']);
  let notifications = 0;
  stream.on('readable', () => notifications++);
  assert.equal(stream.flowing, true);
  assert.equal(stream.write('next'), true);
  stream.end('last');

  assert.deepEqual(received, ['buffered', 'next', 'last']);
  assert.equal(notifications, 0);
  assert.equal(stream.bufferLength, 0);
  assert.equal(stream.emittedEnd, true);
});

test('an empty stream ends without a readable notification', () => {
  const stream = new Minipass();
  let notifications = 0;
  let ends = 0;
  stream.on('readable', () => notifications++);
  stream.on('end', () => ends++);
  stream.end();
  stream.on('readable', () => notifications++);

  assert.equal(notifications, 0);
  assert.equal(ends, 1);
  assert.equal(stream.emittedEnd, true);
});

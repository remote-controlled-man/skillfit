import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

for (const {name, options, chunks, expected} of [
  {
    name: 'buffers',
    chunks: [Buffer.from('ab'), Buffer.from('cd')],
    expected: [Buffer.from('abcd')],
  },
  {
    name: 'decoded strings',
    options: {encoding: 'utf8'},
    chunks: ['你好', '世界'],
    expected: ['你好世界'],
  },
  {
    name: 'objects including a falsy value',
    options: {objectMode: true},
    chunks: [0, {id: 1}],
    expected: [0, {id: 1}],
  },
]) {
  test(`late readable listener immediately consumes buffered ${name}`, () => {
    const stream = new Minipass(options);
    for (const chunk of chunks)
      stream.write(chunk);

    let calls = 0;
    const received = [];
    const result = stream.on('readable', function () {
      assert.equal(this, stream);
      calls++;
      let chunk;
      while ((chunk = this.read()) !== null)
        received.push(chunk);
    });

    assert.equal(result, stream);
    assert.equal(calls, 1, 'registration must notify without another write');
    assert.deepEqual(received, expected);
    assert.equal(stream.bufferLength, 0);
    assert.equal(stream.flowing, false);
    stream.end();
  });
}

for (const method of ['addListener', 'once']) {
  test(`${method} notifies about buffered data and retains its listener semantics`, () => {
    const stream = new Minipass({encoding: 'utf8'});
    stream.write('before');
    const received = [];
    assert.equal(stream[method]('readable', () => {
      received.push(stream.read());
    }), stream);

    assert.deepEqual(received, ['before']);
    stream.write('after');
    if (method === 'once') {
      assert.deepEqual(received, ['before']);
      assert.equal(stream.listenerCount('readable'), 0);
      assert.equal(stream.read(), 'after');
    } else {
      assert.deepEqual(received, ['before', 'after']);
    }
    stream.end();
  });
}

test('readable registration leaves buffered data and explicit pause intact', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.pause();
  stream.write('abc');
  let calls = 0;
  let resumes = 0;
  stream.on('resume', () => resumes++);
  stream.on('readable', () => calls++);

  assert.equal(calls, 1);
  assert.equal(stream.bufferLength, 3);
  assert.equal(stream.paused, true);
  assert.equal(stream.flowing, false);
  assert.equal(resumes, 0);
  stream.write('d');
  assert.equal(calls, 2);
  assert.equal(stream.read(), 'abcd');
  stream.end();
  stream.resume();
});

test('late readable listener drains an ended buffer and completes the stream', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.end('final');
  assert.equal(stream.emittedEnd, false);
  const events = [];
  for (const event of ['end', 'prefinish', 'finish'])
    stream.on(event, () => events.push(event));

  let received;
  stream.once('readable', () => {
    received = stream.read();
  });

  assert.equal(received, 'final');
  assert.deepEqual(events, ['end', 'prefinish', 'finish']);
  assert.equal(stream.emittedEnd, true);
  assert.equal(stream.readable, false);
  assert.equal(stream.bufferLength, 0);
});

test('data listeners still resume and deliver flowing writes without readable events', () => {
  const stream = new Minipass({encoding: 'utf8'});
  assert.equal(stream.write('buffered'), false);
  const received = [];
  stream.on('data', chunk => received.push(chunk));
  assert.deepEqual(received, ['buffered']);
  assert.equal(stream.flowing, true);
  assert.equal(stream.bufferLength, 0);

  let readableCalls = 0;
  stream.on('readable', () => readableCalls++);
  assert.equal(stream.write('flowing'), true);
  stream.end('final');

  assert.deepEqual(received, ['buffered', 'flowing', 'final']);
  assert.equal(readableCalls, 0);
  assert.equal(stream.emittedEnd, true);
});

test('empty streams never notify readable and preserve paused end behavior', () => {
  for (const paused of [false, true]) {
    const stream = new Minipass();
    if (paused)
      stream.pause();
    let readableCalls = 0;
    let endCalls = 0;
    stream.on('readable', () => readableCalls++);
    stream.on('end', () => endCalls++);
    stream.write(Buffer.alloc(0));
    stream.end();
    stream.on('readable', () => readableCalls++);

    assert.equal(readableCalls, 0);
    if (paused) {
      assert.equal(endCalls, 0);
      stream.resume();
    }
    assert.equal(endCalls, 1);
    assert.equal(stream.read(), null);
    let lateEndCalls = 0;
    stream.on('end', () => lateEndCalls++);
    assert.equal(lateEndCalls, 1);
  }
});

test('incomplete decoded input does not notify until readable content exists', () => {
  const stream = new Minipass({encoding: 'utf8'});
  stream.write(Buffer.from([0xe2, 0x82]));
  let calls = 0;
  let received;
  stream.on('readable', () => {
    calls++;
    received = stream.read();
  });

  assert.equal(calls, 0);
  assert.equal(stream.bufferLength, 0);
  stream.write(Buffer.from([0xac]));
  assert.equal(calls, 1);
  assert.equal(received, '€');
  stream.end();
});

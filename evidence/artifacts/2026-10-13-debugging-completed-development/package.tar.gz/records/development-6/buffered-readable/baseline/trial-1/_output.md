我会使用 diagnosing-bugs 技能，先检查缓冲数据与 `readable` 监听器的交互，再修改 `index.js` 并添加回归测试，全程只使用本地源码。

原因已定位：`write()` 会在数据进入缓冲区时发出 `readable`，但这时尚未注册的监听器收不到事件；`on()` 注册监听器后也没有检查已有缓冲数据。现有两项测试通过。我会先用回归测试复现，再补上注册时的通知，并检查同步消费、暂停、流动和空流行为。

修复后 `npm test` 的 12 项测试全部通过；修复前，7 项回归用例复现了延迟通知问题。`index.js` 只新增一个分支：注册 `readable` 监听器后，若可读缓冲长度非零，就同步发出事件。测试也确认了暂停、普通流动、空流和未完整解码输入的行为。现在做最后的改动范围检查。

已修复。根因是 `readable` 只在写入时通知；晚注册的监听器不会收到此前的事件。

[index.js](<TEMP_RUNS>/minipass-v2-v3-development-6-deadline1200/buffered-readable/baseline/trial-1/index.js:379) 现在会在注册监听器后，若缓冲长度非零，就同步发出 `readable`。

新增 [buffered-readable.test.mjs](<TEMP_RUNS>/minipass-v2-v3-development-6-deadline1200/buffered-readable/baseline/trial-1/buffered-readable.test.mjs)，通过 `runtime.cjs` 加载源码，覆盖晚注册、暂停、流动、空流、结束及解码行为。

验证：修复前 7 项回归用例失败；修复后 `npm test` 全部 12 项通过，`git diff --check` 无错误。供应测试、runtime、元数据、文档和 vendor 均未修改，全程未联网。
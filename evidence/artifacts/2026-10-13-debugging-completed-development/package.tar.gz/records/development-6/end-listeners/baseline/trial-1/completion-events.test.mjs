import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');
const completionEvents = ['end', 'prefinish', 'finish'];

for (const method of ['on', 'addListener', 'once']) {
  test(`${method} completion handlers run in order and only once`, () => {
    const stream = new Minipass();
    const calls = [];

    for (const event of completionEvents) {
      stream[method](event, () => {
        calls.push(event);
        for (const previous of completionEvents.slice(0, calls.length - 1))
          assert.equal(stream.listenerCount(previous), 0);
      });
    }

    assert.equal(stream.end(), stream);
    assert.deepEqual(calls, completionEvents);
    assert.equal(stream.emittedEnd, true);
    assert.equal(stream.readable, false);
    assert.equal(stream.writable, false);
    for (const event of completionEvents)
      assert.equal(stream.listenerCount(event), 0);

    stream.end();
    stream.resume();
    stream.read();
    for (const event of completionEvents)
      stream.emit(event);
    assert.deepEqual(calls, completionEvents);
  });
}

for (const consume of ['read', 'resume']) {
  test(`buffered completion waits for ${consume} and delivers every event`, () => {
    const stream = new Minipass({encoding: 'utf8'});
    const calls = [];
    const chunks = [];
    let callbackCalls = 0;

    for (const event of completionEvents)
      stream.on(event, () => calls.push(event));
    stream.end('payload', () => callbackCalls++);

    assert.deepEqual(calls, []);
    assert.equal(callbackCalls, 0);
    assert.equal(stream.emittedEnd, false);
    assert.equal(stream.bufferLength, 7);

    if (consume === 'read') {
      assert.equal(stream.read(), 'payload');
    } else {
      // Adding a data listener resumes and drains the completed stream.
      stream.on('data', chunk => chunks.push(chunk));
      assert.deepEqual(chunks, ['payload']);
    }

    assert.deepEqual(calls, completionEvents);
    assert.equal(callbackCalls, 1);
    assert.equal(stream.bufferLength, 0);
    for (const event of completionEvents)
      assert.equal(stream.listenerCount(event), 0);
    stream.end();
    stream.resume();
    assert.deepEqual(calls, completionEvents);
    assert.equal(callbackCalls, 1);
  });
}

test('late completion listeners run synchronously once without replaying old handlers', () => {
  const stream = new Minipass();
  const initialCalls = [];
  const lateCalls = [];
  for (const event of completionEvents)
    stream.on(event, () => initialCalls.push(event));
  stream.end();
  assert.deepEqual(initialCalls, completionEvents);

  for (const method of ['on', 'addListener', 'once']) {
    for (const event of completionEvents) {
      const label = `${method}:${event}`;
      const before = lateCalls.length;
      assert.equal(stream[method](event, () => lateCalls.push(label)), stream);
      assert.equal(lateCalls.length, before + 1);
      assert.equal(lateCalls.at(-1), label);
      assert.equal(stream.listenerCount(event), 0);
      stream.emit(event);
      assert.equal(lateCalls.length, before + 1);
    }
  }
  assert.deepEqual(initialCalls, completionEvents);
});

test('a late end listener inside end does not discard pending completion handlers', () => {
  const stream = new Minipass();
  const calls = [];
  stream.once('end', () => {
    calls.push('end');
    stream.once('end', () => calls.push('late end'));
    assert.deepEqual(calls, ['end', 'late end']);
    assert.equal(stream.listenerCount('prefinish'), 1);
    assert.equal(stream.listenerCount('finish'), 1);
  });
  stream.on('prefinish', () => calls.push('prefinish'));
  stream.on('finish', () => calls.push('finish'));

  stream.end();
  assert.deepEqual(calls, ['end', 'late end', 'prefinish', 'finish']);
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0);
});

test('emitting a completion event removes only that event\'s listeners', () => {
  const stream = new Minipass();
  const calls = [];
  for (const event of completionEvents)
    stream.on(event, () => calls.push(event));

  assert.equal(stream.emit('prefinish'), true);
  assert.deepEqual(calls, ['prefinish']);
  assert.equal(stream.listenerCount('prefinish'), 0);
  assert.equal(stream.listenerCount('end'), 1);
  assert.equal(stream.listenerCount('finish'), 1);

  stream.end();
  assert.deepEqual(calls, ['prefinish', 'end', 'finish']);
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');
const completionEvents = ['end', 'prefinish', 'finish'];

for (const method of ['on', 'once']) {
  test(`${method} delivers every completion event in order and only once`, () => {
    const stream = new Minipass();
    const calls = [];
    for (const event of completionEvents) {
      stream[method](event, () => calls.push(`${event}:first`));
      stream[method](event, () => calls.push(`${event}:second`));
    }

    stream.end(() => calls.push('end:callback'));
    const expected = [
      'end:first', 'end:second', 'end:callback',
      'prefinish:first', 'prefinish:second',
      'finish:first', 'finish:second',
    ];
    assert.deepEqual(calls, expected);
    assert.equal(stream.emittedEnd, true);
    assert.equal(stream.readable, false);
    assert.equal(stream.writable, false);
    for (const event of completionEvents)
      assert.equal(stream.listenerCount(event), 0);

    stream.end();
    stream.resume();
    stream.read();
    for (const event of completionEvents)
      stream.emit(event);
    assert.deepEqual(calls, expected);
  });
}

for (const consume of ['read', 'resume']) {
  test(`buffered completion waits for ${consume} and delivers every event`, () => {
    const stream = new Minipass({encoding: 'utf8'});
    const calls = [];
    const chunks = [];
    stream.on('data', chunk => chunks.push(chunk));
    stream.pause();
    for (const event of completionEvents)
      stream.on(event, () => calls.push(event));

    stream.end('payload');
    assert.deepEqual(calls, []);
    assert.equal(stream.emittedEnd, false);
    if (consume === 'read') {
      assert.equal(stream.read(3), 'pay');
      assert.deepEqual(calls, []);
      assert.equal(stream.read(), 'load');
    } else {
      stream.resume();
    }
    assert.equal(chunks.join(''), 'payload');
    assert.deepEqual(calls, completionEvents);
    assert.equal(stream.bufferLength, 0);
    for (const event of completionEvents)
      assert.equal(stream.listenerCount(event), 0);
  });
}

test('late completion listeners run immediately without recalling old listeners', () => {
  const stream = new Minipass();
  const calls = [];
  for (const event of completionEvents)
    stream.on(event, () => calls.push(`original:${event}`));
  stream.end();
  const expected = completionEvents.map(event => `original:${event}`);
  assert.deepEqual(calls, expected);

  for (const event of completionEvents) {
    for (const method of ['on', 'once', 'addListener']) {
      const label = `${method}:${event}`;
      stream[method](event, () => calls.push(label));
      expected.push(label);
      assert.deepEqual(calls, expected);
      assert.equal(stream.listenerCount(event), 0);
    }
  }
  stream.end();
  for (const event of completionEvents)
    stream.emit(event);
  assert.deepEqual(calls, expected);
});

test('replaying end during prefinish preserves the pending finish listeners', () => {
  const stream = new Minipass();
  const calls = [];
  stream.on('end', () => calls.push('end'));
  stream.once('prefinish', () => {
    calls.push('prefinish');
    stream.once('end', () => calls.push('late end'));
    assert.equal(stream.listenerCount('finish'), 1);
  });
  stream.on('finish', () => calls.push('finish'));

  stream.end();
  assert.deepEqual(calls, ['end', 'prefinish', 'late end', 'finish']);
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0);
});

test('registering finish during end preserves prefinish and one-shot delivery', () => {
  const stream = new Minipass();
  const calls = [];
  stream.once('end', () => {
    calls.push('end');
    stream.on('finish', () => calls.push('late finish'));
  });
  stream.on('prefinish', () => calls.push('prefinish'));
  stream.on('finish', () => calls.push('original finish'));

  stream.end();
  assert.deepEqual(calls, [
    'end', 'original finish', 'late finish', 'prefinish',
  ]);
  for (const event of completionEvents)
    assert.equal(stream.listenerCount(event), 0);
});

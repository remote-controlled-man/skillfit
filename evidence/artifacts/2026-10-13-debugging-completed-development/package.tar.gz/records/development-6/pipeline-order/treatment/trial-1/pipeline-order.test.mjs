import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

// Forward data synchronously, but keep the upstream paused until the next turn.
// The cache's drain events still propagate through Minipass's real pipe logic.
class SlowProxy extends Minipass {
  write(chunk, encoding, cb) {
    super.write(chunk, encoding, cb);
    this.pause();
    setImmediate(() => this.resume());
    return false;
  }
}

const pipeline = () => {
  const source = new Minipass({encoding: 'utf8'});
  const tee = new Minipass({encoding: 'utf8'});
  const proxy = new SlowProxy({encoding: 'utf8'});
  const cache = new Minipass({encoding: 'utf8'});
  const output = new Minipass({encoding: 'utf8'});
  const cached = [];
  const delivered = [];
  cache.on('data', chunk => cached.push(chunk));
  output.on('data', chunk => delivered.push(chunk));
  assert.equal(proxy.pipe(cache), cache);
  assert.equal(tee.pipe(proxy), proxy);
  assert.equal(tee.pipe(output), output);
  return {source, tee, proxy, cache, output, cached, delivered};
};

test('adding a cache pipe during a tee write does not drain the slow proxy',
  {timeout: 2000}, async () => {
    const {source, tee, cache, output, cached, delivered} = pipeline();
    const observer = new Minipass({encoding: 'utf8'});
    const observed = [];
    observer.on('data', chunk => observed.push(chunk));
    // A cache consumer attaches lazily while the first chunk is being forwarded.
    // It misses that chunk, as documented, but must not resume the whole tee.
    cache.once('data', () => assert.equal(cache.pipe(observer), observer));
    const complete = output.promise();
    const cacheComplete = cache.promise();
    const observerComplete = observer.promise();
    for (const chunk of ['a', 'b', 'c', 'd'])
      assert.equal(source.write(chunk), false);
    assert.equal(source.pipe(tee), tee);
    source.end();
    await Promise.all([complete, cacheComplete, observerComplete]);
    assert.equal(delivered.join(''), 'abcd');
    assert.equal(cached.join(''), 'abcd');
    assert.equal(observed.join(''), 'bcd');
  });

test('a resume-time write stays behind buffered data and respects slow drains',
  {timeout: 2000}, async () => {
    const {source, tee, cache, output, cached, delivered} = pipeline();
    const complete = output.promise();
    const cacheComplete = cache.promise();
    for (const chunk of ['a', 'b', 'c'])
      assert.equal(source.write(chunk), false);
    let calls = 0;
    let result;
    source.once('resume', () => {
      result = source.write('d', () => calls++);
    });
    source.pipe(tee);
    // No second chunk may escape before the proxy's scheduled drain.
    assert.deepEqual(delivered, ['a']);
    assert.equal(source.bufferLength, 3);
    assert.equal(source.flowing, false);
    assert.equal(result, false);
    assert.equal(calls, 1);
    source.end();
    await Promise.all([complete, cacheComplete]);
    assert.equal(delivered.join(''), 'abcd');
    assert.equal(cached.join(''), 'abcd');
    assert.equal(source.bufferLength, 0);
  });

test('flushing before a flowing write preserves synchronous callbacks and returns', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const delivered = [];
  let calls = 0;
  assert.equal(stream.write('a', () => calls++), false);
  stream.once('resume', () => {
    assert.equal(stream.write('b', () => calls++), true);
    assert.deepEqual(delivered, ['a', 'b']);
  });
  stream.on('data', chunk => delivered.push(chunk));
  assert.equal(stream.write('', () => calls++), true);
  assert.equal(stream.write('c', () => calls++), true);
  assert.deepEqual(delivered, ['a', 'b', 'c']);
  assert.equal(calls, 4);
  stream.pause();
  assert.equal(stream.write('', () => calls++), false);
  assert.equal(stream.write('d', () => calls++), false);
  assert.equal(calls, 6);
  assert.equal(stream.bufferLength, 1);
  stream.end();
  stream.resume();
  assert.deepEqual(delivered, ['a', 'b', 'c', 'd']);
});

test('an intermediate flush cannot signal drain before the pending write', () => {
  const stream = new Minipass({encoding: 'utf8'});
  const delivered = [];
  let drains = 0;
  stream.write('a');
  stream.on('drain', () => {
    drains++;
    assert.equal(stream.write('c'), true);
  });
  stream.once('resume', () => assert.equal(stream.write('b'), true));
  stream.on('data', chunk => delivered.push(chunk));
  assert.deepEqual(delivered, ['a', 'b', 'c']);
  assert.equal(drains, 1);
  stream.end();
});

test('a paused destination does not cause a premature drain after the last buffered chunk',
  {timeout: 2000}, async () => {
    const {source, tee, cache, output, delivered} = pipeline();
    const complete = output.promise();
    const cacheComplete = cache.promise();
    let drains = 0;
    source.on('drain', () => drains++);
    assert.equal(source.write('a'), false);
    source.pipe(tee);
    assert.deepEqual(delivered, ['a']);
    assert.equal(source.bufferLength, 0);
    assert.equal(source.flowing, false);
    assert.equal(drains, 0);
    await new Promise(resolve => source.once('drain', resolve));
    assert.equal(source.flowing, true);
    assert.equal(drains, 1);
    source.end();
    await Promise.all([complete, cacheComplete]);
  });

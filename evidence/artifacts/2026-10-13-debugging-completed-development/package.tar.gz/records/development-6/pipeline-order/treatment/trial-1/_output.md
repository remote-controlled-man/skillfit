我会按 diagnosing-bugs 技能先复现多级管道在背压下的乱序，检查 `pipe`/`write` 的执行顺序，再修改 `index.js` 并添加回归测试。全程使用本地 `runtime.cjs` 和内置测试工具。

源码中的 `drain` 会同步向上游传播，`pipe()` 也会立即恢复流动。我正在检查这类重入是否会让仍有旧缓存的流接收新数据；回归测试会保留 tee、慢代理和 cache 之间的实际连接关系。

多级管道已复现乱序：输入 `abcd`，tee 的输出变成了 `bacd`。给正在流动的 cache 添加 `pipe()` 会多发一次同步 `drain`，导致上游在当前 chunk 尚未送到 tee 的另一个分支时继续发送数据。我也会覆盖 `resume` 回调写入新数据的情况，检查新数据是否越过旧缓存。

已修改 [index.js](./index.js)，新增 [pipeline-order.test.mjs](./pipeline-order.test.mjs)。

根因是 `pipe()` 对已流动的流重复恢复，产生同步 `drain`，让上游重入并越过 tee 尚未完成的转发；`write()` 也可能让新数据越过旧缓存。修复后避免重复恢复，先处理旧缓存，并重新检查背压，保留写入返回值和回调行为。

验证：修复前多级管道稳定输出 `bacd`，预期为 `abcd`；修复后 `npm test` 全部 7 项通过，`git diff --check` 通过。未修改 supplied tests、runtime、metadata、文档或 vendor，未使用网络。
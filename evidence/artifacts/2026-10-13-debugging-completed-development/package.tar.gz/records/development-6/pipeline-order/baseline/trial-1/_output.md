我会使用 diagnosing-bugs 技能，先检查公开的 pipe/write 行为和现有测试，再构造包含慢速代理与缓存的回归场景，修复后运行本地测试。

原有两项测试均通过。源码中，pipe() 会无条件调用同步 resume()，而 write() 只根据 flowing 决定是否直接发送数据。我正在检查 tee 两个分支的 drain 回调是否会重入写入，让新数据越过尚未清空的缓冲。

已复现：tee 同时连接普通输出和异步写入缓存的慢速 Writable 代理，恢复时的同步回调再次写入，两个分支都得到 `adbce`，应为 `abcde`。原因是 resume 先将 flowing 设为 true，此时旧缓冲尚未清空，新 write 就直接发送了。我会让写入先处理旧缓冲，并检查修复是否保留背压及返回值。

字节和对象模式的 tee 回归测试已通过，两条分支均按顺序输出。测试还确认慢速代理每次返回 false 后，tee 会等到 drain 才继续发送，write 返回值和回调保持正确。另已验证新增 pipe 不会重复触发 resume/drain；接下来补查首次 pipe 对已有缓冲的同步交付行为。

已修复 `index.js`，新增 `pipeline-order.test.mjs`。

根因是同步 `resume` 回调可重入写入：此时 `flowing` 已为 true，但旧缓冲尚未清空，新数据会抢先发送；`pipe()` 无条件恢复还会产生多余的 resume/drain。修复先处理旧缓冲、避免提前 drain，并尊重回调中重新施加的背压。

验证结果：

- 修复前，tee → 慢速代理 → 缓存场景输出 `adbce`；修复后为 `abcde`。
- `npm test`：7 项全部通过，覆盖字节、对象、背压、write 返回值和回调。
- `git diff --check` 通过。

原测试、runtime、元数据、文档和 vendor 均未修改；全程离线。
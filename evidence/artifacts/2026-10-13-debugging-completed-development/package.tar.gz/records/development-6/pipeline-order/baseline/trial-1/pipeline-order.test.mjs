import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {Writable} from 'node:stream';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

for (const objectMode of [false, true]) {
  test(`tee preserves order through a slow cache proxy (${objectMode ? 'objects' : 'bytes'})`, async () => {
    const options = objectMode ? {objectMode: true} : {encoding: 'utf8'};
    const chunks = objectMode
      ? ['a', 'b', 'c', 'd', 'e'].map(id => ({id}))
      : ['a', 'b', 'c', 'd', 'e'];
    const tee = new Minipass(options);
    const output = new Minipass(options);
    const cache = new Minipass(options);
    const outputResult = objectMode ? output.collect() : output.concat();
    const cacheResult = objectMode ? cache.collect() : cache.concat();
    const cachedWrites = [];
    const proxy = new Writable({
      objectMode,
      highWaterMark: 1,
      write(chunk, encoding, callback) {
        setImmediate(() => {
          cachedWrites.push(cache.write(chunk));
          callback();
        });
      },
      final(callback) {
        cache.end();
        callback();
      },
    });
    const finished = new Promise((resolve, reject) => {
      proxy.once('finish', resolve);
      proxy.once('error', reject);
    });
    let maxPending = 0;
    output.on('data', () => {
      maxPending = Math.max(maxPending, proxy.writableLength);
    });

    assert.equal(tee.pipe(proxy), proxy);
    assert.equal(tee.pipe(output), output);
    const callbacks = [];
    const returns = chunks.slice(0, 3).map((chunk, i) =>
      tee.write(chunk, () => callbacks.push(i)));
    assert.deepEqual(returns, [false, false, false]);
    assert.equal(tee.flowing, false);
    assert.equal(tee.bufferLength, 2);

    tee.once('resume', () => {
      returns.push(tee.write(chunks[3], () => callbacks.push(3)));
      tee.end(chunks[4]);
    });

    const [emitted, cached] = await Promise.all([outputResult, cacheResult, finished]);
    const expected = objectMode ? chunks : chunks.join('');
    assert.deepEqual(emitted, expected);
    assert.deepEqual(cached, expected);
    assert.deepEqual(returns, [false, false, false, false]);
    assert.deepEqual(callbacks, [0, 1, 2, 3]);
    assert.deepEqual(cachedWrites, [true, true, true, true, true]);
    // Each false proxy write must stop the tee until the next drain.
    assert.equal(maxPending, 1);
    assert.equal(tee.bufferLength, 0);
    assert.equal(tee.emittedEnd, true);
  });
}

test('adding a pipe to a flowing stream does not emit resume or drain', async () => {
  const source = new Minipass({encoding: 'utf8'});
  const first = new Minipass({encoding: 'utf8'});
  const second = new Minipass({encoding: 'utf8'});
  const results = [first.concat(), second.concat()];
  assert.equal(source.pipe(first), first);
  const events = [];
  source.on('resume', () => events.push('resume'));
  source.on('drain', () => events.push('drain'));

  assert.equal(source.pipe(second), second);
  assert.deepEqual(events, []);
  assert.equal(source.write('a'), true);
  source.end('b');
  assert.deepEqual(await Promise.all(results), ['ab', 'ab']);
});

test('the first pipe synchronously flushes buffered data and respects end: false', async () => {
  const source = new Minipass({encoding: 'utf8'});
  const destination = new Minipass({encoding: 'utf8'});
  const result = destination.concat();
  const emitted = [];
  destination.on('data', chunk => emitted.push(chunk));
  assert.equal(source.write('a'), false);
  source.end('b');

  assert.equal(source.pipe(destination, {end: false}), destination);
  assert.equal(emitted.join(''), 'ab');
  assert.equal(source.bufferLength, 0);
  assert.equal(source.emittedEnd, true);
  assert.equal(destination.writable, true);
  assert.equal(destination.write('c'), true);
  destination.end();
  assert.equal(await result, 'abc');
});

test('a reentrant write flushes older data without draining before the new chunk', () => {
  const stream = new Minipass({encoding: 'utf8'});
  assert.equal(stream.write('a'), false);
  assert.equal(stream.write('b'), false);
  const emitted = [];
  let drains = 0;
  let callbacks = 0;
  let writeReturn;
  stream.once('resume', () => {
    writeReturn = stream.write('c', () => callbacks++);
  });
  stream.on('drain', () => {
    drains++;
    assert.equal(stream.write('d'), true);
  });
  stream.on('data', chunk => emitted.push(chunk));

  assert.equal(writeReturn, true);
  assert.equal(callbacks, 1);
  assert.equal(drains, 1);
  assert.equal(stream.bufferLength, 0);
  assert.equal(emitted.join(''), 'abcd');
  stream.end();
});

import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {setImmediate} from 'node:timers/promises';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

// Use a real destination stream so duplicate end calls remain observable even
// though Minipass removes its end listeners after the first emission.
function destination() {
  const stream = new Minipass({encoding: 'utf8'});
  const events = [];
  let endCalls = 0;
  const end = stream.end;
  stream.end = function (...args) {
    endCalls++;
    events.push('end()');
    return end.apply(this, args);
  };
  stream.on('data', chunk => events.push(chunk));
  return {stream, events, get endCalls() { return endCalls; }};
}

test('repeated async end in one turn ends an empty pipe once', {timeout: 1000}, async () => {
  const source = new Minipass({async: true});
  const dest = destination();
  let sourceEnds = 0;
  source.on('end', () => sourceEnds++);
  source.pipe(dest.stream);

  source.end();
  source.end();
  source.end();
  assert.equal(dest.endCalls, 0);
  assert.equal(source.emittedEnd, false);

  // nextTick data/end callbacks, including callbacks queued by other callbacks,
  // must all run before checking the result.
  await setImmediate();
  assert.equal(dest.endCalls, 1);
  assert.equal(sourceEnds, 1);
  assert.equal(source.emittedEnd, true);
  assert.deepEqual(dest.events, ['end()']);

  source.end();
  await setImmediate();
  assert.equal(dest.endCalls, 1);
});

for (const flowing of [false, true]) {
  test(`repeated async end preserves ${flowing ? 'flowing' : 'buffered'} pipe data`, {timeout: 1000}, async () => {
    const source = new Minipass({async: true});
    const dest = destination();
    source.pipe(dest.stream);
    if (flowing)
      source.resume();

    source.write('first');
    source.end('last');
    source.end();
    source.end();
    assert.deepEqual(dest.events, []);

    await setImmediate();
    assert.equal(dest.endCalls, 1);
    assert.deepEqual(dest.events, ['first', 'last', 'end()']);
    assert.equal(source.bufferLength, 0);
    assert.equal(dest.stream.emittedEnd, true);
  });
}

test('async end flushes the decoder before ending its pipe once', {timeout: 1000}, async () => {
  const source = new Minipass({async: true, encoding: 'utf8'});
  const dest = destination();
  source.pipe(dest.stream);
  source.resume();
  source.write(Buffer.from([0xe2]));
  source.end(Buffer.from([0x82, 0xac, 0xe2, 0x82]));
  source.end();
  source.end();

  await setImmediate();
  assert.equal(dest.endCalls, 1);
  assert.deepEqual(dest.events, ['€', '\ufffd', 'end()']);
});

test('piping before deferred end runs still receives queued data', {timeout: 1000}, async () => {
  const source = new Minipass({async: true});
  const dest = destination();
  source.resume();
  source.write('first');
  source.end('last');
  source.end();
  source.pipe(dest.stream);
  assert.equal(dest.endCalls, 0);

  await setImmediate();
  assert.equal(dest.endCalls, 1);
  assert.deepEqual(dest.events, ['first', 'last', 'end()']);
});

test('repeated async end honors end:false alongside a normal pipe', {timeout: 1000}, async () => {
  const source = new Minipass({async: true});
  const ended = destination();
  const open = destination();
  source.pipe(ended.stream);
  source.pipe(open.stream, {end: false});
  source.write('first');
  source.end('last');
  source.end();
  source.end();

  await setImmediate();
  assert.equal(ended.endCalls, 1);
  assert.deepEqual(ended.events, ['first', 'last', 'end()']);
  assert.equal(open.endCalls, 0);
  assert.deepEqual(open.events, ['first', 'last']);
  assert.equal(open.stream.writable, true);
  assert.equal(open.stream.emittedEnd, false);
  assert.equal(open.stream.listenerCount('drain'), 0);

  open.stream.write('more');
  open.stream.end();
  assert.equal(open.endCalls, 1);
  assert.deepEqual(open.events, ['first', 'last', 'more', 'end()']);
});

test('repeated synchronous end keeps immediate data and pipe completion', () => {
  const source = new Minipass();
  const dest = destination();
  source.pipe(dest.stream);
  source.write('first');
  source.end('last');
  source.end();
  source.end();

  assert.equal(dest.endCalls, 1);
  assert.deepEqual(dest.events, ['first', 'last', 'end()']);
});

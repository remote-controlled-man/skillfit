import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {setImmediate} from 'node:timers/promises';

const Minipass = createRequire(import.meta.url)('./runtime.cjs');

class RecordingDestination extends Minipass {
  constructor(options = {encoding: 'utf8'}) {
    super(options);
    this.endCalls = 0;
    this.chunks = [];
    this.on('data', chunk => this.chunks.push(chunk));
  }

  end(...args) {
    this.endCalls++;
    return super.end(...args);
  }
}

test('repeated async end calls end an empty pipe destination once', async () => {
  const source = new Minipass({async: true});
  const destination = new RecordingDestination();
  let callbacks = 0;
  let endEvents = 0;
  source.on('end', () => endEvents++);
  source.pipe(destination);

  for (let i = 0; i < 3; i++) {
    assert.equal(source.end(() => callbacks++), source);
  }
  assert.equal(source.emittedEnd, false);
  assert.equal(destination.endCalls, 0);

  await setImmediate();
  assert.equal(destination.endCalls, 1);
  assert.equal(endEvents, 1);
  assert.equal(callbacks, 3);
  assert.equal(source.emittedEnd, true);
  assert.deepEqual(destination.chunks, []);

  source.end();
  await setImmediate();
  assert.equal(destination.endCalls, 1);
});

test('queued async data reaches the destination in order before its only end', async () => {
  const source = new Minipass({async: true});
  const destination = new RecordingDestination();
  let chunksAtEnd;
  destination.on('end', () => { chunksAtEnd = [...destination.chunks]; });
  source.pipe(destination);
  source.resume();
  source.write('first');
  source.write('second');
  source.end('last');
  source.end();
  source.end();

  assert.deepEqual(destination.chunks, []);
  assert.equal(source.emittedEnd, false);
  await setImmediate();
  assert.equal(destination.endCalls, 1);
  assert.deepEqual(chunksAtEnd, ['first', 'second', 'last']);
  assert.deepEqual(destination.chunks, chunksAtEnd);
});

test('buffered async object data drains completely before ending once', async () => {
  const source = new Minipass({async: true, objectMode: true});
  const destination = new RecordingDestination({objectMode: true});
  const first = {id: 1};
  const last = {id: 2};
  source.write(first);
  source.end(last);
  source.end();
  assert.equal(source.bufferLength, 2);
  assert.equal(source.emittedEnd, false);
  source.pipe(destination);
  source.end();

  await setImmediate();
  assert.equal(destination.endCalls, 1);
  assert.equal(source.bufferLength, 0);
  assert.deepEqual(destination.chunks, [first, last]);
  assert.equal(destination.chunks[0], first);
  assert.equal(destination.chunks[1], last);
});

test('async end delivers the decoder remainder before ending the destination', async () => {
  const source = new Minipass({async: true, encoding: 'utf8'});
  const destination = new RecordingDestination();
  let chunksAtEnd;
  destination.on('end', () => { chunksAtEnd = [...destination.chunks]; });
  source.pipe(destination);
  source.resume();
  source.write('prefix');
  source.write(Buffer.from([0xe2, 0x82]));
  source.end();
  source.end();

  await setImmediate();
  assert.equal(destination.endCalls, 1);
  assert.deepEqual(chunksAtEnd, ['prefix', '\ufffd']);
  assert.deepEqual(destination.chunks, chunksAtEnd);
});

test('repeated async end preserves end:false and all piped data', async () => {
  const source = new Minipass({async: true});
  const destination = new RecordingDestination();
  source.pipe(destination, {end: false});
  source.write('first');
  source.end('last');
  source.end();
  source.end();

  await setImmediate();
  assert.equal(source.emittedEnd, true);
  assert.equal(destination.endCalls, 0);
  assert.equal(destination.writable, true);
  assert.equal(destination.emittedEnd, false);
  assert.deepEqual(destination.chunks, ['first', 'last']);
  assert.equal(destination.listenerCount('drain'), 0);

  destination.end('after');
  assert.equal(destination.endCalls, 1);
  assert.deepEqual(destination.chunks, ['first', 'last', 'after']);
});

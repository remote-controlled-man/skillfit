// Offline-only replay of completed development cohorts. No agent/API calls.
import assert from 'node:assert/strict';
import {cpSync,mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {tmpdir} from 'node:os';
import {basename,dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadBench} from '../dist/harness/bench.js';
import {runVerifier} from '../dist/harness/runner.js';
import {verdictFromOutput} from '../dist/harness/verifier-summary.js';
import {summarizeCosts,COST_METRICS} from '../dist/harness/costs.js';
import {mcnemarExactP,pairedDeltaBootstrapCI,pairedScoreBootstrapCI} from '../dist/harness/stats.js';
import {verdictFor} from '../dist/harness/report.js';
const replay=resolve(dirname(fileURLToPath(import.meta.url)),'..'),pkg=resolve(replay,'..');
const root=resolve(process.argv[2]??join(pkg,'records'));
const index=JSON.parse(readFileSync(join(pkg,'export-index.json'),'utf8'));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const file of index.files){const path=file.path.startsWith('records/')?join(root,file.path.slice(8)):join(pkg,file.path);assert.equal(hash(readFileSync(path)),file.exportedSha256,file.path);}
const cohorts=[],measured=[];
for(const batch of [6,7]){
 const dir=join(root,'development-'+batch),manifest=JSON.parse(readFileSync(join(dir,'manifest.json'),'utf8')),bench=loadBench(join(replay,'bench'));
 assert.equal(manifest.experiment.status,'completed');assert.equal(bench.contentSha256,manifest.bench.contentSha256);assert.equal(manifest.trials,1);
 const all={baseline:[],treatment:[]},taskOutcomes=[],scoreTasks=[];let improved=0,regressed=0,regraded=0;
 for(const task of bench.tasks){
  const records={baseline:[],treatment:[]};
  for(const arm of ['baseline','treatment']){
   const delivery=join(dir,task.id,arm,'trial-1'),r=JSON.parse(readFileSync(join(delivery,'_result.json'),'utf8'));
   assert.equal(r.executorInvoked,true);assert.equal(r.error,null);assert.equal(r.usageStatus,'final');assert.equal(r.taskId,task.id);assert.equal(r.condition,arm);
   const scratch=mkdtempSync(join(tmpdir(),'skillfit-completed-replay-'));
   try{
    cpSync(delivery,scratch,{recursive:true,filter:path=>basename(path)!=='.git'});
    const grade=await runVerifier(bench.dir,task.verifier,scratch),summary=verdictFromOutput(grade.output);
    assert.equal(grade.exitCode,r.verifierExitCode);assert.equal(grade.exitCode===0,r.passed);assert.equal(summary?.score??null,r.score);
    assert.deepEqual(summary?.checks?.map(({name,pass})=>({name,pass}))??null,r.checks?.map(({name,pass})=>({name,pass}))??null);
   }finally{rmSync(scratch,{recursive:true,force:true});}
   records[arm].push(r);all[arm].push(r);measured.push(r);regraded++;
  }
  const saved=manifest.tasks.find(t=>t.id===task.id),outcomes=Object.fromEntries(['baseline','treatment'].map(arm=>[arm,records[arm].map(r=>r.passed)]));
  assert.deepEqual(outcomes,saved.outcomes);taskOutcomes.push(outcomes);assert.deepEqual(summarizeCosts(records,records),saved.costs);
  for(const arm of ['baseline','treatment']){assert.equal(saved.conditions[arm].passes,records[arm].filter(r=>r.passed).length);assert.equal(saved.conditions[arm].errors,0);assert.equal(saved.conditions[arm].trials,1);assert.equal(saved.conditions[arm].meanScore,records[arm][0].score);}
  for(const facet of saved.facets)for(const arm of ['baseline','treatment'])assert.equal(facet[arm+'PassRate'],records[arm][0].checks.find(c=>c.name===facet.name).pass?1:0);
  if(!outcomes.baseline[0]&&outcomes.treatment[0])improved++;if(outcomes.baseline[0]&&!outcomes.treatment[0])regressed++;
  const scores={baseline:records.baseline.map(r=>r.score),treatment:records.treatment.map(r=>r.score)};assert.deepEqual(scores,saved.scores);scoreTasks.push(scores);
 }
 const costs=summarizeCosts(all,all);assert.deepEqual(costs,manifest.overall.costs);
 const baselinePasses=all.baseline.filter(r=>r.passed).length,treatmentPasses=all.treatment.filter(r=>r.passed).length,delta=treatmentPasses/4-baselinePasses/4;
 assert.equal(manifest.overall.conditions.baseline.passes,baselinePasses);assert.equal(manifest.overall.conditions.treatment.passes,treatmentPasses);assert.equal(manifest.overall.deltaPassRate,delta);
 assert.deepEqual(manifest.overall.stats.discordant,{improved,regressed});assert.equal(manifest.overall.stats.mcnemarP,mcnemarExactP(improved,regressed));
 assert.deepEqual(manifest.overall.stats.deltaCi,pairedDeltaBootstrapCI(taskOutcomes));assert.deepEqual(manifest.overall.stats.scoreDeltaCi,pairedScoreBootstrapCI(scoreTasks));
 assert.equal(manifest.overall.scoreDelta,pairedScoreBootstrapCI(scoreTasks).point);assert.equal(manifest.overall.verdict,verdictFor({improved,regressed,deltaPassRate:delta}).verdict);
 assert.equal(regraded,8);assert.equal(manifest.experiment.callsStarted,8);
 cohorts.push({batch,status:'completed',agentCliInvocations:8,regradedDeliveries:8,baselinePasses,treatmentPasses,improvedPairs:improved,regressedPairs:regressed,statisticalVerdict:manifest.overall.verdict,qualityStatsMatch:true,costsMatch:true,costs});
}
const population=summarizeCosts({baseline:measured,treatment:[]},{baseline:[],treatment:[]}).attempts.baseline;
console.log(JSON.stringify({schemaVersion:1,scope:'Separate completed development cohorts, never pooled for efficacy; no independent-validation claim.',modelCallsMadeByReplay:0,agentCliInvocations:16,regradedDeliveries:16,indexedFiles:index.files.length,cohorts,totalRecordedSpending:Object.fromEntries(COST_METRICS.map(metric=>[metric,population.metrics[metric]])),automaticUpgrade:false},null,2));

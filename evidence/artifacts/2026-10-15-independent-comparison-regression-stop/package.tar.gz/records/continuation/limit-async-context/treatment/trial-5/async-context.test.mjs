#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

test('queued calls retain each caller\'s async contexts, including no context', {timeout: 5000}, async () => {
	const storage = new AsyncLocalStorage();
	const nestedStorage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const started = gate();
	const hold = gate();
	const blockerContext = {caller: 'blocker'};
	const blockerNestedContext = {caller: 'blocker-nested'};
	const firstContext = {caller: 'first'};
	const firstNestedContext = {caller: 'first-nested'};
	const secondContext = {caller: 'second'};
	const order = [];

	const blocker = storage.run(blockerContext, () => nestedStorage.run(blockerNestedContext, () => limit(() => {
		started.release();
		return hold.promise;
	})));
	await started.promise;

	const work = async (label, expectedContext, expectedNestedContext) => {
		order.push(label);
		assert.equal(storage.getStore(), expectedContext);
		assert.equal(nestedStorage.getStore(), expectedNestedContext);
		await Promise.resolve();
		assert.equal(storage.getStore(), expectedContext);
		assert.equal(nestedStorage.getStore(), expectedNestedContext);
		return label;
	};
	const first = storage.run(firstContext, () => nestedStorage.run(firstNestedContext,
		() => limit(work, 'first', firstContext, firstNestedContext)));
	const second = storage.run(secondContext, () => limit(work, 'second', secondContext, undefined));
	const unscoped = limit(work, 'unscoped', undefined, undefined);
	const results = Promise.all([blocker, first, second, unscoped]);

	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, 3);
	storage.run({caller: 'release'}, () => hold.release('blocker result'));

	assert.deepEqual(await results, ['blocker result', 'first', 'second', 'unscoped']);
	assert.deepEqual(order, ['first', 'second', 'unscoped']);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
	assert.equal(storage.getStore(), undefined);
	assert.equal(nestedStorage.getStore(), undefined);
});

test('rejection and synchronous throws preserve contexts and continue the queue', {timeout: 5000}, async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const started = gate();
	const hold = gate();
	const rejected = new Error('async rejection');
	const thrown = new Error('synchronous throw');
	const first = storage.run('first', () => limit(async () => {
		started.release();
		await hold.promise;
		assert.equal(storage.getStore(), 'first');
		throw rejected;
	}));
	await started.promise;
	const second = storage.run('second', () => limit(() => {
		assert.equal(storage.getStore(), 'second');
		throw thrown;
	}));
	const third = storage.run('third', () => limit(async value => {
		assert.equal(storage.getStore(), 'third');
		await Promise.resolve();
		assert.equal(storage.getStore(), 'third');
		return value;
	}, 42));
	const results = Promise.allSettled([first, second, third]);
	hold.release();
	assert.deepEqual(await results, [
		{status: 'rejected', reason: rejected},
		{status: 'rejected', reason: thrown},
		{status: 'fulfilled', value: 42},
	]);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('concurrency counts and clearQueue keep their ordinary public behavior', {timeout: 5000}, async () => {
	const limit = pLimit(2);
	const hold = gate();
	const bothStarted = gate();
	const order = [];
	const work = async value => {
		order.push(value);
		if (order.length === 2) {
			bothStarted.release();
		}

		await hold.promise;
		return value;
	};
	const first = limit(work, 1);
	const second = limit(work, 2);
	const discarded = observe(limit(work, 3));
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 3);
	await bothStarted.promise;
	assert.equal(limit.activeCount, 2);
	assert.equal(limit.pendingCount, 1);
	assert.equal(limit.clearQueue(), undefined);
	assert.equal(limit.activeCount, 2);
	assert.equal(limit.pendingCount, 0);
	hold.release();
	assert.deepEqual(await Promise.all([first, second]), [1, 2]);
	await flush();
	assert.deepEqual(order, [1, 2]);
	assert.equal(discarded.status, 'pending');
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
	assert.equal(await limit(value => value, 4), 4);
});

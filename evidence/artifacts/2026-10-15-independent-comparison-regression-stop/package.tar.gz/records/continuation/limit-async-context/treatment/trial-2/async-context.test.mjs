#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

test('queued calls retain their own async contexts across awaits', {timeout: 2000}, async t => {
	const storage = new AsyncLocalStorage();
	const otherStorage = new AsyncLocalStorage();
	t.after(() => {
		storage.disable();
		otherStorage.disable();
	});
	const limit = storage.run({id: 'factory'}, () => pLimit(1));
	const started = gate();
	const blocker = gate();
	t.after(blocker.release);
	const observations = [];
	const runningStore = {id: 'running'};
	const runningOtherStore = {id: 'running-other'};
	const first = storage.run(runningStore, () => otherStorage.run(runningOtherStore, () => limit(async () => {
		started.release();
		await blocker.promise;
		return 'first';
	})));
	await started.promise;
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, 0);

	const alpha = {id: 'alpha'};
	const beta = {id: 'beta'};
	const other = {id: 'other'};
	const contexts = [[alpha, other], [beta, undefined], [undefined, undefined], [alpha, other]];
	const queued = contexts.map(([store, otherStore], index) => storage.run(store, () => otherStorage.run(otherStore, () => limit(async (value, suffix) => {
		observations.push([value, storage.getStore(), otherStorage.getStore()]);
		await Promise.resolve();
		observations.push([value, storage.getStore(), otherStorage.getStore()]);
		return `${value}:${suffix}`;
	}, index, 'result'))));
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, contexts.length);
	assert.deepEqual(observations, []);
	blocker.release();
	assert.deepEqual(await Promise.all([first, ...queued]), ['first', '0:result', '1:result', '2:result', '3:result']);
	assert.equal(observations.length, contexts.length * 2);
	for (const [index, store, otherStore] of observations) {
		assert.strictEqual(store, contexts[index][0], `call ${index} must retain its AsyncLocalStorage store`);
		assert.strictEqual(otherStore, contexts[index][1], `call ${index} must retain its second AsyncLocalStorage store`);
	}
	assert.deepEqual(observations.map(([index]) => index), [0, 0, 1, 1, 2, 2, 3, 3]);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('queued errors retain their reasons and contexts while the queue continues', {timeout: 2000}, async t => {
	const storage = new AsyncLocalStorage();
	t.after(() => storage.disable());
	const limit = pLimit(1);
	const blocker = gate();
	t.after(blocker.release);
	const first = storage.run('running', () => limit(() => blocker.promise));
	await flush();
	const syncError = new Error('synchronous failure');
	const asyncError = new Error('asynchronous failure');
	const observations = [];
	const syncFailure = storage.run('sync', () => limit(() => {
		observations.push(storage.getStore());
		throw syncError;
	}));
	const asyncFailure = storage.run('async', () => limit(async () => {
		observations.push(storage.getStore());
		await Promise.resolve();
		observations.push(storage.getStore());
		throw asyncError;
	}));
	const last = storage.run('last', () => limit(value => {
		observations.push(storage.getStore());
		return value;
	}, 42));
	const settled = Promise.allSettled([first, syncFailure, asyncFailure, last]);
	assert.equal(limit.pendingCount, 3);
	blocker.release('released');
	assert.deepEqual(await settled, [
		{status: 'fulfilled', value: 'released'},
		{status: 'rejected', reason: syncError},
		{status: 'rejected', reason: asyncError},
		{status: 'fulfilled', value: 42},
	]);
	assert.deepEqual(observations, ['sync', 'async', 'async', 'last']);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('clearQueue preserves running work and allows fresh calls in their own context', {timeout: 2000}, async t => {
	const storage = new AsyncLocalStorage();
	t.after(() => storage.disable());
	const limit = pLimit(2);
	const blockers = [gate(), gate()];
	t.after(() => blockers.forEach(blocker => blocker.release()));
	const running = blockers.map((blocker, index) => storage.run(`running-${index}`, () => limit(() => blocker.promise)));
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 2);
	await flush();
	assert.equal(limit.activeCount, 2);
	assert.equal(limit.pendingCount, 0);
	let discardedRan = false;
	const discarded = observe(storage.run('discarded', () => limit(() => {
		discardedRan = true;
	})));
	assert.equal(limit.pendingCount, 1);
	assert.equal(limit.clearQueue(), undefined);
	assert.equal(limit.pendingCount, 0);
	assert.equal(limit.activeCount, 2);
	const fresh = storage.run('fresh', () => limit(() => storage.getStore()));
	blockers[1].release(1);
	assert.equal(await fresh, 'fresh');
	assert.equal(limit.activeCount, 1);
	blockers[0].release(0);
	assert.deepEqual(await Promise.all(running), [0, 1]);
	assert.equal(discardedRan, false);
	assert.equal(discarded.status, 'pending');
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

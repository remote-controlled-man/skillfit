我会先检查排队逻辑和现有测试，使用 diagnosing-bugs 技能定位上下文丢失的位置，再做最小修复并添加公开 API 回归测试。

原因已定位：普通的 `Function.bind` 不保存 AsyncLocalStorage 上下文，而前一个任务完成时会直接调用下一个排队任务，导致后者沿用前者的上下文。

现有 `npm test` 已通过。我会先添加一个阻塞首个任务、再从不同上下文排队的测试，确认它能复现缺陷，再修复队列回调的上下文绑定。

回归测试已确认：修复前，首个任务无论成功还是失败，后续任务都会读到它的上下文；修复后，两种场景均通过。

现在队列回调会在入队时通过 `AsyncResource.bind` 保存调用者上下文，原有调度时序保持不变。已通过现有测试及新增的上下文、返回值、错误传播、计数和 `clearQueue` 检查；接下来检查非 Node 回退分支和最终差异。

已修复。原先 `Function.bind` 不保存异步上下文，排队任务会沿用前一个任务的 AsyncLocalStorage 上下文。现在入队时使用 `AsyncResource.bind` 捕获调用者上下文，保留原有调度逻辑，并提供非 Node 回退实现。

新增可执行的 `async-context.test.mjs`，通过公开 API 验证上下文隔离、错误传播、计数和 `clearQueue`。

实际验证（Node v24.21.0）：

- 修复前：两个上下文回归用例均失败。
- `npm test`：1/1 通过。
- `node --test test.mjs async-context.test.mjs`：4/4 通过。
- 模拟非 Node 默认条件分支及 `git diff --check`：通过。

未联网、未安装依赖；受保护文件保持不变。
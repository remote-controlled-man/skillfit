#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from 'p-limit';

function gate() {
	let release;
	const promise = new Promise(resolve => {
		release = resolve;
	});
	return {promise, release};
}

test('queued calls retain their own context before and after awaiting', {timeout: 2000}, async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const started = gate();
	const blocker = gate();
	const firstStore = {caller: 'running'};
	const stores = [{caller: 'second'}, undefined, {caller: 'fourth'}];
	const inputs = stores.map((_, index) => ({index}));
	const seen = [];

	try {
		const first = storage.run(firstStore, () => limit(async () => {
			started.release();
			await blocker.promise;
			return 'first';
		}));
		await started.promise;

		const queued = stores.map((store, index) => storage.run(store, () => limit(async (input, suffix) => {
			seen.push(storage.getStore());
			await Promise.resolve();
			seen.push(storage.getStore());
			return [input, suffix];
		}, inputs[index], 'result')));

		assert.equal(limit.activeCount, 1);
		assert.equal(limit.pendingCount, stores.length);
		assert.deepEqual(seen, []);
		const results = Promise.all([first, ...queued]);
		blocker.release();
		assert.deepEqual(await results, ['first', ...inputs.map(input => [input, 'result'])]);
		for (const [index, store] of stores.entries()) {
			assert.equal(seen[index * 2], store, `caller ${index} at task entry`);
			assert.equal(seen[index * 2 + 1], store, `caller ${index} after awaiting`);
		}
		assert.equal(storage.getStore(), undefined);
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
	} finally {
		blocker.release();
		storage.disable();
	}
});

test('rejections preserve their reasons and release the queue in each caller context', {timeout: 2000}, async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const started = gate();
	const blocker = gate();
	const stores = [{caller: 'throws'}, {caller: 'rejects'}, {caller: 'continues'}];
	const syncError = new Error('synchronous failure');
	const asyncError = new Error('asynchronous failure');
	const seen = [];

	try {
		const first = storage.run({caller: 'running'}, () => limit(async () => {
			started.release();
			await blocker.promise;
		}));
		await started.promise;
		const throwing = storage.run(stores[0], () => limit(() => {
			seen.push(storage.getStore());
			throw syncError;
		}));
		const rejecting = storage.run(stores[1], () => limit(async () => {
			await Promise.resolve();
			seen.push(storage.getStore());
			throw asyncError;
		}));
		const continuing = storage.run(stores[2], () => limit(() => {
			seen.push(storage.getStore());
			return 'continued';
		}));
		const results = Promise.allSettled([first, throwing, rejecting, continuing]);
		blocker.release();
		const outcomes = await results;
		assert.deepEqual(outcomes, [
			{status: 'fulfilled', value: undefined},
			{status: 'rejected', reason: syncError},
			{status: 'rejected', reason: asyncError},
			{status: 'fulfilled', value: 'continued'},
		]);
		assert.equal(outcomes[1].reason, syncError);
		assert.equal(outcomes[2].reason, asyncError);
		for (const [index, store] of stores.entries()) {
			assert.equal(seen[index], store);
		}
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
	} finally {
		blocker.release();
		storage.disable();
	}
});

test('clearQueue keeps active work and allows reuse in a new context', {timeout: 2000}, async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const started = gate();
	const blocker = gate();
	const replacementStore = {caller: 'replacement'};
	let discardedRan = false;
	let discardedSettled = false;

	try {
		const first = storage.run({caller: 'running'}, () => limit(async () => {
			started.release();
			await blocker.promise;
			return 'active completed';
		}));
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 1);
		await started.promise;
		const discarded = storage.run({caller: 'discarded'}, () => limit(() => {
			discardedRan = true;
		}));
		discarded.then(() => {
			discardedSettled = true;
		}, () => {
			discardedSettled = true;
		});
		assert.equal(limit.pendingCount, 1);
		assert.equal(limit.clearQueue(), undefined);
		assert.equal(limit.pendingCount, 0);
		assert.equal(limit.activeCount, 1);

		const replacement = storage.run(replacementStore, () => limit(value => {
			assert.equal(storage.getStore(), replacementStore);
			return value;
		}, 'replacement completed'));
		assert.equal(limit.activeCount, 1);
		assert.equal(limit.pendingCount, 1);
		const results = Promise.all([first, replacement]);
		blocker.release();
		assert.deepEqual(await results, ['active completed', 'replacement completed']);
		assert.equal(discardedRan, false);
		assert.equal(discardedSettled, false);
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
	} finally {
		blocker.release();
		storage.disable();
	}
});

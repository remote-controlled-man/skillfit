export const AsyncResource = {
	bind: fn => fn,
};

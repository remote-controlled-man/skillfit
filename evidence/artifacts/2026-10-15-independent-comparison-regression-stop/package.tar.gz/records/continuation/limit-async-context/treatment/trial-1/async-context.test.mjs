#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from 'p-limit';
import {flush, gate, observe} from './test-clock.mjs';

for (const rejects of [false, true]) {
	test(`queued calls retain their context after the running task ${rejects ? 'rejects' : 'fulfills'}`, {timeout: 2000}, async t => {
		const storage = new AsyncLocalStorage();
		const tracing = new AsyncLocalStorage();
		t.after(() => {
			storage.disable();
			tracing.disable();
		});

		const limit = storage.run({name: 'construction'}, () => pLimit(1));
		const blocker = gate();
		const firstContext = {name: 'first'};
		const firstError = new Error('first task failed');
		const queuedError = new Error('queued task failed');
		const calls = [];
		const first = storage.run(firstContext, () => limit(async value => {
			assert.strictEqual(storage.getStore(), firstContext);
			calls.push(value);
			await blocker.promise;
			assert.strictEqual(storage.getStore(), firstContext);
			if (rejects) {
				throw firstError;
			}

			return value;
		}, 'first'));

		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 1);
		await flush();
		assert.equal(limit.activeCount, 1);
		assert.equal(limit.pendingCount, 0);

		const contexts = [{name: 'second'}, undefined, {name: 'fourth'}, {name: 'fifth'}];
		const queued = contexts.map((context, index) => {
			const trace = {id: index};
			return storage.run(context, () => tracing.run(trace, () => limit(async value => {
				assert.strictEqual(storage.getStore(), context);
				assert.strictEqual(tracing.getStore(), trace);
				assert.equal(limit.activeCount, 1);
				calls.push(value);
				await Promise.resolve();
				assert.strictEqual(storage.getStore(), context);
				assert.strictEqual(tracing.getStore(), trace);
				if (index === 2) {
					throw queuedError;
				}

				return value;
			}, index)));
		});

		await flush();
		assert.deepEqual(calls, ['first']);
		assert.equal(limit.activeCount, 1);
		assert.equal(limit.pendingCount, contexts.length);
		assert.equal(storage.getStore(), undefined);
		assert.equal(tracing.getStore(), undefined);

		const results = Promise.allSettled([first, ...queued]);
		storage.run({name: 'release'}, () => blocker.release());
		assert.deepEqual(await results, [
			rejects ? {status: 'rejected', reason: firstError} : {status: 'fulfilled', value: 'first'},
			{status: 'fulfilled', value: 0},
			{status: 'fulfilled', value: 1},
			{status: 'rejected', reason: queuedError},
			{status: 'fulfilled', value: 3},
		]);
		assert.deepEqual(calls, ['first', 0, 1, 2, 3]);
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
		assert.equal(storage.getStore(), undefined);
		assert.equal(tracing.getStore(), undefined);
	});
}

test('clearQueue discards queued calls and keeps running calls usable', {timeout: 2000}, async () => {
	const limit = pLimit(2);
	const blockers = [gate(), gate()];
	const running = blockers.map(blocker => limit(() => blocker.promise));
	await flush();
	assert.equal(limit.activeCount, 2);

	let discardedCalls = 0;
	const discarded = observe(limit(() => {
		discardedCalls++;
	}));
	assert.equal(limit.pendingCount, 1);
	assert.equal(limit.clearQueue(), undefined);
	assert.equal(limit.pendingCount, 0);
	assert.equal(limit.activeCount, 2);

	const replacement = limit((left, right) => left + right, 2, 3);
	blockers[0].release('first');
	assert.equal(await replacement, 5);
	blockers[1].release('second');
	assert.deepEqual(await Promise.all(running), ['first', 'second']);
	assert.equal(discardedCalls, 0);
	assert.deepEqual(discarded, {status: 'pending'});
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

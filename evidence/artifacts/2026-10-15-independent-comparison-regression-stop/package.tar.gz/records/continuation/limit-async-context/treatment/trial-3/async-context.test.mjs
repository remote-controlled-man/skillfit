#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

for (const rejects of [false, true]) {
	test(`queued calls retain their context after a task ${rejects ? 'rejects' : 'fulfills'}`, {timeout: 2000}, async () => {
		const storage = new AsyncLocalStorage();
		const limit = pLimit(1);
		const started = gate();
		const blocked = gate();
		const owner = {request: 'running'};
		const error = new Error('previous task failed');
		const first = storage.run(owner, () => limit(async () => {
			started.release();
			await blocked.promise;
			assert.equal(storage.getStore(), owner);
			if (rejects) {
				throw error;
			}

			return owner;
		}));
		const firstOutcome = observe(first);
		await started.promise;

		const caller = {request: 'first caller'};
		const contexts = [caller, undefined, {request: 'another caller'}, caller];
		const values = contexts.map((_, index) => ({index}));
		const order = [];
		const read = async (context, value) => {
			assert.equal(storage.getStore(), context, 'context at invocation');
			order.push(value.index);
			await Promise.resolve();
			assert.equal(storage.getStore(), context, 'context after await');
			return value;
		};
		const queued = contexts.map((context, index) => context === undefined
			? limit(read, context, values[index])
			: storage.run(context, () => limit(read, context, values[index])));
		const outcomes = Promise.all(queued);
		assert.equal(storage.getStore(), undefined);
		assert.equal(limit.activeCount, 1);
		assert.equal(limit.pendingCount, contexts.length);
		blocked.release();

		const results = await outcomes;
		for (const [index, value] of results.entries()) {
			assert.equal(value, values[index]);
		}

		assert.deepEqual(order, [0, 1, 2, 3]);
		assert.deepEqual(firstOutcome, rejects
			? {status: 'rejected', reason: error}
			: {status: 'fulfilled', value: owner});
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
		assert.equal(storage.getStore(), undefined);
	});
}

test('concurrency, deferred invocation and clearQueue remain unchanged', {timeout: 2000}, async () => {
	const limit = pLimit(2);
	const blocked = gate();
	const calls = [];
	const run = async value => {
		calls.push(value);
		await blocked.promise;
		return value;
	};
	const first = limit(run, 1);
	const second = limit(run, 2);
	const discarded = observe(limit(run, 3));
	assert.deepEqual(calls, []);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 3);
	await flush();
	assert.deepEqual(calls, [1, 2]);
	assert.equal(limit.activeCount, 2);
	assert.equal(limit.pendingCount, 1);
	assert.equal(limit.clearQueue(), undefined);
	assert.equal(limit.pendingCount, 0);
	blocked.release();
	assert.deepEqual(await Promise.all([first, second]), [1, 2]);
	assert.equal(await limit(run, 4), 4);
	assert.deepEqual(calls, [1, 2, 4]);
	assert.deepEqual(discarded, {status: 'pending'});
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

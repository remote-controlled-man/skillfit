#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';
import {gate} from './test-clock.mjs';

test('queued calls retain each caller\'s AsyncLocalStorage context', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const blocker = gate();
	const started = gate();
	const activeStore = {caller: 'active'};
	const queuedStores = [{caller: 'first queued'}, {caller: 'second queued'}, undefined];
	const active = storage.run(activeStore, () => limit(async () => {
		started.release();
		await blocker.promise;
		assert.strictEqual(storage.getStore(), activeStore);
	}));
	await started.promise;

	const queued = queuedStores.map(store => storage.run(store, () => limit(async argument => {
		const before = storage.getStore();
		await Promise.resolve();
		return {before, after: storage.getStore(), argument};
	}, store)));
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, queuedStores.length);
	blocker.release();
	const [, ...actual] = await Promise.all([active, ...queued]);
	for (const [index, store] of queuedStores.entries()) {
		assert.strictEqual(actual[index].before, store);
		assert.strictEqual(actual[index].after, store);
		assert.strictEqual(actual[index].argument, store);
	}

	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('throws and rejections advance the queue in each caller\'s context', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const blocker = gate();
	const started = gate();
	const failure = new Error('task failed');
	const calls = [];
	const active = storage.run('active', () => limit(async () => {
		started.release();
		await blocker.promise;
		throw failure;
	}));
	await started.promise;

	const throwing = storage.run('throwing', () => limit(() => {
		calls.push(storage.getStore());
		throw failure;
	}));
	const rejecting = storage.run('rejecting', () => limit(async () => {
		await Promise.resolve();
		calls.push(storage.getStore());
		throw failure;
	}));
	const succeeding = storage.run('succeeding', () => limit(value => {
		calls.push(storage.getStore());
		return value;
	}, 42));
	const settled = Promise.allSettled([active, throwing, rejecting, succeeding]);
	blocker.release();
	assert.deepEqual(await settled, [
		{status: 'rejected', reason: failure},
		{status: 'rejected', reason: failure},
		{status: 'rejected', reason: failure},
		{status: 'fulfilled', value: 42},
	]);
	assert.deepEqual(calls, ['throwing', 'rejecting', 'succeeding']);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('clearQueue discards queued calls while the active call can finish', async () => {
	const limit = pLimit(1);
	const blocker = gate();
	const started = gate();
	let discardedRan = false;
	const active = limit(async () => {
		started.release();
		await blocker.promise;
		return 'active';
	});
	await started.promise;
	const discarded = limit(() => {
		discardedRan = true;
	});
	let discardedSettled = false;
	discarded.then(() => {
		discardedSettled = true;
	});
	assert.equal(limit.pendingCount, 1);
	limit.clearQueue();
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, 0);
	blocker.release();
	assert.equal(await active, 'active');
	assert.equal(await limit(value => value, 'later'), 'later');
	assert.equal(discardedRan, false);
	assert.equal(discardedSettled, false);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

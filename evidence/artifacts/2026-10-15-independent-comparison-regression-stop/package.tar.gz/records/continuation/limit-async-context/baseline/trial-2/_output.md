我会先检查实现和本地测试，定位队列切换时上下文丢失的原因，再做最小修复、补充公开 API 回归测试，并用 Node 运行 `npm test`。全程离线，不安装依赖。
我会按 `diagnosing-bugs` 技能，先通过公开 API 写出能稳定触发该缺陷的失败测试，再据此定位并修复。
已稳定复现：原有 `npm test` 通过，但新测试得到 `['first', 'first']`，第二个排队调用应读到 `'second'`。

我会依次检查三种可能：① 出队直接沿用前一任务的上下文；② 队列启动用的微任务混用了上下文；③ Promise 结果传递出了问题。测试直接在任务函数内读取存储值，已将问题范围缩小到调用执行阶段。
原因已确认：队列只用 `Function.bind()` 保存回调；前一个任务完成后，`next()` 在它的上下文中直接执行下一项。`bind()` 不会保存 AsyncLocalStorage 上下文。

我会在入队时用 `AsyncResource.bind()` 捕获各调用的上下文，并为非 Node 环境提供透传替身，保留现有队列调度方式和公开 API。
修复后，最小回归测试已通过。我又补充了跨 `await`、同步抛错、异步拒绝和无存储上下文的检查，以及并发数、参数、计数和 `clearQueue()` 的行为检查，接下来运行完整验证。
已修复。原先 `Function.bind()` 不保存异步上下文，导致出队调用沿用前一任务的上下文；现改为入队时用 `AsyncResource.bind()` 捕获调用者上下文，并加入非 Node 环境的透传替身。

新增可执行的 `async-context.test.mjs`：修复前稳定失败，修复后通过，并覆盖异常、跨 `await`、并发和清队列行为。

实际验证（Node v24.21.0）：

- `npm test`：1/1 通过。
- `npm test -- async-context.test.mjs`：4/4 通过。
- `./async-context.test.mjs`：3/3 通过。
- 非 Node 条件分支模拟、`git diff --check`：通过。

全程离线，未安装依赖；供应测试、helper、vendored dependency、原始元数据、类型和文档均未改动。
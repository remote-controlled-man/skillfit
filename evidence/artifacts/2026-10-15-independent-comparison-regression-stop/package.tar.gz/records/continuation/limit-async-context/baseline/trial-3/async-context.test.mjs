#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';
import {flush, gate, observe} from './test-clock.mjs';

test('queued calls retain the AsyncLocalStorage context of their caller', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const blocker = gate();
	const running = storage.run('running', () => limit(() => blocker.promise));
	await flush();

	const queued = storage.run('queued', () => limit(() => storage.getStore()));
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, 1);

	blocker.release();
	await running;
	assert.equal(await queued, 'queued');
});

for (const concurrency of [1, 2]) {
	test(`queued calls keep independent stores across awaits (concurrency ${concurrency})`, async () => {
		const requests = new AsyncLocalStorage();
		const traces = new AsyncLocalStorage();
		const limit = requests.run('creator', () => pLimit(concurrency));
		const blockers = Array.from({length: concurrency}, () => gate());
		const running = blockers.map(blocker => requests.run('running', () => limit(() => blocker.promise)));
		await flush();

		const contexts = [
			{request: 'first', trace: 1},
			{request: 'second', trace: 2},
			{request: undefined, trace: undefined},
		];
		const order = [];
		const queued = contexts.map(({request, trace}, index) => requests.run(request, () => traces.run(trace, () => limit(async argument => {
			order.push(argument);
			const before = {request: requests.getStore(), trace: traces.getStore()};
			await Promise.resolve();
			const after = {request: requests.getStore(), trace: traces.getStore()};
			return {argument, before, after};
		}, index))));
		assert.equal(limit.activeCount, concurrency);
		assert.equal(limit.pendingCount, contexts.length);

		for (const blocker of [...blockers].reverse()) {
			blocker.release();
		}

		await Promise.all(running);
		assert.deepEqual(await Promise.all(queued), contexts.map((context, argument) => ({argument, before: context, after: context})));
		assert.deepEqual(order, [0, 1, 2]);
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
		assert.equal(requests.getStore(), undefined);
		assert.equal(traces.getStore(), undefined);
	});
}

for (const asynchronous of [false, true]) {
	test(`queued calls retain their context after ${asynchronous ? 'an asynchronous rejection' : 'a synchronous throw'}`, async () => {
		const storage = new AsyncLocalStorage();
		const limit = pLimit(1);
		const blocker = gate();
		const failure = new Error('task failed');
		const running = storage.run('running', () => limit(() => blocker.promise));
		await flush();

		const failing = storage.run('failing', () => limit(() => {
			assert.equal(storage.getStore(), 'failing');
			if (asynchronous) {
				return Promise.resolve().then(() => {
					assert.equal(storage.getStore(), 'failing');
					throw failure;
				});
			}

			throw failure;
		}));
		const rejected = assert.rejects(failing, error => error === failure);
		const following = storage.run('following', () => limit(() => storage.getStore()));

		blocker.release();
		await Promise.all([running, rejected]);
		assert.equal(await following, 'following');
		assert.equal(limit.activeCount, 0);
		assert.equal(limit.pendingCount, 0);
	});
}

test('clearing the queue preserves running work and later callers contexts', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const blocker = gate();
	const running = storage.run('running', () => limit(() => blocker.promise));
	await flush();

	let discardedStarted = false;
	const discarded = storage.run('discarded', () => limit(() => {
		discardedStarted = true;
	}));
	const discardedState = observe(discarded);
	assert.equal(limit.pendingCount, 1);
	limit.clearQueue();
	assert.equal(limit.pendingCount, 0);
	assert.equal(limit.activeCount, 1);
	const following = storage.run('following', () => limit(() => storage.getStore()));

	blocker.release('completed');
	assert.equal(await running, 'completed');
	assert.equal(await following, 'following');
	await flush();
	assert.equal(discardedStarted, false);
	assert.deepEqual(discardedState, {status: 'pending'});
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import test from 'node:test';
import pLimit from 'p-limit';

test('queued calls retain their own AsyncLocalStorage context', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const activeStore = {request: 'active'};
	const queuedStore = {request: 'queued'};
	let release;
	let started;
	const gate = new Promise(resolve => {
		release = resolve;
	});
	const running = new Promise(resolve => {
		started = resolve;
	});
	const active = storage.run(activeStore, () => limit(async () => {
		started();
		await gate;
	}));
	await running;

	const queued = storage.run(queuedStore, () => limit(async value => {
		assert.equal(storage.getStore(), queuedStore);
		await Promise.resolve();
		assert.equal(storage.getStore(), queuedStore);
		return value;
	}, 'result'));
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, 1);
	release();
	assert.equal(await queued, 'result');
	await active;
	assert.equal(storage.getStore(), undefined);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('calls without a store do not inherit the active call context', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	let release;
	let started;
	const gate = new Promise(resolve => {
		release = resolve;
	});
	const running = new Promise(resolve => {
		started = resolve;
	});
	const active = storage.run({request: 'active'}, () => limit(async () => {
		started();
		await gate;
	}));
	await running;

	const queued = limit(async () => {
		assert.equal(storage.getStore(), undefined);
		await Promise.resolve();
		assert.equal(storage.getStore(), undefined);
	});
	release();
	await Promise.all([active, queued]);
});

test('a call queued after clearQueue retains its context when an older microtask starts it', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const queuedStore = {request: 'queued'};
	let discardedRan = false;
	storage.run({request: 'discarded'}, () => limit(() => {
		discardedRan = true;
	}));
	limit.clearQueue();

	const queued = storage.run(queuedStore, () => limit(() => {
		assert.equal(storage.getStore(), queuedStore);
		return 'result';
	}));
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 1);
	assert.equal(await queued, 'result');
	assert.equal(discardedRan, false);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

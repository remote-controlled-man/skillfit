#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';

test('queued calls retain their own AsyncLocalStorage context', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	let release;
	const blocker = new Promise(resolve => {
		release = resolve;
	});
	let started;
	const firstStarted = new Promise(resolve => {
		started = resolve;
	});

	const first = storage.run('first', () => limit(async () => {
		started();
		await blocker;
		return storage.getStore();
	}));
	await firstStarted;
	const second = storage.run('second', () => limit(() => storage.getStore()));
	assert.equal(limit.activeCount, 1);
	assert.equal(limit.pendingCount, 1);
	release();

	assert.deepEqual(await Promise.all([first, second]), ['first', 'second']);
});

test('queued contexts stay isolated across awaits, failures, and absent stores', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	let release;
	const blocker = new Promise(resolve => {
		release = resolve;
	});
	const failure = new Error('task failed');
	const seen = [];
	const readContext = async () => {
		const before = storage.getStore();
		await Promise.resolve();
		return [before, storage.getStore()];
	};

	const first = storage.run('first', () => limit(() => blocker));
	const syncFailure = storage.run('sync', () => limit(() => {
		seen.push(storage.getStore());
		throw failure;
	}));
	const asyncFailure = storage.run('async', () => limit(async () => {
		seen.push(storage.getStore());
		await Promise.resolve();
		seen.push(storage.getStore());
		throw failure;
	}));
	const absent = limit(readContext);
	const last = storage.run('last', () => limit(readContext));
	release();

	assert.deepEqual(await Promise.allSettled([first, syncFailure, asyncFailure, absent, last]), [
		{status: 'fulfilled', value: undefined},
		{status: 'rejected', reason: failure},
		{status: 'rejected', reason: failure},
		{status: 'fulfilled', value: [undefined, undefined]},
		{status: 'fulfilled', value: ['last', 'last']},
	]);
	assert.deepEqual(seen, ['sync', 'async', 'async']);
	assert.equal(storage.getStore(), undefined);
});

test('scheduling, concurrency, arguments, counts, and clearQueue keep their behavior', async () => {
	const limit = pLimit(2);
	let release;
	const blocker = new Promise(resolve => {
		release = resolve;
	});
	const started = [];
	const task = async (...args) => {
		started.push(args[0]);
		await blocker;
		return args;
	};
	const first = limit(task, 'first', 1);
	const second = limit(task, 'second', 2);
	let discardedSettled = false;
	limit(task, 'discarded').then(() => {
		discardedSettled = true;
	});
	assert.deepEqual(started, []);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 3);

	await Promise.resolve();
	assert.deepEqual(started, ['first', 'second']);
	assert.equal(limit.activeCount, 2);
	assert.equal(limit.pendingCount, 1);
	limit.clearQueue();
	assert.equal(limit.activeCount, 2);
	assert.equal(limit.pendingCount, 0);
	const last = limit(task, 'last', 3);
	release();

	assert.deepEqual(await Promise.all([first, second, last]), [
		['first', 1], ['second', 2], ['last', 3],
	]);
	assert.deepEqual(started, ['first', 'second', 'last']);
	assert.equal(discardedSettled, false);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

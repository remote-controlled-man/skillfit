export class AsyncResource {
	static bind(fn) {
		return fn;
	}
}

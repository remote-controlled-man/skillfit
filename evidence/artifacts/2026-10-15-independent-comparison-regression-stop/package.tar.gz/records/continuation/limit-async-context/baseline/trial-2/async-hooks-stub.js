export const AsyncResource = {
	bind(fn) {
		return fn;
	},
};

#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pTimeout, {TimeoutError} from './index.js';
import {gate, observe, withClock} from './test-clock.mjs';

function createCustomTimers() {
	const calls = [];
	const customTimers = {
		setTimeout(callback, milliseconds) {
			assert.ok(this === undefined || this === globalThis, 'setTimeout receiver must be compatible with global timers');
			calls.push('setTimeout');
			return globalThis.setTimeout(callback, milliseconds);
		},
		clearTimeout(timer) {
			assert.ok(this === undefined || this === globalThis, 'clearTimeout receiver must be compatible with global timers');
			calls.push('clearTimeout');
			globalThis.clearTimeout(timer);
		},
	};

	return {customTimers, calls};
}

test('custom timers receive a compatible global timer receiver', async () => {
	await withClock(async clock => {
		const {customTimers, calls} = createCustomTimers();
		assert.equal(await pTimeout(Promise.resolve(7), {milliseconds: 100, customTimers}), 7);
		assert.deepEqual(calls, ['setTimeout', 'clearTimeout']);
		assert.equal(clock.pending, 0);
	});
});

test('custom timers preserve timeout rejection and cleanup', async () => {
	await withClock(async clock => {
		const {customTimers, calls} = createCustomTimers();
		const result = pTimeout(new Promise(() => {}), {milliseconds: 10, customTimers});
		const state = observe(result);
		await clock.advance(9);
		assert.equal(state.status, 'pending');
		await clock.advance(1);
		await assert.rejects(result, error => {
			assert.ok(error instanceof TimeoutError);
			assert.equal(error.message, 'Promise timed out after 10 milliseconds');
			return true;
		});
		assert.deepEqual(calls, ['setTimeout', 'clearTimeout']);
		assert.equal(clock.pending, 0);
	});
});

test('clear uses a compatible receiver and leaves the input promise pending', async () => {
	await withClock(async clock => {
		const {customTimers} = createCustomTimers();
		const input = gate();
		const result = pTimeout(input.promise, {milliseconds: 10, customTimers});
		const state = observe(result);
		assert.equal(clock.pending, 1);
		result.clear();
		assert.equal(clock.pending, 0);
		await clock.advance(20);
		assert.equal(state.status, 'pending');
		input.release(7);
		assert.equal(await result, 7);
		assert.equal(clock.pending, 0);
	});
});

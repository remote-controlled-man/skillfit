#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import pTimeout, {TimeoutError} from './index.js';

function createTimers() {
	const scheduled = [];
	const cleared = [];
	const pending = new Set();
	const customTimers = {
		setTimeout(callback, milliseconds) {
			assert.ok(this === globalThis, 'setTimeout requires a compatible global receiver');
			const handle = {callback, milliseconds};
			scheduled.push(handle);
			pending.add(handle);
			return handle;
		},
		clearTimeout(handle) {
			assert.ok(this === globalThis, 'clearTimeout requires a compatible global receiver');
			cleared.push(handle);
			pending.delete(handle);
		},
	};

	return {
		customTimers,
		scheduled,
		cleared,
		fire() {
			const handles = [...pending];
			for (const handle of handles) {
				pending.delete(handle);
				handle.callback();
			}

			return handles.length;
		},
	};
}

for (const outcome of ['resolve', 'reject']) {
	test(`custom global timers preserve input ${outcome} and clean up`, {timeout: 1000}, async () => {
		const timers = createTimers();
		const value = {answer: 42};
		const source = outcome === 'resolve' ? Promise.resolve(value) : Promise.reject(value);
		const wrapped = pTimeout(source, {milliseconds: 25, customTimers: timers.customTimers});

		if (outcome === 'resolve') {
			assert.equal(await wrapped, value);
		} else {
			await assert.rejects(wrapped, error => error === value);
		}

		assert.equal(timers.scheduled.length, 1);
		assert.equal(timers.scheduled[0].milliseconds, 25);
		assert.deepEqual(timers.cleared, [timers.scheduled[0]]);
		assert.equal(timers.fire(), 0);
	});
}

test('custom global timers time out and cancel the input', {timeout: 1000}, async () => {
	const timers = createTimers();
	const source = new Promise(() => {});
	let cancellations = 0;
	source.cancel = function () {
		assert.equal(this, source);
		cancellations++;
	};
	const wrapped = pTimeout(source, {milliseconds: 25, customTimers: timers.customTimers});
	const rejected = assert.rejects(wrapped, error => {
		assert.ok(error instanceof TimeoutError);
		assert.equal(error.message, 'Promise timed out after 25 milliseconds');
		return true;
	});

	const fired = timers.fire();
	await rejected;
	assert.equal(fired, 1);
	assert.equal(cancellations, 1);
	assert.deepEqual(timers.cleared, [timers.scheduled[0]]);
});

test('clear uses a compatible receiver and preserves later input resolution', {timeout: 1000}, async () => {
	const timers = createTimers();
	let release;
	const source = new Promise(resolve => {
		release = resolve;
	});
	const wrapped = pTimeout(source, {milliseconds: 25, customTimers: timers.customTimers});
	const result = wrapped.then(value => ({value}), error => ({error}));

	assert.equal(wrapped.clear(), undefined);
	assert.deepEqual(timers.cleared, [timers.scheduled[0]]);
	assert.equal(timers.fire(), 0);
	const value = {answer: 42};
	release(value);
	assert.deepEqual(await result, {value});
});

test('abort preserves its reason and clears a custom global timer', {timeout: 1000}, async () => {
	const timers = createTimers();
	const controller = new AbortController();
	const reason = new Error('stop');
	const wrapped = pTimeout(new Promise(() => {}), {
		milliseconds: 25,
		customTimers: timers.customTimers,
		signal: controller.signal,
	});
	const rejected = assert.rejects(wrapped, error => error === reason);

	controller.abort(reason);
	await rejected;
	assert.deepEqual(timers.cleared, [timers.scheduled[0]]);
	assert.equal(timers.fire(), 0);
});

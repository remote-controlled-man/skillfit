#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import {AsyncLocalStorage} from 'node:async_hooks';
import pLimit from './index.js';

test('queued calls retain their own AsyncLocalStorage context', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	let release;
	const gate = new Promise(resolve => {
		release = resolve;
	});
	const blocker = storage.run('blocker', () => limit(() => gate));
	await Promise.resolve();
	assert.equal(limit.activeCount, 1);

	const observe = async value => {
		const before = storage.getStore();
		await Promise.resolve();
		return {value, before, after: storage.getStore()};
	};
	const first = storage.run('first', () => limit(observe, 1));
	const second = storage.run('second', () => limit(observe, 2));
	const outside = limit(observe, 3);
	assert.equal(limit.pendingCount, 3);

	release();
	await blocker;
	assert.deepEqual(await Promise.all([first, second, outside]), [
		{value: 1, before: 'first', after: 'first'},
		{value: 2, before: 'second', after: 'second'},
		{value: 3, before: undefined, after: undefined},
	]);
	assert.equal(storage.getStore(), undefined);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('clearing the queue preserves the context of replacement calls', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	let discardedRan = false;
	storage.run('discarded', () => limit(() => {
		discardedRan = true;
	}));
	limit.clearQueue();
	assert.equal(limit.pendingCount, 0);

	const replacement = storage.run('replacement', () => limit(() => storage.getStore()));
	assert.equal(await replacement, 'replacement');
	assert.equal(discardedRan, false);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

test('thrown and rejected tasks preserve contexts and allow the queue to continue', async () => {
	const storage = new AsyncLocalStorage();
	const limit = pLimit(1);
	const syncError = new Error('synchronous failure');
	const asyncError = new Error('asynchronous failure');
	const seen = [];
	const tasks = [
		storage.run('sync', () => limit(() => {
			seen.push(storage.getStore());
			throw syncError;
		})),
		storage.run('async', () => limit(async () => {
			await Promise.resolve();
			seen.push(storage.getStore());
			throw asyncError;
		})),
		storage.run('success', () => limit(value => {
			seen.push(storage.getStore());
			return value;
		}, 42)),
	];

	const results = await Promise.allSettled(tasks);
	assert.equal(results[0].status, 'rejected');
	assert.equal(results[0].reason, syncError);
	assert.equal(results[1].status, 'rejected');
	assert.equal(results[1].reason, asyncError);
	assert.deepEqual(results[2], {status: 'fulfilled', value: 42});
	assert.deepEqual(seen, ['sync', 'async', 'success']);
	assert.equal(storage.getStore(), undefined);
	assert.equal(limit.activeCount, 0);
	assert.equal(limit.pendingCount, 0);
});

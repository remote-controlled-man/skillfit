// Post-result offline diagnostic, not a new scored task or model call.
import assert from'node:assert/strict';import{createContext,runInContext}from'node:vm';import{cpSync,mkdtempSync,readFileSync,writeFileSync,rmSync}from'node:fs';import{join,dirname}from'node:path';import{tmpdir}from'node:os';import{pathToFileURL,fileURLToPath}from'node:url';import{createHash}from'node:crypto';
const root=dirname(fileURLToPath(import.meta.url)),packaged=process.argv.includes('--package'),old=join(root,'../independent-comparison-execution-20261015'),fixture=packaged?join(root,'bench/fixtures/timeout-custom-timers'):join(old,'inputs/bench/fixtures/timeout-custom-timers');
const sources={original:join(fixture,'index.js'),maintainer:packaged?join(root,'bench/ground-truth/timeout-custom-timers/index.js'):join(old,'inputs/bench/ground-truth/timeout-custom-timers/index.js'),baselineDelivery:join(root,packaged?'records/continuation':'retained-native','timeout-custom-timers/baseline/trial-1/index.js'),v4Delivery:join(root,packaged?'records/continuation':'retained-native','timeout-custom-timers/treatment/trial-1/index.js')};
const results=[],unhandled=[];const listener=e=>unhandled.push(String(e));process.on('unhandledRejection',listener);
try{for(const [variant,source]of Object.entries(sources)){
 const scratch=mkdtempSync(join(tmpdir(),'skillfit-receiver-diagnostic-'));try{
  cpSync(fixture,scratch,{recursive:true});writeFileSync(join(scratch,'index.js'),readFileSync(source));const{default:pTimeout}=await import(pathToFileURL(join(scratch,'index.js')).href);
  let next=1;const pending=new Set();const context=createContext({schedule:()=>{const id=next++;pending.add(id);return id;},cancel:id=>pending.delete(id)});
  // Ordinary functions declared in another realm default to their own global object
  // when called without an explicit receiver. Forcing this realm's global object fails.
  const customTimers=runInContext('({setTimeout:function(...args){if(this!==globalThis)throw new TypeError("Incompatible timer receiver");return schedule(...args)},clearTimeout:function(...args){if(this!==globalThis)throw new TypeError("Incompatible clear receiver");return cancel(...args)}})',context);
  let outcome;try{const value=await pTimeout(Promise.resolve('ok'),{milliseconds:25,customTimers});outcome={status:'fulfilled',value};}catch(e){outcome={status:'rejected',error:e.message};}
  await new Promise(r=>setImmediate(r));await new Promise(r=>setImmediate(r));results.push({variant,sourceSha256:createHash('sha256').update(readFileSync(source)).digest('hex'),outcome,pendingHandles:pending.size});
 }finally{rmSync(scratch,{recursive:true,force:true});}}
}finally{process.off('unhandledRejection',listener);}
assert.equal(results.find(r=>r.variant==='original').outcome.status,'rejected');assert.equal(results.find(r=>r.variant==='v4Delivery').outcome.status,'rejected');
for(const variant of ['maintainer','baselineDelivery']){const r=results.find(r=>r.variant===variant);assert.deepEqual(r.outcome,{status:'fulfilled',value:'ok'});assert.equal(r.pendingHandles,0);}
assert.deepEqual(unhandled,[]);const proof={kind:'skillfit.offline-receiver-diagnostic',modelCalls:0,extraScoredTasks:0,scope:'Additional explanation after the fixed predeclared verifier result; no score, policy, task selection or cohort mutation.',results,unhandled};
if(packaged)assert.deepEqual(proof,JSON.parse(readFileSync(join(root,'execution/receiver-diagnostic.json'))));else writeFileSync(join(root,'receiver-diagnostic.json'),JSON.stringify(proof,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(proof));

#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];

const scientificCases = [
  [1e21, '1e+21', '①e+②①'],
  [1.23e21, '1.23e+21', '①.②③e+②①'],
  [1e-7, '1e-7', '①e-⑦'],
  [1.23e-7, '1.23e-7', '①.②③e-⑦'],
  [Number.MAX_VALUE, '1.7976931348623157e+308', '①.⑦⑨⑦⑥⑨③①③④⑧⑥②③①⑤⑦e+③⓪⑧'],
  [Number.MIN_VALUE, '5e-324', '⑤e-③②④'],
];

for (const [duration, plainCount, replacedCount] of scientificCases) {
  test(`digit replacements preserve scientific notation for ${plainCount}`, () => {
    assert.equal(
      humanizeDuration(duration, { units: ['ms'] }),
      `${plainCount} milliseconds`,
    );
    assert.equal(
      humanizeDuration(duration, { units: ['ms'], digitReplacements }),
      `${replacedCount} milliseconds`,
    );
  });
}

test('humanizer preserves localized units, decimal separators and call overrides', () => {
  const humanizer = humanizeDuration.humanizer({
    units: ['ms'],
    language: 'de',
    digitReplacements,
  });

  assert.equal(humanizer(1.23e21), '①,②③e+②① Millisekunden');
  assert.equal(humanizer(1.23e-7), '①,②③e-⑦ Millisekunden');
  assert.equal(
    humanizer(1.23e21, { decimal: ' point 0e+ ' }),
    '① point 0e+ ②③e+②① Millisekunden',
  );
  assert.equal(
    humanizer(1.23e-7, { digitReplacements: undefined }),
    '1,23e-7 Millisekunden',
  );
  assert.equal(humanizer(1250), '①②⑤⓪ Millisekunden');
});

test('language-provided digit replacements preserve scientific notation', () => {
  const options = { units: ['ms'], language: 'ar' };

  assert.equal(humanizeDuration(1.23e21, options), '١,٢٣e+٢١ جزء من الثانية');
  assert.equal(humanizeDuration(1.23e-7, options), '١,٢٣e-٧ جزء من الثانية');
  assert.equal(humanizeDuration(0, options), '۰ جزء من الثانية');
  assert.equal(humanizeDuration(2, options), 'جزآن من الثانية');
});

test('ordinary digit replacements retain all digits and duration formatting', () => {
  const options = { units: ['ms'], digitReplacements };

  assert.equal(humanizeDuration(1234567890, options), '①②③④⑤⑥⑦⑧⑨⓪ milliseconds');
  assert.equal(humanizeDuration(0, options), '⓪ milliseconds');
  assert.equal(
    humanizeDuration(1000, { units: ['s'], digitReplacements }),
    '① second',
  );
  assert.equal(
    humanizeDuration(1500, { units: ['s'], digitReplacements }),
    '①.⑤ seconds',
  );
  assert.equal(
    humanizeDuration(8123.456789, { units: ['s'], maxDecimalPoints: 3, digitReplacements }),
    '⑧.①②③ seconds',
  );
  assert.equal(
    humanizeDuration(61000, { units: ['m', 's'], digitReplacements }),
    '① minute, ① second',
  );
  assert.equal(
    humanizeDuration(1234, {
      units: ['s'],
      digitReplacements: ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'],
    }),
    'One.TwoThreeFour seconds',
  );
});

test('ordinary calls without digit replacements retain existing formatting', () => {
  assert.equal(humanizeDuration(1234567890, { units: ['ms'] }), '1234567890 milliseconds');
  assert.equal(humanizeDuration(0, { units: ['ms'] }), '0 milliseconds');
  assert.equal(humanizeDuration(1000), '1 second');
  assert.equal(humanizeDuration(1500, { units: ['s'] }), '1.5 seconds');
  assert.equal(humanizeDuration(1500, { units: ['s'], language: 'de' }), '1,5 Sekunden');
  assert.equal(humanizeDuration(1500, { units: ['s'], decimal: ' point ' }), '1 point 5 seconds');
});

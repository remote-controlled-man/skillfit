#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];
const scientificCases = [
  [1e21, '1e+21', '①e+②①'],
  [1.25e21, '1.25e+21', '①.②⑤e+②①'],
  [1e-7, '1e-7', '①e-⑦'],
  [1.25e-7, '1.25e-7', '①.②⑤e-⑦'],
  [Number.MAX_VALUE, '1.7976931348623157e+308', '①.⑦⑨⑦⑥⑨③①③④⑧⑥②③①⑤⑦e+③⓪⑧'],
  [Number.MIN_VALUE, '5e-324', '⑤e-③②④'],
];

for (const [ms, plainCount, replacedCount] of scientificCases) {
  test(`digit replacements preserve scientific notation for ${plainCount}`, () => {
    assert.equal(
      humanizeDuration(ms, {units: ['ms'], digitReplacements}),
      `${replacedCount} milliseconds`,
    );
  });
}

test('scientific notation without replacements stays unchanged', () => {
  for (const [ms, plainCount] of scientificCases) {
    assert.equal(humanizeDuration(ms, {units: ['ms']}), `${plainCount} milliseconds`);
  }
  assert.equal(humanizeDuration(1234, {units: ['s']}), '1.234 seconds');
});

test('scientific notation keeps localized words and decimal separators', () => {
  const options = {units: ['ms'], language: 'de', digitReplacements};
  assert.equal(humanizeDuration(1.25e21, options), '①,②⑤e+②① Millisekunden');
  assert.equal(humanizeDuration(1.25e-7, options), '①,②⑤e-⑦ Millisekunden');
  assert.equal(
    humanizeDuration(1.25e-7, {...options, decimal: '<e+9>'}),
    '①<e+9>②⑤e-⑦ Millisekunden',
  );
});

test('Arabic default digit replacements also preserve scientific notation', () => {
  const options = {units: ['ms'], language: 'ar'};
  assert.equal(humanizeDuration(1.25e-7, options), '١,٢٥e-٧ جزء من الثانية');
  assert.equal(
    humanizeDuration(1.25e-7, {...options, digitReplacements}),
    '①,②⑤e-⑦ جزء من الثانية',
  );
  assert.equal(humanizeDuration(2000, {units: ['s'], language: 'ar'}), 'ثانيتان');
});

test('ordinary replacements, decimals and unit selection stay intact', () => {
  assert.equal(
    humanizeDuration(1234567890, {units: ['ms'], digitReplacements}),
    '①②③④⑤⑥⑦⑧⑨⓪ milliseconds',
  );
  assert.equal(humanizeDuration(0, {units: ['ms'], digitReplacements}), '⓪ milliseconds');
  assert.equal(humanizeDuration(1, {units: ['ms'], digitReplacements}), '① millisecond');
  assert.equal(humanizeDuration(1234, {units: ['s'], digitReplacements}), '①.②③④ seconds');
  assert.equal(
    humanizeDuration(12345, {units: ['s'], maxDecimalPoints: 2, digitReplacements}),
    '①②.③④ seconds',
  );
  assert.equal(
    humanizeDuration(65000, {units: ['m', 's'], digitReplacements}),
    '① minute, ⑤ seconds',
  );
});

test('humanizer defaults and multi-character replacements remain supported', () => {
  const humanizer = humanizeDuration.humanizer({
    units: ['s'],
    digitReplacements: ['[0]', '[1]', '[2]', '[3]', '[4]', '[5]', '[6]', '[7]', '[8]', '[9]'],
  });
  assert.equal(humanizer(1.25e24), '[1].[2][5]e+[2][1] seconds');
  assert.equal(humanizer(0.000125), '[1].[2][5]e-[7] seconds');
  assert.equal(humanizer(1234), '[1].[2][3][4] seconds');
  assert.equal(humanizer(1e24, {digitReplacements: undefined}), '1e+21 seconds');
});

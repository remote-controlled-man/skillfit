#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];
const options = {units: ['ms'], digitReplacements};

test('digit replacements preserve scientific notation for very large durations', () => {
  assert.equal(humanizeDuration(1e21, options), '①e+②① milliseconds');
  assert.equal(humanizeDuration(1.234e25, options), '①.②③④e+②⑤ milliseconds');
  assert.equal(
    humanizeDuration(Number.MAX_VALUE, options),
    '①.⑦⑨⑦⑥⑨③①③④⑧⑥②③①⑤⑦e+③⓪⑧ milliseconds'
  );
});

test('digit replacements preserve scientific notation for tiny durations', () => {
  assert.equal(humanizeDuration(1e-7, options), '①e-⑦ milliseconds');
  assert.equal(humanizeDuration(1.234e-7, options), '①.②③④e-⑦ milliseconds');
  assert.equal(humanizeDuration(Number.MIN_VALUE, options), '⑤e-③②④ milliseconds');
});

test('localized decimal separators and unit words remain intact', () => {
  const localized = {...options, language: 'fr'};
  assert.equal(humanizeDuration(1.234e25, localized), '①,②③④e+②⑤ millisecondes');
  assert.equal(humanizeDuration(1.234e-7, localized), '①,②③④e-⑦ milliseconde');
});

test('Arabic default digit replacements and explicit overrides preserve exponents', () => {
  const localized = {units: ['ms'], language: 'ar'};
  assert.equal(humanizeDuration(1.234e25, localized), '١,٢٣٤e+٢٥ جزء من الثانية');
  assert.equal(humanizeDuration(1.234e-7, localized), '١,٢٣٤e-٧ جزء من الثانية');
  assert.equal(
    humanizeDuration(1.234e25, {...localized, digitReplacements}),
    '①,②③④e+②⑤ جزء من الثانية'
  );
  assert.equal(humanizeDuration(2000, {language: 'ar'}), 'ثانيتان');
});

test('custom decimal separators, spacing and unit labels are not digit-replaced', () => {
  const custom = {
    ...options,
    language: 'custom',
    languages: {custom: {ms: 'unit e+12'}},
    decimal: ' point 0 ',
    spacer: ' / '
  };
  assert.equal(humanizeDuration(1.234e25, custom), '① point 0 ②③④e+②⑤ / unit e+12');
  assert.equal(humanizeDuration(1.234e-7, custom), '① point 0 ②③④e-⑦ / unit e+12');
});

test('ordinary digit replacements and fixed notation remain unchanged', () => {
  assert.equal(humanizeDuration(1023456789.25, options), '①⓪②③④⑤⑥⑦⑧⑨.②⑤ milliseconds');
  assert.equal(humanizeDuration(0, options), '⓪ milliseconds');
  assert.equal(humanizeDuration(1e20, options), '①' + '⓪'.repeat(20) + ' milliseconds');
  assert.equal(humanizeDuration(1e-6, options), '⓪.⓪⓪⓪⓪⓪① milliseconds');
  assert.equal(humanizeDuration(1234, {units: ['s'], digitReplacements}), '①.②③④ seconds');
  assert.equal(
    humanizeDuration(1234.567, {...options, maxDecimalPoints: 2}),
    '①②③④.⑤⑥ milliseconds'
  );
  assert.equal(
    humanizeDuration(1234, {units: ['s'], digitReplacements, round: true}),
    '① second'
  );
});

test('calls without digit replacements retain their notation and localization', () => {
  const plain = {units: ['ms']};
  assert.equal(humanizeDuration(1e21, plain), '1e+21 milliseconds');
  assert.equal(humanizeDuration(1.234e25, plain), '1.234e+25 milliseconds');
  assert.equal(humanizeDuration(1e-7, plain), '1e-7 milliseconds');
  assert.equal(humanizeDuration(1.234e-7, plain), '1.234e-7 milliseconds');
  assert.equal(humanizeDuration(1.234e25, {...plain, language: 'fr'}), '1,234e+25 millisecondes');
  assert.equal(humanizeDuration(1234), '1.234 seconds');
  assert.equal(humanizeDuration(1.234e25, {...plain, decimal: ' point 0 '}), '1 point 0 234e+25 milliseconds');
});

test('humanizer defaults and per-call digit replacement overrides preserve notation', () => {
  const humanizer = humanizeDuration.humanizer(options);
  assert.equal(humanizer(1.234e25), '①.②③④e+②⑤ milliseconds');
  assert.equal(humanizer(1.234e-7), '①.②③④e-⑦ milliseconds');
  assert.equal(humanizer(1e21, {digitReplacements: undefined}), '1e+21 milliseconds');
  assert.equal(humanizer(1234), '①②③④ milliseconds');
});

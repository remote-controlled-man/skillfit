#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = [
  'Zero', 'One', 'Two', 'Three', 'Four',
  'Five', 'Six', 'Seven', 'Eight', 'Nine',
];

test('digit replacements preserve scientific notation and replace exponent digits', () => {
  const cases = [
    [1e21, 'Onee+TwoOne milliseconds'],
    [1.2345e27, 'One.TwoThreeFourFivee+TwoSeven milliseconds'],
    [1e-7, 'Onee-Seven milliseconds'],
    [1.234e-9, 'One.TwoThreeFoure-Nine milliseconds'],
    [1e20, 'One' + 'Zero'.repeat(20) + ' milliseconds'],
    [1e-6, 'Zero.ZeroZeroZeroZeroZeroOne milliseconds'],
  ];
  for (const [duration, expected] of cases) {
    assert.equal(humanizeDuration(duration, {
      units: ['ms'], digitReplacements,
    }), expected, String(duration));
  }
});

test('humanizers replace large and tiny counts after unit conversion', () => {
  const humanizer = humanizeDuration.humanizer({
    units: ['s'], digitReplacements,
  });
  assert.equal(humanizer(1e27), 'Onee+TwoFour seconds');
  assert.equal(humanizer(1e-9), 'Onee-OneTwo seconds');
  assert.equal(humanizer(1234), 'One.TwoThreeFour seconds');
  assert.equal(humanizer(1e27, {digitReplacements: undefined}), '1e+24 seconds');
});

test('localized words and decimal separators survive digit replacements', () => {
  const options = {language: 'fr', units: ['ms'], digitReplacements};
  assert.equal(humanizeDuration(1.25e21, options),
    'One,TwoFivee+TwoOne millisecondes');
  assert.equal(humanizeDuration(1.25e-7, options),
    'One,TwoFivee-Seven milliseconde');
  assert.equal(humanizeDuration(1.25e21, {
    ...options, decimal: ' point2+e ',
  }), 'One point2+e TwoFivee+TwoOne millisecondes');
  assert.equal(humanizeDuration(1.25e-7, {
    ...options, decimal: ' point2+e ',
  }), 'One point2+e TwoFivee-Seven milliseconde');
});

test('custom unit words containing digits stay unchanged', () => {
  assert.equal(humanizeDuration(1.25e21, {
    units: ['ms'], digitReplacements,
    language: 'custom',
    languages: {custom: {ms: 'unit 123 e+/-'}},
  }), 'One.TwoFivee+TwoOne unit 123 e+/-');
});

test('Arabic default replacements preserve scientific notation', () => {
  const options = {language: 'ar', units: ['ms']};
  assert.equal(humanizeDuration(1.25e21, options), '١,٢٥e+٢١ جزء من الثانية');
  assert.equal(humanizeDuration(1.25e-7, options), '١,٢٥e-٧ جزء من الثانية');
  assert.equal(humanizeDuration(0, options), '۰ جزء من الثانية');
  assert.equal(humanizeDuration(2000, {language: 'ar', units: ['s']}), 'ثانيتان');
  assert.equal(humanizeDuration(1.25e21, {
    ...options, digitReplacements: undefined,
  }), '1,25e+21 جزء من الثانية');
});

test('ordinary integer, zero and fractional replacements remain intact', () => {
  const options = {units: ['ms'], digitReplacements};
  assert.equal(humanizeDuration(0, options), 'Zero milliseconds');
  assert.equal(humanizeDuration(1, options), 'One millisecond');
  assert.equal(humanizeDuration(1234567890, options),
    'OneTwoThreeFourFiveSixSevenEightNineZero milliseconds');
  assert.equal(humanizeDuration(1234, {units: ['s'], digitReplacements}),
    'One.TwoThreeFour seconds');
  assert.equal(humanizeDuration(1000.25, {
    ...options, decimal: ',', maxDecimalPoints: 1,
  }), 'OneZeroZeroZero,Two milliseconds');
});

test('calls without replacements retain their existing notation', () => {
  const cases = [
    [1e21, '1e+21 milliseconds'],
    [1.2345e27, '1.2345e+27 milliseconds'],
    [1e-7, '1e-7 milliseconds'],
    [1.234e-9, '1.234e-9 milliseconds'],
    [1e20, '100000000000000000000 milliseconds'],
    [1e-6, '0.000001 milliseconds'],
  ];
  for (const [duration, expected] of cases) {
    assert.equal(humanizeDuration(duration, {units: ['ms']}), expected);
  }
  assert.equal(humanizeDuration(1.25e21, {language: 'fr', units: ['ms']}),
    '1,25e+21 millisecondes');
  assert.equal(humanizeDuration(1500, {units: ['s']}), '1.5 seconds');
});

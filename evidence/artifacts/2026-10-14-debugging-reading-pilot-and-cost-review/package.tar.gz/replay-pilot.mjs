// Offline derivative audit; never invokes an agent or model API.
import assert from 'node:assert/strict';
import {cpSync,mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {sha256File,hashFileSet,listFilesRecursive} from './runner/dist/harness/hash.js';
import {loadBench} from './runner/dist/harness/bench.js';
import {runVerifier} from './runner/dist/harness/runner.js';
import {verdictFromOutput} from './runner/dist/harness/verifier-summary.js';
import {summarizeCosts} from './runner/dist/harness/costs.js';
import {assessEvaluation} from './runner/dist/harness/eval-acceptance.js';
const root=dirname(fileURLToPath(import.meta.url)),json=path=>JSON.parse(readFileSync(join(root,path)));
for(const file of json('package-index.json').files)assert.equal(sha256File(join(root,file.path)),file.sha256,file.path);
assert.equal(hashFileSet(join(root,'runner/dist'),listFilesRecursive(join(root,'runner/dist'))),'da640a88b07b7daa6621c0e17007b4c929927e7c10801d6fc3dfdb40b7f27509');
const manifest=json('records/manifest.json'),saved=json('pilot/assessment.json'),bench=loadBench(join(root,'bench'));
const declaration=json('pilot/execution-declaration.json');
for(const [path,expected] of [['skills/v4',declaration.baselineSha256],['skills/v5-reading-rejected',declaration.candidateSha256],['skills/v5.1-reading-unvalidated',json('review/narrowed-candidate.json').candidateSha256]])assert.equal(hashFileSet(join(root,path),listFilesRecursive(join(root,path))),expected);
assert.equal(bench.contentSha256,manifest.bench.contentSha256);
assert.equal(manifest.experiment.callsStarted,4);assert.equal(manifest.experiment.callsFinished,4);
const arms={baseline:[],treatment:[]};let regraded=0;
for(const task of bench.tasks)for(const arm of ['baseline','treatment'])for(let trial=1;trial<=manifest.trials;trial++){
 const rel=`records/${task.id}/${arm}/trial-${trial}`,record=json(rel+'/_result.json');
 assert.equal(record.taskId,task.id);assert.equal(record.condition,arm);assert.equal(record.trial,trial);
 assert.equal(record.error,null);assert.equal(record.executorInvoked,true);assert.equal(record.usageStatus,'final');
 const scratch=mkdtempSync(join(tmpdir(),'skillfit-public-reading-replay-'));
 try{cpSync(join(root,rel),scratch,{recursive:true});const grade=await runVerifier(bench.dir,task.verifier,scratch),summary=verdictFromOutput(grade.output);assert.equal(grade.exitCode,record.verifierExitCode);assert.equal(summary.score,record.score);assert.deepEqual(summary.checks.map(({name,pass})=>({name,pass})),record.checks.map(({name,pass})=>({name,pass})));assert.equal(grade.exitCode===0,record.passed);}finally{rmSync(scratch,{recursive:true,force:true});}
 arms[arm].push(record);regraded++;
 const trace=readFileSync(join(root,rel,'_transcript.jsonl'),'utf8').trim().split('\n').map(JSON.parse);
 assert.ok(trace.every(e=>e.item?.type!=='reasoning'));
 const final=trace.find(e=>e.type==='turn.completed').usage;
 assert.equal(final.input_tokens,record.tokens.input);assert.equal(final.cached_input_tokens,record.tokens.cachedInput);assert.equal(final.output_tokens,record.tokens.output);
}
assert.deepEqual(summarizeCosts(arms,arms),manifest.overall.costs);
const result=assessEvaluation(manifest,saved.evidence);
for(const key of ['quality','costs','acceptance'])assert.deepEqual(result[key],saved[key]);
assert.equal(result.acceptance.decision,'reject');assert.equal(result.acceptance.automaticUpgrade,false);
const sentence=json('review/narrowed-candidate.json').additionalSentence;
assert.equal(readFileSync(join(root,'skills/v5.1-reading-unvalidated/SKILL.md'),'utf8').replace(' '+sentence,''),readFileSync(join(root,'skills/v4/SKILL.md'),'utf8'));
for(const name of ['LICENSE','agents/openai.yaml','scripts/hitl-loop.template.sh'])assert.deepEqual(readFileSync(join(root,'skills/v5.1-reading-unvalidated',name)),readFileSync(join(root,'skills/v4',name)));
console.log(JSON.stringify({modelCalls:0,regraded,qualityCostsAcceptanceMatch:true,decision:result.acceptance.decision,derivedExport:true,automaticUpgrade:false,narrowedDraftUnvalidated:true}));

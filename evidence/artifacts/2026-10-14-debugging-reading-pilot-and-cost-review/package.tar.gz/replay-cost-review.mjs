import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url)),json=path=>JSON.parse(readFileSync(join(root,path)));
const traces=json('review/command-observations.json').traces,remaining=json('review/remaining-costs.json'),recoveries=json('review/recovery-responses.json');
const hidden=command=>/(?:--check|--quiet|--no-patch)(?:\s|['"]|$)/.test(command);
const raw=/\brtk proxy git diff --no-index\b/, ordinary=/\brtk git diff --no-index\b/;
let emptyPatchTraces=0,checkOnlyTraces=0,patchThenRawTraces=0;
for(const trace of traces){
 const empty=trace.commands.filter(c=>ordinary.test(c.command)&&c.exitCode===1&&c.empty),patch=empty.filter(c=>!hidden(c.command));
 if(patch.length)emptyPatchTraces++;else if(empty.length)checkOnlyTraces++;
 if(trace.commands.some(c=>raw.test(c.command)&&c.outputBytes>0&&patch.some(p=>trace.commands.indexOf(p)<trace.commands.indexOf(c))))patchThenRawTraces++;
}
assert.equal(traces.length,126);assert.deepEqual({emptyPatchTraces,intentionallyEmptyCheckOnlyTraces:checkOnlyTraces,patchThenRawTraces},recoveries.correctedCounts);
const sourceFinal=new Map(traces.map(t=>[t.threadId,t.finalUsage]));
for(const arm of ['baseline','treatment'])for(const trial of [1,2]){
 const events=readFileSync(join(root,`records/duration-large-digits/${arm}/trial-${trial}/_transcript.jsonl`),'utf8').trim().split('\n').map(JSON.parse);
 sourceFinal.set(events.find(e=>e.type==='thread.started').thread_id,events.find(e=>e.type==='turn.completed').usage);
}
const recomputed=[];
for(const cohort of remaining.cohorts){
 for(const run of cohort.runs){
  const totals={input:0,cached:0,uncached:0,output:0};
  for(const response of run.responses){assert.equal(response.uncached,response.input-response.cached);for(const key of Object.keys(totals))totals[key]+=response[key];}
  assert.deepEqual(totals,run.totals);assert.equal(run.responseCount,run.responses.length);
  const final=sourceFinal.get(run.threadId);assert.ok(final);assert.equal(totals.input,final.input_tokens);assert.equal(totals.cached,final.cached_input_tokens);assert.equal(totals.output,final.output_tokens);
  const drops=run.responses.flatMap((current,i)=>i>0&&current.input>=run.responses[i-1].input&&run.responses[i-1].cached-current.cached>=4096?[{response:i+1,previous:run.responses[i-1],current,cacheDrop:run.responses[i-1].cached-current.cached}]:[]);
  assert.deepEqual(drops,run.cacheDrops);
 }
 const pairs=cohort.pairs.map(p=>{
  const b=cohort.runs.find(r=>r.taskId===p.taskId&&r.trial===p.trial&&r.arm==='baseline'),t=cohort.runs.find(r=>r.taskId===p.taskId&&r.trial===p.trial&&r.arm==='treatment');assert.ok(b&&t);
  const delta=Object.fromEntries(Object.keys(b.totals).map(k=>[k,t.totals[k]-b.totals[k]]));delta.responses=t.responseCount-b.responseCount;
  assert.equal(delta.uncached,delta.input-delta.cached);return {taskId:p.taskId,trial:p.trial,delta,uncachedHigherDespiteNoMoreInput:delta.uncached>0&&delta.input<=0};
 });assert.deepEqual(pairs,cohort.pairs);
 const summary={runs:cohort.runs.length,pairs:pairs.length,pairsWithMoreTreatmentResponses:pairs.filter(p=>p.delta.responses>0).length,pairsWithFewerTreatmentResponses:pairs.filter(p=>p.delta.responses<0).length,uncachedHigherDespiteNoMoreInput:pairs.filter(p=>p.uncachedHigherDespiteNoMoreInput).length,runsWithCacheDrop:cohort.runs.filter(r=>r.cacheDrops.length).length,cacheDropEvents:cohort.runs.reduce((n,r)=>n+r.cacheDrops.length,0)};
 assert.deepEqual(summary,cohort.summary);recomputed.push({id:cohort.id,...summary});
}
const classifications=[];
for(const entry of recoveries.cases){
 assert.deepEqual(sourceFinal.get(entry.threadId),entry.finalUsage);
 const totals={input:0,cachedInput:0,uncachedInput:0,output:0};
 for(const r of entry.responses){assert.equal(r.uncachedInput,r.input-r.cachedInput);for(const key of Object.keys(totals))totals[key]+=r[key];}
 assert.equal(totals.input,entry.finalUsage.input_tokens);assert.equal(totals.cachedInput,entry.finalUsage.cached_input_tokens);assert.equal(totals.output,entry.finalUsage.output_tokens);
 for(const r of entry.responses.filter(r=>r.actions.some(a=>a.commands.some(c=>raw.test(c))))){
  const before=entry.responses.filter(s=>s.ordinal<r.ordinal&&s.actions.some(a=>a.hasOrdinaryPatch));
  const same=r.actions.some(a=>a.hasOrdinaryPatch),commands=r.actions.flatMap(a=>a.commands),calls=r.actions.reduce((n,a)=>n+a.execCommandCount,0);
  const dedicated=before.length>0&&!same&&r.actions.length===1&&calls===1&&commands.length===1&&raw.test(commands[0])&&!/[;&|]/.test(commands[0])&&!r.actions.some(a=>a.hasPatch);
  const result={response:r.ordinal,priorOrdinaryPatchResponses:before.map(s=>s.ordinal),sameResponseOrdinaryPatch:same,classification:dedicated?'dedicated-later-response':before.length?'later-response-mixed-work':same?'same-response':'unresolved',usage:{input:r.input,cachedInput:r.cachedInput,uncachedInput:r.uncachedInput,output:r.output}};
  assert.deepEqual(result,entry.classifications.find(c=>c.response===r.ordinal));classifications.push(result);
 }
}
const counts=Object.fromEntries(['dedicated-later-response','later-response-mixed-work','same-response','unresolved'].map(name=>[name,classifications.filter(c=>c.classification===name).length]));assert.deepEqual(counts,recoveries.classifications);
const sum=list=>Object.fromEntries(['input','cachedInput','uncachedInput','output'].map(key=>[key,list.reduce((n,c)=>n+c.usage[key],0)]));
assert.deepEqual(sum(classifications),recoveries.observedAllRecoveryResponseUsage);assert.deepEqual(sum(classifications.filter(c=>c.classification==='dedicated-later-response')),recoveries.observedDedicatedResponseUsage);
const numeric=json('review/pilot-numeric-usage.json'),costs=json('review/pilot-cost-breakdown.json'),commands=json('review/pilot-command-bytes.json');
const labels=['orientation','discovery','reproduction','regression','repair-and-close'];
const phases={'baseline/1':[0,1,1,2,3,4,4,4],'baseline/2':[0,1,1,2,3,4,4],'treatment/1':[0,1,1,2,3,3,4,4,4,4],'treatment/2':[0,1,1,2,3,4,4]};
const commandMap={'baseline/1':[[3,2],[4,6,7,8,9,10],[11],[14],[16,18,19]],'baseline/2':[[3,2],[4,6,7,8,9,10],[11],[14],[16,17]],'treatment/1':[[2,3],[4,5,6,7,8,9,10,11,12,13,14,15],[16],[19,20],[22,24,25,26,27,28]],'treatment/2':[[3,2],[4,5,6,7,8],[9],[11,13],[15,16]]};
const phaseRuns=[];
for(const run of numeric.runs){
 const id=`${run.arm}/${run.trial}`,grouped=Object.fromEntries(labels.map(label=>[label,{responses:0,input:0,cachedInput:0,uncachedInput:0,output:0,reasoningOutput:0,otherOutput:0,commands:0,commandOutputBytes:0}]));
 let cumulative={input_tokens:0,cached_input_tokens:0,output_tokens:0,reasoning_output_tokens:0};assert.equal(run.responses.length,phases[id].length);
 for(const [i,response] of run.responses.entries()){
  for(const key of Object.keys(cumulative))cumulative[key]+=response.usage[key];assert.deepEqual(cumulative,response.cumulative);
  const p=grouped[labels[phases[id][i]]],u=response.usage;p.responses++;p.input+=u.input_tokens;p.cachedInput+=u.cached_input_tokens;p.uncachedInput+=u.input_tokens-u.cached_input_tokens;p.output+=u.output_tokens;p.reasoningOutput+=u.reasoning_output_tokens;p.otherOutput+=u.output_tokens-u.reasoning_output_tokens;
 }
 for(const key of Object.keys(cumulative))assert.equal(cumulative[key],run.publicFinal[key]);
 assert.equal(run.publicFinal.cache_write_input_tokens,0);
 const list=commands.find(c=>c.arm===run.arm&&c.trial===run.trial).commands;
 for(const [phaseIndex,items] of commandMap[id].entries())for(const n of items){const c=list.find(c=>c.id==='item_'+n);assert.ok(c);grouped[labels[phaseIndex]].commands++;grouped[labels[phaseIndex]].commandOutputBytes+=c.outputBytes;}
 const saved=costs.pairs.find(p=>p.trial===run.trial)[run.arm];assert.deepEqual(grouped,saved.phases);
 phaseRuns.push({arm:run.arm,grouped});
}
const byArm=Object.fromEntries(['baseline','treatment'].map(arm=>[arm,Object.fromEntries(labels.map(label=>[label,Object.fromEntries(Object.keys(phaseRuns[0].grouped[label]).map(key=>[key,phaseRuns.filter(r=>r.arm===arm).reduce((s,r)=>s+r.grouped[label][key],0)]))]))]));
assert.deepEqual(byArm,costs.byArm);
const delta=Object.fromEntries(labels.map(label=>[label,Object.fromEntries(Object.keys(byArm.baseline[label]).map(key=>[key,byArm.treatment[label][key]-byArm.baseline[label][key]]))]));assert.deepEqual(delta,costs.phaseDeltas);
assert.equal(Object.values(delta).reduce((s,p)=>s+p.uncachedInput,0),15542);
const rtk=json('review/rtk-observation.json');for(const result of rtk.results)for(const kind of ['native','filtered','raw'])if(result[kind]){assert.equal(Buffer.byteLength(result[kind].stdout),result[kind].stdoutBytes);assert.equal(Buffer.byteLength(result[kind].stderr),result[kind].stderrBytes);}
for(const id of ['added-file-patch','modified-file-patch']){const r=rtk.results.find(r=>r.id===id);assert.equal(r.native.exitCode,1);assert.ok(r.native.stdoutBytes>0);assert.equal(r.filtered.stdoutBytes,0);assert.deepEqual(r.native,r.raw);}
assert.equal(rtk.results.find(r=>r.id==='clean-whitespace-check').native.stdoutBytes,0);
const ledger=json('review/cumulative-ledger.json'),analysis=json('pilot/analysis.json');
assert.equal(ledger.actualExecutorCalls,174+4);assert.equal(ledger.missingPublicFinalUsage,7);
const attempts=json('pilot/assessment.json').costs.allInvocations;
// Read the frozen manifest populations, including every invocation.
const populations=json('records/manifest.json').overall.costs.attempts;
for(const key of ['input','cachedInput','uncachedInput','output','durationSeconds']){
 const added=populations.baseline.metrics[key].knownTotal+populations.treatment.metrics[key].knownTotal;
 assert.equal(Number((ledger.priorPublished.nativeKnownLowerBound[key]+added).toFixed(3)),ledger.nativeKnownLowerBound[key]);
}
for(const key of ['input','cachedInput','uncachedInput','output','durationSeconds'])assert.equal(ledger.nativeKnownLowerBound[key]+ledger.qualifiedUnattestedReadinessSupplement[key],ledger.includingQualifiedSupplement[key]);
for(const bound of [ledger.nativeKnownLowerBound,ledger.includingQualifiedSupplement])assert.equal(bound.input-bound.cachedInput,bound.uncachedInput);
assert.deepEqual(ledger.includingQualifiedSupplement,analysis.cumulative.knownLowerBoundIncludingQualifiedLocalReadinessSupplement);
console.log(JSON.stringify({modelCalls:0,numericFinalsMatched:130,correctedCounts:recoveries.correctedCounts,recoveryClassifications:counts,cohorts:recomputed,pilotPhaseCostsMatch:true,rtkRecordedControlsMatch:true,cumulativeCalls:ledger.actualExecutorCalls,missingPublicFinalUsage:7,netSavingsUnproven:true}));

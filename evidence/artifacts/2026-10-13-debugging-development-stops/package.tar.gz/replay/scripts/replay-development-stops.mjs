// Offline delivery and spending reproduction. Never invokes an agent/model CLI.
import assert from 'node:assert/strict';
import {cpSync,mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {basename,dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {loadBench} from '../dist/harness/bench.js';
import {runVerifier} from '../dist/harness/runner.js';
import {verdictFromOutput} from '../dist/harness/verifier-summary.js';
import {summarizeCosts,COST_METRICS} from '../dist/harness/costs.js';
import {parseEvalReport} from '../dist/commands/eval-report.js';
const replay=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const pkg=resolve(replay,'..');
const root=resolve(process.argv[2]??join(pkg,'records'));
const index=JSON.parse(readFileSync(join(pkg,'export-index.json'),'utf8'));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const file of index.files){
 const path=file.path.startsWith('records/')?join(root,file.path.slice('records/'.length)):join(pkg,file.path);
 assert.equal(hash(readFileSync(path)),file.exportedSha256,'Exported bytes changed: '+file.path);
}
const cohorts=[];const measured=[];
for(const batch of [2,4,5]){
 const directory=join(root,'development-'+batch),manifest=JSON.parse(readFileSync(join(directory,'manifest.json'),'utf8'));parseEvalReport(manifest);
 const bench=loadBench(join(replay,'benches',batch===5?'development-v3':'oss-minipass'));assert.equal(bench.contentSha256,manifest.bench.contentSha256);
 const all={baseline:[],treatment:[]},paired={baseline:[],treatment:[]};let regraded=0,invoked=0;
 for(const task of bench.tasks){
  const taskAll={baseline:[],treatment:[]},taskPaired={baseline:[],treatment:[]};
  for(let trial=1;trial<=manifest.trials;trial++){
   const pair={};
   for(const arm of ['baseline','treatment']){
    const delivery=join(directory,task.id,arm,'trial-'+trial),receipt=JSON.parse(readFileSync(join(delivery,'_result.json'),'utf8'));
    assert.equal(receipt.taskId,task.id);assert.equal(receipt.trial,trial);assert.equal(receipt.condition,arm);
    pair[arm]=receipt;all[arm].push(receipt);taskAll[arm].push(receipt);
    if(receipt.executorInvoked){invoked++;measured.push(receipt);}
    if(receipt.error!==null)continue;
    const scratch=mkdtempSync(join(tmpdir(),'skillfit-development-replay-'));
    try{
     cpSync(delivery,scratch,{recursive:true,filter:path=>basename(path)!=='.git'});
     const grade=await runVerifier(bench.dir,task.verifier,scratch),summary=verdictFromOutput(grade.output);
     assert.equal(grade.exitCode,receipt.verifierExitCode);assert.equal(grade.exitCode===0,receipt.passed);
     assert.equal(summary?.score??null,receipt.score);
     assert.deepEqual(summary?.checks?.map(({name,pass})=>({name,pass}))??null,receipt.checks?.map(({name,pass})=>({name,pass}))??null);
     regraded++;
    }finally{rmSync(scratch,{recursive:true,force:true});}
   }
   if(pair.baseline.error===null&&pair.treatment.error===null)for(const arm of ['baseline','treatment']){paired[arm].push(pair[arm]);taskPaired[arm].push(pair[arm]);}
  }
  assert.deepEqual(summarizeCosts(taskAll,taskPaired),manifest.tasks.find(t=>t.id===task.id).costs);
 }
 const costs=summarizeCosts(all,paired);assert.deepEqual(costs,manifest.overall.costs);assert.equal(invoked,manifest.experiment.callsStarted);
 cohorts.push({batch,status:manifest.experiment.status,actualCalls:invoked,regradedDeliveries:regraded,gradedPairs:paired.baseline.length,baselinePasses:manifest.overall.conditions.baseline.passes,treatmentPasses:manifest.overall.conditions.treatment.passes,verdict:manifest.overall.verdict,costsMatch:true,costs});
}
const readiness=[];
for(const batch of [2,4]){
 const r=JSON.parse(readFileSync(join(pkg,'development-'+batch+'-readiness.json'),'utf8'));assert.equal(r.ready,true);
 const observation={executorInvoked:true,passed:false,error:r.error,durationSeconds:r.durationSeconds,tokens:r.tokens,usageStatus:r.usageStatus};measured.push(observation);readiness.push({batch,...r});
}
const population=summarizeCosts({baseline:measured,treatment:[]},{baseline:[],treatment:[]}).attempts.baseline;

const supplement=JSON.parse(readFileSync(join(pkg,'failed-usage-supplement.json'),'utf8'));
const verification=JSON.parse(readFileSync(join(pkg,'failed-usage-reader-verification.json'),'utf8'));
assert.equal(supplement.originalReceiptsChanged,false);assert.equal(supplement.modelCallsMade,0);
assert.equal(supplement.failedCliExecutions.length,3);assert.equal(verification.matchedAllThree,true);
const additional={input:0,cachedInput:0,output:0,uncachedInput:0};
for(const row of supplement.failedCliExecutions){
 const dir=join(root,'development-'+row.batch,row.task,row.arm,'trial-1');
 const receipt=JSON.parse(readFileSync(join(dir,'_result.json'),'utf8'));
 assert.equal(receipt.executorInvoked,true);assert.notEqual(receipt.error,null);assert.equal(receipt.tokens,null);
 const events=readFileSync(join(dir,'_transcript.jsonl'),'utf8').split('\n').filter(Boolean).map(line=>JSON.parse(line));
 assert.ok(events.some(e=>e.type==='thread.started'&&e.thread_id===row.threadId));
 const at=Date.parse(row.lastUsageAt);assert.ok(at>=Date.parse(receipt.startedAt)&&at<=Date.parse(receipt.finishedAt));
 const usage=row.cumulativeUsage,probe=verification.rows.find(r=>r.batch===row.batch);
 const tokens={input:usage.input_tokens,cachedInput:usage.cached_input_tokens,output:usage.output_tokens};
 for(const n of Object.values(tokens))assert.ok(Number.isSafeInteger(n)&&n>=0);assert.ok(tokens.cachedInput<=tokens.input);
 assert.deepEqual(probe.tokens,tokens);assert.equal(probe.evidence.threadId,row.threadId);assert.equal(probe.evidence.counterAt,row.lastUsageAt);
 assert.match(probe.evidence.recordSha256,/^[0-9a-f]{64}$/);
 additional.input+=tokens.input;additional.cachedInput+=tokens.cachedInput;additional.output+=tokens.output;additional.uncachedInput+=tokens.input-tokens.cachedInput;
}
assert.deepEqual(additional,supplement.additionalKnownPartial);
const lower=Object.fromEntries(Object.keys(additional).map(metric=>[metric,population.metrics[metric].knownTotal+additional[metric]]));
assert.deepEqual(lower,supplement.totalKnownLowerBoundWithReadiness);
const supplementalCosts={source:'Identity-bound numeric sidecar; original failed receipts remain unknown',additionalKnownPartial:additional,totalKnownLowerBoundWithReadiness:lower,finalUsageMissingInvocations:3,originalReceiptsChanged:false,completeBilling:false};

const actualCalls=measured.length;assert.equal(actualCalls,12);assert.equal(cohorts.reduce((s,c)=>s+c.regradedDeliveries,0),7);
console.log(JSON.stringify({schemaVersion:1,modelCallsMadeByReplay:0,scope:'Separate stopped development cohorts; never pooled for a quality verdict. Invocation counts are agent CLI executions, not provider-internal requests. Complete known spending includes readiness, failed executions and excluded partners; unknown token receipts remain unknown.',exportIntegrityFiles:index.files.length,exportedNativeSeal:'derived paths; original native verification cannot be asserted for exported bytes',cohorts,readiness,agentCliInvocations:actualCalls,benchmarkInvocations:cohorts.reduce((s,c)=>s+c.actualCalls,0),readinessInvocations:readiness.length,completedDeliveryRegrades:7,totalRecordedSpending:Object.fromEntries(COST_METRICS.map(metric=>[metric,population.metrics[metric]])),missingFinalInputInvocations:actualCalls-population.metrics.input.coverage.final,supplementalCosts,automaticUpgrade:false},null,2));

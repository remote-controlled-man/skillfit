# Debugging Skill development stops: reproducibility package

This package retains three separate stopped development cohorts, plus two
zero-call preparation failures. It supports no stable improvement or adoption
claim. Independent validation was not run in these cohorts.

## Recorded outcomes

| Cohort | Ordering | Actual benchmark CLI executions | Graded pairs | Completed deliveries regraded | Stop |
|---|---|---:|---:|---:|---|
| 2: original / compact v2 | baseline first | 4 | 1 | 3 | Provider 503 / selected model at capacity |
| 4: original / compact v2 | balanced | 5 | 2 | 4 | Original pipeline execution reached the real 600s deadline |
| 5: compact v2 / compact v3 | balanced | 1 | 0 | 0 | Compact-v2 pipeline execution reached the real 600s deadline; v3 never invoked |

The successful paired cases tie at full correctness. Cohort 2's one surviving
pair reduces uncached input 35.4%; cohort 4's two surviving pairs increase it
30.8%. These different stopped cohorts cannot establish stable savings or be
pooled as validation. The completed excluded partner remains in spending.

Across the cohorts and two successful readiness checks: **12 agent CLI
executions**, input **at least 1,850,417**, cached input at least 1,630,848,
uncached input at least 219,569, output **at least 43,625**, and 3265.534 seconds
of recorded intervals. Three failed executions lack final token usage in their native receipts;
these remain unknown, not zero. Provider-internal requests/retries, dollar billing,
candidate authoring, orchestration and offline verification are not fully
metered here. No blended price or complete optimization bill is inferred.

A separate numeric supplement recovers partial cumulative counters from exactly
those three CLI sessions, bound by public thread ID, workdir and interval. Eight
successful executions calibrated exactly against final public usage. Including
these partial counters, recorded spending is at least **2,632,108 input**,
2,343,936 cached input, **288,172 uncached input** and **71,128 output**. The
three final usages remain missing; pending requests and provider retries are
unrecorded. Reasoning tokens are already included in output. Original receipts
and their stopped status are unchanged. The private local session bodies are
not distributed; offline replay verifies the saved numeric sidecar, its hashes,
public session identities and arithmetic, rather than independently attesting
the undistributed private source.

The configured environment is Node v24.21.0, Codex CLI 0.162.0-alpha.17.2,
`gpt-6.1-sol` / `xhigh` / `default`. Served model identity and sampling controls
remain unattested. Inherited agent configuration is not isolated. The temporary
macOS sleep assertions were verified, alive through execution and released;
forced sleep is not prevented. Both timeouts show normal monotonic timing.

## Contents and integrity

- `records.tar.gz`: all retained task files, installed Skills, prompts, public
  transcripts, receipts, ledgers, manifests and native inventories; Git internals
  and private rollout reasoning are excluded.
- `replay/`: frozen compiled/source evaluation code, package/license and both
  exact minipass bench arrangements, with unchanged fixtures, verifiers and
  maintainer oracles. It is a partial project snapshot.
- `export-index.json`: original and exported byte hashes. Metadata/public local
  paths are normalized to `<HOME>`, `<WORKSPACE>` and `<TEMP_RUNS>`. Source,
  tests, Skills and licenses remain byte-identical. Original native hashes bind
  original private paths; exported hashes bind the derived public copy. The
  public copy does **not** claim an unchanged original native seal or adoption
  eligibility. Three original copies passed local native audit before export.
- `offline-replay-verified.json`, `summary.json`: exact regraded outcomes and
  recomputed paired/all-invocation costs, including partial/unknown coverage.
- `failed-usage-supplement.json`, `failed-usage-reader-verification.json`: numeric
  partial counters and original record hashes, kept separate from native receipts.
- Readiness, power, declarations, preparation failures and timeout-delivery
  diagnostics are retained separately. Offline diagnosis of incomplete timed-out
  deliveries never changes their native excluded status or counts as a model
  success. Both such deliveries still missed a public write-return behavior.

## Offline reproduction

With Node >=22 (verified here on v24.21.0), run from this directory:

```bash
SKILLFIT_DEVELOPMENT_RECORDS=$(mktemp -d)
tar -xzf records.tar.gz -C "$SKILLFIT_DEVELOPMENT_RECORDS"
node replay/scripts/replay-development-stops.mjs "$SKILLFIT_DEVELOPMENT_RECORDS/records"
node --test replay/dist/harness/stats.test.js replay/dist/harness/eval-efficiency.test.js replay/dist/harness/execution-timing.test.js
```

Expected: export hashes match, 7 completed deliveries regrade identically,
all cohort spending matches, 12 CLI executions including 2 readiness executions,
3 invocations missing final input usage, and supplemental lower bounds recompute
exactly; frozen standalone tests pass 23/23.
These commands make zero model/agent calls and install no dependency. Scratch
copies are used for grading, so retained deliveries are unchanged. The partial
snapshot does not contain the unrelated historical fixtures needed by the full
project test suite; the complete checkout passed 491/491 separately.

A fresh live procedure requires a new request/run group, authorization to spend,
its reviewed preview hash, pinned inputs and compatible agent configuration.
Use the current component contract and keep prior failures separate. Changing a
candidate, deadline or sample count cannot replace an earlier failed observation.
Fresh model calls reproduce the method, not identical stochastic outcomes,
cache usage or latency. The component never upgrades a Skill automatically.

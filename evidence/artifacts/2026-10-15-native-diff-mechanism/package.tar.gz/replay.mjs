// Offline replay of a normalized derivative; no model, agent CLI or network.
import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { hashFileSet, listFilesRecursive, sha256File } from './runner/dist/harness/hash.js';
import { loadBench } from './runner/dist/harness/bench.js';
import { runVerifier } from './runner/dist/harness/runner.js';
import { verdictFromOutput } from './runner/dist/harness/verifier-summary.js';
import { summarizeCosts } from './runner/dist/harness/costs.js';
import { assessEvaluation } from './runner/dist/harness/eval-acceptance.js';
import { NATIVE_DIFF_GUIDANCE, NATIVE_DIFF_SOURCE, nativeDiffDescriptor } from './runner/dist/harness/native-diff.js';
const root = dirname(fileURLToPath(import.meta.url));
const json = path => JSON.parse(readFileSync(join(root, path), 'utf8'));
for (const file of json('package-index.json').files) assert.equal(sha256File(join(root, file.path)), file.sha256, file.path);
const declaration = json('execution/execution-declaration.json'), analysis = json('execution/analysis.json');
assert.equal(hashFileSet(join(root, 'runner/dist'), listFilesRecursive(join(root, 'runner/dist'))), declaration.implementationSha256);
for (const [path, expected] of [['skills/original', declaration.baselineSha256], ['skills/v4', declaration.candidateSha256]]) assert.equal(hashFileSet(join(root, path), listFilesRecursive(join(root, path))), expected);
const warningReview = json('execution/startup-warning-review.json');
assert.equal(warningReview.count, 4); assert.equal(warningReview.configChanged, false);
assert.equal(sha256File(join(root, 'execution/protocol.md')), declaration.pins.find(pin => pin.path.endsWith('docs/plans/2026-10-15-native-diff-mechanism.md')).sha256);
assert.equal(json('execution/authorization-summary.json').actualCalls, 4);
const manifest = json('records/manifest.json'), saved = json('execution/assessment.json'), bench = loadBench(join(root, 'bench'));
assert.equal(bench.contentSha256, declaration.benchSha256);
assert.equal(manifest.experiment.callsStarted, 4); assert.equal(manifest.experiment.callsFinished, 4);
assert.equal(manifest.pairOrder, 'balanced');
const starts = readFileSync(join(root, 'records/_calls.jsonl'), 'utf8').trim().split('\n').map(JSON.parse).filter(row => row.event === 'started');
assert.deepEqual(starts.map(row => row.workdir.split('/').slice(-2)), [['baseline', 'trial-1'], ['treatment', 'trial-1'], ['treatment', 'trial-2'], ['baseline', 'trial-2']]);
const arms = { baseline: [], treatment: [] };
let regraded = 0, observed = 0, helperExecutions = 0, suspiciousEmptyPatches = 0;
for (const task of bench.tasks) for (const arm of ['baseline', 'treatment']) for (let trial = 1; trial <= manifest.trials; trial++) {
  const rel = `records/${task.id}/${arm}/trial-${trial}`, record = json(rel + '/_result.json');
  const row = analysis.rows.find(row => row.arm === arm && row.trial === trial);
  assert.equal(record.error, null); assert.equal(record.executorInvoked, true); assert.equal(record.usageStatus, 'final');
  const scratch = mkdtempSync(join(tmpdir(), 'skillfit-native-diff-replay-'));
  try {
    cpSync(join(root, rel), scratch, { recursive: true });
    const grade = await runVerifier(bench.dir, task.verifier, scratch), summary = verdictFromOutput(grade.output);
    assert.equal(grade.exitCode, record.verifierExitCode); assert.equal(summary.score, record.score);
    assert.deepEqual(summary.checks.map(({ name, pass }) => ({ name, pass })), record.checks.map(({ name, pass }) => ({ name, pass })));
    assert.equal(grade.exitCode === 0, record.passed);
  } finally { rmSync(scratch, { recursive: true, force: true }); }
  arms[arm].push(record); regraded++;
  const events = readFileSync(join(root, rel, '_transcript.jsonl'), 'utf8').trim().split('\n').map(JSON.parse);
  assert.ok(events.every(event => event.item?.type !== 'reasoning'));
  const warning = events.filter(event => event.item?.type === 'error'); assert.equal(warning.length, 1); assert.match(warning[0].item.message, /^Under-development features enabled: local_thread_store_compression\./);
  const turns = events.filter(event => event.type === 'turn.completed'); assert.ok(turns.length > 0);
  for (const [key, wire] of [['input', 'input_tokens'], ['cachedInput', 'cached_input_tokens'], ['output', 'output_tokens']]) assert.equal(turns.reduce((sum, turn) => sum + turn.usage[wire], 0), record.tokens[key]);
  const commands = events.filter(event => event.type === 'item.completed' && event.item?.type === 'command_execution').map(event => event.item);
  assert.equal(commands.length, row.commandCount);
  // Exported command bodies keep byte lengths through padded path normalization.
  assert.equal(commands.reduce((sum, command) => sum + Buffer.byteLength(command.aggregated_output ?? ''), 0), row.commandOutputBytes);
  const direct = commands.filter(command => /^\/bin\/(?:zsh|bash) -lc 'node _skillfit\/native-diff\.cjs [A-Za-z0-9._/-]+'$/.test(command.command));
  assert.equal(direct.length, row.helperExecutions); helperExecutions += direct.length;
  let used = false;
  for (const command of direct) {
    const target = command.command.match(/native-diff\.cjs ([A-Za-z0-9._/-]+)'$/)[1];
    assert.equal(command.exit_code, 1); assert.match(command.aggregated_output, /^diff --git /m); assert.match(command.aggregated_output, /^--- \/dev\/null$/m); assert.match(command.aggregated_output, /^@@/m);
    assert.ok(!listFilesRecursive(join(root, 'bench', task.fixture)).includes(target));
    assert.ok(commands.some(row => /\bgit status\b/.test(row.command) && row.aggregated_output.split('\n').some(line => line.trim() === `?? ${target}`)));
    assert.ok(!commands.some(row => /\bgit\s+(add|commit|rm|reset)\b/.test(row.command)));
    used = true;
  }
  assert.equal(row.helperUse, used ? 'observed' : 'not-observed'); if (used) observed++;
  suspiciousEmptyPatches += commands.filter(command => /\bgit diff\b/.test(command.command) && /--no-index\b/.test(command.command) && !/--check\b/.test(command.command) && command.exit_code === 1 && !command.aggregated_output).length;
  assert.equal(sha256File(join(root, rel, declaration.nativeDiffTool.path)), declaration.nativeDiffTool.sha256);
  assert.equal(record.timing.execution.anomaly, null); assert.equal(record.timing.execution.timeoutMs, 1200000);
}
assert.deepEqual(summarizeCosts(arms, arms), manifest.overall.costs);
const result = assessEvaluation(manifest, saved.evidence);
for (const key of ['quality', 'costs', 'acceptance']) assert.deepEqual(result[key], saved[key]);
assert.equal(result.acceptance.decision, 'inconclusive'); assert.equal(result.acceptance.eligibleForUpgrade, false); assert.equal(result.acceptance.automaticUpgrade, false);
assert.equal(observed, analysis.observedHelperUseRuns); assert.equal(helperExecutions, analysis.totalHelperExecutions); assert.equal(suspiciousEmptyPatches, analysis.suspiciousEmptyPatchCount);
assert.deepEqual(nativeDiffDescriptor(), analysis.nativeDiffTool); assert.equal(Buffer.byteLength(NATIVE_DIFF_GUIDANCE), analysis.commonGuidanceBytes); assert.equal(Buffer.byteLength(NATIVE_DIFF_SOURCE), analysis.helperSourceBytes);
const metrics = ['input', 'cachedInput', 'uncachedInput', 'output', 'durationSeconds'];
const total = Object.fromEntries(metrics.map(metric => [metric, analysis.rows.reduce((sum, row) => sum + row.usage[metric], 0)]));
assert.deepEqual(total, analysis.totals);
for (const pair of analysis.pairs) for (const metric of metrics) assert.equal(pair.changes[metric], pair.treatment[metric] / pair.baseline[metric] - 1);
const prior = json('review/prior-cumulative-ledger.json'); assert.equal(prior.actualExecutorCalls, 178);
assert.equal(analysis.cumulative.actualExecutorCalls, 182); assert.equal(analysis.cumulative.missingPublicFinalUsage, prior.missingPublicFinalUsage);
for (const metric of metrics) assert.equal(analysis.cumulative.nativeKnownLowerBound[metric], Math.round((prior.nativeKnownLowerBound[metric] + total[metric]) * 1000) / 1000);
assert.equal(json('execution/power.json').released, true);
console.log(JSON.stringify({ modelCalls: 0, regraded, qualityCostsAcceptanceMatch: true, observedHelperUseRuns: observed, helperExecutions, suspiciousEmptyPatches, cumulativeCalls: 182, missingPublicFinalUsage: 7, decision: result.acceptance.decision, automaticUpgrade: false, derivedExport: true }));

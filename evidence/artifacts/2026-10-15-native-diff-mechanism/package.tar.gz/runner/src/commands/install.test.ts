import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { promises as fs } from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { parseFrontmatter } from '../frontmatter.js';
import {
  BACKUP_SUFFIX,
  LOCKFILE_NAME,
  MARKER_END,
  MARKER_START,
  loadProfile,
  renderManagedBlock,
  runInstall,
  upsertManagedBlock,
  type InstallOptions,
} from './install.js';

const PROFILES_DIR = fileURLToPath(new URL('../../profiles/', import.meta.url));
const CLI_PATH = fileURLToPath(new URL('../../dist/cli.js', import.meta.url));

async function tempDirs(t: test.TestContext): Promise<{ home: string; project: string }> {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'skillfit-install-'));
  t.after(async () => { await fs.rm(root, { recursive: true, force: true }); });
  const home = path.join(root, 'home');
  const project = path.join(root, 'project');
  await fs.mkdir(home, { recursive: true });
  await fs.mkdir(project, { recursive: true });
  return { home, project };
}

function makeOpts(home: string, project: string, extra: Partial<InstallOptions> = {}): InstallOptions {
  return {
    profile: 'recommended',
    homeDir: home,
    projectDir: project,
    profilesDir: PROFILES_DIR,
    env: { PATH: '' },
    yes: true,
    log: () => {},
    ...extra,
  };
}

function captureLogs(): { lines: string[]; log: (line: string) => void } {
  const lines: string[] = [];
  return { lines, log: (line) => { lines.push(line); } };
}

async function exists(p: string): Promise<boolean> {
  try {
    await fs.access(p);
    return true;
  } catch {
    return false;
  }
}

async function snapshot(root: string): Promise<Record<string, string>> {
  const out: Record<string, string> = {};
  async function walk(dir: string): Promise<void> {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(full);
      else if (entry.isFile()) out[path.relative(root, full)] = await fs.readFile(full, 'utf8');
    }
  }
  await walk(root);
  return out;
}

interface LockShape {
  version: number;
  entries: Record<string, { sha256: string; profileVersion: string; installedAt: string; kind: string }>;
}

async function readLock(dir: string): Promise<LockShape> {
  return JSON.parse(await fs.readFile(path.join(dir, LOCKFILE_NAME), 'utf8')) as LockShape;
}

test('installs rules and skill for codex at user scope', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));

  const agentsMd = await fs.readFile(path.join(home, '.codex', 'AGENTS.md'), 'utf8');
  assert.ok(agentsMd.includes(MARKER_START));
  assert.ok(agentsMd.includes(MARKER_END));
  assert.match(agentsMd, /red-green-refactor/);

  const skillMd = await fs.readFile(path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md'), 'utf8');
  const fm = parseFrontmatter(skillMd);
  assert.equal(fm?.name, 'commit-message');
  assert.ok(fm?.description);

  const lock = await readLock(home);
  assert.equal(lock.version, 1);
  assert.deepEqual(Object.keys(lock.entries).sort(), ['codex:rules', 'codex:skill:commit-message']);
  const rulesEntry = lock.entries['codex:rules'];
  assert.ok(rulesEntry);
  assert.equal(rulesEntry.profileVersion, '1.0.0');
  assert.match(rulesEntry.sha256, /^[0-9a-f]{64}$/);
  assert.ok(rulesEntry.installedAt);
});

test('uses CODEX_HOME for global Codex rules while keeping user skills under home', async (t) => {
  const { home, project } = await tempDirs(t);
  const codexHome = path.join(home, 'alternate-codex');
  await runInstall(makeOpts(home, project, {
    agent: 'codex',
    env: { PATH: '', CODEX_HOME: codexHome },
  }));

  assert.ok(await exists(path.join(codexHome, 'AGENTS.md')));
  assert.ok(await exists(path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md')));
  assert.equal(await exists(path.join(home, '.codex', 'AGENTS.md')), false);
});

test('refuses a Codex global rules install shadowed by AGENTS.override.md', async (t) => {
  const { home, project } = await tempDirs(t);
  const codexHome = path.join(home, '.codex');
  await fs.mkdir(codexHome, { recursive: true });
  await fs.writeFile(path.join(codexHome, 'AGENTS.override.md'), '# Active override\n');
  const { lines, log } = captureLogs();
  await assert.rejects(runInstall(makeOpts(home, project, {
    agent: 'codex', log,
  })), /conflict/i);
  assert.match(lines.join('\n'), /AGENTS\.override\.md.*shadows/);
  assert.equal(await exists(path.join(home, '.agents', 'skills', 'commit-message')), false);
});

test('installs a profile supplied by directory and preserves binary skill assets', async (t) => {
  const { home, project } = await tempDirs(t);
  const profile = path.join(project, 'portable');
  const skillDir = path.join(profile, 'skills', 'example');
  await fs.mkdir(skillDir, { recursive: true });
  await fs.writeFile(path.join(profile, 'profile.json'), JSON.stringify({
    name: 'portable', version: '1.0.0', agents: ['codex'],
    skills: [{ name: 'example', source: 'skills/example' }],
  }));
  await fs.writeFile(path.join(skillDir, 'SKILL.md'), '---\nname: example\ndescription: Example skill.\n---\nUse it.\n');
  const image = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x00, 0xff, 0x80]);
  await fs.writeFile(path.join(skillDir, 'icon.png'), image);

  await runInstall(makeOpts(home, project, { agent: 'codex', profilePath: profile }));

  assert.deepEqual(
    await fs.readFile(path.join(home, '.agents', 'skills', 'example', 'icon.png')),
    image,
  );
});

test('refuses to replace a symlinked rules file', async (t) => {
  const { home, project } = await tempDirs(t);
  const target = path.join(home, '.codex', 'AGENTS.md');
  const real = path.join(project, 'real-agents.md');
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(real, '# original\n');
  try {
    await fs.symlink(real, target);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'EPERM') return t.skip('symlinks unavailable');
    throw error;
  }
  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'codex' })), /symlink/i);
  assert.equal(await fs.readFile(real, 'utf8'), '# original\n');
});

test('rejects a portable profile whose skill path is a symlink outside the profile', async (t) => {
  const { home, project } = await tempDirs(t);
  const profile = path.join(project, 'portable');
  const outside = path.join(project, 'outside');
  await fs.mkdir(path.join(profile, 'skills'), { recursive: true });
  await fs.mkdir(outside);
  await fs.writeFile(path.join(outside, 'SKILL.md'), '---\nname: example\ndescription: Example.\n---\n');
  await fs.writeFile(path.join(profile, 'profile.json'), JSON.stringify({
    name: 'portable', version: '1.0.0', agents: ['codex'],
    skills: [{ name: 'example', source: 'skills/example' }],
  }));
  try {
    await fs.symlink(outside, path.join(profile, 'skills', 'example'), 'junction');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'EPERM') return t.skip('symlinks unavailable');
    throw error;
  }
  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'codex', profilePath: profile })),
    /symlink/i,
  );
  assert.equal(await exists(path.join(home, '.agents', 'skills', 'example')), false);
});

test('rejects duplicate skills in a portable profile before staging files', async (t) => {
  const { home, project } = await tempDirs(t);
  const profile = path.join(project, 'portable');
  const skillDir = path.join(profile, 'skills', 'example');
  await fs.mkdir(skillDir, { recursive: true });
  await fs.writeFile(path.join(skillDir, 'SKILL.md'), '---\nname: example\ndescription: Example.\n---\n');
  await fs.writeFile(path.join(profile, 'profile.json'), JSON.stringify({
    name: 'portable', version: '1.0.0', agents: ['codex'],
    skills: [
      { name: 'example', source: 'skills/example' },
      { name: 'example', source: 'skills/example' },
    ],
  }));
  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'codex', profilePath: profile })),
    /duplicate skill/i,
  );
  assert.equal(await exists(path.join(home, '.agents', 'skills', 'example')), false);
});

test('second run skips unchanged items and writes nothing', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));
  const before = await snapshot(home);

  const { lines, log } = captureLogs();
  await runInstall(makeOpts(home, project, { agent: 'codex', log }));

  assert.deepEqual(await snapshot(home), before);
  assert.ok(lines.some((l) => l.includes('SKIP')));
  assert.ok(lines.some((l) => l.includes('up to date')));
});

test('preserves existing content outside markers and backs up the original', async (t) => {
  const { home, project } = await tempDirs(t);
  const target = path.join(home, '.codex', 'AGENTS.md');
  await fs.mkdir(path.dirname(target), { recursive: true });
  const original = '# My own rules\n\nAlways be terse.\n';
  await fs.writeFile(target, original);

  await runInstall(makeOpts(home, project, { agent: 'codex' }));

  const content = await fs.readFile(target, 'utf8');
  assert.ok(content.startsWith(original));
  assert.ok(content.includes(MARKER_START));
  assert.equal(await fs.readFile(target + BACKUP_SUFFIX, 'utf8'), original);
});

test('rewrites a stale managed block while keeping outside edits', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));
  const target = path.join(home, '.codex', 'AGENTS.md');

  const stale = (await fs.readFile(target, 'utf8')).replace(MARKER_END, `stale line\n${MARKER_END}`);
  await fs.writeFile(target, `${stale}\nUser appendix.\n`);

  const { lines, log } = captureLogs();
  await runInstall(makeOpts(home, project, { agent: 'codex', log }));

  const content = await fs.readFile(target, 'utf8');
  assert.ok(!content.includes('stale line'));
  assert.ok(content.includes('User appendix.'));
  assert.ok(lines.some((l) => l.includes('UPDATE')));
  assert.equal(await fs.readFile(target + BACKUP_SUFFIX, 'utf8'), `${stale}\nUser appendix.\n`);
});

test('claude-code project scope installs AGENTS.md plus an @AGENTS.md bridge in CLAUDE.md', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'claude-code', project: true }));

  const agentsMd = await fs.readFile(path.join(project, 'AGENTS.md'), 'utf8');
  assert.ok(agentsMd.includes(MARKER_START));
  assert.match(agentsMd, /red-green-refactor/);

  const claudeMd = await fs.readFile(path.join(project, 'CLAUDE.md'), 'utf8');
  assert.ok(claudeMd.includes(MARKER_START));
  assert.ok(claudeMd.split('\n').some((line) => line.trim() === '@AGENTS.md'));

  assert.ok(await exists(path.join(project, '.claude', 'skills', 'commit-message', 'SKILL.md')));
  const lock = await readLock(project);
  assert.deepEqual(
    Object.keys(lock.entries).sort(),
    ['claude-code:bridge', 'claude-code:rules', 'claude-code:skill:commit-message'],
  );
});

test('does not add a managed bridge when CLAUDE.md already imports AGENTS.md', async (t) => {
  const { home, project } = await tempDirs(t);
  const claudePath = path.join(project, 'CLAUDE.md');
  const original = '# Project notes\n\n@AGENTS.md\n';
  await fs.writeFile(claudePath, original);

  const { lines, log } = captureLogs();
  await runInstall(makeOpts(home, project, { agent: 'claude-code', project: true, log }));

  assert.equal(await fs.readFile(claudePath, 'utf8'), original);
  assert.ok(lines.some((l) => l.includes('already present')));
});

test('kimi-code project scope uses the shared .agents/skills directory', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'kimi-code', project: true }));
  assert.ok(await exists(path.join(project, '.agents', 'skills', 'commit-message', 'SKILL.md')));
  assert.ok(await exists(path.join(project, 'AGENTS.md')));
});

test('conflicting foreign skill content aborts the whole install without writes', async (t) => {
  const { home, project } = await tempDirs(t);
  const skillTarget = path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md');
  await fs.mkdir(path.dirname(skillTarget), { recursive: true });
  const foreign = '---\nname: commit-message\ndescription: hand-written\n---\nmine\n';
  await fs.writeFile(skillTarget, foreign);

  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'codex' })), /conflict/i);

  assert.equal(await fs.readFile(skillTarget, 'utf8'), foreign);
  assert.ok(!(await exists(path.join(home, '.codex', 'AGENTS.md'))));
  assert.ok(!(await exists(path.join(home, LOCKFILE_NAME))));
});

test('modifying an installed skill turns the next run into a conflict', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));
  const skillTarget = path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md');
  await fs.writeFile(skillTarget, 'user edits\n');

  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'codex' })), /conflict/i);
  assert.equal(await fs.readFile(skillTarget, 'utf8'), 'user edits\n');
});

async function foreignSkill(home: string): Promise<void> {
  const skillDir = path.join(home, '.agents', 'skills', 'commit-message');
  await fs.mkdir(skillDir, { recursive: true });
  await fs.writeFile(
    path.join(skillDir, 'SKILL.md'),
    '---\nname: commit-message\ndescription: written by someone else\n---\nforeign body\n',
  );
}

test('install --dry-run reports conflicts and returns instead of throwing', async (t) => {
  const { home, project } = await tempDirs(t);
  await foreignSkill(home);
  const { lines, log } = captureLogs();

  // A dry run is a question, not an attempt. Before this it exited non-zero, so CI that ran
  // --dry-run as a pre-flight check failed on the very condition the check exists to surface.
  await runInstall(makeOpts(home, project, { agent: 'codex', dryRun: true, yes: false, log }));

  const output = lines.join('\n');
  assert.match(output, /CONFLICT/);
  assert.match(output, /conflict\(s\) would block this install/);
  assert.match(output, /pass --strict to make them fail/);
  assert.equal(
    await exists(path.join(home, '.codex', 'AGENTS.md')),
    false,
    'a dry run still writes nothing',
  );
});

test('install --dry-run --strict throws on conflicts', async (t) => {
  const { home, project } = await tempDirs(t);
  await foreignSkill(home);
  const { lines, log } = captureLogs();

  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'codex', dryRun: true, strict: true, yes: false, log })),
    /conflict\(s\) found/,
  );
  assert.equal(await exists(path.join(home, '.codex', 'AGENTS.md')), false);
});


test('a skill update from the same profile overwrites a pristine install', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));

  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const skillSrc = path.join(profilesCopy, 'recommended', 'skills', 'commit-message', 'SKILL.md');
  await fs.writeFile(skillSrc, '---\nname: commit-message\ndescription: v2 improved\n---\nnew body\n');
  const manifestPath = path.join(profilesCopy, 'recommended', 'profile.json');
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8')) as { version: string };
  manifest.version = '1.1.0';
  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

  await runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy }));

  const installed = await fs.readFile(path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md'), 'utf8');
  assert.match(installed, /v2 improved/);
  const lock = await readLock(home);
  assert.equal(lock.entries['codex:skill:commit-message']?.profileVersion, '1.1.0');
});

test('a second update preserves the first backup instead of clobbering it', async (t) => {
  const { home, project } = await tempDirs(t);
  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const skillSrc = path.join(profilesCopy, 'recommended', 'skills', 'commit-message', 'SKILL.md');
  const skillTarget = path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md');
  const backup = skillTarget + BACKUP_SUFFIX;

  const installVersion = async (body: string) => {
    await fs.writeFile(skillSrc, `---\nname: commit-message\ndescription: ${body}\n---\n${body}\n`);
    await runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy }));
  };

  await installVersion('v1 body');
  assert.equal(await exists(backup), false, 'a first install creates nothing to back up');

  await installVersion('v2 body');
  assert.match(await fs.readFile(skillTarget, 'utf8'), /v2 body/);
  assert.match(await fs.readFile(backup, 'utf8'), /v1 body/, 'the first update backs up v1');

  await installVersion('v3 body');
  assert.match(await fs.readFile(skillTarget, 'utf8'), /v3 body/);
  // The backup exists so a user can get their pre-skillfit file back. Overwriting it on every update
  // means the second update destroys the only copy of the original.
  assert.match(
    await fs.readFile(backup, 'utf8'),
    /v1 body/,
    'the original must survive later updates',
  );
});

test('a staging failure applies nothing, not even the items staged before it', async (t) => {
  const { home, project } = await tempDirs(t);
  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const agentsMd = path.join(home, '.codex', 'AGENTS.md');
  const manifestPath = path.join(profilesCopy, 'recommended', 'profile.json');
  const lockPath = path.join(home, LOCKFILE_NAME);

  // Block the skill write after planning, so the failure lands inside the write phase —
  // after the rules item has already been staged.
  await fs.mkdir(path.join(home, '.agents', 'skills'), { recursive: true });

  // Bump the profile version so the rules block changes and the rules item is a real write.
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8')) as { version: string };
  manifest.version = '1.1.0';
  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

  await assert.rejects(
    runInstall(makeOpts(home, project, {
      agent: 'codex', profilesDir: profilesCopy, yes: false,
      confirm: async () => {
        await fs.writeFile(path.join(home, '.agents', 'skills', 'commit-message'), 'not a directory\n');
        return true;
      },
    })),
    'the failure must surface, not be swallowed',
  );

  assert.equal(await exists(agentsMd), false, 'the rules file must not be written when a later item fails');
  assert.equal(await exists(lockPath), false, 'the lockfile must not record an install that did not happen');
});

test('a rename failure after the first file does not leave a partial install', async (t) => {
  const { home, project } = await tempDirs(t);
  const rulesTarget = path.join(home, '.codex', 'AGENTS.md');
  const skillTarget = path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md');
  const realRename = fs.rename.bind(fs);
  t.mock.method(fs, 'rename', async (source: string, target: string) => {
    if (target === skillTarget && source.includes('.skillfit-staged')) {
      throw Object.assign(new Error('injected rename failure'), { code: 'EACCES' });
    }
    return realRename(source, target);
  });

  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'codex' })), /injected rename failure/);

  assert.equal(await exists(rulesTarget), false, 'the earlier rules write must be rolled back');
  assert.equal(await exists(skillTarget), false);
  assert.equal(await exists(path.join(home, LOCKFILE_NAME)), false);
});

test('a lockfile rename failure restores updated content and the old lockfile', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));
  const rulesTarget = path.join(home, '.codex', 'AGENTS.md');
  const skillTarget = path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md');
  const lockTarget = path.join(home, LOCKFILE_NAME);
  const originalRules = await fs.readFile(rulesTarget, 'utf8');
  const originalSkill = await fs.readFile(skillTarget, 'utf8');
  const originalLock = await fs.readFile(lockTarget, 'utf8');

  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const skillSrc = path.join(profilesCopy, 'recommended', 'skills', 'commit-message', 'SKILL.md');
  await fs.writeFile(skillSrc, '---\nname: commit-message\ndescription: v2\n---\nv2 body\n');
  const manifestPath = path.join(profilesCopy, 'recommended', 'profile.json');
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8')) as { version: string };
  manifest.version = '1.1.0';
  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

  const realRename = fs.rename.bind(fs);
  t.mock.method(fs, 'rename', async (source: string, target: string) => {
    if (target === lockTarget && source.includes('.skillfit-staged')) {
      throw Object.assign(new Error('injected lockfile rename failure'), { code: 'EACCES' });
    }
    return realRename(source, target);
  });
  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy })),
    /injected lockfile rename failure/,
  );

  assert.equal(await fs.readFile(rulesTarget, 'utf8'), originalRules);
  assert.equal(await fs.readFile(skillTarget, 'utf8'), originalSkill);
  assert.equal(await fs.readFile(lockTarget, 'utf8'), originalLock);
  assert.equal(await fs.readFile(lockTarget + BACKUP_SUFFIX, 'utf8'), originalLock);
  const files = Object.keys(await snapshot(home));
  assert.ok(!files.some((name) => name.includes('.skillfit-staged') || name.includes('.skillfit-restore')));
});

test('an unreadable existing skill path stops planning before any write', async (t) => {
  const { home, project } = await tempDirs(t);
  const skillFile = path.join(home, '.agents', 'skills', 'commit-message', 'SKILL.md');
  await fs.mkdir(skillFile, { recursive: true });
  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'codex' })),
    (error: unknown) => ['EISDIR', 'EPERM', 'EACCES'].includes((error as NodeJS.ErrnoException).code ?? ''),
  );
  assert.equal(await exists(path.join(home, '.codex', 'AGENTS.md')), false);
});

test('removed profile files cause a conflict rather than leaving an obsolete skill asset silently', async (t) => {
  const { home, project } = await tempDirs(t);
  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const skillDir = path.join(profilesCopy, 'recommended', 'skills', 'commit-message');
  const oldSource = path.join(skillDir, 'scripts', 'old.mjs');
  await fs.mkdir(path.dirname(oldSource), { recursive: true });
  await fs.writeFile(oldSource, 'export const old = true;\n');
  await runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy }));

  await fs.rm(oldSource);
  const { lines, log } = captureLogs();
  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy, dryRun: true, strict: true, log })),
    /conflict/,
  );
  assert.match(lines.join('\n'), /existing files absent from profile: scripts\/old\.mjs/);
  assert.equal(await fs.readFile(path.join(home, '.agents', 'skills', 'commit-message', 'scripts', 'old.mjs'), 'utf8'), 'export const old = true;\n');
});

test('a stale lockfile entry reconciles on the next successful run', async (t) => {
  const { home, project } = await tempDirs(t);
  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const skillSrc = path.join(profilesCopy, 'recommended', 'skills', 'commit-message', 'SKILL.md');
  const lockPath = path.join(home, LOCKFILE_NAME);

  await runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy }));

  // Simulate what an older partial run left behind: the rules file on disk is current, but the
  // lockfile entry describing it is stale. Nothing rewrites a skipped item, so without a reconcile
  // step this record stays wrong forever.
  const stale = JSON.parse(await fs.readFile(lockPath, 'utf8')) as {
    entries: Record<string, { profileVersion: string; sha256: string }>;
  };
  const rulesEntry = stale.entries['codex:rules'];
  assert.ok(rulesEntry);
  rulesEntry.profileVersion = '0.0.1';
  rulesEntry.sha256 = 'deadbeef';
  await fs.writeFile(lockPath, JSON.stringify(stale, null, 2));

  // The skill changes, so this run has something to write and reaches the recording step.
  await fs.writeFile(skillSrc, '---\nname: commit-message\ndescription: v2\n---\nv2 body\n');
  const manifestPath = path.join(profilesCopy, 'recommended', 'profile.json');
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8')) as { version: string };
  manifest.version = '1.1.0';
  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

  await runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy }));

  const lock = await readLock(home);
  assert.equal(lock.entries['codex:rules']?.profileVersion, '1.1.0', 'the skipped item is reconciled');
  assert.match(lock.entries['codex:rules']?.sha256 ?? '', /^[0-9a-f]{64}$/, 'and its hash is restored');
  assert.equal(lock.entries['codex:skill:commit-message']?.profileVersion, '1.1.0');
});

test('the lockfile is backed up before it is rewritten', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));
  const lockPath = path.join(home, LOCKFILE_NAME);
  const before = await fs.readFile(lockPath, 'utf8');

  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const manifestPath = path.join(profilesCopy, 'recommended', 'profile.json');
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8')) as { version: string };
  manifest.version = '1.1.0';
  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));
  await runInstall(makeOpts(home, project, { agent: 'codex', profilesDir: profilesCopy }));

  assert.equal(await fs.readFile(lockPath + BACKUP_SUFFIX, 'utf8'), before, 'the previous lockfile survives');
  assert.match(await fs.readFile(lockPath, 'utf8'), /1\.1\.0/);
});

test('install fails fast when stdin closes without an answer', async (t) => {
  const { project } = await tempDirs(t);
  // Runs the real readline path in a child process: the defect is stdin closing without ever
  // delivering a line, which an injected `confirm` stub cannot reproduce. --project keeps every
  // write inside the temp directory.
  const result = spawnSync(
    process.execPath,
    [CLI_PATH, 'install', '--project', '--agent', 'codex'],
    { cwd: project, encoding: 'utf8', input: '', timeout: 30_000 },
  );
  assert.equal(result.signal, null, 'must not hang until the timeout');
  assert.notEqual(result.status, 0, 'closed non-TTY stdin must fail, not exit 0 having written nothing');
  assert.match(result.stderr, /--yes/);
  assert.equal(await exists(path.join(project, LOCKFILE_NAME)), false, 'nothing was written');
});

test('dry-run prints the plan and writes nothing', async (t) => {
  const { home, project } = await tempDirs(t);
  const { lines, log } = captureLogs();
  await runInstall(makeOpts(home, project, { agent: 'codex', dryRun: true, yes: false, log }));

  assert.ok(lines.some((l) => l.includes('CREATE')));
  assert.ok(lines.some((l) => /dry run/i.test(l)));
  assert.deepEqual(await fs.readdir(home), []);
});

test('interactive install asks for confirmation and honors a no', async (t) => {
  const { home, project } = await tempDirs(t);
  let asked = 0;
  const confirm = async (): Promise<boolean> => { asked += 1; return false; };
  await runInstall(makeOpts(home, project, { agent: 'codex', yes: false, confirm }));

  assert.equal(asked, 1);
  assert.deepEqual(await fs.readdir(home), []);
});

test('interactive install proceeds on yes', async (t) => {
  const { home, project } = await tempDirs(t);
  const confirm = async (): Promise<boolean> => true;
  await runInstall(makeOpts(home, project, { agent: 'codex', yes: false, confirm }));
  assert.ok(await exists(path.join(home, '.codex', 'AGENTS.md')));
});

test('rejects unknown agents, bad profile names and missing profiles', async (t) => {
  const { home, project } = await tempDirs(t);
  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'nope' })), /Unknown agent/);
  await assert.rejects(runInstall(makeOpts(home, project, { profile: '../evil' })), /Invalid profile name/);
  await assert.rejects(runInstall(makeOpts(home, project, { profile: 'missing' })), /not found/);
});

test('rejects an agent the profile does not target', async (t) => {
  const { home, project } = await tempDirs(t);
  const profilesCopy = path.join(project, 'profiles-copy');
  await fs.cp(PROFILES_DIR, profilesCopy, { recursive: true });
  const manifestPath = path.join(profilesCopy, 'recommended', 'profile.json');
  const manifest = JSON.parse(await fs.readFile(manifestPath, 'utf8')) as { agents: string[] };
  manifest.agents = ['codex'];
  await fs.writeFile(manifestPath, JSON.stringify(manifest, null, 2));

  await assert.rejects(
    runInstall(makeOpts(home, project, { agent: 'kimi-code', profilesDir: profilesCopy })),
    /does not target/,
  );
});

test('without --agent installs only for detected agents', async (t) => {
  const { home, project } = await tempDirs(t);
  await fs.mkdir(path.join(home, '.codex'), { recursive: true });
  await fs.mkdir(path.join(home, '.claude'), { recursive: true });

  await runInstall(makeOpts(home, project));

  assert.ok(await exists(path.join(home, '.codex', 'AGENTS.md')));
  assert.ok(await exists(path.join(home, '.claude', 'AGENTS.md')));
  assert.ok(await exists(path.join(home, '.claude', 'CLAUDE.md')));
  assert.ok(!(await exists(path.join(home, '.kimi-code'))));
});

test('without --agent and nothing detected, fails with guidance', async (t) => {
  const { home, project } = await tempDirs(t);
  await assert.rejects(runInstall(makeOpts(home, project)), /No target agents detected/);
});

test('refuses to touch a file with malformed markers', async (t) => {
  const { home, project } = await tempDirs(t);
  const target = path.join(home, '.codex', 'AGENTS.md');
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(target, `broken ${MARKER_START} only\n`);

  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'codex' })), /malformed/i);
  assert.equal(await fs.readFile(target, 'utf8'), `broken ${MARKER_START} only\n`);
});

test('a corrupt lockfile fails loudly', async (t) => {
  const { home, project } = await tempDirs(t);
  await runInstall(makeOpts(home, project, { agent: 'codex' }));
  await fs.writeFile(path.join(home, LOCKFILE_NAME), '{oops');

  await assert.rejects(runInstall(makeOpts(home, project, { agent: 'codex' })), /not valid JSON/);
});

test('the bundled recommended profile passes validation', async () => {
  const { manifest } = await loadProfile(PROFILES_DIR, 'recommended');
  assert.equal(manifest.name, 'recommended');
  assert.deepEqual([...manifest.agents].sort(), ['claude-code', 'codex', 'kimi-code']);
});

// parseFrontmatter's own tests live in src/frontmatter.test.ts, next to the single implementation
// doctor and install now share.

test('upsertManagedBlock creates, appends and replaces', () => {
  const block = renderManagedBlock('body', 'p', '1.0.0');
  assert.equal(upsertManagedBlock(null, block), `${block}\n`);
  assert.equal(upsertManagedBlock('   \n', block), `${block}\n`);

  const appended = upsertManagedBlock('user text\n', block);
  assert.ok(appended.startsWith('user text\n'));
  assert.ok(appended.includes(block));

  const replaced = upsertManagedBlock(`pre ${MARKER_START}\nold\n${MARKER_END} post`, block);
  assert.equal(replaced, `pre ${block} post`);

  assert.throws(() => upsertManagedBlock(`x ${MARKER_START} y`, block), /malformed/i);
});

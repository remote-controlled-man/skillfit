import assert from 'node:assert/strict';

export function assertCompleteReceipt(record, trace) {
  assert.equal(record.executorInvoked, true, 'Previous executor was not invoked');
  assert.equal(record.error, null, 'Previous executor or verifier failed');
  assert.equal(record.usageStatus, 'final', 'Previous usage is not final');
  for (const key of ['input', 'cachedInput', 'output']) {
    assert.ok(Number.isFinite(record.tokens?.[key]) && record.tokens[key] >= 0, `Missing final ${key}`);
  }
  assert.ok(record.tokens.cachedInput <= record.tokens.input);
  assert.ok(Number.isFinite(record.durationSeconds) && record.durationSeconds >= 0);
  const timing = record.timing?.execution;
  assert.equal(timing?.timeoutMs, 1_200_000);
  assert.equal(timing?.anomaly, null, 'Previous timing anomaly');
  const events = trace.trim().split('\n').map(line => JSON.parse(line));
  assert.ok(events.some(event => event.type === 'thread.started' && typeof event.thread_id === 'string'), 'Missing routed thread identity');
  assert.ok(!events.some(event => ['error', 'turn.failed'].includes(event.type)), 'CLI routing or turn failure');
  const turns = events.filter(event => event.type === 'turn.completed');
  assert.ok(turns.length > 0, 'Missing final turn');
  for (const [key, wire] of [['input', 'input_tokens'], ['cachedInput', 'cached_input_tokens'], ['output', 'output_tokens']]) {
    assert.ok(turns.every(turn => Number.isFinite(turn.usage?.[wire]) && turn.usage[wire] >= 0), `Missing turn ${wire}`);
    assert.equal(turns.reduce((sum, turn) => sum + turn.usage[wire], 0), record.tokens[key]);
  }
}

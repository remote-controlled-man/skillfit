import assert from 'node:assert/strict';
import test from 'node:test';
import { assertCompleteReceipt } from './receipt-guard.mjs';
const receipt = { executorInvoked: true, error: null, usageStatus: 'final', tokens: { input: 10, cachedInput: 5, output: 2 }, durationSeconds: 1, timing: { execution: { timeoutMs: 1200000, anomaly: null } }, passed: false };
const trace = [ { type: 'thread.started', thread_id: 'offline' }, { type: 'turn.completed', usage: { input_tokens: 10, cached_input_tokens: 5, output_tokens: 2 } } ].map(JSON.stringify).join('\n');
test('complete usage permits an ordinary functional failure without erasing it', () => assertCompleteReceipt(receipt, trace));
test('missing usage, routing errors and timing anomalies stop before another call', () => {
  assert.throws(() => assertCompleteReceipt({ ...receipt, tokens: { input: 10, output: 2 } }, trace));
  assert.throws(() => assertCompleteReceipt({ ...receipt, usageStatus: 'partial' }, trace));
  assert.throws(() => assertCompleteReceipt({ ...receipt, error: 'routing failed' }, trace));
  assert.throws(() => assertCompleteReceipt({ ...receipt, timing: { execution: { timeoutMs: 1200000, anomaly: 'gap' } } }, trace));
  assert.throws(() => assertCompleteReceipt(receipt, trace + '\n' + JSON.stringify({ type: 'error' })));
  assert.throws(() => assertCompleteReceipt(receipt, trace.replace('"input_tokens":10', '"input_tokens":11')));
});

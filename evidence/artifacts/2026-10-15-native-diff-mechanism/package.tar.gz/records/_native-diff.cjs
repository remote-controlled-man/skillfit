'use strict';
const { spawnSync } = require('node:child_process');
const { resolve, relative, isAbsolute, sep } = require('node:path');
const { existsSync, realpathSync } = require('node:fs');
if (process.argv.length !== 3 || !process.argv[2]) {
  console.error('Usage: node _skillfit/native-diff.cjs <untracked-file>');
  process.exit(2);
}
const file = resolve(process.argv[2]);
const inside = value => { const p = relative(realpathSync(process.cwd()), value); return !isAbsolute(p) && p !== '..' && !p.startsWith('..' + sep); };
if (!inside(existsSync(file) ? realpathSync(file) : file)) {
  console.error('Untracked diff file must stay inside the task workspace.');
  process.exit(2);
}
const child = spawnSync('git', ['diff', '--no-ext-diff', '--no-index', '--', '/dev/null', process.argv[2]], { stdio: 'inherit', shell: false });
if (child.error) { console.error(child.error.message); process.exit(127); }
if (child.signal) process.kill(process.pid, child.signal);
else process.exit(child.status === null ? 1 : child.status);

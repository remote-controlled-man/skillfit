#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];

const notationCases = [
  [1e21, '1e+21', '①e+②①'],
  [1.25e21, '1.25e+21', '①.②⑤e+②①'],
  [1e-7, '1e-7', '①e-⑦'],
  [1.25e-7, '1.25e-7', '①.②⑤e-⑦'],
  [Number.MAX_VALUE, '1.7976931348623157e+308', '①.⑦⑨⑦⑥⑨③①③④⑧⑥②③①⑤⑦e+③⓪⑧'],
  [Number.MIN_VALUE, '5e-324', '⑤e-③②④'],
  [1e20, '100000000000000000000', '①⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪⓪'],
  [1e-6, '0.000001', '⓪.⓪⓪⓪⓪⓪①'],
];

test('digit replacements preserve scientific and fixed notation', () => {
  for (const [ms, , replaced] of notationCases) {
    assert.equal(
      humanizeDuration(ms, { units: ['ms'], digitReplacements }),
      `${replaced} milliseconds`,
      `duration ${ms}`,
    );
  }
});

test('calls without digit replacements retain their existing notation', () => {
  for (const [ms, plain] of notationCases) {
    assert.equal(humanizeDuration(ms, { units: ['ms'] }), `${plain} milliseconds`);
  }
});

test('localized unit words and decimal separators are preserved', () => {
  for (const [ms, exponent, word] of [
    [1.25e21, '+②①', 'millisecondes'],
    [1.25e-7, '-⑦', 'milliseconde'],
  ]) {
    assert.equal(
      humanizeDuration(ms, { units: ['ms'], language: 'fr', digitReplacements }),
      `①,②⑤e${exponent} ${word}`,
    );
    assert.equal(
      humanizeDuration(ms, {
        units: ['ms'],
        language: 'fr',
        digitReplacements,
        decimal: ' point 0e+- ',
      }),
      `① point 0e+- ②⑤e${exponent} ${word}`,
    );
  }
});

test('Arabic default digit replacements preserve exponent signs and localization', () => {
  const options = { units: ['ms'], language: 'ar' };
  assert.equal(humanizeDuration(1.25e21, options), '١,٢٥e+٢١ جزء من الثانية');
  assert.equal(humanizeDuration(1.25e-7, options), '١,٢٥e-٧ جزء من الثانية');
  assert.equal(
    humanizeDuration(1.25e21, { ...options, digitReplacements: undefined }),
    '1,25e+21 جزء من الثانية',
  );
  assert.equal(humanizeDuration(2500, { language: 'ar', units: ['s'] }), '٢,٥ ثواني');
  assert.equal(humanizeDuration(2000, { language: 'ar', units: ['s'] }), 'ثانيتان');
});

test('ordinary digit replacements retain all digits, decimals and unit forms', () => {
  assert.equal(
    humanizeDuration(1234567890.5, { units: ['ms'], digitReplacements }),
    '①②③④⑤⑥⑦⑧⑨⓪.⑤ milliseconds',
  );
  assert.equal(humanizeDuration(0, { digitReplacements }), '⓪ seconds');
  assert.equal(humanizeDuration(1000, { digitReplacements }), '① second');
  assert.equal(
    humanizeDuration(1234.5678, { units: ['s'], maxDecimalPoints: 2, digitReplacements }),
    '①.②③ seconds',
  );
  assert.equal(
    humanizeDuration(1234, {
      units: ['s'],
      digitReplacements: ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'],
    }),
    'One.TwoThreeFour seconds',
  );
});

test('humanizer defaults and per-call overrides support scientific notation', () => {
  const humanizer = humanizeDuration.humanizer({ units: ['s'], digitReplacements });
  assert.equal(humanizer(1.25e24), '①.②⑤e+②① seconds');
  assert.equal(humanizer(1.25e-4), '①.②⑤e-⑦ seconds');
  assert.equal(humanizer(1.25e24, { digitReplacements: undefined }), '1.25e+21 seconds');
  assert.equal(humanizer(1234), '①.②③④ seconds');
});

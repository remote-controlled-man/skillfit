#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];

test('digit replacements preserve scientific notation and fixed notation boundaries', () => {
  const cases = [
    [1e21, '①e+②①'],
    [1.25e22, '①.②⑤e+②②'],
    [1e-7, '①e-⑦'],
    [1.25e-8, '①.②⑤e-⑧'],
    [1e20, '①' + '⓪'.repeat(20)],
    [1e-6, '⓪.⓪⓪⓪⓪⓪①'],
  ];

  for (const [duration, count] of cases) {
    assert.equal(
      humanizeDuration(duration, {units: ['ms'], digitReplacements}),
      `${count} milliseconds`,
      `duration: ${duration}`,
    );
  }
});

test('scientific notation keeps localized unit words and decimal separators', () => {
  const options = {units: ['ms'], language: 'fr', digitReplacements};
  assert.equal(humanizeDuration(1.25e22, options), '①,②⑤e+②② millisecondes');
  assert.equal(humanizeDuration(1.25e-8, options), '①,②⑤e-⑧ milliseconde');
  assert.equal(
    humanizeDuration(1.25e-8, {...options, decimal: ' point 2e+3 '}),
    '① point 2e+3 ②⑤e-⑧ milliseconde',
  );
});

test('language-default digits and explicit overrides preserve exponent signs', () => {
  const options = {units: ['s'], language: 'ar'};
  assert.equal(humanizeDuration(1e24, options), '١e+٢١ ثانية');
  assert.equal(humanizeDuration(1e-5, options), '١e-٨ ثانية');
  assert.equal(
    humanizeDuration(1e24, {...options, digitReplacements}),
    '①e+②① ثانية',
  );
  assert.equal(
    humanizeDuration(1e24, {...options, digitReplacements: undefined}),
    '1e+21 ثانية',
  );
  assert.equal(humanizeDuration(1234, options), '١,٢٣٤ ثانية');
  assert.equal(humanizeDuration(2000, options), 'ثانيتان');
});

test('ordinary replacements still support all digits and multi-character strings', () => {
  const words = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const options = {digitReplacements: words};
  assert.equal(humanizeDuration(0, options), 'Zero seconds');
  assert.equal(humanizeDuration(1000, options), 'One second');
  assert.equal(humanizeDuration(1234, options), 'One.TwoThreeFour seconds');
  assert.equal(
    humanizeDuration(1023456789, {...options, units: ['ms']}),
    'OneZeroTwoThreeFourFiveSixSevenEightNine milliseconds',
  );
});

test('humanizer defaults and per-call overrides retain replacement behavior', () => {
  const humanizer = humanizeDuration.humanizer({units: ['s'], digitReplacements});
  assert.equal(humanizer(1e24), '①e+②① seconds');
  assert.equal(humanizer(1e-5), '①e-⑧ seconds');
  assert.equal(humanizer(1234), '①.②③④ seconds');
  assert.equal(humanizer(1e24, {digitReplacements: undefined}), '1e+21 seconds');
  assert.equal(humanizer(1000), '① second');
});

test('calls without digit replacements keep existing notation and localization', () => {
  const cases = [
    [1e21, '1e+21'],
    [1.25e22, '1.25e+22'],
    [1e-7, '1e-7'],
    [1.25e-8, '1.25e-8'],
    [1e20, '100000000000000000000'],
    [1e-6, '0.000001'],
  ];

  for (const [duration, count] of cases) {
    assert.equal(humanizeDuration(duration, {units: ['ms']}), `${count} milliseconds`);
  }
  assert.equal(
    humanizeDuration(1.25e22, {units: ['ms'], language: 'fr'}),
    '1,25e+22 millisecondes',
  );
  assert.equal(humanizeDuration(1234), '1.234 seconds');
});

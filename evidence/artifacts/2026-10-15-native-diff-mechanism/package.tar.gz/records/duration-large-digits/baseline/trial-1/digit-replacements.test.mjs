#!/usr/bin/env node

import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['⓪', '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];

test('digit replacements preserve scientific notation for large and tiny durations', () => {
  const cases = [
    [1e21, '①e+②① milliseconds'],
    [1.25e21, '①.②⑤e+②① milliseconds'],
    [1e-7, '①e-⑦ milliseconds'],
    [1.25e-7, '①.②⑤e-⑦ milliseconds'],
    [Number.MIN_VALUE, '⑤e-③②④ milliseconds']
  ];

  for (const [duration, expected] of cases) {
    assert.equal(humanizeDuration(duration, {
      units: ['ms'],
      digitReplacements
    }), expected, String(duration));
  }
});

test('language-provided digit replacements preserve exponents and localized text', () => {
  const cases = [
    [1e21, '١e+٢١ جزء من الثانية'],
    [1.25e21, '١,٢٥e+٢١ جزء من الثانية'],
    [1e-7, '١e-٧ جزء من الثانية'],
    [1.25e-7, '١,٢٥e-٧ جزء من الثانية'],
    [2, 'جزآن من الثانية']
  ];

  for (const [duration, expected] of cases) {
    assert.equal(humanizeDuration(duration, {
      units: ['ms'],
      language: 'ar'
    }), expected, String(duration));
  }
});

test('explicit replacements keep localized unit words and decimal separators', () => {
  const options = {units: ['ms'], language: 'fr', digitReplacements};

  assert.equal(humanizeDuration(1.25e21, options), '①,②⑤e+②① millisecondes');
  assert.equal(humanizeDuration(1.25e-7, options), '①,②⑤e-⑦ milliseconde');
  assert.equal(humanizeDuration(1.25e-7, {
    ...options,
    decimal: '·'
  }), '①·②⑤e-⑦ milliseconde');
  assert.equal(humanizeDuration(1.25e-7, {
    ...options,
    language: 'ar'
  }), '①,②⑤e-⑦ جزء من الثانية');
});

test('configured humanizers replace only count digits', () => {
  const humanizer = humanizeDuration.humanizer({
    units: ['ms'],
    language: 'custom',
    languages: {custom: {ms: 'tick2e+3', decimal: '·9'}},
    spacer: '|0|',
    digitReplacements
  });

  assert.equal(humanizer(1.25e21), '①·9②⑤e+②①|0|tick2e+3');
  assert.equal(humanizer(1.25e-7, {decimal: ':'}), '①:②⑤e-⑦|0|tick2e+3');
});

test('ordinary digit replacements still handle zero, fractions and multiple units', () => {
  const options = {units: ['ms'], digitReplacements};

  assert.equal(humanizeDuration(0, options), '⓪ milliseconds');
  assert.equal(humanizeDuration(1, options), '① millisecond');
  assert.equal(humanizeDuration(1234567890.25, options), '①②③④⑤⑥⑦⑧⑨⓪.②⑤ milliseconds');
  assert.equal(humanizeDuration(1234.567, {
    ...options,
    maxDecimalPoints: 2
  }), '①②③④.⑤⑥ milliseconds');
  assert.equal(humanizeDuration(3723500, {digitReplacements}), '① hour, ② minutes, ③.⑤ seconds');
  assert.equal(humanizeDuration(12.5, {
    units: ['ms'],
    digitReplacements: ['<0>', '<1>', '<2>', '<3>', '<4>', '<5>', '<6>', '<7>', '<8>', '<9>']
  }), '<1><2>.<5> milliseconds');
});

test('calls without replacements keep their existing notation and localization', () => {
  const cases = [
    [1e21, '1e+21 milliseconds'],
    [1.25e21, '1.25e+21 milliseconds'],
    [1e-7, '1e-7 milliseconds'],
    [1.25e-7, '1.25e-7 milliseconds'],
    [Number.MIN_VALUE, '5e-324 milliseconds'],
    [1e20, '100000000000000000000 milliseconds'],
    [0.000001, '0.000001 milliseconds']
  ];

  for (const [duration, expected] of cases) {
    assert.equal(humanizeDuration(duration, {units: ['ms']}), expected, String(duration));
  }
  assert.equal(humanizeDuration(1.25e21, {
    units: ['ms'],
    language: 'fr'
  }), '1,25e+21 millisecondes');
  assert.equal(humanizeDuration(1.25e-7, {
    units: ['ms'],
    language: 'ar',
    digitReplacements: undefined
  }), '1,25e-7 جزء من الثانية');
});

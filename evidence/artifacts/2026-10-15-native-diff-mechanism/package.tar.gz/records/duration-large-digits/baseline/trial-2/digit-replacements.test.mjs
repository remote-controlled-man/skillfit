#!/usr/bin/env node
import test from 'node:test';
import assert from 'node:assert/strict';
import humanizeDuration from './index.js';

const digitReplacements = ['０', '１', '２', '３', '４', '５', '６', '７', '８', '９'];
const scientificCases = [
  [1e21, '1e+21', '１e+２１'],
  [1.25e21, '1.25e+21', '１.２５e+２１'],
  [1e-7, '1e-7', '１e-７'],
  [1.25e-7, '1.25e-7', '１.２５e-７'],
  [Number.MAX_VALUE, '1.7976931348623157e+308', '１.７９７６９３１３４８６２３１５７e+３０８'],
  [Number.MIN_VALUE, '5e-324', '５e-３２４'],
];

test('replaces scientific-notation digits while preserving exponent letters and signs', () => {
  for (const [value, , replaced] of scientificCases) {
    assert.equal(
      humanizeDuration(value, {units: ['ms'], digitReplacements}),
      `${replaced} milliseconds`,
      String(value),
    );
  }
});

test('preserves scientific notation without digit replacements', () => {
  for (const [value, plain] of scientificCases) {
    assert.equal(humanizeDuration(value, {units: ['ms']}), `${plain} milliseconds`);
  }
});

test('preserves localized decimal separators and unit words', () => {
  for (const [value, expected] of [
    [1.25e21, '１,２５e+２１ millisecondes'],
    [1.25e-7, '１,２５e-７ milliseconde'],
  ]) {
    assert.equal(
      humanizeDuration(value, {units: ['ms'], language: 'fr', digitReplacements}),
      expected,
    );
  }
  assert.equal(
    humanizeDuration(1.25e21, {units: ['ms'], language: 'ar'}),
    '١,٢٥e+٢١ جزء من الثانية',
  );
  assert.equal(
    humanizeDuration(1.25e-7, {units: ['ms'], language: 'ar'}),
    '١,٢٥e-٧ جزء من الثانية',
  );
});

test('does not replace digits inside custom separators or unit words', () => {
  assert.equal(
    humanizeDuration(1.25e21, {
      units: ['ms'],
      digitReplacements,
      decimal: '[0e+-]',
      spacer: ' / ',
      language: 'custom',
      languages: {custom: {ms: 'unit2e+3'}},
    }),
    '１[0e+-]２５e+２１ / unit2e+3',
  );
});

test('keeps ordinary replacements and fixed notation intact', () => {
  for (const [value, expected] of [
    [0, '０ milliseconds'],
    [1, '１ millisecond'],
    [1234567890.5, '１２３４５６７８９０.５ milliseconds'],
    [1e20, '１００００００００００００００００００００ milliseconds'],
    [1e-6, '０.０００００１ milliseconds'],
  ]) {
    assert.equal(humanizeDuration(value, {units: ['ms'], digitReplacements}), expected);
  }
});

test('supports multi-character digit replacements without rescanning them', () => {
  assert.equal(
    humanizeDuration(1.25e21, {
      units: ['ms'],
      digitReplacements: Array.from({length: 10}, (_, digit) => `[${digit}]`),
    }),
    '[1].[2][5]e+[2][1] milliseconds',
  );
});

test('supports humanizer defaults and per-call replacement overrides', () => {
  const humanizer = humanizeDuration.humanizer({units: ['ms'], digitReplacements});
  assert.equal(humanizer(1e21), '１e+２１ milliseconds');
  assert.equal(humanizer(1e-7), '１e-７ milliseconds');
  assert.equal(humanizer(1e21, {digitReplacements: null}), '1e+21 milliseconds');
  assert.equal(humanizer(1500), '１５００ milliseconds');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('query shape compatibility: assigned parameters still sort by key', () => {
	const url = 'https://example.com/search?z=last&b=second&a=first&b=third';
	const expected = 'https://example.com/search?a=first&b=second&b=third&z=last';

	assert.equal(normalizeUrl(url), expected);
	assert.equal(normalizeUrl(url, {sortQueryParameters: true}), expected);
});

test('query shape compatibility: bare and assigned parameters sort together', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=9&/catalog/item&b=&a=1&debug'),
		'https://example.com/index.php?/catalog/item&a=1&b=&debug&z=9',
	);
});

test('query shape compatibility: similar names keep their own assignment markers', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?route_long=&route&route_short=value&/catalog/item=&/catalog'),
		'https://example.com/index.php?/catalog&/catalog/item=&route&route_long=&route_short=value',
	);
});

test('query shape compatibility: a bare parameter differs from an explicit empty value', () => {
	assert.equal(normalizeUrl('https://example.com/search?empty'), 'https://example.com/search?empty');
	assert.equal(normalizeUrl('https://example.com/search?empty='), 'https://example.com/search?empty=');
	assert.equal(
		normalizeUrl('https://example.com/index.php?/catalog/item='),
		'https://example.com/index.php?/catalog/item=',
	);
});

test('query shape compatibility: sorting opt-out preserves mixed query order and shape', () => {
	const url = 'https://example.com/index.php?z=last&/catalog/item&b=&a=first&flag#section';

	assert.equal(normalizeUrl(url, {sortQueryParameters: false}), url);
});

test('query shape compatibility: ordinary URL normalization still applies', () => {
	assert.equal(
		normalizeUrl(' HTTPS://user:password@www.Example.com:443/a//b/../index.php/?z=2&a=1&utm_source=campaign '),
		'https://example.com/a/index.php?a=1&z=2',
	);
});

test('query shape compatibility: fragments survive query sorting', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=2&/catalog/item&a=#details'),
		'https://example.com/index.php?/catalog/item&a=&z=2#details',
	);
});

test('query shape compatibility: fragment options still apply to bare queries', () => {
	const url = 'https://example.com/index.php?/catalog/item#details:~:text=selected%20item';

	assert.equal(normalizeUrl(url), 'https://example.com/index.php?/catalog/item#details');
	assert.equal(normalizeUrl(url, {stripTextFragment: false}), url);
	assert.equal(normalizeUrl(url, {stripHash: true}), 'https://example.com/index.php?/catalog/item');
});

test('query shape compatibility: encoded path backslashes remain encoded', () => {
	assert.equal(
		normalizeUrl('https://example.com/some%5Bthing%5Celse/that-is%40great@coding?z=2&a=1'),
		'https://example.com/some[thing%5Celse/that-is%40great@coding?a=1&z=2',
	);
});

test('query shape compatibility: Unicode values survive sorting alongside bare parameters', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=東京&/catalog/item&a=café&empty='),
		'https://example.com/index.php?/catalog/item&a=caf%C3%A9&empty=&z=%E6%9D%B1%E4%BA%AC',
	);
	assert.equal(
		normalizeUrl('https://example.com/search?z=%E6%9D%B1%E4%BA%AC&a=caf%C3%A9'),
		'https://example.com/search?a=caf%C3%A9&z=%E6%9D%B1%E4%BA%AC',
	);
});

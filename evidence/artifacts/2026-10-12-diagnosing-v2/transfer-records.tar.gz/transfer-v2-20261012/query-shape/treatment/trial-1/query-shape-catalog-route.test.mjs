import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('catalog route regression: default sorting preserves a bare path query', () => {
	const url = 'https://example.com/index.php?/catalog/item';

	assert.equal(normalizeUrl(url), url);
});

test('inventory route regression: sorting agrees with the opt-out for a bare path query', () => {
	const url = 'https://shop.example.net/router.php?/inventory/sku-73/details';

	assert.equal(normalizeUrl(url, {sortQueryParameters: false}), url);
	assert.equal(normalizeUrl(url), url);
	assert.equal(normalizeUrl(url, {sortQueryParameters: true}), url);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('path-query-shape-7d3a: default sorting preserves a bare path query', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?/catalog/item'),
		'https://example.com/index.php?/catalog/item',
	);
});

test('path-query-shape-7d3a: sorting opt-out preserves the reported query', () => {
	const input = 'https://example.com/index.php?/catalog/item';
	assert.equal(normalizeUrl(input, {sortQueryParameters: false}), input);
});

test('path-query-shape-7d3a: bare path parameters still sort among assigned parameters', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=last&/catalog/item&a=first'),
		'https://example.com/index.php?/catalog/item&a=first&z=last',
	);
});

test('path-query-shape-7d3a: an explicitly empty path parameter keeps its assignment', () => {
	const input = 'https://example.com/index.php?/catalog/item=';
	assert.equal(normalizeUrl(input), input);
});

import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

const cases = [
	{
		name: 'default sorting orders ordinary assigned parameters',
		input: 'https://example.com/?z=last&b=two&a=one',
		expected: 'https://example.com/?a=one&b=two&z=last',
	},
	{
		name: 'explicit sorting preserves the stable order of duplicate keys',
		input: 'https://example.com/?b=two&a=second&a=first',
		options: {sortQueryParameters: true},
		expected: 'https://example.com/?a=second&a=first&b=two',
	},
	{
		name: 'sorting opt-out preserves order and bare versus assigned forms',
		input: 'https://example.com/?z=last&flag&empty=&a=first',
		options: {sortQueryParameters: false},
		expected: 'https://example.com/?z=last&flag&empty=&a=first',
	},
	{
		name: 'sorting mixes bare, empty, and nonempty parameters',
		input: 'https://example.com/?z=last&flag&b=two&a=one&empty=',
		expected: 'https://example.com/?a=one&b=two&empty=&flag&z=last',
	},
	{
		name: 'similar names retain their own assignment markers',
		input: 'https://example.com/?flagged=&preflag=&flag&flag-long=assigned&aflag=',
		expected: 'https://example.com/?aflag=&flag&flag-long=assigned&flagged=&preflag=',
	},
	{
		name: 'an explicitly empty value remains distinct from a bare parameter',
		input: 'https://example.com/?empty=',
		expected: 'https://example.com/?empty=',
	},
	{
		name: 'all-bare parameters sort without acquiring assignments',
		input: 'https://example.com/?z&b&a',
		expected: 'https://example.com/?a&b&z',
	},
	{
		name: 'duplicate keys retain each occurrence of bare and assigned forms',
		input: 'https://example.com/?z=last&flag&flag=&flag=value&flag&flag=&a=first',
		expected: 'https://example.com/?a=first&flag&flag=&flag=value&flag&flag=&z=last',
	},
	{
		name: 'equivalent encoded names retain each occurrence of their forms',
		input: 'https://example.com/?z=last&%66lag=&flag&%66lag=value',
		expected: 'https://example.com/?flag=&flag&flag=value&z=last',
	},
	{
		name: 'ordinary host, port, and path normalization still applies',
		input: '  HTTPS://www.Example.com:443/a//b/../index.php?z=2&a=1  ',
		expected: 'https://example.com/a/index.php?a=1&z=2',
	},
	{
		name: 'a query-free URL still normalizes normally',
		input: 'https://www.example.com:443/a//b/',
		expected: 'https://example.com/a/b',
	},
	{
		name: 'fragments are preserved independently of query assignments',
		input: 'https://example.com/index.php?flag#flag=&tail=',
		expected: 'https://example.com/index.php?flag#flag=&tail=',
	},
	{
		name: 'stripHash still removes fragments with a bare path query',
		input: 'https://example.com/index.php?/catalog/item#details',
		options: {stripHash: true},
		expected: 'https://example.com/index.php?/catalog/item',
	},
	{
		name: 'encoded path backslashes survive query sorting',
		input: 'https://www.example.com:443/something%5Celse/great?z=2&flag&a=1#part',
		expected: 'https://example.com/something%5Celse/great?a=1&flag&z=2#part',
	},
	{
		name: 'Unicode parameter values retain normal URL encoding',
		input: 'https://example.com/?z=東京&a=雪&flag',
		expected: 'https://example.com/?a=%E9%9B%AA&flag&z=%E6%9D%B1%E4%BA%AC',
	},
	{
		name: 'removing tracking parameters preserves surviving query forms',
		input: 'https://example.com/?utm_source=test&z=last&flag&empty=',
		expected: 'https://example.com/?empty=&flag&z=last',
	},
	{
		name: 'keeping selected parameters preserves bare and empty forms',
		input: 'https://example.com/?drop=value&flag&empty=',
		options: {keepQueryParameters: ['flag', 'empty']},
		expected: 'https://example.com/?empty=&flag',
	},
];

for (const {name, input, options, expected} of cases) {
	test(`query-sorting-contract-7d3a: ${name}`, () => {
		assert.equal(normalizeUrl(input, options), expected);
	});
}

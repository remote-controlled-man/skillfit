import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('default sorting preserves the reported bare catalog path query', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?/catalog/item'),
		'https://example.com/index.php?/catalog/item',
	);
});

test('sorting opt-out preserves the reported bare catalog path query', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?/catalog/item', {sortQueryParameters: false}),
		'https://example.com/index.php?/catalog/item',
	);
});

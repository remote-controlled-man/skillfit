我会使用 diagnosing-bugs 技能，先用本地可执行测试复现问题，再修复查询排序并保留回归测试；全程不访问网络或其他 checkout。

已复现：`node --test path-query-shape.regression.test.mjs` 在默认排序下失败，实际结果多出 `=`；关闭排序时通过。缩减为 `https://example.com/?a` 后也出现同样问题。

接下来检查三个原因，按可能性排序：① `searchParams.sort()` 重新序列化时将裸参数写成空值赋值；② 排序后的解码步骤引入 `=`；③ 最终 URL 序列化引入 `=`。各步骤的输出可以直接区分它们。

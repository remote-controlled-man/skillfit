#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { setImmediate } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(fileURLToPath(new URL('.', import.meta.url)), true);
after(cleanup);

test('fetch lifecycle: a coalesced miss inserts only the resolved application value as add', async () => {
  const provider = Promise.withResolvers();
  const inserts = [];
  let calls = 0;
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    onInsert: (...event) => inserts.push(event),
    fetchMethod: () => { calls++; return provider.promise; },
  });
  const first = cache.fetch('item');
  const second = cache.fetch('item');
  assert.equal(calls, 1);
  assert.deepEqual(inserts, []);
  assert.equal(cache.peek('item'), undefined);
  provider.resolve(value);
  assert.deepEqual(await Promise.all([first, second]), [value, value]);
  assert.deepEqual(inserts, [[value, 'item', 'add']]);
  assert.equal(cache.get('item'), value);
  assert.equal(await cache.fetch('item'), value);
  assert.equal(calls, 1);
});

for (const sameValue of [true, false]) {
  test(`fetch lifecycle: refresh reports ${sameValue ? 'update for the same' : 'replace for a different'} application value`, async () => {
    const provider = Promise.withResolvers();
    const inserts = [];
    const disposed = [];
    const disposedAfter = [];
    const oldValue = { version: 1 };
    const newValue = sameValue ? oldValue : { version: 2 };
    const cache = new Cache({
      max: 2,
      onInsert: (...event) => inserts.push(event),
      dispose: (...event) => disposed.push(event),
      disposeAfter: (...event) => disposedAfter.push(event),
      fetchMethod: (key, stale) => {
        assert.equal(key, 'item');
        assert.equal(stale, oldValue);
        return provider.promise;
      },
    });
    cache.set('item', oldValue);
    const refreshing = cache.fetch('item', { forceRefresh: true });
    assert.equal(cache.peek('item'), oldValue);
    assert.deepEqual(inserts, [[oldValue, 'item', 'add']]);
    provider.resolve(newValue);
    assert.equal(await refreshing, newValue);
    assert.deepEqual(inserts, [
      [oldValue, 'item', 'add'],
      [newValue, 'item', sameValue ? 'update' : 'replace'],
    ]);
    assert.equal(cache.get('item'), newValue);
    const expectedDisposals = sameValue ? [] : [[oldValue, 'item', 'set']];
    assert.deepEqual(disposed, expectedDisposals);
    assert.deepEqual(disposedAfter, expectedDisposals);
  });
}

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful ${refresh ? 'refresh' : 'miss'} never aborts its own provider`, async () => {
    const provider = Promise.withResolvers();
    const aborts = [];
    const disposed = [];
    const disposedAfter = [];
    let signal;
    const cache = new Cache({
      max: 2,
      dispose: (...event) => disposed.push(event),
      disposeAfter: (...event) => disposedAfter.push(event),
      fetchMethod: (key, stale, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return provider.promise;
      },
    });
    if (refresh) cache.set('item', 'old');
    const fetching = cache.fetch('item', { forceRefresh: refresh });
    provider.resolve('new');
    assert.equal(await fetching, 'new');
    assert.equal(cache.get('item'), 'new');
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborts, []);
    const expected = refresh ? [['old', 'item', 'set']] : [];
    assert.deepEqual(disposed, expected);
    assert.deepEqual(disposedAfter, expected);
  });
}

for (const eviction of ['capacity', 'size', 'pop', 'noDisposeOnSet']) {
  test(`fetch lifecycle: ${eviction} eviction disposes a refreshing stale value exactly once`, async () => {
    const provider = Promise.withResolvers();
    const staleValue = eviction === 'pop' ? 'stale' : 0;
    const disposed = [];
    const disposedAfter = [];
    let signal;
    const cache = new Cache({
      max: eviction === 'size' || eviction === 'pop' ? 3 : 1,
      noDisposeOnSet: eviction === 'noDisposeOnSet',
      ...(eviction === 'size' ? { maxSize: 1, sizeCalculation: () => 1 } : {}),
      dispose: (...event) => disposed.push(event),
      disposeAfter: (...event) => {
        assert.equal(cache.peek('old'), undefined);
        disposedAfter.push(event);
      },
      fetchMethod: (key, stale, options) => {
        assert.equal(stale, staleValue);
        signal = options.signal;
        return provider.promise;
      },
    });
    cache.set('old', staleValue);
    const refreshing = cache.fetch('old', { forceRefresh: true });
    const rejected = assert.rejects(refreshing, /evicted/);
    if (eviction === 'pop') assert.equal(cache.pop(), staleValue);
    else cache.set('new', 1);
    assert.equal(signal.aborted, true);
    assert.match(signal.reason.message, /evicted/);
    assert.deepEqual(disposed, [[staleValue, 'old', 'evict']]);
    assert.deepEqual(disposedAfter, [[staleValue, 'old', 'evict']]);
    await rejected;
    provider.resolve(2);
    await setImmediate();
    assert.equal(cache.has('old'), false);
    assert.equal(cache.size, eviction === 'pop' ? 0 : 1);
    if (eviction !== 'pop') assert.equal(cache.get('new'), 1);
    assert.deepEqual(disposed, [[staleValue, 'old', 'evict']]);
    assert.deepEqual(disposedAfter, [[staleValue, 'old', 'evict']]);
  });
}

test('fetch lifecycle: eviction of a pending miss never disposes an internal value', async () => {
  const provider = Promise.withResolvers();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    dispose: (...event) => disposed.push(event),
    disposeAfter: (...event) => disposedAfter.push(event),
    fetchMethod: () => provider.promise,
  });
  const fetching = cache.fetch('pending');
  const rejected = assert.rejects(fetching, /evicted/);
  cache.set('replacement', 'value');
  await rejected;
  provider.resolve('late');
  await setImmediate();
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.equal(cache.get('replacement'), 'value');
  assert.equal(cache.has('pending'), false);
});

for (const [label, value] of [['zero', 0], ['false', false], ['object', { version: 1 }], ['undefined', undefined]]) {
  test(`fetch lifecycle: synchronous ${label} result settles all callers`, async () => {
    let calls = 0;
    const inserts = [];
    const cache = new Cache({
      max: 2,
      onInsert: (...event) => inserts.push(event),
      fetchMethod: () => { calls++; return value; },
    });
    const callers = Promise.all([cache.fetch('sync'), cache.fetch('sync')]);
    // A synchronous provider must settle before the next event-loop turn.
    const result = await Promise.race([
      callers,
      setImmediate().then(() => assert.fail('synchronous fetch result did not settle')),
    ]);
    assert.deepEqual(result, [value, value]);
    assert.equal(calls, 1);
    assert.equal(cache.peek('sync'), value);
    assert.equal(cache.size, value === undefined ? 0 : 1);
    assert.deepEqual(inserts, value === undefined ? [] : [[value, 'sync', 'add']]);
  });
}

test('fetch lifecycle: a synchronous refresh serves stale callers and then stores the new value', async () => {
  const inserts = [];
  let calls = 0;
  let signal;
  const cache = new Cache({
    max: 2,
    onInsert: (...event) => inserts.push(event),
    fetchMethod: (key, stale, options) => {
      calls++;
      assert.equal(stale, 'old');
      signal = options.signal;
      return 'new';
    },
  });
  cache.set('item', 'old');
  const staleCaller = cache.fetch('item', { forceRefresh: true, allowStale: true });
  const freshCaller = cache.fetch('item');
  assert.deepEqual(inserts, [['old', 'item', 'add']]);
  assert.equal(await staleCaller, 'old');
  assert.equal(await Promise.race([
    freshCaller,
    setImmediate().then(() => assert.fail('synchronous refresh did not settle')),
  ]), 'new');
  assert.equal(calls, 1);
  assert.equal(signal.aborted, false);
  assert.equal(cache.get('item'), 'new');
  assert.deepEqual(inserts, [['old', 'item', 'add'], ['new', 'item', 'replace']]);
});

for (const history of ['missing', 'same', 'different']) {
  test(`fetch lifecycle: explicit replacement cancels a provider with ${history} application history`, async () => {
    const provider = Promise.withResolvers();
    const inserts = [];
    const oldValue = { version: 1 };
    const newValue = history === 'same' ? oldValue : { version: 2 };
    let signal;
    const cache = new Cache({
      max: 2,
      onInsert: (...event) => inserts.push(event),
      fetchMethod: (key, stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    if (history !== 'missing') cache.set('item', oldValue);
    const fetching = cache.fetch('item', { forceRefresh: true });
    const rejected = assert.rejects(fetching, /replaced/);
    cache.set('item', newValue);
    assert.equal(signal.aborted, true);
    assert.match(signal.reason.message, /replaced/);
    await rejected;
    provider.resolve({ version: 3 });
    await setImmediate();
    const expected = history === 'missing' ? [] : [[oldValue, 'item', 'add']];
    expected.push([newValue, 'item', history === 'missing' ? 'add' : history === 'same' ? 'update' : 'replace']);
    assert.deepEqual(inserts, expected);
    assert.equal(cache.get('item'), newValue);
  });
}

test('fetch lifecycle: completed fetches retain ordinary LRU order and insertion reasons', async () => {
  const inserts = [];
  const disposed = [];
  const cache = new Cache({
    max: 2,
    onInsert: (...event) => inserts.push(event),
    dispose: (...event) => disposed.push(event),
    fetchMethod: async key => key.toUpperCase(),
  });
  assert.equal(await cache.fetch('a'), 'A');
  cache.set('b', 'B');
  assert.equal(await cache.fetch('a'), 'A');
  cache.set('c', 'C');
  assert.equal(cache.has('b'), false);
  assert.deepEqual([...cache.entries()], [['c', 'C'], ['a', 'A']]);
  cache.set('a', 'A');
  cache.set('a', 'updated');
  assert.deepEqual(inserts, [
    ['A', 'a', 'add'], ['B', 'b', 'add'], ['C', 'c', 'add'],
    ['A', 'a', 'update'], ['updated', 'a', 'replace'],
  ]);
  assert.deepEqual(disposed, [['B', 'b', 'evict'], ['A', 'a', 'set']]);
});

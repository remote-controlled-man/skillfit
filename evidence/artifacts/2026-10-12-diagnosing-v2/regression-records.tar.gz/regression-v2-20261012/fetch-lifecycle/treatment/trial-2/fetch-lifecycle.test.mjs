#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

// A deadline makes the synchronous-result regression fail instead of hanging.
async function settled(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 1000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle: a coalesced miss inserts only its application value with add', async () => {
  const provider = Promise.withResolvers();
  const value = { version: 1 };
  const insertions = [];
  let calls = 0;
  const cache = new Cache({
    max: 2,
    onInsert: (...event) => insertions.push(event),
    fetchMethod: () => { calls++; return provider.promise; },
  });
  const first = cache.fetch('item');
  const second = cache.fetch('item');
  assert.deepEqual(insertions, []);
  assert.equal(calls, 1);
  provider.resolve(value);
  assert.deepEqual(await settled(Promise.all([first, second])), [value, value]);
  assert.equal(cache.get('item'), value);
  assert.deepEqual(insertions, [[value, 'item', 'add']]);
});

for (const same of [true, false]) {
  test(`fetch lifecycle: successful ${same ? 'same-value' : 'different-value'} refresh reports application history without aborting`, async () => {
    const provider = Promise.withResolvers();
    const old = { version: 1 };
    const value = same ? old : { version: 2 };
    const insertions = [];
    const disposed = [];
    const disposedAfter = [];
    const aborts = [];
    let signal;
    const cache = new Cache({
      max: 2,
      onInsert: (...event) => insertions.push(event),
      dispose: (...event) => disposed.push(event),
      disposeAfter: (...event) => disposedAfter.push(event),
      fetchMethod: (key, stale, options) => {
        assert.equal(key, 'item');
        assert.equal(stale, old);
        signal = options.signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return provider.promise;
      },
    });
    cache.set('item', old);
    const refresh = cache.fetch('item', { forceRefresh: true });
    assert.equal(await cache.fetch('item', { allowStale: true }), old);
    assert.deepEqual(insertions, [[old, 'item', 'add']]);
    provider.resolve(value);
    assert.equal(await settled(refresh), value);
    assert.equal(cache.get('item'), value);
    assert.deepEqual(insertions, [[old, 'item', 'add'], [value, 'item', same ? 'update' : 'replace']]);
    const expectedDisposal = same ? [] : [[old, 'item', 'set']];
    assert.deepEqual(disposed, expectedDisposal);
    assert.deepEqual(disposedAfter, expectedDisposal);
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborts, []);
  });
}

for (const mode of ['count limit', 'size limit', 'pop']) {
  test(`fetch lifecycle: ${mode} eviction disposes the refreshing stale value exactly once`, async () => {
    const provider = Promise.withResolvers();
    const old = { version: 1 };
    const disposed = [];
    const disposedAfter = [];
    let signal;
    const cache = new Cache({
      max: mode === 'size limit' ? 3 : 1,
      ...(mode === 'size limit' ? { maxSize: 1, sizeCalculation: () => 1 } : {}),
      dispose: (...event) => disposed.push(event),
      disposeAfter: (...event) => {
        assert.equal(cache.has('item'), false);
        disposedAfter.push(event);
      },
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    cache.set('item', old);
    const refresh = cache.fetch('item', { forceRefresh: true });
    const rejected = assert.rejects(refresh, /evicted/);
    if (mode === 'pop') assert.equal(cache.pop(), old);
    else cache.set('next', { version: 3 });
    assert.equal(signal.aborted, true);
    assert.deepEqual(disposed, [[old, 'item', 'evict']]);
    assert.deepEqual(disposedAfter, [[old, 'item', 'evict']]);
    await settled(rejected);
    provider.resolve({ version: 2 });
    await provider.promise;
    assert.equal(cache.has('item'), false);
    assert.deepEqual(disposed, [[old, 'item', 'evict']]);
    assert.deepEqual(disposedAfter, [[old, 'item', 'evict']]);
    if (mode !== 'pop') assert.equal(cache.get('next').version, 3);
  });
}

test('fetch lifecycle: disposeAfter alone receives a falsy stale value on eviction', async () => {
  const provider = Promise.withResolvers();
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    disposeAfter: (...event) => disposedAfter.push(event),
    fetchMethod: () => provider.promise,
  });
  cache.set('item', 0);
  const rejected = assert.rejects(cache.fetch('item', { forceRefresh: true }), /evicted/);
  cache.set('next', 1);
  await settled(rejected);
  provider.resolve(2);
  await provider.promise;
  assert.deepEqual(disposedAfter, [[0, 'item', 'evict']]);
});

test('fetch lifecycle: evicting a pending miss never disposes an internal placeholder', async () => {
  const provider = Promise.withResolvers();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    dispose: (...event) => disposed.push(event),
    disposeAfter: (...event) => disposedAfter.push(event),
    fetchMethod: () => provider.promise,
  });
  const rejected = assert.rejects(cache.fetch('item'), /evicted/);
  cache.set('next', 1);
  await settled(rejected);
  provider.resolve(2);
  await provider.promise;
  assert.equal(cache.get('next'), 1);
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
});

for (const [label, value] of [['object', { version: 1 }], ['zero', 0], ['false', false], ['empty string', ''], ['undefined', undefined]]) {
  test(`fetch lifecycle: synchronous ${label} result settles and caches only defined values`, async () => {
    const insertions = [];
    const cache = new Cache({ max: 1, fetchMethod: () => value, onInsert: (...event) => insertions.push(event) });
    assert.equal(await settled(cache.fetch('item')), value);
    assert.equal(cache.get('item'), value);
    assert.equal(cache.size, value === undefined ? 0 : 1);
    assert.deepEqual(insertions, value === undefined ? [] : [[value, 'item', 'add']]);
  });
}

test('fetch lifecycle: synchronous undefined refresh retains the previous application value', async () => {
  const insertions = [];
  const cache = new Cache({ max: 1, fetchMethod: () => undefined, onInsert: (...event) => insertions.push(event) });
  cache.set('item', 0);
  assert.equal(await settled(cache.fetch('item', { forceRefresh: true })), undefined);
  assert.equal(cache.get('item'), 0);
  assert.deepEqual(insertions, [[0, 'item', 'add']]);
});

for (const history of ['miss', 'same value', 'different value']) {
  test(`fetch lifecycle: explicit set cancels a pending ${history} fetch and reports the application insertion reason`, async () => {
    const provider = Promise.withResolvers();
    const old = { version: 1 };
    const value = history === 'same value' ? old : { version: 2 };
    const insertions = [];
    let signal;
    const cache = new Cache({
      max: 1,
      onInsert: (...event) => insertions.push(event),
      fetchMethod: (_key, _stale, options) => { signal = options.signal; return provider.promise; },
    });
    if (history !== 'miss') cache.set('item', old);
    const rejected = assert.rejects(cache.fetch('item', { forceRefresh: true }), /replaced/);
    cache.set('item', value);
    assert.equal(signal.aborted, true);
    await settled(rejected);
    provider.resolve({ version: 3 });
    await provider.promise;
    assert.equal(cache.get('item'), value);
    const reason = history === 'miss' ? 'add' : history === 'same value' ? 'update' : 'replace';
    assert.deepEqual(insertions, [...(history === 'miss' ? [] : [[old, 'item', 'add']]), [value, 'item', reason]]);
  });
}

test('fetch lifecycle: successful fetches preserve LRU hits and ordinary set reasons', async () => {
  const insertions = [];
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: async key => { calls++; return key.toUpperCase(); },
    onInsert: (...event) => insertions.push(event),
  });
  assert.equal(await cache.fetch('a'), 'A');
  assert.equal(await cache.fetch('b'), 'B');
  assert.equal(await cache.fetch('a'), 'A');
  assert.equal(calls, 2);
  cache.set('c', 'C');
  assert.equal(cache.has('b'), false);
  assert.deepEqual([...cache.keys()], ['c', 'a']);
  cache.set('c', 'C');
  cache.set('c', 'new C');
  assert.deepEqual(insertions, [['A', 'a', 'add'], ['B', 'b', 'add'], ['C', 'c', 'add'], ['C', 'c', 'update'], ['new C', 'c', 'replace']]);
});

test('fetch lifecycle: rejected and throwing providers still follow rejection options', async () => {
  const error = new Error('provider failure');
  const throwing = new Cache({ max: 1, fetchMethod: () => { throw error; } });
  await assert.rejects(settled(throwing.fetch('item')), e => e === error);
  assert.equal(throwing.size, 0);
  const insertions = [];
  const rejected = new Cache({
    max: 1,
    fetchMethod: async () => { throw error; },
    onInsert: (...event) => insertions.push(event),
  });
  rejected.set('item', 0);
  assert.equal(await settled(rejected.fetch('item', { forceRefresh: true, allowStaleOnFetchRejection: true })), 0);
  assert.equal(rejected.get('item'), 0);
  assert.deepEqual(insertions, [[0, 'item', 'add']]);
});

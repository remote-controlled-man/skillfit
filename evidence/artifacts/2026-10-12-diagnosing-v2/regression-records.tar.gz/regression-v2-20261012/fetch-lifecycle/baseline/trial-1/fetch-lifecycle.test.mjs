#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

const deferred = () => {
  let resolve;
  const promise = new Promise(res => {
    resolve = res;
  });
  return { promise, resolve };
};

// A hung fetch must fail the test without leaving a timer alive on success.
const settles = async promise => {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 1000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
};

test('fetch lifecycle: a cache miss reports only the resolved application value as add', async () => {
  const provider = deferred();
  const inserted = [];
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  const fetching = cache.fetch('key');
  const pendingInsertions = inserted.slice();
  provider.resolve(value);
  assert.equal(await settles(fetching), value);
  assert.deepEqual(pendingInsertions, []);
  assert.deepEqual(inserted, [[value, 'key', 'add']]);
  assert.equal(cache.get('key'), value);
});

test('fetch lifecycle: a refresh reports replace only when the application value changes', async () => {
  const provider = deferred();
  const inserted = [];
  const oldValue = { version: 1 };
  const newValue = { version: 2 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  cache.set('key', oldValue);
  inserted.length = 0;
  const fetching = cache.fetch('key', { forceRefresh: true });
  assert.deepEqual(inserted, []);
  provider.resolve(newValue);
  assert.equal(await settles(fetching), newValue);
  assert.deepEqual(inserted, [[newValue, 'key', 'replace']]);
});

test('fetch lifecycle: refreshing with the same application value reports update', async () => {
  const inserted = [];
  const disposed = [];
  const disposedAfter = [];
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => value,
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', value);
  inserted.length = 0;
  assert.equal(await settles(cache.fetch('key', { forceRefresh: true })), value);
  assert.deepEqual(inserted, [[value, 'key', 'update']]);
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
});

test('fetch lifecycle: evicting a refresh disposes its stale value exactly once per hook', async () => {
  const provider = deferred();
  const disposed = [];
  const disposedAfter = [];
  const oldValue = { version: 1 };
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', oldValue);
  const fetching = cache.fetch('key', { forceRefresh: true });
  const rejected = assert.rejects(settles(fetching), error => error === signal.reason);
  cache.set('other', 'retained');
  await rejected;
  provider.resolve({ version: 2 });
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(disposed, [[oldValue, 'key', 'evict']]);
  assert.deepEqual(disposedAfter, [[oldValue, 'key', 'evict']]);
  assert.equal(cache.has('key'), false);
  assert.equal(cache.get('other'), 'retained');
});

test('fetch lifecycle: a synchronous provider settles concurrent callers and caches its value', async () => {
  let calls = 0;
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return value;
    },
  });
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.deepEqual(await settles(Promise.all([first, second])), [value, value]);
  assert.equal(calls, 1);
  assert.equal(cache.get('key'), value);
  assert.equal(await cache.fetch('key'), value);
  assert.equal(calls, 1);
});

test('fetch lifecycle: synchronous falsy application values are returned and inserted', async () => {
  for (const value of [0, false, '']) {
    const inserted = [];
    const cache = new Cache({
      max: 1,
      fetchMethod: () => value,
      onInsert: (...args) => inserted.push(args),
    });
    assert.equal(await settles(cache.fetch('key')), value);
    assert.equal(cache.get('key'), value);
    assert.deepEqual(inserted, [[value, 'key', 'add']]);
  }
});

test('fetch lifecycle: synchronous undefined settles a miss and preserves an existing stale value', async () => {
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => undefined,
    onInsert: (...args) => inserted.push(args),
  });
  assert.equal(await settles(cache.fetch('missing')), undefined);
  assert.equal(cache.size, 0);
  assert.deepEqual(inserted, []);
  cache.set('key', 'old');
  inserted.length = 0;
  assert.equal(await settles(cache.fetch('key', { forceRefresh: true })), undefined);
  assert.equal(cache.get('key'), 'old');
  assert.deepEqual(inserted, []);
});

test('fetch lifecycle: a successful refresh does not abort its own provider', async () => {
  const provider = deferred();
  const disposed = [];
  const disposedAfter = [];
  let signal;
  let aborts = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      signal.addEventListener('abort', () => aborts++);
      return provider.promise;
    },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 'old');
  const fetching = cache.fetch('key', { forceRefresh: true });
  provider.resolve('new');
  assert.equal(await settles(fetching), 'new');
  assert.equal(cache.get('key'), 'new');
  assert.equal(signal.aborted, false);
  assert.equal(aborts, 0);
  assert.deepEqual(disposed, [['old', 'key', 'set']]);
  assert.deepEqual(disposedAfter, [['old', 'key', 'set']]);
});

test('fetch lifecycle: an explicit set still aborts an in-flight refresh and keeps the replacement', async () => {
  const provider = deferred();
  const inserted = [];
  const disposed = [];
  const disposedAfter = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 'old');
  inserted.length = 0;
  const fetching = cache.fetch('key', { forceRefresh: true });
  const rejected = assert.rejects(settles(fetching), error => error === signal.reason);
  cache.set('key', 'replacement');
  await rejected;
  assert.equal(signal.aborted, true);
  provider.resolve('late');
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(cache.get('key'), 'replacement');
  assert.deepEqual(inserted, [['replacement', 'key', 'replace']]);
  assert.deepEqual(disposed, [['old', 'key', 'set']]);
  assert.deepEqual(disposedAfter, [['old', 'key', 'set']]);
});

test('fetch lifecycle: ordinary inserts retain add update replace reasons and LRU eviction', () => {
  const inserted = [];
  const disposed = [];
  const cache = new Cache({
    max: 2,
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
  });
  cache.set('a', 1);
  cache.set('a', 1);
  cache.set('a', 2);
  cache.set('b', 3);
  assert.equal(cache.get('a'), 2);
  cache.set('c', 4);
  assert.deepEqual(inserted, [
    [1, 'a', 'add'],
    [1, 'a', 'update'],
    [2, 'a', 'replace'],
    [3, 'b', 'add'],
    [4, 'c', 'add'],
  ]);
  assert.deepEqual(disposed, [[1, 'a', 'set'], [3, 'b', 'evict']]);
  assert.deepEqual([...cache.keys()], ['c', 'a']);
});

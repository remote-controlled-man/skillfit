#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

function deferred() {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
}

async function settles(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 1000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle regression: an asynchronous miss inserts only its application value with add', async () => {
  const result = deferred();
  const inserts = [];
  const value = { fetched: true };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => result.promise,
    onInsert: (...args) => inserts.push(args),
  });
  const pending = cache.fetch('key');
  const beforeCompletion = inserts.slice();
  result.resolve(value);
  assert.equal(await settles(pending), value);
  assert.deepEqual(beforeCompletion, []);
  assert.deepEqual(inserts, [[value, 'key', 'add']]);
  assert.equal(cache.get('key'), value);
});

for (const sameValue of [true, false]) {
  const reason = sameValue ? 'update' : 'replace';
  test(`fetch lifecycle regression: a refresh reports ${reason} for its application value`, async () => {
    const result = deferred();
    const inserts = [];
    const stale = { version: 1 };
    const value = sameValue ? stale : { version: 2 };
    const cache = new Cache({
      max: 2,
      fetchMethod: (key, previous) => {
        assert.equal(key, 'key');
        assert.equal(previous, stale);
        return result.promise;
      },
      onInsert: (...args) => inserts.push(args),
    });
    cache.set('key', stale);
    inserts.length = 0;
    const pending = cache.fetch('key', { forceRefresh: true });
    const beforeCompletion = inserts.slice();
    result.resolve(value);
    assert.equal(await settles(pending), value);
    assert.deepEqual(beforeCompletion, []);
    assert.deepEqual(inserts, [[value, 'key', reason]]);
    assert.equal(cache.get('key'), value);
  });
}

for (const [stale, noDisposeOnSet] of [[{ version: 1 }, false], [0, false], [{ version: 1 }, true]]) {
  test(`fetch lifecycle regression: eviction disposes the ${stale === 0 ? 'zero' : 'object'} stale value once per hook with noDisposeOnSet=${noDisposeOnSet}`, async () => {
    const result = deferred();
    const disposed = [];
    const disposedAfter = [];
    let signal;
    const cache = new Cache({
      max: 1,
      noDisposeOnSet,
      fetchMethod: (key, previous, options) => {
        signal = options.signal;
        return result.promise;
      },
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args),
    });
    cache.set('key', stale);
    const pending = cache.fetch('key', { forceRefresh: true });
    const rejected = assert.rejects(pending, error => error === signal.reason);
    cache.set('other', 2);
    await settles(rejected);
    result.resolve({ version: 2 });
    await new Promise(resolve => setImmediate(resolve));
    assert.equal(signal.aborted, true);
    assert.deepEqual(disposed, [[stale, 'key', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'key', 'evict']]);
    assert.equal(cache.has('key'), false);
    assert.equal(cache.get('other'), 2);
  });
}

test('fetch lifecycle regression: synchronous values settle a miss and a refresh', async () => {
  const inserts = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: (key, previous) => previous === undefined ? 0 : previous + 1,
    onInsert: (...args) => inserts.push(args),
  });
  assert.equal(await settles(cache.fetch('key')), 0);
  assert.equal(await settles(cache.fetch('key', { forceRefresh: true })), 1);
  assert.equal(cache.get('key'), 1);
  assert.deepEqual(inserts, [[0, 'key', 'add'], [1, 'key', 'replace']]);
});

test('fetch lifecycle regression: synchronous undefined settles without inserting an application value', async () => {
  const inserts = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => undefined,
    onInsert: (...args) => inserts.push(args),
  });
  assert.equal(await settles(cache.fetch('key')), undefined);
  assert.equal(cache.has('key'), false);
  assert.deepEqual(inserts, []);
});

test('fetch lifecycle regression: storing a successful refresh does not abort its provider', async () => {
  const result = deferred();
  const aborts = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (key, previous, options) => {
      signal = options.signal;
      signal.addEventListener('abort', () => aborts.push(signal.reason));
      return result.promise;
    },
  });
  cache.set('key', 1);
  const pending = cache.fetch('key', { forceRefresh: true });
  result.resolve(2);
  assert.equal(await settles(pending), 2);
  assert.equal(cache.get('key'), 2);
  assert.equal(signal.aborted, false);
  assert.deepEqual(aborts, []);
});

test('fetch lifecycle regression: explicit replacement still cancels a refresh and ignores its late result', async () => {
  const result = deferred();
  const inserts = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (key, previous, options) => {
      signal = options.signal;
      return result.promise;
    },
    onInsert: (...args) => inserts.push(args),
  });
  cache.set('key', 1);
  const pending = cache.fetch('key', { forceRefresh: true });
  const rejected = assert.rejects(pending, error => error === signal.reason);
  cache.set('key', 3);
  await settles(rejected);
  result.resolve(2);
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(signal.aborted, true);
  assert.equal(cache.get('key'), 3);
  assert.deepEqual(inserts, [[1, 'key', 'add'], [3, 'key', 'replace']]);
});

test('fetch lifecycle regression: shared fetches succeed and retain ordinary LRU order', async () => {
  const result = deferred();
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return result.promise;
    },
  });
  cache.set('older', 1);
  const first = cache.fetch('fetched');
  const second = cache.fetch('fetched');
  result.resolve(2);
  assert.deepEqual(await settles(Promise.all([first, second])), [2, 2]);
  assert.equal(calls, 1);
  assert.equal(await settles(cache.fetch('fetched')), 2);
  assert.equal(calls, 1);
  cache.set('newer', 3);
  assert.equal(cache.has('older'), false);
  assert.deepEqual([...cache], [['newer', 3], ['fetched', 2]]);
});

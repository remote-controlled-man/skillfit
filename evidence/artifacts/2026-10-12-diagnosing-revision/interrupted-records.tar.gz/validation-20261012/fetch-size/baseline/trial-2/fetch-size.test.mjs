#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

const weight = value => value.length;

function deferredFetches() {
  const requests = [];
  const fetchMethod = (key, staleValue) => new Promise(resolve => {
    requests.push({ key, staleValue, resolve });
  });
  return { requests, fetchMethod };
}

function assertIteration(iterator, expected) {
  // Read only the expected entries and one terminator: a broken linked order
  // must fail an assertion rather than exhaust memory in an unbounded spread.
  for (const value of expected) {
    assert.deepEqual(iterator.next(), { value, done: false });
  }
  assert.equal(iterator.next().done, true, 'iteration must terminate');
}

function assertState(cache, expected) {
  const size = expected.reduce((sum, [, value]) => sum + weight(value), 0);
  assert.equal(cache.calculatedSize, size, 'calculatedSize must match retained values');
  assert.ok(size <= cache.maxSize, 'retained values must fit the size limit');
  assert.equal(cache.size, expected.length);
  assertIteration(cache.entries(), expected);
  assertIteration(cache.rentries(), [...expected].reverse());
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size: reverse completion retains the last result and supports later writes', async () => {
  const { requests, fetchMethod } = deferredFetches();
  const cache = new Cache({ maxSize: 1, sizeCalculation: weight, fetchMethod });
  const first = cache.fetch('a');
  const second = cache.fetch('b');

  requests[1].resolve('b');
  assert.equal(await second, 'b');
  assert.equal(cache.calculatedSize, 1);
  requests[0].resolve('a');
  assert.equal(await first, 'a');
  assertState(cache, [['a', 'a']]);
  assert.equal(cache.has('b'), false);

  cache.set('c', 'c');
  assertState(cache, [['c', 'c']]);
  cache.set('d', 'd');
  assertState(cache, [['d', 'd']]);
});

test('fetch-size: concurrent fills use completion order for subsequent LRU eviction', async () => {
  const { requests, fetchMethod } = deferredFetches();
  const cache = new Cache({ maxSize: 8, sizeCalculation: weight, fetchMethod });
  const first = cache.fetch('a');
  const second = cache.fetch('b');
  const third = cache.fetch('c');

  requests[2].resolve('c');
  assert.equal(await third, 'c');
  requests[1].resolve('bbb');
  assert.equal(await second, 'bbb');
  requests[0].resolve('aa');
  assert.equal(await first, 'aa');
  assertState(cache, [['a', 'aa'], ['b', 'bbb'], ['c', 'c']]);

  assert.equal(cache.get('c'), 'c');
  assertState(cache, [['c', 'c'], ['a', 'aa'], ['b', 'bbb']]);
  cache.set('d', 'ddd');
  assertState(cache, [['d', 'ddd'], ['c', 'c'], ['a', 'aa']]);
  assert.equal(cache.has('b'), false);
  cache.set('a', 'aaaa');
  assertState(cache, [['a', 'aaaa'], ['d', 'ddd'], ['c', 'c']]);
});

test('fetch-size: a growing refresh survives eviction of older sized entries', async () => {
  const { requests, fetchMethod } = deferredFetches();
  const cache = new Cache({ maxSize: 10, sizeCalculation: weight, fetchMethod });
  cache.set('a', 'aa');
  cache.set('b', 'bbb');
  cache.set('c', 'cccc');
  const refreshed = cache.fetch('a', { forceRefresh: true });
  assert.equal(requests[0].staleValue, 'aa');
  assert.equal(cache.calculatedSize, 9);

  requests[0].resolve('aaaaa');
  assert.equal(await refreshed, 'aaaaa');
  assertState(cache, [['a', 'aaaaa'], ['c', 'cccc']]);
  assert.equal(cache.has('b'), false);
  assert.equal(cache.get('c'), 'cccc');
  cache.set('d', 'ddd');
  assertState(cache, [['d', 'ddd'], ['c', 'cccc']]);
  assert.equal(cache.has('a'), false);
});

test('fetch-size: ordinary updates and reads preserve both count and size limits', () => {
  const cache = new Cache({ max: 2, maxSize: 4, sizeCalculation: weight });
  cache.set('a', 'a');
  cache.set('b', 'bbb');
  cache.set('a', 'aa');
  assertState(cache, [['a', 'aa']]);
  assert.equal(cache.get('b'), undefined);

  cache.set('c', 'c');
  assert.equal(cache.get('a'), 'aa');
  assertState(cache, [['a', 'aa'], ['c', 'c']]);
  cache.set('d', 'dd');
  assertState(cache, [['d', 'dd'], ['a', 'aa']]);
  cache.set('a', 'a');
  assertState(cache, [['a', 'a'], ['d', 'dd']]);
  cache.set('a', 'a');
  assertState(cache, [['a', 'a'], ['d', 'dd']]);
});

test('fetch-size: duplicate refresh requests share one fetch through sized eviction', async () => {
  const { requests, fetchMethod } = deferredFetches();
  const cache = new Cache({ maxSize: 4, sizeCalculation: weight, fetchMethod });
  cache.set('a', 'a');
  cache.set('b', 'bbb');
  const first = cache.fetch('a', { forceRefresh: true });
  const second = cache.fetch('a', { forceRefresh: true });
  assert.equal(requests.length, 1);
  assert.equal(requests[0].key, 'a');
  assert.equal(cache.peek('a'), 'a');
  assert.equal(cache.get('a'), undefined);
  assert.equal(cache.calculatedSize, 4);

  requests[0].resolve('aa');
  assert.deepEqual(await Promise.all([first, second]), ['aa', 'aa']);
  assertState(cache, [['a', 'aa']]);
  assert.equal(await cache.fetch('a'), 'aa');
  assert.equal(requests.length, 1);
  assertState(cache, [['a', 'aa']]);
});

test('fetch-size: late results cannot overwrite entries after eviction or replacement', async () => {
  const { requests, fetchMethod } = deferredFetches();
  const cache = new Cache({ max: 2, maxSize: 2, sizeCalculation: weight, fetchMethod });
  const evicted = cache.fetch('a');
  cache.set('b', 'bb');
  cache.set('c', 'cc');
  assertState(cache, [['c', 'cc']]);
  requests[0].resolve('x');
  assert.equal(await evicted, 'x');
  assertState(cache, [['c', 'cc']]);
  assert.equal(cache.has('a'), false);

  const replaced = cache.fetch('a');
  cache.set('a', 'A');
  assertState(cache, [['a', 'A']]);
  requests[1].resolve('y');
  assert.equal(await replaced, 'y');
  assertState(cache, [['a', 'A']]);
  assert.equal(cache.delete('a'), true);
  assertState(cache, []);
});

test('fetch-size: removing the final entry after weighted eviction permits safe reuse', () => {
  const cache = new Cache({ maxSize: 1, sizeCalculation: weight });
  cache.set('a', 'a');
  cache.set('b', 'b');
  assert.equal(cache.pop(), 'b');
  assertState(cache, []);
  cache.set('c', 'c');
  assertState(cache, [['c', 'c']]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(
  dirname(fileURLToPath(import.meta.url)),
  false
);
after(cleanup);

const deferredCache = options => {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    maxSize: 5,
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod: (key, stale) => {
      calls.push([key, stale]);
      return new Promise((resolve, reject) => {
        pending.set(key, { resolve, reject });
      });
    },
  });
  return { cache, pending, calls };
};

const assertContents = (cache, entries) => {
  const total = entries.reduce((size, [, value]) => size + value.length, 0);
  assert.equal(cache.calculatedSize, total);
  assert.ok(total <= cache.maxSize);
  assert.equal(cache.size, entries.length);
  assert.deepEqual([...cache.entries()], entries);
  assert.deepEqual([...cache.rentries()], [...entries].reverse());
};

test('fetch-size historical regression: reverse completion evicts the older result without losing the updated entry', async () => {
  const resolve = new Map();
  const cache = new Cache({
    maxSize: 2,
    sizeCalculation: value => value.length,
    fetchMethod: key => new Promise(done => resolve.set(key, done)),
  });
  const first = cache.fetch('first');
  const second = cache.fetch('second');

  resolve.get('second')('b');
  assert.equal(await second, 'b');
  resolve.get('first')('aa');
  assert.equal(await first, 'aa');

  assert.equal(cache.calculatedSize, 2);
  assert.equal(cache.size, 1);
  assert.deepEqual([...cache.entries()], [['first', 'aa']]);
  assert.equal(cache.has('second'), false);

  cache.set('third', 'c');
  assert.equal(cache.calculatedSize, 1);
  assert.equal(cache.size, 1);
  assert.deepEqual([...cache.entries()], [['third', 'c']]);
});

test('fetch-size regression: out-of-order fetch completion accounts for every retained value', async () => {
  const resolve = new Map();
  const cache = new Cache({
    maxSize: 4,
    sizeCalculation: value => value.length,
    fetchMethod: key => new Promise(done => resolve.set(key, done)),
  });
  const first = cache.fetch('first');
  const second = cache.fetch('second');

  resolve.get('second')('bb');
  assert.equal(await second, 'bb');
  assert.equal(cache.calculatedSize, 2);

  resolve.get('first')('aa');
  assert.equal(await first, 'aa');
  assert.equal(cache.calculatedSize, 4);
  assert.equal(cache.size, 2);
  assert.deepEqual([...cache.entries()], [['first', 'aa'], ['second', 'bb']]);

  cache.set('third', 'cc');
  assert.equal(cache.calculatedSize, 4);
  assert.equal(cache.size, 2);
  assert.deepEqual([...cache.entries()], [['third', 'cc'], ['first', 'aa']]);
});

test('fetch-size regression: three mixed completions preserve both iteration directions after later reads and writes', async () => {
  const { cache, pending } = deferredCache();
  const first = cache.fetch('first');
  const second = cache.fetch('second');
  const third = cache.fetch('third');

  pending.get('second').resolve('bb');
  assert.equal(await second, 'bb');
  pending.get('first').resolve('aaa');
  assert.equal(await first, 'aaa');
  pending.get('third').resolve('c');
  assert.equal(await third, 'c');
  assertContents(cache, [['third', 'c'], ['first', 'aaa']]);
  assert.equal(cache.has('second'), false);

  assert.equal(cache.get('first'), 'aaa');
  assertContents(cache, [['first', 'aaa'], ['third', 'c']]);
  cache.set('fourth', 'dd');
  assertContents(cache, [['fourth', 'dd'], ['first', 'aaa']]);
  assert.equal(cache.has('third'), false);
  assert.equal(cache.delete('first'), true);
  cache.set('fifth', 'eee');
  assertContents(cache, [['fifth', 'eee'], ['fourth', 'dd']]);
});

test('fetch-size regression: growing a forced refresh evicts the least recently used other entry', async () => {
  const { cache, pending, calls } = deferredCache();
  cache.set('first', 'a');
  cache.set('second', 'bb');
  cache.set('third', 'cc');
  const refresh = cache.fetch('first', { forceRefresh: true });
  assert.equal(cache.calculatedSize, 5);
  assert.equal(cache.peek('first'), 'a');
  assert.deepEqual(calls, [['first', 'a']]);

  pending.get('first').resolve('aaa');
  assert.equal(await refresh, 'aaa');
  assertContents(cache, [['first', 'aaa'], ['third', 'cc']]);
  assert.equal(cache.has('second'), false);
  cache.set('fourth', 'd');
  assertContents(cache, [['fourth', 'd'], ['first', 'aaa']]);
});

test('fetch-size regression: shrinking a forced refresh releases capacity for later writes', async () => {
  const { cache, pending } = deferredCache();
  cache.set('first', 'aaa');
  cache.set('second', 'bb');
  const refresh = cache.fetch('first', { forceRefresh: true });
  pending.get('first').resolve('a');
  assert.equal(await refresh, 'a');
  assertContents(cache, [['first', 'a'], ['second', 'bb']]);

  cache.set('third', 'cc');
  assertContents(cache, [['third', 'cc'], ['first', 'a'], ['second', 'bb']]);
});

test('fetch-size regression: concurrent misses deduplicate and fetch hits retain get-style recency', async () => {
  const { cache, pending, calls } = deferredCache({ maxSize: 4 });
  const first = cache.fetch('first');
  const duplicate = cache.fetch('first');
  const forcedDuplicate = cache.fetch('first', { forceRefresh: true });
  assert.deepEqual(calls, [['first', undefined]]);
  assert.equal(cache.calculatedSize, 0);
  assert.equal(cache.size, 1);

  pending.get('first').resolve('aa');
  assert.deepEqual(await Promise.all([first, duplicate, forcedDuplicate]), ['aa', 'aa', 'aa']);
  assertContents(cache, [['first', 'aa']]);
  cache.set('second', 'bb');
  assert.equal(await cache.fetch('first'), 'aa');
  assert.equal(calls.length, 1);
  assertContents(cache, [['first', 'aa'], ['second', 'bb']]);
  cache.set('third', 'cc');
  assertContents(cache, [['third', 'cc'], ['first', 'aa']]);
});

test('fetch-size regression: ordinary sized updates preserve capacity and get/set recency', () => {
  const cache = new Cache({ maxSize: 5, sizeCalculation: value => value.length });
  cache.set('first', 'a');
  cache.set('second', 'bb');
  cache.set('third', 'cc');
  cache.set('first', 'aaa');
  assertContents(cache, [['first', 'aaa'], ['third', 'cc']]);
  assert.equal(cache.get('third'), 'cc');
  assertContents(cache, [['third', 'cc'], ['first', 'aaa']]);
  cache.set('third', 'c');
  cache.set('fourth', 'd');
  assertContents(cache, [['fourth', 'd'], ['third', 'c'], ['first', 'aaa']]);
});

test('fetch-size regression: explicit fetch sizes and entry-count bounds remain consistent', async () => {
  const { cache, pending } = deferredCache({ max: 2, maxSize: 3, sizeCalculation: undefined });
  const first = cache.fetch('first', { size: 2 });
  const second = cache.fetch('second', { size: 1 });
  pending.get('second').resolve('b');
  assert.equal(await second, 'b');
  pending.get('first').resolve('aa');
  assert.equal(await first, 'aa');
  assertContents(cache, [['first', 'aa'], ['second', 'b']]);

  cache.set('third', 'cc', { size: 2 });
  assertContents(cache, [['third', 'cc']]);
  cache.set('fourth', 'd', { size: 1 });
  assertContents(cache, [['fourth', 'd'], ['third', 'cc']]);
});

test('fetch-size regression: an oversized result leaves retained entries and later writes intact', async () => {
  const { cache, pending } = deferredCache({ maxSize: 3 });
  cache.set('retained', 'aa');
  const oversized = cache.fetch('oversized');
  pending.get('oversized').resolve('bbbb');
  assert.equal(await oversized, 'bbbb');
  assert.equal(cache.has('oversized'), false);
  assertContents(cache, [['retained', 'aa']]);
  cache.set('next', 'c');
  assertContents(cache, [['next', 'c'], ['retained', 'aa']]);
});

test('fetch-size regression: a write during a fetch prevents its late result from changing size or recency', async () => {
  const { cache, pending } = deferredCache({ maxSize: 4 });
  const fetch = cache.fetch('first');
  cache.set('first', 'a');
  cache.set('second', 'bb');
  assertContents(cache, [['second', 'bb'], ['first', 'a']]);
  pending.get('first').resolve('aaaa');
  await fetch;
  assertContents(cache, [['second', 'bb'], ['first', 'a']]);
  cache.set('third', 'c');
  assertContents(cache, [['third', 'c'], ['second', 'bb'], ['first', 'a']]);
});

test('fetch-size regression: a rejected forced refresh retains its stale value and size when requested', async () => {
  const { cache, pending } = deferredCache({ maxSize: 3 });
  cache.set('first', 'aa');
  cache.set('second', 'b');
  const refresh = cache.fetch('first', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  });
  pending.get('first').reject(new Error('expected fetch failure'));
  assert.equal(await refresh, 'aa');
  assertContents(cache, [['second', 'b'], ['first', 'aa']]);
  cache.set('third', 'cc');
  assertContents(cache, [['third', 'cc'], ['second', 'b']]);
});

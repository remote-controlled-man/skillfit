#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)));

function deferred() {
  let resolve;
  const promise = new Promise(res => {
    resolve = res;
  });
  return { promise, resolve };
}

function readEntries(cache, iterator) {
  const entries = [];
  for (const entry of iterator) {
    entries.push(entry);
    assert.ok(entries.length <= cache.size, 'iteration must terminate without repeating entries');
  }
  return entries;
}

function assertCache(cache, entries) {
  assert.equal(cache.calculatedSize, entries.reduce((sum, [, value]) => sum + value.length, 0));
  assert.ok(cache.calculatedSize <= cache.maxSize);
  assert.equal(cache.size, entries.length);
  assert.deepEqual(readEntries(cache, cache.entries()), entries);
  assert.deepEqual(readEntries(cache, cache.rentries()), [...entries].reverse());
  for (const [key, value] of entries) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size historical regression: an earlier request resolving last survives size eviction', async () => {
  const first = deferred();
  const second = deferred();
  const cache = new Cache({
    max: 4,
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: key => (key === 'first' ? first.promise : second.promise),
  });
  const firstResult = cache.fetch('first');
  const secondResult = cache.fetch('second');
  assert.equal(cache.calculatedSize, 0);

  second.resolve('bbbb');
  assert.equal(await secondResult, 'bbbb');
  assert.equal(cache.calculatedSize, 4);
  assert.equal(cache.size, 2);

  first.resolve('aaaa');
  assert.equal(await firstResult, 'aaaa');
  assertCache(cache, [['first', 'aaaa']]);
  assert.equal(cache.has('second'), false);

  cache.set('third', 'cc');
  assertCache(cache, [['third', 'cc']]);
  cache.set('fourth', 'ddd');
  assertCache(cache, [['fourth', 'ddd'], ['third', 'cc']]);
  assert.equal(cache.get('third'), 'cc');
  assertCache(cache, [['third', 'cc'], ['fourth', 'ddd']]);
  cache.set('fifth', 'e');
  assertCache(cache, [['fifth', 'e'], ['third', 'cc']]);
  assert.equal(cache.has('fourth'), false);
});

test('fetch-size regression: out-of-order refreshes retain stale sizes until replacement', async () => {
  const first = deferred();
  const second = deferred();
  const cache = new Cache({
    maxSize: 8,
    sizeCalculation: value => value.length,
    fetchMethod: key => (key === 'first' ? first.promise : second.promise),
  });
  cache.set('first', 'aa');
  cache.set('second', 'bb');
  cache.set('third', 'cc');
  const firstResult = cache.fetch('first', { forceRefresh: true });
  const secondResult = cache.fetch('second', { forceRefresh: true });
  assert.equal(cache.calculatedSize, 6);
  assert.equal(cache.peek('first'), 'aa');
  assert.equal(cache.peek('second'), 'bb');

  second.resolve('bbbb');
  assert.equal(await secondResult, 'bbbb');
  assert.equal(cache.calculatedSize, 8);
  first.resolve('aaaaa');
  assert.equal(await firstResult, 'aaaaa');
  assertCache(cache, [['first', 'aaaaa']]);
  assert.equal(cache.has('second'), false);
  assert.equal(cache.has('third'), false);

  cache.set('fourth', 'ddd');
  assertCache(cache, [['fourth', 'ddd'], ['first', 'aaaaa']]);
  assert.equal(cache.delete('first'), true);
  assertCache(cache, [['fourth', 'ddd']]);
  cache.set('fifth', 'eeeee');
  assertCache(cache, [['fifth', 'eeeee'], ['fourth', 'ddd']]);
});

test('fetch-size compatibility: growing ordinary updates preserve both LRU directions', () => {
  const cache = new Cache({ max: 4, maxSize: 5, sizeCalculation: value => value.length });
  cache.set('first', 'a');
  cache.set('second', 'b');
  cache.set('third', 'c');
  cache.set('second', 'bbbbb');
  assertCache(cache, [['second', 'bbbbb']]);
  assert.equal(cache.has('first'), false);
  assert.equal(cache.has('third'), false);

  cache.set('second', 'bb');
  cache.set('fourth', 'ddd');
  assertCache(cache, [['fourth', 'ddd'], ['second', 'bb']]);
  assert.equal(cache.get('second'), 'bb');
  cache.set('fifth', 'e');
  assertCache(cache, [['fifth', 'e'], ['second', 'bb']]);
});

test('fetch-size compatibility: concurrent callers deduplicate and cached fetches update recency', async () => {
  const result = deferred();
  let calls = 0;
  const cache = new Cache({
    max: 3,
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: () => {
      calls++;
      return result.promise;
    },
  });
  cache.set('existing', 'aa');
  const firstResult = cache.fetch('shared');
  const secondResult = cache.fetch('shared');
  assert.equal(calls, 1);
  assert.equal(cache.calculatedSize, 2);
  result.resolve('bbb');
  assert.deepEqual(await Promise.all([firstResult, secondResult]), ['bbb', 'bbb']);
  assertCache(cache, [['shared', 'bbb'], ['existing', 'aa']]);
  assert.equal(await cache.fetch('existing'), 'aa');
  assert.equal(calls, 1);
  assertCache(cache, [['existing', 'aa'], ['shared', 'bbb']]);
  cache.set('new', 'c');
  assertCache(cache, [['new', 'c'], ['existing', 'aa']]);
  assert.equal(cache.has('shared'), false);
});

test('fetch-size compatibility: an evicted fetch completion cannot overwrite a reused slot', async () => {
  const first = deferred();
  const second = deferred();
  const cache = new Cache({
    max: 2,
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: key => (key === 'first' ? first.promise : second.promise),
  });
  const firstResult = cache.fetch('first');
  const secondResult = cache.fetch('second');
  cache.set('replacement', 'cc');
  assert.equal(cache.has('first'), false);
  second.resolve('bbb');
  assert.equal(await secondResult, 'bbb');
  assertCache(cache, [['second', 'bbb'], ['replacement', 'cc']]);
  first.resolve('aaaa');
  assert.equal(await firstResult, 'aaaa');
  assertCache(cache, [['second', 'bbb'], ['replacement', 'cc']]);
  assert.equal(cache.has('first'), false);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(
  dirname(fileURLToPath(import.meta.url)),
  false
);
after(cleanup);

function deferred() {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

function controlledFetch(options = {}) {
  const completion = deferred();
  const started = deferred();
  const calls = [];
  const cache = new Cache({
    max: 2,
    ...options,
    fetchMethod: (key, stale, { signal }) => {
      calls.push({ key, stale, signal });
      started.resolve(signal);
      return completion.promise;
    },
  });
  return { cache, completion, started: started.promise, calls };
}

function observe(pending) {
  return pending.then(
    value => ({ status: 'fulfilled', value }),
    reason => ({ status: 'rejected', reason })
  );
}

async function nextTurnOutcome(outcome) {
  const unsettled = Symbol('provider still pending');
  const result = await Promise.race([
    outcome,
    new Promise(resolve => setImmediate(resolve, unsettled)),
  ]);
  assert.notStrictEqual(result, unsettled, 'fetch must settle without waiting for its provider');
  return result;
}

function assertCancelled(result, signal) {
  assert.equal(signal.aborted, true);
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, signal.reason);
}

test('fetch cancellation: deleting a pending entry rejects with its signal reason', async () => {
  let resolveProvider;
  let providerSignal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      providerSignal = signal;
      return new Promise(resolve => { resolveProvider = resolve; });
    },
  });

  const pending = cache.fetch('pending');
  cache.delete('pending');
  assert.equal(providerSignal.aborted, true);
  resolveProvider('late value');
  await assert.rejects(pending, reason => {
    assert.strictEqual(reason, providerSignal.reason);
    return true;
  });
  assert.equal(cache.has('pending'), false);
});

const invalidations = [
  {
    name: 'eviction',
    invalidate: cache => cache.set('other', 'surviving entry'),
    check: cache => {
      assert.equal(cache.has('pending'), false);
      assert.equal(cache.get('other'), 'surviving entry');
    },
  },
  {
    name: 'deletion',
    invalidate: cache => cache.delete('pending'),
    check: cache => assert.equal(cache.has('pending'), false),
  },
  {
    name: 'replacement',
    invalidate: cache => cache.set('pending', 'explicit replacement'),
    check: cache => assert.equal(cache.get('pending'), 'explicit replacement'),
  },
  {
    name: 'clear',
    invalidate: cache => cache.clear(),
    check: cache => assert.equal(cache.size, 0),
  },
];

for (const { name, invalidate, check } of invalidations) {
  test(`fetch cancellation: ${name} rejects before an uncooperative provider settles`, async () => {
    const { cache, completion, started } = controlledFetch({ max: 1 });
    const outcome = observe(cache.fetch('pending'));
    const signal = await started;
    invalidate(cache);

    try {
      assertCancelled(await nextTurnOutcome(outcome), signal);
      check(cache);
    } finally {
      completion.resolve('late provider value');
      await outcome;
      await new Promise(resolve => setImmediate(resolve));
    }
    check(cache);
  });
}

test('fetch cancellation: a late provider rejection cannot replace the abort reason or delete a replacement', async () => {
  const { cache, completion, started } = controlledFetch();
  const outcome = observe(cache.fetch('pending'));
  const signal = await started;
  cache.set('pending', 'explicit replacement');
  completion.reject(new Error('unrelated provider failure'));

  assertCancelled(await outcome, signal);
  assert.equal(cache.get('pending'), 'explicit replacement');
});

test('fetch cancellation: concurrent callers share one provider and one abort reason', async () => {
  const { cache, completion, started, calls } = controlledFetch();
  const first = observe(cache.fetch('pending'));
  const second = observe(cache.fetch('pending'));
  const signal = await started;
  assert.equal(calls.length, 1);
  cache.delete('pending');

  try {
    assertCancelled(await nextTurnOutcome(first), signal);
    assertCancelled(await nextTurnOutcome(second), signal);
  } finally {
    completion.resolve('late shared value');
    await Promise.all([first, second]);
  }
  assert.equal(cache.has('pending'), false);
});

test('fetch cancellation: a late old fetch cannot interfere with a new fetch for the same key', async () => {
  const providers = [deferred(), deferred()];
  const signals = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      const provider = providers[signals.length];
      signals.push(signal);
      return provider.promise;
    },
  });
  const first = observe(cache.fetch('pending'));
  cache.delete('pending');
  const second = cache.fetch('pending');
  assert.equal(signals.length, 2);

  providers[0].resolve('obsolete result');
  assertCancelled(await first, signals[0]);
  assert.equal(signals[1].aborted, false);
  providers[1].resolve('current result');
  assert.equal(await second, 'current result');
  assert.equal(cache.get('pending'), 'current result');
});

test('fetch preservation: successful concurrent calls are deduplicated and cached', async () => {
  const { cache, completion, started, calls } = controlledFetch();
  const first = cache.fetch('pending');
  const second = cache.fetch('pending');
  await started;
  assert.equal(calls.length, 1);
  const value = { fetched: true };
  completion.resolve(value);

  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(cache.get('pending'), value);
  assert.strictEqual(await cache.fetch('pending'), value);
  assert.equal(calls.length, 1);
});

test('fetch preservation: a successful forced refresh replaces the cached value', async () => {
  const { cache, completion, started, calls } = controlledFetch();
  cache.set('pending', 'old value');
  const pending = cache.fetch('pending', { forceRefresh: true });
  await started;
  assert.equal(calls[0].stale, 'old value');
  completion.resolve('fresh value');

  assert.equal(await pending, 'fresh value');
  assert.equal(cache.get('pending'), 'fresh value');
});

test('fetch preservation: ordinary rejection keeps the exact provider error', async () => {
  const { cache, completion, started } = controlledFetch();
  const outcome = observe(cache.fetch('pending'));
  await started;
  const error = { providerFailure: true };
  completion.reject(error);

  const result = await outcome;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, error);
  assert.equal(cache.has('pending'), false);
});

test('fetch preservation: allowStaleOnFetchRejection returns and retains the previous value', async () => {
  const { cache, completion, started } = controlledFetch();
  const stale = { cached: true };
  cache.set('pending', stale);
  const pending = cache.fetch('pending', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  });
  await started;
  completion.reject(new Error('refresh failed'));

  assert.strictEqual(await pending, stale);
  assert.strictEqual(cache.get('pending'), stale);
});

test('fetch preservation: stale-on-rejection cancellation returns stale without overwriting a replacement', async () => {
  const { cache, completion, started } = controlledFetch();
  const stale = { cached: true };
  const replacement = { replacement: true };
  cache.set('pending', stale);
  const outcome = observe(cache.fetch('pending', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  }));
  const signal = await started;
  cache.set('pending', replacement);

  try {
    assert.equal(signal.aborted, true);
    const result = await nextTurnOutcome(outcome);
    assert.equal(result.status, 'fulfilled');
    assert.strictEqual(result.value, stale);
  } finally {
    completion.resolve('late refresh');
    await outcome;
    await new Promise(resolve => setImmediate(resolve));
  }
  assert.strictEqual(cache.get('pending'), replacement);
});

test('fetch preservation: a stale background refresh may fail without a waiting caller', async () => {
  const { cache, completion, started } = controlledFetch({
    allowStaleOnFetchRejection: true,
  });
  cache.set('pending', 'stale value');
  assert.equal(await cache.fetch('pending', {
    forceRefresh: true,
    allowStale: true,
  }), 'stale value');
  await started;
  completion.reject(new Error('background failure'));
  await new Promise(resolve => setImmediate(resolve));

  assert.equal(cache.get('pending'), 'stale value');
});

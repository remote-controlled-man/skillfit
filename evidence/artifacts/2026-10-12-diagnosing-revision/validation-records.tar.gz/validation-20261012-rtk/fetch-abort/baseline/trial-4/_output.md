我会使用 diagnosing-bugs 技能，先检查本地实现和测试约定，再修复取消行为并添加可直接运行的回归测试。

回归测试已在原实现上失败：`node --test fetch-abort.test.mjs` 报告 `Missing expected rejection`，确认淘汰后的晚到结果没有让调用方拒绝。

我会依次验证三个假设：① abort 没有直接结束调用方的 Promise，导致未结束的 provider 让调用方一直等待；② 缓存条目变化后，完成回调跳过了取消原因检查；③ 晚到结果的写回缺少条目归属检查，可能覆盖替换值或重新插入已删除条目。

已定位到两个原因：取消事件没有直接拒绝等待中的 Promise；成功回调在发现已取消时只跳过写回，仍返回 provider 的结果。新增测试在原实现上有 9 项失败，正常成功、并发去重和 stale-on-rejection 的 3 项测试通过。

修复会让 abort 直接拒绝等待，原样传递 `signal.reason`，并在写回前确认缓存中仍是本次后台请求。

修复后，新增 12 项回归测试和原有测试全部通过。测试覆盖了 provider 永不结束时的及时取消、取消原因的对象身份、晚到结果不覆盖或重新插入条目，以及成功请求、并发去重和 stale-on-rejection。正在确认测试文件可直接执行，且受保护文件未改动。

已修复取消语义：abort 会及时以原始 `signal.reason` 拒绝，无需等待 provider；晚到结果不会覆盖替换值或重新插入已删除条目。保留并发去重、正常成功和 stale-on-rejection 行为。

新增可执行 `fetch-abort.test.mjs`，共 12 项测试；原实现上 9 项失败，修复后全部通过。

验证通过：

- `node --test test.mjs fetch-abort.test.mjs`：13/13
- `npm test`
- `git diff --check`

现有测试、运行适配器、元数据和许可证均未修改。
#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

const outcome = promise => promise.then(
  value => ({ status: 'fulfilled', value }),
  reason => ({ status: 'rejected', reason }),
);

const deferred = () => {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
};

test('fetch abort regression: eviction rejects with the provider signal reason after a late fulfillment', async () => {
  let complete;
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return new Promise(resolve => { complete = resolve; });
    },
  });
  const pending = cache.fetch('pending');
  const rejected = assert.rejects(pending, reason => {
    assert.strictEqual(reason, signal.reason);
    return true;
  });
  cache.set('replacement', 'explicit value');
  assert.equal(signal.aborted, true);
  complete('late provider value');
  await rejected;
  assert.equal(cache.has('pending'), false);
  assert.equal(cache.get('replacement'), 'explicit value');
});

for (const [operation, max, cancel] of [
  ['eviction', 1, cache => cache.set('other', 'other value')],
  ['deletion', 2, cache => cache.delete('pending')],
  ['replacement', 2, cache => cache.set('pending', 'explicit value')],
  ['clear', 2, cache => cache.clear()],
]) {
  test(`fetch abort prompt settlement: ${operation} rejects even when the provider never settles`, async () => {
    let signal;
    const cache = new Cache({
      max,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return new Promise(() => {});
      },
    });
    if (max > 1) cache.set('anchor', 'anchor value');
    const pending = outcome(cache.fetch('pending'));
    cancel(cache);
    assert.equal(signal.aborted, true);
    const result = await Promise.race([
      pending,
      setImmediate({ status: 'pending' }),
    ]);
    assert.equal(result.status, 'rejected');
    assert.strictEqual(result.reason, signal.reason);
  });
}

for (const completion of ['fulfillment', 'rejection']) {
  test(`fetch abort late ${completion}: an explicit replacement survives provider completion`, async () => {
    const provider = deferred();
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    const pending = outcome(cache.fetch('pending'));
    cache.set('pending', 'explicit value');
    if (completion === 'fulfillment') provider.resolve('late provider value');
    else provider.reject(new Error('late provider failure'));
    const result = await pending;
    assert.equal(result.status, 'rejected');
    assert.strictEqual(result.reason, signal.reason);
    await setImmediate();
    assert.equal(cache.get('pending'), 'explicit value');
    assert.equal(cache.size, 1);
  });
}

test('fetch abort late fulfillment: deletion does not reinsert the removed key', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 2, fetchMethod: () => provider.promise });
  const pending = outcome(cache.fetch('pending'));
  cache.delete('pending');
  provider.resolve('late provider value');
  assert.equal((await pending).status, 'rejected');
  await setImmediate();
  assert.equal(cache.has('pending'), false);
  assert.equal(cache.size, 0);
});

test('fetch abort renewed fetch: an old provider cannot overwrite a new fetch for the same key', async () => {
  const providers = [deferred(), deferred()];
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => providers[calls++].promise,
  });
  const first = outcome(cache.fetch('key'));
  cache.delete('key');
  const second = cache.fetch('key');
  providers[1].resolve('new value');
  assert.equal(await second, 'new value');
  providers[0].resolve('old value');
  assert.equal((await first).status, 'rejected');
  await setImmediate();
  assert.equal(cache.get('key'), 'new value');
  assert.equal(calls, 2);
});

test('fetch preservation: concurrent callers share one provider and cache its successful value', async () => {
  const provider = deferred();
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => { calls++; return provider.promise; },
  });
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.equal(calls, 1);
  const value = { result: 'provider value' };
  provider.resolve(value);
  const results = await Promise.all([first, second]);
  assert.strictEqual(results[0], value);
  assert.strictEqual(results[1], value);
  assert.strictEqual(cache.get('key'), value);
  assert.strictEqual(await cache.fetch('key'), value);
  assert.equal(calls, 1);
});

test('fetch preservation: stale-on-rejection returns and retains the cached value', async () => {
  const provider = deferred();
  const stale = { result: 'cached value' };
  const cache = new Cache({
    max: 2,
    allowStaleOnFetchRejection: true,
    fetchMethod: (_key, value) => {
      assert.strictEqual(value, stale);
      return provider.promise;
    },
  });
  cache.set('key', stale);
  const pending = cache.fetch('key', { forceRefresh: true });
  provider.reject(new Error('provider failure'));
  assert.strictEqual(await pending, stale);
  assert.strictEqual(cache.get('key'), stale);
});

test('fetch preservation: ordinary provider rejection keeps its original reason', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 2, fetchMethod: () => provider.promise });
  const pending = outcome(cache.fetch('key'));
  const reason = { failure: 'provider rejection' };
  provider.reject(reason);
  const result = await pending;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(cache.has('key'), false);
});

我会先阅读本地实现、项目说明和测试入口，复现取消问题，再修复并添加可直接运行的回归测试。我会使用 diagnosing-bugs 技能推进排查。

已复现：`node --test fetch-cancellation.test.mjs` 失败。删除条目后，provider 收到的 signal 已取消，但调用方仍未结算，触发了 250ms 超时。

接下来按这三个假设检查：

1. 取消只通知了 provider，调用方仍在等待 provider 结算；补上直接拒绝路径应能解除挂起。
2. 完成回调把取消当作普通返回值；provider 迟到完成时可能导致 `undefined` 或错误值。
3. 缓存写回缺少条目身份检查；旧请求可能覆盖替换值或重新插入已删除条目。
已确认两个原因：取消事件没有直接拒绝 fetch 的内部 Promise；成功回调在 signal 已取消时仍返回 provider 的结果。第二个复现中，替换值保留在缓存里，但调用方错误地收到了迟到的 provider 值。

我会让取消事件直接拒绝 Promise，并检查完成回调执行前是否已取消。回归测试会覆盖淘汰、删除、替换、迟到完成、并发去重和 stale-on-rejection 行为。

修复后，新增的 13 个测试全部通过；修复前，其中 9 个失败。provider 永不结算时，取消现在也能立即拒绝调用方，拒绝值与 `signal.reason` 是同一对象。迟到完成不会改写缓存，去重、正常成功和 stale-on-rejection 测试也通过。

现有 `npm test` 已通过。我正在核对最终差异，确认改动仅限实现和新增测试。

已修复取消语义：调用方会及时以原始 `AbortSignal.reason` 拒绝，无需等待 provider；迟到完成不会覆盖替换值或恢复已删除条目。

新增可执行的 `fetch-cancellation.test.mjs`，包含 13 个测试，原实现中 9 个失败，修复后全部通过。并发去重、正常成功和 stale-on-rejection 行为保留。

验证：`npm test` 通过，合并运行 14/14 通过，`git diff --check` 通过。既有测试、runtime adapter、元数据和许可证均未修改。
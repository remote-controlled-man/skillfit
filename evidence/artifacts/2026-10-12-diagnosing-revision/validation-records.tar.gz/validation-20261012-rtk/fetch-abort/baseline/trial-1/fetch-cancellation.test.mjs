#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

async function promptly(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle after cancellation')), 250);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

function deferred() {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

const cancellations = [
  ['eviction', cache => cache.set('other', 'survivor'), [['other', 'survivor']]],
  ['deletion', cache => cache.delete('target'), []],
  ['replacement', cache => cache.set('target', 'replacement'), [['target', 'replacement']]],
];

for (const [name, cancel, expectedEntries] of cancellations) {
  test(`fetch cancellation by ${name} rejects promptly when the provider never settles`, async () => {
    let signal;
    let calls = 0;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        calls++;
        signal = options.signal;
        return new Promise(() => {});
      },
    });
    const pending = [cache.fetch('target'), cache.fetch('target')];
    assert.equal(calls, 1);
    const rejected = pending.map(promise =>
      assert.rejects(promptly(promise), reason => reason === signal.reason));
    cancel(cache);
    assert.equal(signal.aborted, true);
    await Promise.all(rejected);
    assert.deepEqual([...cache.entries()], expectedEntries);
  });

  test(`fetch cancellation by ${name} rejects the signal reason instead of a late provider value`, async () => {
    const provider = deferred();
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    const pending = cache.fetch('target');
    cancel(cache);
    provider.resolve({ bogus: name });
    await assert.rejects(promptly(pending), reason => reason === signal.reason);
    // Let the late provider's completion callbacks run before checking the cache.
    await new Promise(resolve => setImmediate(resolve));
    assert.deepEqual([...cache.entries()], expectedEntries);
  });
}

test('fetch cancellation wins over an already resolved provider before its callbacks run', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return 'provider value';
    },
  });
  const pending = cache.fetch('target');
  cache.delete('target');
  await assert.rejects(promptly(pending), reason => reason === signal.reason);
  assert.equal(cache.has('target'), false);
});

test('fetch cancellation preserves the signal reason when the provider rejects with another error', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return new Promise((_, reject) => {
        signal.addEventListener('abort', () => reject(new Error('provider failure')));
      });
    },
  });
  const pending = cache.fetch('target');
  cache.delete('target');
  await assert.rejects(promptly(pending), reason => reason === signal.reason);
});

test('fetch cancellation leaves a subsequent fetch of the same key intact after late resolution', async () => {
  const oldProvider = deferred();
  const newProvider = deferred();
  let calls = 0;
  let oldSignal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      if (++calls === 1) {
        oldSignal = options.signal;
        return oldProvider.promise;
      }
      return newProvider.promise;
    },
  });
  const oldPending = cache.fetch('target');
  const oldRejected = assert.rejects(promptly(oldPending), reason => reason === oldSignal.reason);
  cache.delete('target');
  const newPending = cache.fetch('target');
  await oldRejected;
  oldProvider.resolve('obsolete');
  await new Promise(resolve => setImmediate(resolve));
  newProvider.resolve('fresh');
  assert.equal(await promptly(newPending), 'fresh');
  assert.equal(cache.get('target'), 'fresh');
  assert.equal(calls, 2);
});

test('ordinary concurrent fetches share one provider and cache the successful result', async () => {
  const provider = deferred();
  const value = { result: 'success' };
  let calls = 0;
  const cache = new Cache({
    max: 1,
    fetchMethod: () => {
      calls++;
      return provider.promise;
    },
  });
  const first = cache.fetch('target');
  const second = cache.fetch('target');
  assert.equal(calls, 1);
  provider.resolve(value);
  const results = await promptly(Promise.all([first, second]));
  assert.equal(results[0], value);
  assert.equal(results[1], value);
  assert.equal(cache.get('target'), value);
  assert.equal(await cache.fetch('target'), value);
  assert.equal(calls, 1);
});

test('ordinary provider rejection propagates its exact error and removes the failed entry', async () => {
  const provider = deferred();
  const failure = { failure: 'provider rejection' };
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  const pending = cache.fetch('target');
  provider.reject(failure);
  await assert.rejects(promptly(pending), reason => reason === failure);
  assert.equal(cache.has('target'), false);
});

test('allowStaleOnFetchRejection returns and retains the previous value after a failed refresh', async () => {
  const provider = deferred();
  const stale = { result: 'previous value' };
  const cache = new Cache({
    max: 1,
    allowStaleOnFetchRejection: true,
    fetchMethod: (_key, previous) => {
      assert.equal(previous, stale);
      return provider.promise;
    },
  });
  cache.set('target', stale);
  const pending = cache.fetch('target', { forceRefresh: true });
  provider.reject(new Error('refresh failed'));
  assert.equal(await promptly(pending), stale);
  assert.equal(cache.get('target'), stale);
});

test('allowStale background refresh remains safe when its abandoned provider later rejects', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  cache.set('target', 'stale');
  assert.equal(await cache.fetch('target', { forceRefresh: true, allowStale: true }), 'stale');
  cache.set('target', 'replacement');
  provider.reject(new Error('late background failure'));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(cache.get('target'), 'replacement');
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { setImmediate } from 'node:timers/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)));
after(cleanup);

const observe = pending => pending.then(
  value => ({ state: 'fulfilled', value }),
  reason => ({ state: 'rejected', reason }),
);

const promptly = outcome => Promise.race([
  outcome,
  setImmediate({ state: 'pending' }),
]);

const invalidations = [
  ['eviction', cache => cache.set('replacement', 'kept')],
  ['deletion', cache => cache.delete('pending')],
  ['replacement', cache => cache.set('pending', 'kept')],
  ['clear', cache => cache.clear()],
];

for (const [name, invalidate] of invalidations) {
  test(`fetch-abort: ${name} promptly rejects deduplicated callers with the signal reason`, async () => {
    let providerSignal;
    let calls = 0;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, { signal }) => {
        calls++;
        providerSignal = signal;
        return new Promise(() => {});
      },
    });
    const first = observe(cache.fetch('pending'));
    const second = observe(cache.fetch('pending'));
    assert.equal(calls, 1);
    invalidate(cache);
    assert.equal(providerSignal.aborted, true);
    for (const outcome of [first, second]) {
      const result = await promptly(outcome);
      assert.equal(result.state, 'rejected');
      assert.strictEqual(result.reason, providerSignal.reason);
    }
  });

  test(`fetch-abort: ${name} rejects a late provider value without changing cache contents`, async () => {
    let providerSignal;
    let complete;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, { signal }) => {
        providerSignal = signal;
        return new Promise(resolve => { complete = resolve; });
      },
    });
    const outcome = observe(cache.fetch('pending'));
    invalidate(cache);
    assert.equal(providerSignal.aborted, true);
    // Let the provider finish, even if cancellation has already settled fetch().
    complete({ bogus: name });
    await setImmediate();
    assert.equal(cache.get('pending'), name === 'replacement' ? 'kept' : undefined);
    assert.equal(cache.size, name === 'eviction' || name === 'replacement' ? 1 : 0);
    if (name === 'eviction') assert.equal(cache.get('replacement'), 'kept');
    const result = await promptly(outcome);
    assert.equal(result.state, 'rejected');
    assert.strictEqual(result.reason, providerSignal.reason);
  });
}

test('fetch-abort: deleting one of several entries rejects a late undefined completion', async () => {
  let providerSignal;
  let complete;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, { signal }) => {
      providerSignal = signal;
      return new Promise(resolve => { complete = resolve; });
    },
  });
  cache.set('other', 'kept');
  const outcome = observe(cache.fetch('pending'));
  assert.equal(cache.delete('pending'), true);
  complete(undefined);
  await setImmediate();
  assert.equal(cache.has('pending'), false);
  assert.equal(cache.get('other'), 'kept');
  assert.equal(cache.size, 1);
  const result = await promptly(outcome);
  assert.equal(result.state, 'rejected');
  assert.strictEqual(result.reason, providerSignal.reason);
});

test('fetch-abort: replacement wins over a late provider rejection', async () => {
  let providerSignal;
  let fail;
  const providerError = new Error('provider failed later');
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      providerSignal = signal;
      return new Promise((_resolve, reject) => { fail = reject; });
    },
  });
  const outcome = observe(cache.fetch('pending'));
  cache.set('pending', 'kept');
  fail(providerError);
  await setImmediate();
  assert.equal(cache.get('pending'), 'kept');
  const result = await promptly(outcome);
  assert.equal(result.state, 'rejected');
  assert.strictEqual(result.reason, providerSignal.reason);
});

test('fetch-abort: cancellation wins over a provider already resolved in the same turn', async () => {
  let providerSignal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      providerSignal = signal;
      return Promise.resolve('bogus');
    },
  });
  const outcome = observe(cache.fetch('pending'));
  cache.delete('pending');
  const result = await promptly(outcome);
  assert.equal(result.state, 'rejected');
  assert.strictEqual(result.reason, providerSignal.reason);
  assert.equal(cache.size, 0);
});

test('fetch-abort: ordinary concurrent successful fetches share one provider and cache its value', async () => {
  let calls = 0;
  let complete;
  const value = { cached: true };
  const cache = new Cache({
    max: 1,
    fetchMethod: () => {
      calls++;
      return new Promise(resolve => { complete = resolve; });
    },
  });
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.equal(calls, 1);
  complete(value);
  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(cache.get('key'), value);
  assert.strictEqual(await cache.fetch('key'), value);
  assert.equal(calls, 1);
});

test('fetch-abort: a synchronous provider still succeeds', async () => {
  const cache = new Cache({ max: 1, fetchMethod: () => 'value' });
  assert.equal(await cache.fetch('key'), 'value');
  assert.equal(cache.get('key'), 'value');
});

test('fetch-abort: ordinary rejection preserves the provider error and removes the failed entry', async () => {
  const reason = { providerFailure: true };
  const cache = new Cache({ max: 1, fetchMethod: () => Promise.reject(reason) });
  const result = await observe(cache.fetch('key'));
  assert.equal(result.state, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(cache.has('key'), false);
});

test('fetch-abort: stale-on-rejection returns and retains the previous value', async () => {
  const stale = { previous: true };
  const cache = new Cache({
    max: 1,
    allowStaleOnFetchRejection: true,
    fetchMethod: (_key, previous) => {
      assert.strictEqual(previous, stale);
      return Promise.reject(new Error('refresh failed'));
    },
  });
  cache.set('key', stale);
  assert.strictEqual(await cache.fetch('key', { forceRefresh: true }), stale);
  assert.strictEqual(cache.get('key'), stale);
});

test('fetch-abort: a successful background refresh updates the cached stale value', async () => {
  let complete;
  const cache = new Cache({
    max: 1,
    fetchMethod: () => new Promise(resolve => { complete = resolve; }),
  });
  cache.set('key', 'stale');
  assert.equal(await cache.fetch('key', { forceRefresh: true, allowStale: true }), 'stale');
  complete('fresh');
  await setImmediate();
  assert.equal(cache.get('key'), 'fresh');
});

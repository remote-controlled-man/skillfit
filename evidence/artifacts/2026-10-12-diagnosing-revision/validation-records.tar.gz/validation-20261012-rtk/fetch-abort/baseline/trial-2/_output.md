我会按 diagnosing-bugs 技能先复现取消问题，再修复实现并添加独立的回归测试；只使用本地源码和 Node 内置模块。

已复现：`node --test fetch-abort.test.mjs` 失败，淘汰触发了 provider 的 abort signal，但 `fetch()` 到下一轮事件循环仍未结束。

接下来验证三个可能原因：
1. abort 只通知 provider，没有让调用方的 Promise 拒绝；永不结束的 provider 会使它一直挂起。
2. 取消仅在 provider 返回时处理；延迟返回可能让调用方收到错误的值。
3. 旧请求完成时没有确认条目归属；删除或替换后可能回写缓存。

原因已确认：原实现直接让内部 Promise 接管 provider 的结果，也没有把 abort 连接到拒绝路径。取消后，它仍会等待 provider；provider 返回时，成功回调只跳过缓存写入，却继续把返回值交给调用方。

新增测试在原实现上有 11 项失败，涵盖挂起、错误返回值和错误拒绝原因。修复会让 abort 直接触发拒绝，并保留现有的陈旧值回退逻辑。

已修复取消语义：`fetch()` 及时以原始 `AbortSignal.reason` 拒绝，无需等待 provider；迟到结果不会覆盖替换值或恢复已移除条目。保留并发去重、正常成功和陈旧值回退行为。

新增可执行的 `fetch-abort.test.mjs`，含 16 个公开行为测试。原实现有 11 项失败，修复后新增测试全部通过。

验证通过：合并运行 17 项测试、`npm test`、直接执行新增测试及 `git diff --check`。既有测试、运行适配器、元数据和许可证均未修改。
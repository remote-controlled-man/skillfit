#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

const nextTurn = () => new Promise(resolve => setImmediate(resolve));
const outcome = promise => promise.then(
  value => ({ status: 'fulfilled', value }),
  reason => ({ status: 'rejected', reason }),
);

function deferred() {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => { resolve = res; reject = rej; });
  return { promise, resolve, reject };
}

function harness(options = {}) {
  const requests = [];
  const cache = new Cache({
    max: 2,
    ...options,
    fetchMethod: (key, stale, { signal }) => {
      const provider = deferred();
      requests.push({ key, stale, signal, ...provider });
      return provider.promise;
    },
  });
  return { cache, requests };
}

async function assertCancelled(pending, signal) {
  assert.equal(signal.aborted, true);
  const result = await Promise.race([
    pending,
    nextTurn().then(() => ({ status: 'pending' })),
  ]);
  assert.equal(result.status, 'rejected', 'fetch must reject without waiting for its provider');
  assert.strictEqual(result.reason, signal.reason);
}

test('fetch cancellation historical regression: deletion rejects with the actual signal reason', async () => {
  let signal;
  let resolveProvider;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return new Promise(resolve => { resolveProvider = resolve; });
    },
  });
  const pending = cache.fetch('removed').then(
    value => ({ status: 'fulfilled', value }),
    reason => ({ status: 'rejected', reason }),
  );

  cache.delete('removed');
  assert.equal(signal.aborted, true);
  resolveProvider('bogus late value');

  const result = await pending;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, signal.reason);
  assert.equal(cache.has('removed'), false);
});

for (const action of ['eviction', 'deletion', 'clear', 'replacement']) {
  test(`fetch cancellation promptness: ${action} settles before an unresponsive provider`, async () => {
    const { cache, requests } = harness({ max: action === 'deletion' ? 2 : 1 });
    const replacement = { explicitly: 'set' };
    if (action === 'deletion') cache.set('anchor', 'kept');
    const pending = outcome(cache.fetch('pending'));
    const request = requests[0];

    if (action === 'eviction') cache.set('other', replacement);
    else if (action === 'deletion') cache.delete('pending');
    else if (action === 'clear') cache.clear();
    else cache.set('pending', replacement);

    await assertCancelled(pending, request.signal);
    request.resolve('bogus late value');
    await nextTurn();
    if (action === 'replacement') {
      assert.strictEqual(cache.get('pending'), replacement);
    } else {
      assert.equal(cache.has('pending'), false);
    }
    if (action === 'eviction') assert.strictEqual(cache.get('other'), replacement);
    if (action === 'deletion') assert.equal(cache.get('anchor'), 'kept');
    if (action === 'clear') assert.equal(cache.size, 0);
  });
}

test('fetch cancellation race: queued provider success cannot overwrite an explicit replacement', async () => {
  const { cache, requests } = harness();
  const pending = outcome(cache.fetch('race'));
  const replacement = { source: 'explicit set' };
  requests[0].resolve('queued provider value');
  await new Promise(resolve => queueMicrotask(() => {
    cache.set('race', replacement);
    resolve();
  }));

  await assertCancelled(pending, requests[0].signal);
  assert.strictEqual(cache.get('race'), replacement);
});

test('fetch cancellation deduplication: concurrent callers receive the same abort reason', async () => {
  const { cache, requests } = harness();
  const first = outcome(cache.fetch('shared'));
  const second = outcome(cache.fetch('shared'));
  assert.equal(requests.length, 1);
  cache.delete('shared');

  await Promise.all([
    assertCancelled(first, requests[0].signal),
    assertCancelled(second, requests[0].signal),
  ]);
});

for (const completion of ['resolve', 'reject']) {
  test(`fetch cancellation reuse: old provider ${completion} leaves a newer fetch intact`, async () => {
    const { cache, requests } = harness({ max: 1 });
    const old = outcome(cache.fetch('reused'));
    cache.delete('reused');
    await assertCancelled(old, requests[0].signal);
    const current = cache.fetch('reused');
    assert.equal(requests.length, 2);

    requests[0][completion](completion === 'resolve' ? 'old value' : new Error('old failure'));
    await nextTurn();
    assert.equal(requests[1].signal.aborted, false);
    const deduplicated = cache.fetch('reused');
    assert.equal(requests.length, 2);
    const value = { source: 'new provider' };
    requests[1].resolve(value);
    assert.strictEqual(await current, value);
    assert.strictEqual(await deduplicated, value);
    assert.strictEqual(cache.get('reused'), value);
  });
}

test('fetch cancellation late rejection: explicit replacement survives provider failure', async () => {
  const { cache, requests } = harness();
  const pending = outcome(cache.fetch('replaced'));
  const replacement = { source: 'replacement' };
  cache.set('replaced', replacement);
  await assertCancelled(pending, requests[0].signal);
  requests[0].reject(new Error('late failure'));
  await nextTurn();
  assert.strictEqual(cache.get('replaced'), replacement);
});

test('fetch compatibility success: concurrent requests share one provider and cache its value', async () => {
  const { cache, requests } = harness();
  const first = cache.fetch('success');
  const second = cache.fetch('success');
  assert.equal(requests.length, 1);
  const value = { source: 'provider' };
  requests[0].resolve(value);

  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(cache.get('success'), value);
  assert.strictEqual(await cache.fetch('success'), value);
  assert.equal(requests.length, 1);
});

test('fetch compatibility rejection: provider error identity is preserved and entry is removed', async () => {
  const { cache, requests } = harness();
  const pending = outcome(cache.fetch('failure'));
  const error = { source: 'provider error' };
  requests[0].reject(error);
  const result = await pending;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, error);
  assert.equal(cache.has('failure'), false);
});

for (const scope of ['cache', 'fetch']) {
  test(`fetch compatibility stale rejection: ${scope} option returns and retains the previous value`, async () => {
    const { cache, requests } = harness(scope === 'cache' ? { allowStaleOnFetchRejection: true } : {});
    const stale = { source: 'previous value' };
    cache.set('stale', stale);
    const pending = cache.fetch('stale', {
      forceRefresh: true,
      ...(scope === 'fetch' ? { allowStaleOnFetchRejection: true } : {}),
    });
    assert.strictEqual(requests[0].stale, stale);
    requests[0].reject(new Error('refresh failed'));
    assert.strictEqual(await pending, stale);
    assert.strictEqual(cache.get('stale'), stale);
  });
}

test('fetch compatibility retained stale: noDeleteOnFetchRejection preserves stale while rejecting', async () => {
  const { cache, requests } = harness({ noDeleteOnFetchRejection: true });
  const stale = { source: 'retained' };
  const error = new Error('refresh failure');
  cache.set('retained', stale);
  const pending = outcome(cache.fetch('retained', { forceRefresh: true }));
  requests[0].reject(error);
  const result = await pending;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, error);
  assert.strictEqual(cache.get('retained'), stale);
});

test('fetch compatibility background rejection: stale callers retain their value after refresh fails', async () => {
  const { cache, requests } = harness({ allowStaleOnFetchRejection: true });
  const stale = { source: 'background stale' };
  cache.set('background', stale);
  assert.strictEqual(await cache.fetch('background', { forceRefresh: true, allowStale: true }), stale);
  requests[0].reject(new Error('background failure'));
  await nextTurn();
  assert.strictEqual(cache.get('background'), stale);
});

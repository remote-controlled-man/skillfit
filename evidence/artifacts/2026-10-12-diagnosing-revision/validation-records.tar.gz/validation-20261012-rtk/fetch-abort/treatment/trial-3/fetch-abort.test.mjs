#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function deferred() {
  let resolve, reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

const nextTurn = () => new Promise(resolve => setImmediate(resolve));
const observe = promise => promise.then(
  value => ({ status: 'fulfilled', value }),
  reason => ({ status: 'rejected', reason }),
);

async function assertAborted(outcome, signal) {
  assert.equal(signal.aborted, true);
  const result = await Promise.race([
    outcome,
    nextTurn().then(() => ({ status: 'pending' })),
  ]);
  assert.equal(result.status, 'rejected', 'fetch must reject before the next event-loop turn');
  assert.strictEqual(result.reason, signal.reason);
}

for (const value of [undefined, 'bogus provider value']) {
  test(`fetch cancellation rejects the signal reason when an abort handler resolves ${String(value)}`, async () => {
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return new Promise(resolve => {
          signal.addEventListener('abort', () => resolve(value), { once: true });
        });
      },
    });
    const outcome = observe(cache.fetch('pending'));
    cache.set('other', 'retained');

    await assertAborted(outcome, signal);
    assert.equal(cache.has('pending'), false);
    assert.equal(cache.get('other'), 'retained');
  });
}

const cancellations = [
  ['eviction', cache => cache.set('other', 'retained'), cache => {
    assert.equal(cache.has('pending'), false);
    assert.equal(cache.get('other'), 'retained');
  }],
  ['deletion', cache => cache.delete('pending'), cache => {
    assert.equal(cache.has('pending'), false);
    assert.equal(cache.size, 0);
  }],
  ['replacement', cache => cache.set('pending', 'replacement'), cache => {
    assert.equal(cache.get('pending'), 'replacement');
    assert.equal(cache.size, 1);
  }],
  ['clear', cache => cache.clear(), cache => {
    assert.equal(cache.has('pending'), false);
    assert.equal(cache.size, 0);
  }],
];

for (const [name, cancel, checkCache] of cancellations) {
  test(`fetch ${name} promptly rejects deduplicated callers before the provider settles`, async () => {
    const provider = deferred();
    let signal;
    let calls = 0;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        calls++;
        signal = options.signal;
        return provider.promise;
      },
    });
    const outcomes = [observe(cache.fetch('pending')), observe(cache.fetch('pending'))];
    assert.equal(calls, 1);
    cancel(cache);

    await Promise.all(outcomes.map(outcome => assertAborted(outcome, signal)));
    checkCache(cache);

    provider.resolve('late provider value');
    await nextTurn();
    checkCache(cache);
    assert.equal(calls, 1);
  });
}

test('fetch cancellation wins after provider resolution but before its result is delivered', async () => {
  const provider = deferred();
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
  });
  const outcome = observe(cache.fetch('pending'));
  provider.resolve('superseded provider value');
  await Promise.resolve();
  cache.set('pending', 'replacement');

  await assertAborted(outcome, signal);
  assert.equal(cache.get('pending'), 'replacement');
});

test('fetch cancellation wins after provider rejection but before its error is delivered', async () => {
  const provider = deferred();
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
  });
  const outcome = observe(cache.fetch('pending'));
  provider.reject({ failure: 'superseded provider reason' });
  await Promise.resolve();
  cache.delete('pending');

  await assertAborted(outcome, signal);
  assert.equal(cache.has('pending'), false);
});

test('fetch late rejection after deletion leaves a new fetch of the same key intact', async () => {
  const oldProvider = deferred();
  const newProvider = deferred();
  let oldSignal;
  let calls = 0;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      calls++;
      if (calls === 1) {
        oldSignal = options.signal;
        return oldProvider.promise;
      }
      return newProvider.promise;
    },
  });
  const oldOutcome = observe(cache.fetch('key'));
  cache.delete('key');
  const newFetch = cache.fetch('key');

  await assertAborted(oldOutcome, oldSignal);
  oldProvider.reject(new Error('late provider failure'));
  await nextTurn();
  assert.equal(cache.has('key'), true);
  const joinedFetch = cache.fetch('key');
  assert.equal(calls, 2);

  const value = { source: 'new provider' };
  newProvider.resolve(value);
  assert.strictEqual(await newFetch, value);
  assert.strictEqual(await joinedFetch, value);
  assert.strictEqual(cache.get('key'), value);
});

test('fetch ordinary success shares one provider call and caches the exact returned object', async () => {
  const provider = deferred();
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return provider.promise;
    },
  });
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.equal(calls, 1);
  const value = { result: 'success' };
  provider.resolve(value);

  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(cache.get('key'), value);
  assert.strictEqual(await cache.fetch('key'), value);
  assert.equal(calls, 1);
});

test('fetch synchronous providers still succeed and propagate thrown values', async () => {
  const reason = { failure: 'synchronous provider' };
  const cache = new Cache({
    max: 2,
    fetchMethod: key => {
      if (key === 'failure') throw reason;
      return 'success';
    },
  });

  assert.equal(await cache.fetch('success'), 'success');
  assert.equal(cache.get('success'), 'success');
  await assert.rejects(cache.fetch('failure'), error => error === reason);
  assert.equal(cache.has('failure'), false);
});

test('fetch allowStaleOnFetchRejection still returns and preserves the previous value', async () => {
  const provider = deferred();
  const cache = new Cache({
    max: 1,
    allowStaleOnFetchRejection: true,
    fetchMethod: () => provider.promise,
  });
  const stale = { result: 'previous value' };
  cache.set('key', stale);
  const pending = cache.fetch('key', { forceRefresh: true });
  provider.reject(new Error('provider failed'));

  assert.strictEqual(await pending, stale);
  assert.strictEqual(cache.get('key'), stale);
});

test('fetch allowStaleOnFetchRejection handles cancellation without overwriting a replacement', async () => {
  const provider = deferred();
  const cache = new Cache({
    max: 1,
    allowStaleOnFetchRejection: true,
    fetchMethod: () => provider.promise,
  });
  const stale = { result: 'previous value' };
  cache.set('key', stale);
  const outcome = observe(cache.fetch('key', { forceRefresh: true }));
  cache.set('key', 'replacement');

  const result = await Promise.race([
    outcome,
    nextTurn().then(() => ({ status: 'pending' })),
  ]);
  assert.equal(result.status, 'fulfilled');
  assert.strictEqual(result.value, stale);
  assert.equal(cache.get('key'), 'replacement');

  provider.resolve('late provider value');
  await nextTurn();
  assert.equal(cache.get('key'), 'replacement');
});

test('fetch noDeleteOnFetchRejection preserves the value while rejecting the provider reason', async () => {
  const reason = { failure: 'provider rejection' };
  const cache = new Cache({
    max: 1,
    noDeleteOnFetchRejection: true,
    fetchMethod: () => Promise.reject(reason),
  });
  cache.set('key', 'previous value');

  await assert.rejects(cache.fetch('key', { forceRefresh: true }), error => error === reason);
  assert.equal(cache.get('key'), 'previous value');
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { setImmediate as nextTurn } from 'node:timers/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function deferred() {
  let resolve, reject;
  const promise = new Promise((res, rej) => { resolve = res; reject = rej; });
  return { promise, resolve, reject };
}

function observe(promise) {
  const outcome = { status: 'pending' };
  promise.then(
    value => Object.assign(outcome, { status: 'fulfilled', value }),
    reason => Object.assign(outcome, { status: 'rejected', reason }),
  );
  return outcome;
}

function assertAborted(outcome, signal) {
  assert.equal(signal.aborted, true);
  assert.equal(outcome.status, 'rejected');
  assert.strictEqual(outcome.reason, signal.reason);
}

test('fetch abort regression: eviction rejects even when the provider resolves undefined on abort', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return new Promise(resolve => signal.addEventListener('abort', () => resolve(undefined), { once: true }));
    },
  });
  const outcome = observe(cache.fetch('pending'));
  cache.set('survivor', 'kept');
  await nextTurn();
  assertAborted(outcome, signal);
  assert.equal(cache.has('pending'), false);
  assert.equal(cache.get('survivor'), 'kept');
});

const cancellations = [
  ['eviction', cache => cache.set('survivor', 'kept')],
  ['delete', cache => cache.delete('pending')],
  ['clear', cache => cache.clear()],
  ['replacement', cache => cache.set('pending', 'replacement')],
];

for (const [operation, cancel] of cancellations) {
  test(`fetch abort regression: ${operation} promptly rejects a provider that never settles`, async () => {
    let signal;
    let calls = 0;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        calls++;
        signal = options.signal;
        return new Promise(() => {});
      },
    });
    const first = observe(cache.fetch('pending'));
    const second = observe(cache.fetch('pending'));
    assert.equal(calls, 1);
    cancel(cache);
    // Allow the rejection chain to drain without waiting for the provider.
    await nextTurn();
    assertAborted(first, signal);
    assertAborted(second, signal);
    assert.equal(cache.get('pending'), operation === 'replacement' ? 'replacement' : undefined);
    assert.equal(cache.size, operation === 'replacement' || operation === 'eviction' ? 1 : 0);
  });
}

for (const [operation, cancel] of cancellations) {
  for (const completion of ['resolve', 'reject']) {
    test(`fetch abort regression: ${operation} ignores a late provider ${completion}`, async () => {
      const provider = deferred();
      let signal;
      const cache = new Cache({
        max: 1,
        fetchMethod: (_key, _stale, options) => {
          signal = options.signal;
          return provider.promise;
        },
      });
      const outcome = observe(cache.fetch('pending'));
      cancel(cache);
      provider[completion](completion === 'resolve' ? 'bogus late value' : new Error('late provider rejection'));
      await nextTurn();
      assertAborted(outcome, signal);
      if (operation === 'replacement') {
        assert.equal(cache.get('pending'), 'replacement');
      } else {
        assert.equal(cache.has('pending'), false);
      }
      assert.equal(cache.size, operation === 'replacement' || operation === 'eviction' ? 1 : 0);
      if (operation === 'eviction') assert.equal(cache.get('survivor'), 'kept');
    });
  }
}

test('fetch abort regression: an old completion cannot replace a new fetch after deletion', async () => {
  const oldProvider = deferred();
  const newProvider = deferred();
  let calls = 0;
  let oldSignal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      calls++;
      if (calls === 1) { oldSignal = signal; return oldProvider.promise; }
      return newProvider.promise;
    },
  });
  const oldOutcome = observe(cache.fetch('pending'));
  cache.delete('pending');
  const newFetch = cache.fetch('pending');
  const concurrentFetch = cache.fetch('pending');
  oldProvider.resolve('obsolete');
  await nextTurn();
  assertAborted(oldOutcome, oldSignal);
  assert.equal(calls, 2);
  assert.equal(cache.peek('pending'), undefined);
  newProvider.resolve('fresh');
  assert.equal(await newFetch, 'fresh');
  assert.equal(await concurrentFetch, 'fresh');
  assert.equal(cache.get('pending'), 'fresh');
});

test('fetch abort compatibility: concurrent successful fetches share one provider and cache its result', async () => {
  const provider = deferred();
  const value = { fetched: true };
  let calls = 0;
  const cache = new Cache({ max: 2, fetchMethod: () => { calls++; return provider.promise; } });
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.equal(calls, 1);
  provider.resolve(value);
  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(await cache.fetch('key'), value);
  assert.strictEqual(cache.get('key'), value);
  assert.equal(calls, 1);
});

test('fetch abort compatibility: synchronous provider values are returned and cached', async () => {
  const cache = new Cache({ max: 1, fetchMethod: () => 'fresh' });
  assert.equal(await cache.fetch('key'), 'fresh');
  assert.equal(cache.get('key'), 'fresh');
});

test('fetch abort compatibility: ordinary provider rejection propagates unchanged and removes the entry', async () => {
  const reason = { provider: 'failed' };
  const cache = new Cache({ max: 1, fetchMethod: () => Promise.reject(reason) });
  await assert.rejects(cache.fetch('key'), error => error === reason);
  assert.equal(cache.has('key'), false);
});

test('fetch abort compatibility: allowStaleOnFetchRejection returns and retains the previous value', async () => {
  const stale = { version: 'old' };
  const cache = new Cache({
    max: 1,
    allowStaleOnFetchRejection: true,
    fetchMethod: (_key, value) => { assert.strictEqual(value, stale); throw new Error('provider failed'); },
  });
  cache.set('key', stale);
  assert.strictEqual(await cache.fetch('key', { forceRefresh: true }), stale);
  assert.strictEqual(cache.get('key'), stale);
});

test('fetch abort compatibility: noDeleteOnFetchRejection retains stale data while propagating the failure', async () => {
  const reason = new Error('provider failed');
  const cache = new Cache({ max: 1, noDeleteOnFetchRejection: true, fetchMethod: () => Promise.reject(reason) });
  cache.set('key', 'stale');
  await assert.rejects(cache.fetch('key', { forceRefresh: true }), error => error === reason);
  assert.equal(cache.get('key'), 'stale');
});

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { setImmediate as nextTurn } from 'node:timers/promises';
import Cache from './index.js';

function deferred() {
  let resolve, reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

function observe(promise) {
  return promise.then(
    value => ({ status: 'fulfilled', value }),
    reason => ({ status: 'rejected', reason }),
  );
}

async function expectAbort(observed, signal) {
  assert.equal(signal.aborted, true);
  // Drain promise jobs, with an event-loop turn as a bound. A provider that
  // ignores cancellation must not keep the caller waiting indefinitely.
  const result = await Promise.race([
    observed,
    nextTurn().then(() => ({ status: 'pending' })),
  ]);
  assert.equal(result.status, 'rejected', 'cancelled fetch must promptly reject');
  assert.strictEqual(result.reason, signal.reason);
}

const invalidations = [
  {
    name: 'capacity eviction',
    max: 1,
    invalidate(cache) { cache.set('survivor', 'retained'); },
    verify(cache) {
      assert.equal(cache.has('target'), false);
      assert.equal(cache.get('survivor'), 'retained');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'deleting the sole entry',
    max: 2,
    invalidate(cache) { assert.equal(cache.delete('target'), true); },
    verify(cache) {
      assert.equal(cache.has('target'), false);
      assert.equal(cache.size, 0);
    },
  },
  {
    name: 'deleting one of several entries',
    max: 2,
    prepare(cache) { cache.set('survivor', 'retained'); },
    invalidate(cache) { assert.equal(cache.delete('target'), true); },
    verify(cache) {
      assert.equal(cache.has('target'), false);
      assert.equal(cache.get('survivor'), 'retained');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'explicit replacement',
    max: 2,
    invalidate(cache) { cache.set('target', 'replacement'); },
    verify(cache) {
      assert.equal(cache.get('target'), 'replacement');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'clearing the cache',
    max: 2,
    prepare(cache) { cache.set('survivor', 'retained'); },
    invalidate(cache) { cache.clear(); },
    verify(cache) {
      assert.equal(cache.has('target'), false);
      assert.equal(cache.has('survivor'), false);
      assert.equal(cache.size, 0);
    },
  },
];

for (const scenario of invalidations) {
  test(`fetch cancellation: ${scenario.name} rejects all waiters before provider settlement`, async () => {
    const provider = deferred();
    let signal, calls = 0;
    const cache = new Cache({
      max: scenario.max,
      fetchMethod(_key, _stale, options) {
        calls++;
        signal = options.signal;
        return provider.promise;
      },
    });
    scenario.prepare?.(cache);
    const first = observe(cache.fetch('target'));
    const second = observe(cache.fetch('target'));
    assert.equal(calls, 1);
    scenario.invalidate(cache);
    await Promise.all([expectAbort(first, signal), expectAbort(second, signal)]);
    scenario.verify(cache);

    provider.resolve('late provider value');
    await nextTurn();
    scenario.verify(cache);
  });
}

for (const completion of ['undefined', 'bogus value', 'unrelated rejection']) {
  test(`fetch cancellation: provider ${completion} on abort cannot replace the signal reason`, async () => {
    const provider = deferred();
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod(_key, _stale, options) {
        signal = options.signal;
        signal.addEventListener('abort', () => {
          if (completion === 'unrelated rejection') {
            provider.reject(new Error('provider failure'));
          } else {
            provider.resolve(completion === 'undefined' ? undefined : { bogus: true });
          }
        }, { once: true });
        return provider.promise;
      },
    });
    const observed = observe(cache.fetch('target'));
    cache.set('survivor', 'retained');
    await expectAbort(observed, signal);
    assert.equal(cache.has('target'), false);
    assert.equal(cache.get('survivor'), 'retained');
  });
}

test('fetch cancellation: an already queued success still rejects after replacement', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod(_key, _stale, options) {
      signal = options.signal;
      return 'provider value';
    },
  });
  const observed = observe(cache.fetch('target'));
  cache.set('target', 'replacement');
  await expectAbort(observed, signal);
  assert.equal(cache.get('target'), 'replacement');
});

for (const completion of ['resolve', 'reject']) {
  test(`fetch cancellation: abort wins over an already queued provider ${completion}`, async () => {
    const provider = deferred();
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod(_key, _stale, options) {
        signal = options.signal;
        return provider.promise;
      },
    });
    const observed = observe(cache.fetch('target'));
    provider[completion]({ provider: completion });
    // Let the provider's promise jobs run, then cancel before fetch's
    // completion callbacks can publish their result.
    await Promise.resolve();
    cache.set('target', 'replacement');
    await expectAbort(observed, signal);
    assert.equal(cache.get('target'), 'replacement');
  });
}

test('fetch cancellation: a late rejection cannot delete a subsequent fetch for the same key', async () => {
  const oldProvider = deferred();
  const newProvider = deferred();
  let oldSignal, calls = 0;
  const cache = new Cache({
    max: 1,
    fetchMethod(_key, _stale, { signal }) {
      if (++calls === 1) {
        oldSignal = signal;
        return oldProvider.promise;
      }
      return newProvider.promise;
    },
  });
  const oldObserved = observe(cache.fetch('target'));
  cache.delete('target');
  const fresh = cache.fetch('target');
  await expectAbort(oldObserved, oldSignal);
  oldProvider.reject(new Error('late provider failure'));
  await nextTurn();
  const concurrent = cache.fetch('target');
  assert.equal(calls, 2);
  newProvider.resolve('fresh value');
  assert.deepEqual(await Promise.all([fresh, concurrent]), ['fresh value', 'fresh value']);
  assert.equal(cache.get('target'), 'fresh value');
});

test('fetch compatibility: concurrent successful calls share one provider and cache its result', async () => {
  const provider = deferred();
  const value = { fetched: true };
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod() { calls++; return provider.promise; },
  });
  const first = cache.fetch('target');
  const second = cache.fetch('target');
  assert.equal(calls, 1);
  provider.resolve(value);
  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(cache.get('target'), value);
  assert.strictEqual(await cache.fetch('target'), value);
  assert.equal(calls, 1);
});

test('fetch compatibility: synchronous provider values succeed and thrown reasons propagate', async () => {
  const reason = { provider: 'threw' };
  const cache = new Cache({
    max: 2,
    fetchMethod(key) {
      if (key === 'failure') throw reason;
      return 'synchronous value';
    },
  });
  assert.equal(await cache.fetch('success'), 'synchronous value');
  assert.equal(cache.get('success'), 'synchronous value');
  const result = await observe(cache.fetch('failure'));
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(cache.has('failure'), false);
});

test('fetch compatibility: an ordinary provider rejection removes the entry and preserves its reason', async () => {
  const reason = { provider: 'rejected' };
  const cache = new Cache({ max: 1, fetchMethod: () => Promise.reject(reason) });
  const result = await observe(cache.fetch('target'));
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(cache.has('target'), false);
  assert.equal(cache.size, 0);
});

test('fetch compatibility: allowStaleOnFetchRejection returns and retains the previous value', async () => {
  const provider = deferred();
  const stale = { cached: true };
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  cache.set('target', stale);
  const pending = cache.fetch('target', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  });
  provider.reject(new Error('refresh failure'));
  assert.strictEqual(await pending, stale);
  assert.strictEqual(cache.get('target'), stale);
});

test('fetch compatibility: allowStaleOnFetchRejection promptly supplies stale data on cancellation', async () => {
  const provider = deferred();
  const stale = { cached: true };
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  cache.set('target', stale);
  const observed = observe(cache.fetch('target', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  }));
  cache.set('target', 'replacement');
  const result = await Promise.race([
    observed,
    nextTurn().then(() => ({ status: 'pending' })),
  ]);
  assert.equal(result.status, 'fulfilled');
  assert.strictEqual(result.value, stale);
  provider.resolve('late provider value');
  await nextTurn();
  assert.equal(cache.get('target'), 'replacement');
});

test('fetch compatibility: noDeleteOnFetchRejection retains the previous value while rejecting', async () => {
  const reason = { refresh: 'failed' };
  const stale = { cached: true };
  const cache = new Cache({ max: 1, fetchMethod: () => Promise.reject(reason) });
  cache.set('target', stale);
  const result = await observe(cache.fetch('target', {
    forceRefresh: true,
    noDeleteOnFetchRejection: true,
  }));
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.strictEqual(cache.get('target'), stale);
});

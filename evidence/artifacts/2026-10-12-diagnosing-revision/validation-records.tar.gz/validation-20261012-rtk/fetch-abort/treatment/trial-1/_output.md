我会先按 `diagnosing-bugs` 技能检查取消与缓存更新路径，再修改实现并添加独立回归测试；验证只使用本地源码和 Node 内置功能。

已定位原因：当前代码只在 provider 完成后检查取消，且取消后的成功回调仍会返回 provider 的值。接下来会让 abort 直接结算等待中的 Promise，并测试删除、淘汰、替换后的拒绝原因与晚到结果。

原始实现已复现问题：新增测试中 10 项失败，表现为调用仍挂起、返回错误值或拒绝原因被 provider 覆盖；5 项兼容性测试通过。修复会在调用 provider 前注册 abort 监听，并检查已排队的完成回调是否已被取消。

已修复 [index.js](<runs-root>/validation-20261012-rtk/fetch-abort/treatment/trial-1/index.js)：取消时立即以同一个 `AbortSignal.reason` 拒绝，无需等待 provider；晚到结果不会覆盖替换值或恢复已删除条目。并发去重、正常成功和 stale-on-rejection 行为均保留。

新增 `fetch-abort.test.mjs`，包含 18 项公开行为回归测试。原实现已复现 10 项失败；修复后：

- 新增与既有测试：19/19 通过。
- `npm test`、`git diff --check` 通过。

既有测试、runtime adapter、元数据及许可证未修改。
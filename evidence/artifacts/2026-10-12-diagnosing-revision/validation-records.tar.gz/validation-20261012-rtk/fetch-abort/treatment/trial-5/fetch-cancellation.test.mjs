import assert from 'node:assert/strict';
import { test } from 'node:test';
import { setImmediate } from 'node:timers/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

const deferred = () => {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
};

// One event-loop turn lets promise reactions run without waiting for a provider.
const promptly = promise => Promise.race([
  promise.then(
    value => ({ status: 'fulfilled', value }),
    reason => ({ status: 'rejected', reason }),
  ),
  setImmediate({ status: 'pending' }),
]);

const assertAborted = (result, signal) => {
  assert.equal(signal.aborted, true);
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, signal.reason);
};

for (const value of [undefined, 'bogus provider value']) {
  test(`fetch cancellation: eviction rejects when provider resolves ${String(value)} on abort`, async () => {
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (key, stale, options) => {
        signal = options.signal;
        return new Promise(resolve => {
          signal.addEventListener('abort', () => resolve(value), { once: true });
        });
      },
    });
    const pending = cache.fetch('pending');
    cache.set('survivor', 'kept');

    assertAborted(await promptly(pending), signal);
    assert.equal(cache.has('pending'), false);
    assert.equal(cache.get('survivor'), 'kept');
  });
}

test('fetch cancellation: provider rejection on abort preserves the actual signal reason', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (key, stale, options) => {
      signal = options.signal;
      return new Promise((resolve, reject) => {
        signal.addEventListener('abort', () => reject(new Error('provider error')), { once: true });
      });
    },
  });
  const pending = cache.fetch('pending');
  cache.delete('pending');
  assertAborted(await promptly(pending), signal);
});

const cancellations = [
  ['eviction', cache => cache.set('other', 'kept')],
  ['deletion', cache => cache.delete('pending')],
  ['replacement', cache => cache.set('pending', 'explicit replacement')],
  ['clear', cache => cache.clear()],
];

for (const [name, cancel] of cancellations) {
  test(`fetch cancellation: ${name} promptly rejects a provider that never settles`, async () => {
    let signal;
    let calls = 0;
    const cache = new Cache({
      max: 1,
      fetchMethod: (key, stale, options) => {
        calls++;
        signal = options.signal;
        return new Promise(() => {});
      },
    });
    const first = cache.fetch('pending');
    const second = cache.fetch('pending');
    const firstResult = promptly(first);
    const secondResult = promptly(second);
    assert.equal(calls, 1);
    cancel(cache);

    assertAborted(await firstResult, signal);
    assertAborted(await secondResult, signal);
    if (name === 'replacement') {
      assert.equal(cache.get('pending'), 'explicit replacement');
    } else {
      assert.equal(cache.has('pending'), false);
    }
    if (name === 'eviction') assert.equal(cache.get('other'), 'kept');
  });

  test(`fetch cancellation: ${name} ignores a late provider fulfillment`, async () => {
    const provider = deferred();
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (key, stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    const pending = cache.fetch('pending');
    cancel(cache);
    assertAborted(await promptly(pending), signal);

    provider.resolve('late provider value');
    await setImmediate();
    if (name === 'replacement') {
      assert.equal(cache.get('pending'), 'explicit replacement');
    } else {
      assert.equal(cache.has('pending'), false);
    }
    if (name === 'eviction') assert.equal(cache.get('other'), 'kept');
  });
}

test('fetch cancellation: a late rejection leaves an explicit replacement intact', async () => {
  const provider = deferred();
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (key, stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
  });
  const pending = cache.fetch('pending');
  cache.set('pending', 'explicit replacement');
  assertAborted(await promptly(pending), signal);

  provider.reject(new Error('late provider rejection'));
  await setImmediate();
  assert.equal(cache.get('pending'), 'explicit replacement');
});

test('fetch cancellation: replacement wins between provider resolution and cache update', async () => {
  const provider = deferred();
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (key, stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
  });
  const pending = cache.fetch('pending');
  const result = promptly(pending);
  provider.resolve('provider value');
  await Promise.resolve();
  cache.set('pending', 'explicit replacement');

  assertAborted(await result, signal);
  assert.equal(cache.get('pending'), 'explicit replacement');
});

test('fetch cancellation: deletion wins between provider rejection and rejection handling', async () => {
  const provider = deferred();
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (key, stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
  });
  const pending = cache.fetch('pending');
  const result = promptly(pending);
  provider.reject(new Error('provider rejection before cancellation'));
  await Promise.resolve();
  cache.delete('pending');

  assertAborted(await result, signal);
  assert.equal(cache.has('pending'), false);
});

test('fetch cancellation: a removed key can start a new independent fetch', async () => {
  const oldProvider = deferred();
  const newProvider = deferred();
  const signals = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: (key, stale, { signal }) => {
      signals.push(signal);
      return signals.length === 1 ? oldProvider.promise : newProvider.promise;
    },
  });
  const oldFetch = cache.fetch('pending');
  cache.delete('pending');
  const newFetch = cache.fetch('pending');
  assert.equal(signals.length, 2);
  assertAborted(await promptly(oldFetch), signals[0]);

  oldProvider.resolve('obsolete value');
  await setImmediate();
  newProvider.resolve('new value');
  assert.equal(await newFetch, 'new value');
  assert.equal(cache.get('pending'), 'new value');
});

test('fetch cancellation compatibility: concurrent callers share a successful provider', async () => {
  const provider = deferred();
  let calls = 0;
  const value = { cached: true };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return provider.promise;
    },
  });
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.equal(calls, 1);
  provider.resolve(value);

  assert.deepEqual(await Promise.all([first, second]), [value, value]);
  assert.strictEqual(cache.get('key'), value);
  assert.strictEqual(await cache.fetch('key'), value);
  assert.equal(calls, 1);
});

test('fetch cancellation compatibility: a synchronous provider value is cached', async () => {
  const cache = new Cache({ max: 1, fetchMethod: () => 'success' });
  assert.equal(await cache.fetch('key'), 'success');
  assert.equal(cache.get('key'), 'success');
});

test('fetch cancellation compatibility: provider rejection propagates and removes the entry', async () => {
  const reason = { providerFailure: true };
  const cache = new Cache({ max: 1, fetchMethod: () => Promise.reject(reason) });
  const result = await promptly(cache.fetch('key'));
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(cache.has('key'), false);
});

test('fetch cancellation compatibility: allowStaleOnFetchRejection returns and retains the stale value', async () => {
  const provider = deferred();
  const stale = { cached: 'stale' };
  const cache = new Cache({
    max: 1,
    allowStaleOnFetchRejection: true,
    fetchMethod: (key, previous) => {
      assert.strictEqual(previous, stale);
      return provider.promise;
    },
  });
  cache.set('key', stale);
  const pending = cache.fetch('key', { forceRefresh: true });
  provider.reject(new Error('provider rejection'));

  assert.strictEqual(await pending, stale);
  assert.strictEqual(cache.get('key'), stale);
});

test('fetch cancellation compatibility: stale rejection fallback promptly preserves an explicit replacement', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  cache.set('key', 'stale');
  const pending = cache.fetch('key', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  });
  cache.set('key', 'explicit replacement');

  assert.deepEqual(await promptly(pending), { status: 'fulfilled', value: 'stale' });
  assert.equal(cache.get('key'), 'explicit replacement');
  provider.resolve('late provider value');
  await setImmediate();
  assert.equal(cache.get('key'), 'explicit replacement');
});

test('fetch cancellation compatibility: returning stale immediately tolerates a background rejection', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  cache.set('key', 'stale');
  assert.equal(await cache.fetch('key', { forceRefresh: true, allowStale: true }), 'stale');
  provider.reject(new Error('background provider rejection'));
  await setImmediate();
  assert.equal(cache.has('key'), false);
});

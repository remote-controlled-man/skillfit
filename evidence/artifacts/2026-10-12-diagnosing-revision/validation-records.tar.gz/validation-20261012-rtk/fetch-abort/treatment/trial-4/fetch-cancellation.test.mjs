#!/usr/bin/env node
import assert from 'node:assert/strict';
import { setImmediate } from 'node:timers/promises';
import { test } from 'node:test';
import Cache from './index.js';

const deferred = () => {
  let resolve;
  let reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
};

const observe = promise => promise.then(
  value => ({ status: 'fulfilled', value }),
  reason => ({ status: 'rejected', reason }),
);

const assertCancelled = async (outcome, signal) => {
  assert.equal(signal.aborted, true);
  const result = await Promise.race([
    outcome,
    setImmediate({ status: 'pending' }),
  ]);
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, signal.reason);
};

for (const [action, remove] of [
  ['eviction', cache => cache.set('other', 'survivor')],
  ['deletion', cache => cache.delete('pending')],
  ['replacement', cache => cache.set('pending', 'replacement')],
  ['clear', cache => cache.clear()],
]) {
  test(`fetch cancellation regression: ${action} rejects before an uncooperative provider settles`, async () => {
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return new Promise(() => {});
      },
    });
    const outcome = observe(cache.fetch('pending'));
    remove(cache);
    await assertCancelled(outcome, signal);
    assert.equal(cache.get('pending'), action === 'replacement' ? 'replacement' : undefined);
    if (action === 'eviction') assert.equal(cache.get('other'), 'survivor');
  });
}

for (const [label, value] of [
  ['undefined', undefined],
  ['a bogus value', { cancelledProviderResult: true }],
]) {
  test(`fetch cancellation regression: an abort handler returning ${label} rejects with the signal reason`, async () => {
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return new Promise(resolve => {
          signal.addEventListener('abort', () => resolve(value), { once: true });
        });
      },
    });
    cache.set('other', 'survivor');
    const outcome = observe(cache.fetch('pending'));
    cache.delete('pending');
    await assertCancelled(outcome, signal);
    assert.equal(cache.has('pending'), false);
    assert.equal(cache.get('other'), 'survivor');
  });
}

for (const [action, remove] of [
  ['eviction', cache => cache.set('other', 'survivor')],
  ['deletion', cache => cache.delete('pending')],
  ['replacement', cache => cache.set('pending', 'replacement')],
  ['clear', cache => cache.clear()],
]) {
  test(`fetch cancellation regression: late fulfillment after ${action} preserves the current cache`, async () => {
    let signal;
    const provider = deferred();
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    const outcome = observe(cache.fetch('pending'));
    remove(cache);
    provider.resolve('late provider value');
    await assertCancelled(outcome, signal);
    await setImmediate();
    assert.equal(cache.has('pending'), action === 'replacement');
    assert.equal(cache.get('pending'), action === 'replacement' ? 'replacement' : undefined);
    assert.equal(cache.size, action === 'replacement' || action === 'eviction' ? 1 : 0);
    if (action === 'eviction') assert.equal(cache.get('other'), 'survivor');
  });
}

test('fetch cancellation regression: late provider rejection keeps the abort reason and explicit replacement', async () => {
  let signal;
  const provider = deferred();
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
  });
  const outcome = observe(cache.fetch('pending'));
  cache.set('pending', 'replacement');
  provider.reject(new Error('late provider rejection'));
  await assertCancelled(outcome, signal);
  await setImmediate();
  assert.equal(cache.get('pending'), 'replacement');
});

test('fetch cancellation regression: concurrent callers share one provider and the same abort reason', async () => {
  let signal;
  let calls = 0;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      calls++;
      signal = options.signal;
      return new Promise(() => {});
    },
  });
  const first = observe(cache.fetch('pending'));
  const second = observe(cache.fetch('pending'));
  assert.equal(calls, 1);
  cache.delete('pending');
  await Promise.all([assertCancelled(first, signal), assertCancelled(second, signal)]);
});

test('fetch cancellation regression: successful concurrent fetches remain deduplicated and cached', async () => {
  const provider = deferred();
  const value = { successfulProviderResult: true };
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return provider.promise;
    },
  });
  const first = cache.fetch('pending');
  const second = cache.fetch('pending');
  assert.equal(calls, 1);
  provider.resolve(value);
  assert.strictEqual(await first, value);
  assert.strictEqual(await second, value);
  assert.strictEqual(cache.get('pending'), value);
  assert.strictEqual(await cache.fetch('pending'), value);
  assert.equal(calls, 1);
});

test('fetch cancellation regression: a synchronous provider result is cached normally', async () => {
  const cache = new Cache({ max: 1, fetchMethod: () => 'fresh' });
  assert.equal(await cache.fetch('pending'), 'fresh');
  assert.equal(cache.get('pending'), 'fresh');
});

test('fetch cancellation regression: ordinary provider rejection still returns stale when configured', async () => {
  const provider = deferred();
  const stale = { staleValue: true };
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  cache.set('pending', stale);
  const pending = cache.fetch('pending', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  });
  provider.reject(new Error('provider failed'));
  assert.strictEqual(await pending, stale);
  assert.strictEqual(cache.get('pending'), stale);
});

test('fetch cancellation regression: ordinary provider rejection retains its own reason by default', async () => {
  const provider = deferred();
  const reason = { providerFailure: true };
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  const outcome = observe(cache.fetch('pending'));
  provider.reject(reason);
  const result = await outcome;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(cache.has('pending'), false);
});

我会使用 `diagnosing-bugs` 技能，先复现取消问题，再修复实现并添加只依赖公开行为的回归测试。全程只检查本地源码。

已定位原因：后台 promise 直接跟随 provider 的结果，取消信号不会让它立即拒绝；provider 在取消后返回的值也会传给调用方。我会先添加覆盖驱逐、删除、替换的回归测试，确认原实现失败，再修复取消传播。

已修复：取消会立即以原始 `AbortSignal.reason` 拒绝，无需等待 provider；迟到结果不会覆盖替换值或恢复已删除条目。

新增可执行 `fetch-cancellation.test.mjs`，覆盖取消、并发去重、正常成功及 stale-on-rejection。

验证：原实现新增测试有 12 项失败；修复后 `node --test test.mjs fetch-cancellation.test.mjs` 全部 17 项通过。既有测试、适配器、元数据和许可证均未修改。
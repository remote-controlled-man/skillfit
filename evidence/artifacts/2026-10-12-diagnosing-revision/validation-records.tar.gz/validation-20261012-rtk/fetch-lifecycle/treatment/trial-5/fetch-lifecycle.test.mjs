#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

const deferred = () => {
  const { promise, resolve, reject } = Promise.withResolvers();
  return { promise, resolve, reject };
};

// A deadline makes the historical synchronous-result hang fail explicitly.
async function withinDeadline(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 1000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle: coalesced misses insert only the fetched application value as add', async () => {
  const provider = deferred();
  const value = { version: 1 };
  const inserted = [];
  let calls = 0;
  const cache = new Cache({
    max: 2,
    onInsert: (...args) => inserted.push(args),
    fetchMethod: () => { calls++; return provider.promise; },
  });
  const first = cache.fetch('item');
  const second = cache.fetch('item');
  const whilePending = inserted.slice();
  provider.resolve(value);
  assert.deepEqual(await withinDeadline(Promise.all([first, second])), [value, value]);
  assert.deepEqual(whilePending, []);
  assert.deepEqual(inserted, [[value, 'item', 'add']]);
  assert.equal(calls, 1);
  assert.equal(cache.get('item'), value);
  assert.equal(await cache.fetch('item'), value);
  assert.equal(calls, 1);
  assert.equal(inserted.length, 1);
});

test('fetch lifecycle: refresh insertion reasons compare application values', async () => {
  let provider = deferred();
  const stale = { version: 1 };
  const fresh = { version: 2 };
  const inserted = [];
  const disposed = [];
  const cache = new Cache({
    max: 2,
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
    fetchMethod: () => provider.promise,
  });
  cache.set('item', stale);
  const refresh = cache.fetch('item', { forceRefresh: true });
  assert.equal(cache.get('item'), stale);
  provider.resolve(fresh);
  assert.equal(await withinDeadline(refresh), fresh);
  provider = deferred();
  const unchanged = cache.fetch('item', { forceRefresh: true });
  provider.resolve(fresh);
  assert.equal(await withinDeadline(unchanged), fresh);
  assert.deepEqual(inserted, [
    [stale, 'item', 'add'],
    [fresh, 'item', 'replace'],
    [fresh, 'item', 'update'],
  ]);
  assert.deepEqual(disposed, [[stale, 'item', 'set']]);
});

test('fetch lifecycle: ordinary set still reports add update replace and accepts application Promises', () => {
  const inserted = [];
  const value = { version: 1 };
  const applicationPromise = Promise.resolve('application value');
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'fetched',
    onInsert: (...args) => inserted.push(args),
  });
  cache.set('item', value);
  cache.set('item', value);
  cache.set('item', applicationPromise);
  assert.deepEqual(inserted, [
    [value, 'item', 'add'],
    [value, 'item', 'update'],
    [applicationPromise, 'item', 'replace'],
  ]);
  assert.equal(cache.get('item'), applicationPromise);
});

test('fetch lifecycle: capacity eviction disposes a refreshing stale value once per hook', async () => {
  const provider = deferred();
  const stale = { version: 1 };
  const disposed = [];
  const disposedAfter = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, oldValue, options) => {
      assert.equal(oldValue, stale);
      signal = options.signal;
      return provider.promise;
    },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => {
      assert.equal(cache.has('item'), false);
      disposedAfter.push(args);
    },
  });
  cache.set('item', stale);
  cache.set('other', 'retained');
  const refresh = cache.fetch('item', { forceRefresh: true });
  const canceled = assert.rejects(refresh, /evicted/);
  cache.set('new', 'new value');
  await withinDeadline(canceled);
  provider.resolve({ version: 2 });
  await setImmediate();
  assert.equal(signal.aborted, true);
  assert.deepEqual(disposed, [[stale, 'item', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'item', 'evict']]);
  assert.equal(cache.has('item'), false);
  assert.deepEqual([...cache.keys()], ['new', 'other']);
  assert.equal(cache.get('other'), 'retained');
});

test('fetch lifecycle: pop disposes a refreshing value with evict and returns its stale value', async () => {
  const provider = deferred();
  const stale = { version: 1 };
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('item', stale);
  const canceled = assert.rejects(cache.fetch('item', { forceRefresh: true }), /evicted/);
  assert.equal(cache.pop(), stale);
  await withinDeadline(canceled);
  provider.resolve('late result');
  await setImmediate();
  assert.equal(cache.size, 0);
  assert.deepEqual(disposed, [[stale, 'item', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'item', 'evict']]);
});

test('fetch lifecycle: evicting a pending miss does not dispose an internal Promise', async () => {
  const provider = deferred();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  const canceled = assert.rejects(cache.fetch('item'), /evicted/);
  cache.set('other', 'retained');
  await withinDeadline(canceled);
  provider.resolve('late result');
  await setImmediate();
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.equal(cache.get('other'), 'retained');
  assert.equal(cache.has('item'), false);
});

for (const [label, value] of [
  ['object', { version: 1 }],
  ['zero', 0],
  ['false', false],
  ['empty string', ''],
]) {
  test(`fetch lifecycle: synchronous ${label} results settle and cache for all callers`, async () => {
    let calls = 0;
    const cache = new Cache({ max: 1, fetchMethod: () => { calls++; return value; } });
    const first = cache.fetch('item');
    const second = cache.fetch('item');
    const values = await withinDeadline(Promise.all([first, second]));
    for (const result of values) assert.equal(result, value);
    assert.equal(cache.get('item'), value);
    assert.equal(calls, 1);
    assert.equal(await cache.fetch('item', { forceRefresh: true }), value);
    assert.equal(calls, 2);
  });
}

test('fetch lifecycle: synchronous undefined settles misses and retains refresh stale values', async () => {
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => undefined,
    onInsert: (...args) => inserted.push(args),
  });
  assert.equal(await withinDeadline(cache.fetch('missing')), undefined);
  assert.equal(cache.has('missing'), false);
  assert.equal(cache.size, 0);
  cache.set('item', 'stale');
  assert.equal(await withinDeadline(cache.fetch('item', { forceRefresh: true })), undefined);
  assert.equal(cache.get('item'), 'stale');
  assert.deepEqual(inserted, [['stale', 'item', 'add']]);
});

test('fetch lifecycle: successful miss and refresh do not abort their providers when stored', async () => {
  const signals = [];
  const aborts = [];
  let version = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: async (_key, _oldValue, { signal }) => {
      signals.push(signal);
      signal.addEventListener('abort', () => aborts.push(signal.reason));
      return { version: ++version };
    },
  });
  const first = await withinDeadline(cache.fetch('item'));
  assert.equal(cache.get('item'), first);
  const fresh = await withinDeadline(cache.fetch('item', { forceRefresh: true }));
  assert.equal(cache.get('item'), fresh);
  assert.equal(fresh.version, 2);
  cache.set('item', 'explicit value after completion');
  assert.deepEqual(aborts, []);
  assert.equal(signals.length, 2);
  for (const signal of signals) assert.equal(signal.aborted, false);
});

test('fetch lifecycle: explicit replacement cancels an active provider and wins over its late result', async () => {
  const provider = deferred();
  const stale = { version: 1 };
  const replacement = { version: 3 };
  const disposed = [];
  const disposedAfter = [];
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _oldValue, options) => { signal = options.signal; return provider.promise; },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('item', stale);
  const canceled = assert.rejects(cache.fetch('item', { forceRefresh: true }), /replaced/);
  cache.set('item', replacement);
  await withinDeadline(canceled);
  assert.equal(signal.aborted, true);
  provider.resolve({ version: 2 });
  await setImmediate();
  assert.equal(cache.get('item'), replacement);
  assert.deepEqual(disposed, [[stale, 'item', 'set']]);
  assert.deepEqual(disposedAfter, [[stale, 'item', 'set']]);
});

test('fetch lifecycle: rejection fallback and normal LRU recency remain intact', async () => {
  const error = new Error('provider failed');
  const cache = new Cache({ max: 2, fetchMethod: () => { throw error; } });
  cache.set('item', 'stale');
  cache.set('other', 'other value');
  assert.equal(await cache.fetch('item', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  }), 'stale');
  assert.equal(cache.get('item'), 'stale');
  cache.set('new', 'new value');
  assert.equal(cache.has('other'), false);
  assert.deepEqual([...cache.keys()], ['new', 'item']);
  await assert.rejects(cache.fetch('item', { forceRefresh: true }), error);
  assert.equal(cache.has('item'), false);
  assert.equal(cache.get('new'), 'new value');
});

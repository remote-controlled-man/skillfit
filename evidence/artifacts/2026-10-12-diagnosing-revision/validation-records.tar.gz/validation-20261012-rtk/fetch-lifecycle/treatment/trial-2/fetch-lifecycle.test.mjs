#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

// A deadline makes an unsettled fetch fail even when it holds no event-loop handles.
async function settles(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 500);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle: direct insertion reports add, update and replace for application values', () => {
  const inserted = [];
  const applicationPromise = Promise.resolve('application value');
  const cache = new Cache({ max: 2, fetchMethod: async () => 'fetched',
    onInsert: (...args) => inserted.push(args) });
  cache.set('key', applicationPromise);
  cache.set('key', applicationPromise);
  cache.set('key', 'replacement');
  assert.deepEqual(inserted, [
    [applicationPromise, 'key', 'add'],
    [applicationPromise, 'key', 'update'],
    ['replacement', 'key', 'replace'],
  ]);
});

test('fetch lifecycle: a cold fetch announces only the resolved application value as add', async () => {
  const deferred = Promise.withResolvers();
  const inserted = [];
  const value = { fetched: true };
  let calls = 0;
  const cache = new Cache({ max: 2,
    fetchMethod: () => { calls++; return deferred.promise; },
    onInsert: (...args) => inserted.push(args) });
  const first = cache.fetch('cold');
  const second = cache.fetch('cold');
  assert.equal(calls, 1);
  assert.equal(cache.peek('cold'), undefined);
  assert.deepEqual(inserted, [], 'the in-flight placeholder is not an application insertion');
  deferred.resolve(value);
  assert.deepEqual(await settles(Promise.all([first, second])), [value, value]);
  assert.deepEqual(inserted, [[value, 'cold', 'add']]);
  assert.equal(cache.get('cold'), value);
});

for (const sameValue of [false, true]) {
  test(`fetch lifecycle: refresh reports ${sameValue ? 'update for the same value' : 'replace for a new value'}`, async () => {
    const deferred = Promise.withResolvers();
    const inserted = [];
    const previous = { version: 1 };
    const result = sameValue ? previous : { version: 2 };
    const cache = new Cache({ max: 2, fetchMethod: () => deferred.promise,
      onInsert: (...args) => inserted.push(args) });
    cache.set('refresh', previous);
    inserted.length = 0;
    const pending = cache.fetch('refresh', { forceRefresh: true });
    assert.equal(cache.get('refresh'), previous);
    assert.deepEqual(inserted, []);
    deferred.resolve(result);
    assert.equal(await settles(pending), result);
    assert.deepEqual(inserted, [[result, 'refresh', sameValue ? 'update' : 'replace']]);
    assert.equal(cache.get('refresh'), result);
  });
}

for (const mode of ['both', 'dispose', 'disposeAfter']) {
  test(`fetch lifecycle: refresh eviction disposes the stale value once with ${mode} hooks`, async () => {
    const deferred = Promise.withResolvers();
    const disposed = [];
    const disposedAfter = [];
    const stale = { version: 'stale' };
    let signal;
    const cache = new Cache({ max: 1,
      fetchMethod: (_key, oldValue, options) => {
        assert.equal(oldValue, stale);
        signal = options.signal;
        return deferred.promise;
      },
      ...(mode !== 'disposeAfter' ? { dispose: (...args) => disposed.push(args) } : {}),
      ...(mode !== 'dispose' ? { disposeAfter: (...args) => {
        assert.equal(cache.has('refresh'), false);
        disposedAfter.push(args);
      } } : {}),
    });
    cache.set('refresh', stale);
    const pending = cache.fetch('refresh', { forceRefresh: true });
    const rejected = assert.rejects(pending, error => error === signal.reason);
    cache.set('new', 'new value');
    assert.equal(signal.aborted, true);
    const expected = [[stale, 'refresh', 'evict']];
    assert.deepEqual(disposed, mode === 'disposeAfter' ? [] : expected);
    assert.deepEqual(disposedAfter, mode === 'dispose' ? [] : expected);
    await settles(rejected);
    deferred.resolve('late result');
    await setImmediate();
    assert.deepEqual(disposed, mode === 'disposeAfter' ? [] : expected);
    assert.deepEqual(disposedAfter, mode === 'dispose' ? [] : expected);
    assert.equal(cache.get('refresh'), undefined);
    assert.equal(cache.get('new'), 'new value');
  });
}

test('fetch lifecycle: eviction preserves falsy stale application values in both disposal hooks', async () => {
  for (const stale of [0, false, '', null]) {
    const disposed = [];
    const disposedAfter = [];
    const cache = new Cache({ max: 1, fetchMethod: () => new Promise(() => {}),
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args) });
    cache.set('refresh', stale);
    const pending = cache.fetch('refresh', { forceRefresh: true });
    const rejected = assert.rejects(pending);
    cache.set('new', 'new value');
    await settles(rejected);
    assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
    assert.deepEqual(disposedAfter, disposed);
  }
});

test('fetch lifecycle: evicting a cold fetch does not dispose its placeholder', async () => {
  const disposed = [];
  const cache = new Cache({ max: 1, fetchMethod: () => new Promise(() => {}),
    dispose: (...args) => disposed.push(['dispose', ...args]),
    disposeAfter: (...args) => disposed.push(['disposeAfter', ...args]) });
  const pending = cache.fetch('cold');
  const rejected = assert.rejects(pending);
  cache.set('new', 'new value');
  await settles(rejected);
  assert.deepEqual(disposed, []);
});

test('fetch lifecycle: synchronous values settle, coalesce and remain cached', async () => {
  for (const value of [0, false, '', null, 'value', { sync: true }]) {
    let calls = 0;
    let signal;
    const cache = new Cache({ max: 2, fetchMethod: (_key, _stale, options) => {
      calls++;
      signal = options.signal;
      return value;
    } });
    const first = cache.fetch('sync');
    const second = cache.fetch('sync');
    assert.deepEqual(await settles(Promise.all([first, second])), [value, value]);
    assert.equal(calls, 1);
    assert.equal(cache.get('sync'), value);
    assert.equal(await cache.fetch('sync'), value);
    assert.equal(calls, 1);
    assert.equal(signal.aborted, false);
  }
});

test('fetch lifecycle: synchronous undefined settles a miss and retains an existing refresh value', async () => {
  const cache = new Cache({ max: 2, fetchMethod: () => undefined });
  assert.equal(await settles(cache.fetch('missing')), undefined);
  assert.equal(cache.size, 0);
  cache.set('refresh', 'previous');
  assert.equal(await settles(cache.fetch('refresh', { forceRefresh: true })), undefined);
  assert.equal(cache.get('refresh'), 'previous');
});

test('fetch lifecycle: a synchronous refresh replaces its value without cancelling the provider', async () => {
  const inserted = [];
  let signal;
  const cache = new Cache({ max: 2,
    fetchMethod: (_key, stale, options) => {
      assert.equal(stale, 'previous');
      signal = options.signal;
      return 'refreshed';
    },
    onInsert: (...args) => inserted.push(args) });
  cache.set('key', 'previous');
  inserted.length = 0;
  assert.equal(await settles(cache.fetch('key', { forceRefresh: true })), 'refreshed');
  assert.equal(cache.get('key'), 'refreshed');
  assert.deepEqual(inserted, [['refreshed', 'key', 'replace']]);
  assert.equal(signal.aborted, false);
});

test('fetch lifecycle: successful async refresh disposes the replaced value without provider abort', async () => {
  const deferred = Promise.withResolvers();
  const disposed = [];
  const disposedAfter = [];
  const aborts = [];
  let signal;
  const cache = new Cache({ max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      signal.addEventListener('abort', () => aborts.push(signal.reason));
      return deferred.promise;
    },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args) });
  cache.set('refresh', 'previous');
  const pending = cache.fetch('refresh', { forceRefresh: true });
  deferred.resolve('refreshed');
  assert.equal(await settles(pending), 'refreshed');
  assert.equal(signal.aborted, false);
  assert.deepEqual(aborts, []);
  assert.deepEqual(disposed, [['previous', 'refresh', 'set']]);
  assert.deepEqual(disposedAfter, disposed);
  assert.equal(cache.get('refresh'), 'refreshed');
});

for (const hasStale of [false, true]) {
  test(`fetch lifecycle: explicit replacement cancels ${hasStale ? 'a refresh' : 'a cold fetch'} and keeps the replacement`, async () => {
    const deferred = Promise.withResolvers();
    const inserted = [];
    const disposed = [];
    let signal;
    const cache = new Cache({ max: 2,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return deferred.promise;
      },
      onInsert: (...args) => inserted.push(args),
      dispose: (...args) => disposed.push(args) });
    if (hasStale) cache.set('key', 'previous');
    const pending = cache.fetch('key', { forceRefresh: true });
    const rejected = assert.rejects(pending, error => error === signal.reason);
    inserted.length = 0;
    cache.set('key', 'explicit');
    assert.equal(signal.aborted, true);
    await settles(rejected);
    deferred.resolve('late result');
    await setImmediate();
    assert.equal(cache.get('key'), 'explicit');
    assert.deepEqual(inserted, [['explicit', 'key', hasStale ? 'replace' : 'add']]);
    assert.deepEqual(disposed, hasStale ? [['previous', 'key', 'set']] : []);
  });
}

test('fetch lifecycle: successful misses and cache hits preserve LRU order and avoid provider abort', async () => {
  const signals = [];
  let calls = 0;
  const cache = new Cache({ max: 2, fetchMethod: async (key, _stale, { signal }) => {
    signals.push(signal);
    calls++;
    return `value:${key}`;
  } });
  cache.set('oldest', 'old');
  cache.set('keep', 'kept');
  assert.equal(await settles(cache.fetch('fetched')), 'value:fetched');
  assert.equal(cache.has('oldest'), false);
  assert.equal(cache.get('keep'), 'kept');
  assert.equal(await cache.fetch('fetched'), 'value:fetched');
  assert.equal(calls, 1);
  cache.set('newest', 'new');
  assert.equal(cache.has('keep'), false);
  assert.deepEqual([...cache.entries()], [['newest', 'new'], ['fetched', 'value:fetched']]);
  assert.equal(signals[0].aborted, false);
});

test('fetch lifecycle: synchronous provider errors reject and retain stale data when requested', async () => {
  const error = new Error('provider failed');
  const cache = new Cache({ max: 2, fetchMethod: () => { throw error; } });
  await assert.rejects(settles(cache.fetch('missing')), actual => actual === error);
  assert.equal(cache.size, 0);
  cache.set('refresh', 'previous');
  await assert.rejects(settles(cache.fetch('refresh', {
    forceRefresh: true, noDeleteOnFetchRejection: true,
  })), actual => actual === error);
  assert.equal(cache.get('refresh'), 'previous');
});

我会先读本地实现和项目约束，使用 diagnosing-bugs 技能定位这些 fetch 生命周期问题，再修复并添加可执行回归测试。

原因已定位：内部 fetch Promise 触发了 `onInsert`；淘汰时只取消请求，漏掉旧值清理；同步返回值没有结算 Promise；成功结果写回又触发了 replacement abort。现有 LRU 测试通过，我会先用公开 API 写回归测试，确认这些故障在原实现上可复现。

新测试在原实现上复现了 7 项失败，覆盖四类问题；修复后，新旧测试共 14 项全部通过。修复保留了现有插入原因语义，显式替换仍会取消请求。我正在检查最终差异和测试文件的可执行性。

已修复四类问题：`onInsert` 仅接收应用值并保留正确原因；淘汰时两个清理回调各处理旧值一次；同步 fetch 正常结算；成功写回不再误触发 abort，显式替换仍会取消请求。

新增可执行 `fetch-lifecycle.test.mjs`，包含 13 项公开 API 回归测试。原实现有 7 项失败，修复后全部通过；现有 `npm test` 和 `git diff --check` 也通过。

现有测试、runtime adapter、metadata、helper modules 和许可证均未修改。
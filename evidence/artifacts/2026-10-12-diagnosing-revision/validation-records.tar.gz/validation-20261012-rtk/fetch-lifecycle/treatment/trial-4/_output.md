我会使用 `diagnosing-bugs` 技能，检查本地 fetch 生命周期并完成修复，新增可执行回归测试；现有测试、适配器和元数据保持不变。
已定位到四处问题：fetch 占位 Promise 会进入 `onInsert`；刷新中的条目被驱逐时只取消请求，遗漏旧值清理；同步返回值没有触发 Promise 完成；结果写回时又被当作显式替换，向 provider 发出 `replaced` 取消信号。我会先用公共 API 测试复现，再修复这些路径。
修复前，14 个新增测试中有 11 个失败，复现了四类症状；修复后已全部通过。实现用当前 fetch 的身份区分结果写回与显式替换，后者仍会取消请求。接下来运行现有测试，并检查最终改动范围。
复查还发现一个相关边界：插入时设置 `noDisposeOnSet` 会阻止 `disposeAfter` 队列执行，连带漏掉此次驱逐的回调。新增测试已复现它；我会修正队列执行条件，并验证该选项仍能抑制普通替换的清理。
已修复四类 fetch 生命周期问题：`onInsert` 仅接收应用值并保留正确原因；驱逐时两个清理回调各接收旧值一次，原因为 `evict`；同步结果正常完成；成功写回不再取消 provider，显式替换仍会取消。

新增可执行的 [fetch-lifecycle.test.mjs](<runs-root>/validation-20261012-rtk/fetch-lifecycle/treatment/trial-4/fetch-lifecycle.test.mjs)，含 16 个公共 API 回归测试。修复前已复现失败。

验证通过：`npm test`、新旧测试合跑 **17/17**、直接执行新测试 **16/16**、`git diff --check`。现有测试、适配器、元数据、辅助模块和许可证均未修改。
#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

// All tested providers finish synchronously or in microtasks. An event-loop
// turn makes a hung fetch fail deterministically without a timing-based sleep.
const settled = promise => Promise.race([
  promise,
  setImmediate().then(() => assert.fail('fetch did not settle after its provider completed')),
]);

test('fetch lifecycle: cold onInsert reports only the resolved application value as add', async () => {
  const provider = Promise.withResolvers();
  const value = { answer: 42 };
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  const pending = cache.fetch('answer');
  const duringFetch = inserted.slice();
  provider.resolve(value);
  assert.equal(await settled(pending), value);
  assert.deepEqual(duringFetch, []);
  assert.deepEqual(inserted, [[value, 'answer', 'add']]);
  assert.equal(cache.get('answer'), value);
});

test('fetch lifecycle: ordinary set keeps add update replace reasons and LRU order', () => {
  const inserted = [];
  const cache = new Cache({ max: 2, onInsert: (...args) => inserted.push(args) });
  cache.set('a', 1);
  cache.set('a', 1);
  cache.set('a', 2);
  cache.set('b', 3);
  assert.equal(cache.get('a'), 2);
  cache.set('c', 4);
  assert.equal(cache.has('b'), false);
  assert.deepEqual([...cache.entries()], [['c', 4], ['a', 2]]);
  assert.deepEqual(inserted, [
    [1, 'a', 'add'], [1, 'a', 'update'], [2, 'a', 'replace'],
    [3, 'b', 'add'], [4, 'c', 'add'],
  ]);
});

test('fetch lifecycle: refresh onInsert compares with the previous application value', async () => {
  const oldValue = { version: 1 };
  const newValue = { version: 2 };
  let result = oldValue;
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => result,
    onInsert: (...args) => inserted.push(args),
  });
  cache.set('value', oldValue);
  assert.equal(await settled(cache.fetch('value', { forceRefresh: true })), oldValue);
  result = newValue;
  assert.equal(await settled(cache.fetch('value', { forceRefresh: true })), newValue);
  assert.deepEqual(inserted, [
    [oldValue, 'value', 'add'],
    [oldValue, 'value', 'update'],
    [newValue, 'value', 'replace'],
  ]);
});

for (const mode of ['capacity', 'size', 'pop']) {
  test(`fetch lifecycle: ${mode} eviction disposes the stale value once in each hook`, async () => {
    const provider = Promise.withResolvers();
    const stale = mode === 'capacity' ? false : { version: 'stale' };
    const disposed = [];
    const disposedAfter = [];
    let signal;
    const cache = new Cache({
      max: mode === 'size' ? 3 : 2,
      ...(mode === 'size' ? { maxSize: 2, sizeCalculation: () => 1 } : {}),
      fetchMethod: (_key, previous, options) => {
        assert.equal(previous, stale);
        signal = options.signal;
        return provider.promise;
      },
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args),
    });
    cache.set('refresh', stale);
    cache.set('keep', 'kept');
    const pending = cache.fetch('refresh', { forceRefresh: true });
    const aborted = assert.rejects(pending, { message: 'evicted' });
    const popped = mode === 'pop' ? cache.pop() : undefined;
    cache.set('new', 'new value');
    await aborted;
    provider.resolve({ version: 'late' });
    await setImmediate();
    if (mode === 'pop') assert.equal(popped, stale);
    assert.equal(signal.aborted, true);
    assert.equal(signal.reason.message, 'evicted');
    assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
    assert.equal(cache.has('refresh'), false);
    assert.equal(cache.size, 2);
    assert.deepEqual([...cache.entries()], [['new', 'new value'], ['keep', 'kept']]);
    if (mode === 'size') assert.equal(cache.calculatedSize, 2);
  });
}

test('fetch lifecycle: evicting a cold fetch never disposes an internal promise', async () => {
  const provider = Promise.withResolvers();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  const pending = cache.fetch('pending');
  const aborted = assert.rejects(pending, { message: 'evicted' });
  cache.set('kept', 'value');
  await aborted;
  provider.resolve('late');
  await setImmediate();
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.equal(cache.get('kept'), 'value');
  assert.equal(cache.has('pending'), false);
});

for (const [label, value] of [
  ['object', { synchronous: true }], ['zero', 0], ['false', false],
  ['empty string', ''], ['undefined', undefined],
]) {
  test(`fetch lifecycle: synchronous ${label} results settle and update the cache`, async () => {
    const inserted = [];
    const cache = new Cache({
      max: 1,
      fetchMethod: () => value,
      onInsert: (...args) => inserted.push(args),
    });
    assert.equal(await settled(cache.fetch('sync')), value);
    assert.equal(cache.get('sync'), value);
    assert.equal(cache.size, value === undefined ? 0 : 1);
    assert.deepEqual(inserted, value === undefined ? [] : [[value, 'sync', 'add']]);
  });
}

test('fetch lifecycle: synchronous refresh stores its result without aborting its provider', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, previous, options) => {
      assert.equal(previous, 'old');
      signal = options.signal;
      return 'new';
    },
  });
  cache.set('refresh', 'old');
  assert.equal(await settled(cache.fetch('refresh', { forceRefresh: true })), 'new');
  assert.equal(cache.get('refresh'), 'new');
  assert.equal(signal.aborted, false);
});

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful ${refresh ? 'refresh' : 'cold fetch'} coalesces callers without provider abort`, async () => {
    const provider = Promise.withResolvers();
    let signal;
    let calls = 0;
    const aborts = [];
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _previous, options) => {
        calls++;
        signal = options.signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return provider.promise;
      },
    });
    if (refresh) cache.set('value', 'old');
    const first = cache.fetch('value', { forceRefresh: refresh });
    const second = cache.fetch('value');
    const stale = refresh ? await cache.fetch('value', { allowStale: true }) : undefined;
    provider.resolve('new');
    assert.deepEqual(await settled(Promise.all([first, second])), ['new', 'new']);
    if (refresh) assert.equal(stale, 'old');
    assert.equal(calls, 1);
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborts, []);
    assert.equal(cache.get('value'), 'new');
    assert.equal(await cache.fetch('value'), 'new');
    assert.equal(calls, 1);
  });
}

test('fetch lifecycle: explicit replacement still cancels refresh and preserves the replacement', async () => {
  const provider = Promise.withResolvers();
  const inserted = [];
  const disposed = [];
  const disposedAfter = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _previous, options) => {
      signal = options.signal;
      return provider.promise;
    },
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('value', 'stale');
  const pending = cache.fetch('value', { forceRefresh: true });
  const aborted = assert.rejects(pending, { message: 'replaced' });
  cache.set('value', 'explicit');
  await aborted;
  provider.resolve('late');
  await setImmediate();
  assert.equal(signal.aborted, true);
  assert.equal(signal.reason.message, 'replaced');
  assert.equal(cache.get('value'), 'explicit');
  assert.deepEqual(inserted, [['stale', 'value', 'add'], ['explicit', 'value', 'replace']]);
  assert.deepEqual(disposed, [['stale', 'value', 'set']]);
  assert.deepEqual(disposedAfter, [['stale', 'value', 'set']]);
});

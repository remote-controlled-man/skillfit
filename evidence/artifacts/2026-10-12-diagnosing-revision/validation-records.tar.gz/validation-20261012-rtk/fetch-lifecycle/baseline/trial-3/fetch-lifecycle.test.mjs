#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate as nextTurn } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

function deferred() {
  let resolve;
  const promise = new Promise(res => { resolve = res; });
  return { promise, resolve };
}

async function settled(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 500);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle: a cache miss reports only the resolved application value', async () => {
  const inserts = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'fetched',
    onInsert: (value, key, reason) => inserts.push([value, key, reason]),
  });

  const result = cache.fetch('key');
  assert.deepEqual(inserts, []);
  assert.equal(await result, 'fetched');
  assert.deepEqual(inserts, [['fetched', 'key', 'add']]);
  assert.equal(cache.get('key'), 'fetched');
});

test('fetch lifecycle: ordinary set reports add, update and replace', () => {
  const inserts = [];
  const first = { version: 1 };
  const second = { version: 2 };
  const cache = new Cache({
    max: 2,
    onInsert: (value, key, reason) => inserts.push([value, key, reason]),
  });
  cache.set('key', first);
  cache.set('key', first);
  cache.set('key', second);
  assert.deepEqual(inserts, [
    [first, 'key', 'add'],
    [first, 'key', 'update'],
    [second, 'key', 'replace'],
  ]);
});

test('fetch lifecycle: application Promise values still trigger onInsert', () => {
  const inserts = [];
  const value = Promise.resolve('application value');
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'fetched',
    onInsert: (value, key, reason) => inserts.push([value, key, reason]),
  });
  cache.set('key', value);
  cache.set('key', value);
  assert.deepEqual(inserts, [[value, 'key', 'add'], [value, 'key', 'update']]);
  assert.equal(cache.get('key'), value);
});

for (const same of [false, true]) {
  const reason = same ? 'update' : 'replace';
  test(`fetch lifecycle: refresh reports ${reason} for its application value`, async () => {
    const inserts = [];
    const provider = deferred();
    const stale = { version: 1 };
    const fresh = same ? stale : { version: 2 };
    const cache = new Cache({
      max: 2,
      fetchMethod: () => provider.promise,
      onInsert: (value, key, reason) => inserts.push([value, key, reason]),
    });
    cache.set('key', stale);
    inserts.length = 0;
    const result = cache.fetch('key', { forceRefresh: true });
    assert.deepEqual(inserts, []);
    assert.equal(cache.get('key'), stale);
    provider.resolve(fresh);
    assert.equal(await settled(result), fresh);
    assert.deepEqual(inserts, [[fresh, 'key', reason]]);
    assert.equal(cache.get('key'), fresh);
  });
}

for (const [label, value] of [
  ['string', 'synchronous'],
  ['zero', 0],
  ['false', false],
  ['empty string', ''],
  ['object', { synchronous: true }],
]) {
  test(`fetch lifecycle: synchronous ${label} results settle and are cached`, async () => {
    const cache = new Cache({ max: 2, fetchMethod: () => value });
    assert.equal(await settled(cache.fetch('key')), value);
    assert.equal(cache.get('key'), value);
    assert.equal(cache.size, 1);
  });
}

test('fetch lifecycle: synchronous refresh settles with the new value', async () => {
  const cache = new Cache({ max: 2, fetchMethod: () => 'fresh' });
  cache.set('key', 'stale');
  assert.equal(await settled(cache.fetch('key', { forceRefresh: true })), 'fresh');
  assert.equal(cache.get('key'), 'fresh');
});

test('fetch lifecycle: synchronous undefined settles without an insertion', async () => {
  const inserts = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => undefined,
    onInsert: (value, key, reason) => inserts.push([value, key, reason]),
  });
  assert.equal(await settled(cache.fetch('key')), undefined);
  assert.equal(cache.size, 0);
  assert.deepEqual(inserts, []);
});

test('fetch lifecycle: undefined refresh retains the previous application value', async () => {
  const inserts = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => undefined,
    onInsert: (value, key, reason) => inserts.push([value, key, reason]),
  });
  cache.set('key', 'stale');
  inserts.length = 0;
  assert.equal(await settled(cache.fetch('key', { forceRefresh: true })), undefined);
  assert.equal(cache.get('key'), 'stale');
  assert.deepEqual(inserts, []);
});

for (const hooks of ['both', 'dispose', 'disposeAfter']) {
  test(`fetch lifecycle: eviction releases a refreshing value once with ${hooks}`, async () => {
    const disposed = [];
    const disposedAfter = [];
    const provider = deferred();
    const stale = { version: 1 };
    let signal;
    let cache;
    cache = new Cache({
      max: 2,
      fetchMethod: (_key, previous, options) => {
        assert.equal(previous, stale);
        signal = options.signal;
        return provider.promise;
      },
      ...(hooks !== 'disposeAfter' && {
        dispose: (value, key, reason) => disposed.push([value, key, reason]),
      }),
      ...(hooks !== 'dispose' && {
        disposeAfter: (value, key, reason) => {
          disposedAfter.push([value, key, reason]);
          assert.equal(cache.has(key), false);
          assert.equal(cache.get('new'), 'new');
        },
      }),
    });
    cache.set('key', stale);
    cache.set('other', 'other');
    const result = cache.fetch('key', { forceRefresh: true });
    const aborted = assert.rejects(result, /evicted/);
    cache.set('new', 'new');
    await aborted;
    assert.equal(signal.aborted, true);
    provider.resolve({ version: 2 });
    await nextTurn();
    const expected = [[stale, 'key', 'evict']];
    assert.deepEqual(disposed, hooks === 'disposeAfter' ? [] : expected);
    assert.deepEqual(disposedAfter, hooks === 'dispose' ? [] : expected);
    assert.equal(cache.has('key'), false);
    assert.deepEqual([...cache.keys()], ['new', 'other']);
  });
}

test('fetch lifecycle: eviction disposes a falsy previous value', async () => {
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => new Promise(() => {}),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 0);
  const result = cache.fetch('key', { forceRefresh: true });
  const aborted = assert.rejects(result, /evicted/);
  cache.set('new', 1);
  await aborted;
  assert.deepEqual(disposed, [[0, 'key', 'evict']]);
  assert.deepEqual(disposedAfter, [[0, 'key', 'evict']]);
});

test('fetch lifecycle: pop releases the previous value of an active refresh', async () => {
  const disposed = [];
  const disposedAfter = [];
  const stale = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => new Promise(() => {}),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', stale);
  const result = cache.fetch('key', { forceRefresh: true });
  const aborted = assert.rejects(result, /evicted/);
  assert.equal(cache.pop(), stale);
  await aborted;
  assert.deepEqual(disposed, [[stale, 'key', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'key', 'evict']]);
  assert.equal(cache.size, 0);
});

test('fetch lifecycle: evicting an unfulfilled miss does not dispose a placeholder', async () => {
  const disposed = [];
  const disposedAfter = [];
  const inserts = [];
  const provider = deferred();
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
    onInsert: (...args) => inserts.push(args),
  });
  const result = cache.fetch('key');
  const aborted = assert.rejects(result, /evicted/);
  cache.set('new', 'new');
  await aborted;
  provider.resolve('late');
  await nextTurn();
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.deepEqual(inserts, [['new', 'new', 'add']]);
  assert.equal(cache.has('key'), false);
  assert.equal(cache.get('new'), 'new');
});

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful ${refresh ? 'refresh' : 'miss'} does not abort its provider`, async () => {
    const provider = deferred();
    const aborts = [];
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _previous, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return provider.promise;
      },
    });
    if (refresh) cache.set('key', 'stale');
    const result = cache.fetch('key', { forceRefresh: refresh });
    provider.resolve('fresh');
    assert.equal(await settled(result), 'fresh');
    await nextTurn();
    assert.equal(cache.get('key'), 'fresh');
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborts, []);
  });
}

test('fetch lifecycle: explicit replacement still cancels a refresh and keeps the replacement', async () => {
  const provider = deferred();
  const inserts = [];
  const disposed = [];
  const disposedAfter = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _previous, options) => {
      signal = options.signal;
      return provider.promise;
    },
    onInsert: (...args) => inserts.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 'stale');
  inserts.length = 0;
  const result = cache.fetch('key', { forceRefresh: true });
  const aborted = assert.rejects(result, /replaced/);
  cache.set('key', 'manual');
  await aborted;
  assert.equal(signal.aborted, true);
  provider.resolve('late');
  await nextTurn();
  assert.equal(cache.get('key'), 'manual');
  assert.deepEqual(inserts, [['manual', 'key', 'replace']]);
  assert.deepEqual(disposed, [['stale', 'key', 'set']]);
  assert.deepEqual(disposedAfter, [['stale', 'key', 'set']]);
});

test('fetch lifecycle: concurrent stale refresh callers share a successful fetch', async () => {
  const provider = deferred();
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => { calls++; return provider.promise; },
  });
  cache.set('key', 'stale');
  assert.equal(await cache.fetch('key', { forceRefresh: true, allowStale: true }), 'stale');
  const first = cache.fetch('key');
  const second = cache.fetch('key');
  assert.equal(calls, 1);
  provider.resolve('fresh');
  assert.deepEqual(await settled(Promise.all([first, second])), ['fresh', 'fresh']);
  assert.equal(cache.get('key'), 'fresh');
});

test('fetch lifecycle: successful refresh preserves LRU promotion on completion', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 2, fetchMethod: () => provider.promise });
  cache.set('oldest', 'stale');
  cache.set('other', 'other');
  const result = cache.fetch('oldest', { forceRefresh: true });
  provider.resolve('fresh');
  assert.equal(await settled(result), 'fresh');
  cache.set('new', 'new');
  assert.equal(cache.has('other'), false);
  assert.deepEqual([...cache.entries()], [['new', 'new'], ['oldest', 'fresh']]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

test('fetch lifecycle: a cache miss inserts only the resolved application value', async () => {
  const inserts = [];
  const value = { fetched: true };
  const { promise, resolve } = Promise.withResolvers();
  const cache = new Cache({
    max: 2,
    fetchMethod: () => promise,
    onInsert: (...args) => inserts.push(args),
  });

  const fetched = cache.fetch('missing');
  assert.deepEqual(inserts, []);
  resolve(value);
  assert.equal(await fetched, value);
  assert.equal(cache.get('missing'), value);
  assert.deepEqual(inserts, [[value, 'missing', 'add']]);
});

for (const unchanged of [false, true]) {
  test(`fetch lifecycle: refresh reports ${unchanged ? 'update' : 'replace'} for an application value`, async () => {
    const inserts = [];
    const stale = { version: 1 };
    const value = unchanged ? stale : { version: 2 };
    const { promise, resolve } = Promise.withResolvers();
    const cache = new Cache({
      max: 2,
      fetchMethod: () => promise,
      onInsert: (...args) => inserts.push(args),
    });
    cache.set('refresh', stale);

    const fetched = cache.fetch('refresh', { forceRefresh: true });
    assert.equal(cache.get('refresh'), stale);
    assert.deepEqual(inserts, [[stale, 'refresh', 'add']]);
    resolve(value);
    assert.equal(await fetched, value);
    assert.equal(cache.get('refresh'), value);
    assert.deepEqual(inserts, [
      [stale, 'refresh', 'add'],
      [value, 'refresh', unchanged ? 'update' : 'replace'],
    ]);
  });
}

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful ${refresh ? 'refresh' : 'miss'} does not abort its provider`, async () => {
    const aborts = [];
    let providerSignal;
    const { promise, resolve } = Promise.withResolvers();
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, { signal }) => {
        providerSignal = signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return promise;
      },
    });
    if (refresh) cache.set('key', 'old');
    const fetched = cache.fetch('key', { forceRefresh: refresh });
    resolve('new');
    assert.equal(await fetched, 'new');
    assert.equal(cache.get('key'), 'new');
    assert.equal(providerSignal.aborted, false);
    assert.deepEqual(aborts, []);
  });
}

for (const [label, value] of [
  ['object', { synchronous: true }],
  ['zero', 0],
  ['false', false],
  ['empty string', ''],
  ['undefined', undefined],
]) {
  test(`fetch lifecycle: synchronous ${label} settles all waiting callers`, async () => {
    let calls = 0;
    const cache = new Cache({
      max: 1,
      fetchMethod: () => {
        calls++;
        return value;
      },
    });
    const first = cache.fetch('sync');
    const second = cache.fetch('sync');
    const values = await Promise.race([
      Promise.all([first, second]),
      setImmediate().then(() => { throw new Error('synchronous fetch did not settle'); }),
    ]);
    assert.deepEqual(values, [value, value]);
    assert.equal(calls, 1);
    assert.equal(cache.get('sync'), value);
    assert.equal(cache.has('sync'), value !== undefined);
  });
}

for (const [label, stale] of [
  ['object', { previous: true }],
  ['zero', 0],
  ['false', false],
  ['empty string', ''],
]) {
  test(`fetch lifecycle: eviction disposes a refreshing ${label} once through both hooks`, async () => {
    const disposed = [];
    const disposedAfter = [];
    const { promise, resolve } = Promise.withResolvers();
    const cache = new Cache({
      max: 1,
      fetchMethod: () => promise,
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args),
    });
    cache.set('refresh', stale);
    const fetched = cache.fetch('refresh', { forceRefresh: true });
    const rejected = assert.rejects(fetched, /evicted/);
    cache.set('other', 'survivor');

    assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
    await rejected;
    resolve('late result');
    await setImmediate();
    assert.equal(cache.has('refresh'), false);
    assert.equal(cache.get('other'), 'survivor');
    assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
  });
}

test('fetch lifecycle: pop invokes disposeAfter for the stale value without a dispose hook', async () => {
  const disposedAfter = [];
  const { promise, resolve } = Promise.withResolvers();
  const cache = new Cache({
    max: 2,
    fetchMethod: () => promise,
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('refresh', 'stale');
  const fetched = cache.fetch('refresh', { forceRefresh: true });
  const rejected = assert.rejects(fetched, /evicted/);
  assert.equal(cache.pop(), 'stale');
  assert.deepEqual(disposedAfter, [['stale', 'refresh', 'evict']]);
  assert.equal(cache.size, 0);
  await rejected;
  resolve('late result');
  await setImmediate();
  assert.deepEqual(disposedAfter, [['stale', 'refresh', 'evict']]);
});

test('fetch lifecycle: noDisposeOnSet still delivers both eviction hooks for a refresh', async () => {
  const disposed = [];
  const disposedAfter = [];
  const { promise, resolve } = Promise.withResolvers();
  const cache = new Cache({
    max: 1,
    noDisposeOnSet: true,
    fetchMethod: () => promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('refresh', 'stale');
  const fetched = cache.fetch('refresh', { forceRefresh: true });
  const rejected = assert.rejects(fetched, /evicted/);
  cache.set('other', 'survivor');
  await rejected;
  resolve('late result');
  await setImmediate();
  assert.deepEqual(disposed, [['stale', 'refresh', 'evict']]);
  assert.deepEqual(disposedAfter, [['stale', 'refresh', 'evict']]);
  cache.set('other', 'replacement');
  assert.deepEqual(disposed, [['stale', 'refresh', 'evict']]);
  assert.deepEqual(disposedAfter, [['stale', 'refresh', 'evict']]);
});

test('fetch lifecycle: a synchronous refresh stores its value without cancelling the provider', async () => {
  const inserts = [];
  const disposed = [];
  let providerSignal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, stale, { signal }) => {
      providerSignal = signal;
      assert.equal(stale, 'old');
      return 'new';
    },
    onInsert: (...args) => inserts.push(args),
    dispose: (...args) => disposed.push(args),
  });
  cache.set('key', 'old');
  const fetched = cache.fetch('key', { forceRefresh: true });
  assert.equal(await Promise.race([
    fetched,
    setImmediate().then(() => { throw new Error('synchronous refresh did not settle'); }),
  ]), 'new');
  assert.equal(cache.get('key'), 'new');
  assert.equal(providerSignal.aborted, false);
  assert.deepEqual(inserts, [['old', 'key', 'add'], ['new', 'key', 'replace']]);
  assert.deepEqual(disposed, [['old', 'key', 'set']]);
});

test('fetch lifecycle: serving a stale value still completes the refresh for waiting callers', async () => {
  const { promise, resolve } = Promise.withResolvers();
  let providerSignal;
  let calls = 0;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      providerSignal = signal;
      calls++;
      return promise;
    },
  });
  cache.set('key', 'old');
  assert.equal(await cache.fetch('key', { forceRefresh: true, allowStale: true }), 'old');
  const waiting = cache.fetch('key');
  assert.equal(calls, 1);
  resolve('new');
  assert.equal(await waiting, 'new');
  assert.equal(cache.get('key'), 'new');
  assert.equal(providerSignal.aborted, false);
});

test('fetch lifecycle: evicting an unresolved miss never disposes a placeholder', async () => {
  const disposed = [];
  const { promise, resolve } = Promise.withResolvers();
  const cache = new Cache({
    max: 1,
    fetchMethod: () => promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposed.push(args),
  });
  const fetched = cache.fetch('missing');
  const rejected = assert.rejects(fetched, /evicted/);
  cache.set('other', 'survivor');
  await rejected;
  resolve('late result');
  await setImmediate();
  assert.deepEqual(disposed, []);
  assert.equal(cache.get('other'), 'survivor');
  assert.equal(cache.has('missing'), false);
});

test('fetch lifecycle: explicit replacement still aborts a refresh and wins over its late result', async () => {
  const inserts = [];
  const disposed = [];
  const disposedAfter = [];
  let providerSignal;
  const { promise, resolve } = Promise.withResolvers();
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, { signal }) => {
      providerSignal = signal;
      return promise;
    },
    onInsert: (...args) => inserts.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 'old');
  const fetched = cache.fetch('key', { forceRefresh: true });
  const rejected = assert.rejects(fetched, /replaced/);
  cache.set('key', 'explicit');
  await rejected;
  assert.equal(providerSignal.aborted, true);
  assert.equal(providerSignal.reason.message, 'replaced');
  resolve('late result');
  await setImmediate();
  assert.equal(cache.get('key'), 'explicit');
  assert.deepEqual(inserts, [['old', 'key', 'add'], ['explicit', 'key', 'replace']]);
  assert.deepEqual(disposed, [['old', 'key', 'set']]);
  assert.deepEqual(disposedAfter, [['old', 'key', 'set']]);
});

test('fetch lifecycle: successful fetches coalesce, hit the cache, and preserve LRU eviction', async () => {
  let calls = 0;
  const { promise, resolve } = Promise.withResolvers();
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return promise;
    },
  });
  cache.set('older', 'old');
  const first = cache.fetch('fetched');
  const second = cache.fetch('fetched');
  assert.equal(calls, 1);
  resolve('value');
  assert.deepEqual(await Promise.all([first, second]), ['value', 'value']);
  assert.equal(await cache.fetch('fetched'), 'value');
  assert.equal(calls, 1);
  assert.equal(cache.get('older'), 'old');
  cache.set('newer', 'new');
  assert.equal(cache.has('fetched'), false);
  assert.equal(cache.get('older'), 'old');
  assert.equal(cache.get('newer'), 'new');
  assert.equal(cache.size, 2);
});

test('fetch lifecycle: ordinary sets report add, update, replace, and accept application Promises', () => {
  const inserts = [];
  const applicationPromise = Promise.resolve('application value');
  const cache = new Cache({
    max: 2,
    fetchMethod: () => undefined,
    onInsert: (...args) => inserts.push(args),
  });
  cache.set('key', 'old');
  cache.set('key', 'old');
  cache.set('key', 'new');
  cache.set('promise', applicationPromise);
  assert.equal(cache.get('promise'), applicationPromise);
  assert.deepEqual(inserts, [
    ['old', 'key', 'add'],
    ['old', 'key', 'update'],
    ['new', 'key', 'replace'],
    [applicationPromise, 'promise', 'add'],
  ]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

function deferred() {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
}

async function settled(promise) {
  const pending = Symbol('pending fetch');
  const value = await Promise.race([promise, setImmediate(pending)]);
  assert.notEqual(value, pending, 'fetch must settle after its provider returns a value');
  return value;
}

test('fetch lifecycle: a cache miss inserts only the resolved application value with add', async () => {
  const provider = deferred();
  const inserted = [];
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...event) => inserted.push(event),
  });
  const result = cache.fetch('item');
  assert.deepEqual(inserted, [], 'an internal fetch promise is not an application insertion');
  provider.resolve(value);
  assert.equal(await settled(result), value);
  assert.equal(cache.get('item'), value);
  assert.deepEqual(inserted, [[value, 'item', 'add']]);
});

for (const sameValue of [false, true]) {
  test(`fetch lifecycle: refresh reports ${sameValue ? 'update for the same value' : 'replace for a new value'}`, async () => {
    const provider = deferred();
    const inserted = [];
    const stale = { version: 1 };
    const value = sameValue ? stale : { version: 2 };
    const cache = new Cache({
      max: 2,
      fetchMethod: () => provider.promise,
      onInsert: (...event) => inserted.push(event),
    });
    cache.set('item', stale);
    const result = cache.fetch('item', { forceRefresh: true });
    assert.deepEqual(inserted, [[stale, 'item', 'add']]);
    assert.equal(cache.get('item', { allowStale: true }), stale);
    provider.resolve(value);
    assert.equal(await settled(result), value);
    assert.deepEqual(inserted, [
      [stale, 'item', 'add'],
      [value, 'item', sameValue ? 'update' : 'replace'],
    ]);
  });
}

for (const hooks of [['dispose'], ['disposeAfter'], ['dispose', 'disposeAfter']]) {
  test(`fetch lifecycle: refresh eviction disposes the stale value once via ${hooks.join(' and ')}`, async () => {
    const provider = deferred();
    const events = { dispose: [], disposeAfter: [] };
    const stale = { version: 1 };
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, oldValue, options) => {
        assert.equal(oldValue, stale);
        signal = options.signal;
        return provider.promise;
      },
      ...Object.fromEntries(hooks.map(hook => [hook, (...event) => events[hook].push(event)])),
    });
    cache.set('item', stale);
    const result = cache.fetch('item', { forceRefresh: true });
    const rejected = assert.rejects(result);
    cache.set('other', { version: 3 });
    assert.equal(signal.aborted, true);
    for (const hook of hooks) assert.deepEqual(events[hook], [[stale, 'item', 'evict']]);
    await rejected;
    provider.resolve({ version: 2 });
    await setImmediate();
    assert.equal(cache.has('item'), false);
    for (const hook of hooks) assert.deepEqual(events[hook], [[stale, 'item', 'evict']]);
  });
}

test('fetch lifecycle: evicting an unresolved cache miss does not dispose a promise', async () => {
  const provider = deferred();
  const disposed = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    dispose: (...event) => disposed.push(event),
    disposeAfter: (...event) => disposed.push(event),
  });
  const result = cache.fetch('item');
  const rejected = assert.rejects(result);
  cache.set('other', 3);
  await rejected;
  provider.resolve(2);
  await setImmediate();
  assert.deepEqual(disposed, []);
  assert.equal(cache.get('other'), 3);
});

for (const [name, value] of [['object', { version: 1 }], ['zero', 0], ['false', false], ['empty string', '']]) {
  test(`fetch lifecycle: a synchronous ${name} result settles coalesced callers and is cached`, async () => {
    let calls = 0;
    const cache = new Cache({ max: 2, fetchMethod: () => { calls++; return value; } });
    const first = cache.fetch('item');
    const second = cache.fetch('item');
    assert.deepEqual(await settled(Promise.all([first, second])), [value, value]);
    assert.equal(cache.get('item'), value);
    assert.equal(await settled(cache.fetch('item')), value);
    assert.equal(calls, 1);
  });
}

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful ${refresh ? 'refresh' : 'initial fetch'} does not abort its provider`, async () => {
    const provider = deferred();
    const aborts = [];
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return provider.promise;
      },
    });
    if (refresh) cache.set('item', 1);
    const result = cache.fetch('item', { forceRefresh: refresh });
    provider.resolve(2);
    assert.equal(await settled(result), 2);
    assert.equal(cache.get('item'), 2);
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborts, []);
  });
}

test('fetch lifecycle: explicitly replacing a refresh cancels it and preserves the replacement', async () => {
  const provider = deferred();
  const aborts = [];
  const inserted = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      signal.addEventListener('abort', () => aborts.push(signal.reason));
      return provider.promise;
    },
    onInsert: (...event) => inserted.push(event),
  });
  cache.set('item', 1);
  const result = cache.fetch('item', { forceRefresh: true });
  const rejected = assert.rejects(result);
  cache.set('item', 3);
  await rejected;
  assert.equal(signal.aborted, true);
  assert.equal(aborts.length, 1);
  provider.resolve(2);
  await setImmediate();
  assert.equal(cache.get('item'), 3);
  assert.deepEqual(inserted, [[1, 'item', 'add'], [3, 'item', 'replace']]);
});

test('fetch lifecycle: ordinary insertion reasons and LRU order remain intact after fetching', async () => {
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 1,
    onInsert: (...event) => inserted.push(event),
  });
  assert.equal(await settled(cache.fetch('a')), 1);
  cache.set('b', 2);
  cache.set('b', 2);
  cache.set('b', 3);
  assert.equal(cache.get('a'), 1);
  cache.set('c', 4);
  assert.equal(cache.has('b'), false);
  assert.deepEqual([...cache.keys()], ['c', 'a']);
  assert.deepEqual(inserted, [
    [1, 'a', 'add'], [2, 'b', 'add'], [2, 'b', 'update'], [3, 'b', 'replace'], [4, 'c', 'add'],
  ]);
});

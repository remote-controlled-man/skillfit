#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { setImmediate as nextTurn } from 'node:timers/promises';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

const deferred = () => {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
};

const settledByNextTurn = promise => Promise.race([
  promise,
  nextTurn().then(() => { throw new Error('fetch did not settle by the next event loop turn'); }),
]);

test('fetch lifecycle: a cache miss inserts only the resolved application value with add', async () => {
  const provider = deferred();
  const inserted = [];
  const value = { answer: 42 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  const fetched = cache.fetch('answer');
  const joined = cache.fetch('answer');
  assert.deepEqual(inserted, []);
  provider.resolve(value);
  assert.equal(await fetched, value);
  assert.equal(await joined, value);
  assert.equal(cache.get('answer'), value);
  assert.deepEqual(inserted, [[value, 'answer', 'add']]);
  assert.equal(await cache.fetch('answer'), value);
  assert.equal(inserted.length, 1);
});

test('fetch lifecycle: refreshing the same value reports update without exposing a promise', async () => {
  const provider = deferred();
  const inserted = [];
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  cache.set('entry', value);
  inserted.length = 0;
  const fetched = cache.fetch('entry', { forceRefresh: true });
  assert.deepEqual(inserted, []);
  provider.resolve(value);
  assert.equal(await fetched, value);
  assert.deepEqual(inserted, [[value, 'entry', 'update']]);
});

test('fetch lifecycle: refreshing a changed value reports replace and keeps stale reads available', async () => {
  const provider = deferred();
  const inserted = [];
  const stale = { version: 1 };
  const fresh = { version: 2 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  cache.set('entry', stale);
  inserted.length = 0;
  const fetched = cache.fetch('entry', { forceRefresh: true });
  assert.equal(cache.get('entry', { allowStale: true }), stale);
  assert.deepEqual(inserted, []);
  provider.resolve(fresh);
  assert.equal(await fetched, fresh);
  assert.equal(cache.get('entry'), fresh);
  assert.deepEqual(inserted, [[fresh, 'entry', 'replace']]);
});

test('fetch lifecycle: eviction during refresh disposes the stale value once in each hook', async () => {
  const provider = deferred();
  const disposed = [];
  const disposedAfter = [];
  const stale = { version: 1 };
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, old, options) => {
      assert.equal(old, stale);
      signal = options.signal;
      return provider.promise;
    },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => {
      disposedAfter.push(args);
      assert.equal(cache.has('entry'), false);
    },
  });
  cache.set('entry', stale);
  const fetched = cache.fetch('entry', { forceRefresh: true });
  const rejected = assert.rejects(fetched, /evicted/);
  cache.set('other', 'survivor');
  assert.equal(signal.aborted, true);
  await rejected;
  assert.deepEqual(disposed, [[stale, 'entry', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'entry', 'evict']]);
  provider.resolve({ version: 2 });
  await nextTurn();
  assert.equal(cache.has('entry'), false);
  assert.equal(cache.get('other'), 'survivor');
  assert.equal(disposed.length, 1);
  assert.equal(disposedAfter.length, 1);
});

test('fetch lifecycle: synchronous values settle misses and refreshes including falsy values', async () => {
  for (const value of [{ answer: 42 }, 0, false, '']) {
    const inserted = [];
    const cache = new Cache({
      max: 1,
      fetchMethod: () => value,
      onInsert: (...args) => inserted.push(args),
    });
    assert.equal(await settledByNextTurn(cache.fetch('entry')), value);
    assert.equal(cache.get('entry'), value);
    assert.equal(await settledByNextTurn(cache.fetch('entry', { forceRefresh: true })), value);
    assert.deepEqual(inserted, [[value, 'entry', 'add'], [value, 'entry', 'update']]);
  }
});

test('fetch lifecycle: synchronous undefined settles without adding an application value', async () => {
  const inserted = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => undefined,
    onInsert: (...args) => inserted.push(args),
  });
  assert.equal(await settledByNextTurn(cache.fetch('entry')), undefined);
  assert.equal(cache.has('entry'), false);
  assert.deepEqual(inserted, []);
});

test('fetch lifecycle: storing a successful provider result does not abort its signal', async () => {
  for (const refreshing of [false, true]) {
    const provider = deferred();
    const aborted = [];
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _old, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => aborted.push(signal.reason));
        return provider.promise;
      },
    });
    if (refreshing) cache.set('entry', 'stale');
    const fetched = cache.fetch('entry', { forceRefresh: refreshing });
    provider.resolve('fresh');
    assert.equal(await fetched, 'fresh');
    assert.equal(cache.get('entry'), 'fresh');
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborted, []);
  }
});

test('fetch lifecycle: explicit replacement still aborts a provider and preserves the replacement', async () => {
  for (const refreshing of [false, true]) {
    const provider = deferred();
    const inserted = [];
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _old, options) => {
        signal = options.signal;
        return provider.promise;
      },
      onInsert: (...args) => inserted.push(args),
    });
    if (refreshing) cache.set('entry', 'stale');
    const fetched = cache.fetch('entry', { forceRefresh: refreshing });
    const rejected = assert.rejects(fetched, /replaced/);
    inserted.length = 0;
    cache.set('entry', 'replacement');
    assert.equal(signal.aborted, true);
    await rejected;
    assert.deepEqual(inserted, [['replacement', 'entry', refreshing ? 'replace' : 'add']]);
    provider.resolve('late result');
    await nextTurn();
    assert.equal(cache.get('entry'), 'replacement');
    assert.equal(inserted.length, 1);
  }
});

test('fetch lifecycle: ordinary insert reasons and fetch hits preserve LRU eviction', async () => {
  const inserted = [];
  const disposed = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'fetched',
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
  });
  cache.set('a', 1);
  cache.set('a', 1);
  cache.set('a', 2);
  cache.set('b', 3);
  assert.equal(await cache.fetch('a'), 2);
  cache.set('c', 4);
  assert.equal(cache.has('b'), false);
  assert.deepEqual([...cache.keys()], ['c', 'a']);
  assert.deepEqual(inserted, [[1, 'a', 'add'], [1, 'a', 'update'], [2, 'a', 'replace'], [3, 'b', 'add'], [4, 'c', 'add']]);
  assert.deepEqual(disposed, [[1, 'a', 'set'], [3, 'b', 'evict']]);
});

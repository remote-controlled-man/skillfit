#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate as nextTurn } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(
  dirname(fileURLToPath(import.meta.url)),
  true,
);
after(cleanup);

async function settledFetch(promise) {
  const pending = Symbol('pending');
  const value = await Promise.race([
    promise,
    nextTurn().then(() => pending),
  ]);
  assert.notEqual(value, pending, 'fetch must settle by the next event loop turn');
  return value;
}

test('fetch lifecycle: onInsert receives only the application value on a miss', async () => {
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'fetched value',
    onInsert: (...args) => inserted.push(args),
  });

  assert.equal(await cache.fetch('key'), 'fetched value');
  assert.deepEqual(inserted, [['fetched value', 'key', 'add']]);
});

test('fetch lifecycle: ordinary set reports add, update and replace for application values', () => {
  const inserted = [];
  const value = { version: 1 };
  const replacement = { version: 2 };
  const applicationPromise = Promise.resolve('application promise');
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'unused',
    onInsert: (...args) => inserted.push(args),
  });

  cache.set('key', value);
  cache.set('key', value);
  cache.set('key', replacement);
  cache.set('promise', applicationPromise);
  assert.deepEqual(inserted, [
    [value, 'key', 'add'],
    [value, 'key', 'update'],
    [replacement, 'key', 'replace'],
    [applicationPromise, 'promise', 'add'],
  ]);
});

for (const unchanged of [true, false]) {
  test(`fetch lifecycle: refresh reports ${unchanged ? 'update' : 'replace'} relative to the stale application value`, async () => {
    const inserted = [];
    const oldValue = { version: 1 };
    const fetchedValue = unchanged ? oldValue : { version: 2 };
    const provider = Promise.withResolvers();
    const cache = new Cache({
      max: 2,
      fetchMethod: () => provider.promise,
      onInsert: (...args) => inserted.push(args),
    });
    cache.set('key', oldValue);
    inserted.length = 0;

    const result = cache.fetch('key', { forceRefresh: true });
    assert.deepEqual(inserted, []);
    assert.equal(cache.peek('key'), oldValue);
    provider.resolve(fetchedValue);
    assert.equal(await settledFetch(result), fetchedValue);
    assert.deepEqual(inserted, [
      [fetchedValue, 'key', unchanged ? 'update' : 'replace'],
    ]);
    assert.equal(cache.get('key'), fetchedValue);
  });
}

for (const allowStaleOnFetchAbort of [false, true]) {
  test(`fetch lifecycle: eviction disposes the stale value once with stale-on-abort ${allowStaleOnFetchAbort}`, async () => {
    const disposed = [];
    const disposedAfter = [];
    const provider = Promise.withResolvers();
    let signal;
    const cache = new Cache({
      max: 1,
      allowStaleOnFetchAbort,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args),
    });
    // A falsy value is still an application value that must be disposed.
    cache.set('key', 0);
    const result = cache.fetch('key', { forceRefresh: true });
    const completion = allowStaleOnFetchAbort
      ? result.then(value => assert.equal(value, 0))
      : assert.rejects(result, /evicted/);
    cache.set('survivor', 'retained');

    assert.equal(signal.aborted, true);
    assert.deepEqual(disposed, [[0, 'key', 'evict']]);
    assert.deepEqual(disposedAfter, [[0, 'key', 'evict']]);
    await completion;
    provider.resolve('late value');
    await nextTurn();
    assert.deepEqual(disposed, [[0, 'key', 'evict']]);
    assert.deepEqual(disposedAfter, [[0, 'key', 'evict']]);
    assert.equal(cache.has('key'), false);
    assert.equal(cache.get('survivor'), 'retained');
    assert.equal(cache.size, 1);
  });
}

test('fetch lifecycle: pop disposes the stale application value during refresh', async () => {
  const disposed = [];
  const disposedAfter = [];
  const provider = Promise.withResolvers();
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 'stale');
  const result = cache.fetch('key', { forceRefresh: true });
  const completion = assert.rejects(result, /evicted/);

  assert.equal(cache.pop(), 'stale');
  await completion;
  provider.resolve('late value');
  await nextTurn();
  assert.deepEqual(disposed, [['stale', 'key', 'evict']]);
  assert.deepEqual(disposedAfter, [['stale', 'key', 'evict']]);
  assert.equal(cache.size, 0);
});

test('fetch lifecycle: evicting a pending miss does not dispose an internal promise', async () => {
  const inserted = [];
  const disposed = [];
  const disposedAfter = [];
  const provider = Promise.withResolvers();
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  const result = cache.fetch('key');
  const completion = assert.rejects(result, /evicted/);
  cache.set('survivor', 'retained');
  await completion;
  provider.resolve('late value');
  await nextTurn();

  assert.deepEqual(inserted, [['retained', 'survivor', 'add']]);
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.equal(cache.get('survivor'), 'retained');
});

for (const [label, value] of [
  ['string', 'synchronous value'],
  ['zero', 0],
  ['false', false],
  ['empty string', ''],
  ['null', null],
  ['object', { synchronous: true }],
  ['undefined', undefined],
]) {
  test(`fetch lifecycle: synchronous ${label} result settles and caches correctly`, async () => {
    const inserted = [];
    let calls = 0;
    const cache = new Cache({
      max: 2,
      fetchMethod: () => {
        calls++;
        return value;
      },
      onInsert: (...args) => inserted.push(args),
    });

    assert.equal(await settledFetch(cache.fetch('key')), value);
    assert.equal(cache.get('key'), value);
    assert.equal(cache.has('key'), value !== undefined);
    assert.deepEqual(inserted, value === undefined ? [] : [[value, 'key', 'add']]);
    if (value !== undefined) {
      assert.equal(await settledFetch(cache.fetch('key')), value);
      assert.equal(calls, 1);
    }
  });
}

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful ${refresh ? 'refresh' : 'miss'} leaves the provider signal un-aborted`, async () => {
    const provider = Promise.withResolvers();
    const aborts = [];
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => aborts.push(signal.reason));
        return provider.promise;
      },
    });
    if (refresh) cache.set('key', 'stale');
    const result = cache.fetch('key', { forceRefresh: refresh });
    provider.resolve('fresh');

    assert.equal(await settledFetch(result), 'fresh');
    assert.equal(cache.get('key'), 'fresh');
    assert.equal(signal.aborted, false);
    assert.deepEqual(aborts, []);
  });
}

for (const refresh of [false, true]) {
  test(`fetch lifecycle: explicit replacement cancels a pending ${refresh ? 'refresh' : 'miss'}`, async () => {
    const provider = Promise.withResolvers();
    const inserted = [];
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
      onInsert: (...args) => inserted.push(args),
    });
    if (refresh) cache.set('key', 'stale');
    inserted.length = 0;
    const result = cache.fetch('key', { forceRefresh: refresh });
    const completion = assert.rejects(result, /replaced/);
    cache.set('key', 'explicit replacement');

    assert.equal(signal.aborted, true);
    await completion;
    provider.resolve('late provider value');
    await nextTurn();
    assert.equal(cache.get('key'), 'explicit replacement');
    assert.deepEqual(inserted, [
      ['explicit replacement', 'key', refresh ? 'replace' : 'add'],
    ]);
  });
}

test('fetch lifecycle: coalesced callers and stale reads preserve successful refresh and LRU eviction', async () => {
  const provider = Promise.withResolvers();
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return provider.promise;
    },
  });
  cache.set('key', 'stale');
  cache.set('other', 'other value');
  const first = cache.fetch('key', { forceRefresh: true });
  const second = cache.fetch('key');
  assert.equal(await cache.fetch('key', { allowStale: true }), 'stale');
  assert.equal(calls, 1);
  provider.resolve('fresh');
  assert.deepEqual(await Promise.all([first, second]), ['fresh', 'fresh']);
  assert.equal(await cache.fetch('key'), 'fresh');
  assert.equal(calls, 1);

  cache.set('newest', 'new value');
  assert.equal(cache.has('other'), false);
  assert.deepEqual([...cache.entries()], [
    ['newest', 'new value'],
    ['key', 'fresh'],
  ]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function controlledFetch(options) {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    ...options,
    fetchMethod(key, staleValue) {
      calls.push([key, staleValue]);
      return new Promise(resolve => pending.set(key, resolve));
    },
  });
  return { cache, calls, resolve: (key, value) => pending.get(key)(value) };
}

// Bound traversal so a broken linked order fails instead of hanging the suite.
function readOrder(iterator, length) {
  const entries = [];
  for (let i = 0; i < length; i++) {
    const step = iterator.next();
    assert.equal(step.done, false, 'LRU traversal must include every entry');
    entries.push(step.value);
  }
  assert.equal(iterator.next().done, true, 'LRU traversal must end at cache.size');
  return entries;
}

function assertState(cache, entries) {
  assert.equal(cache.size, entries.length);
  assert.equal(cache.calculatedSize, entries.reduce((size, [, value]) => size + value.length, 0));
  assert.ok(cache.calculatedSize <= cache.maxSize, 'stored values must fit maxSize');
  assert.deepEqual(readOrder(cache.entries(), entries.length), entries);
  assert.deepEqual(readOrder(cache.rentries(), entries.length), [...entries].reverse());
  for (const [key, value] of entries) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size regression: reverse completion preserves accounting, eviction and later LRU writes', async () => {
  const { cache, resolve } = controlledFetch({ max: 3, maxSize: 4, sizeCalculation: value => value.length });
  const first = cache.fetch('first');
  const second = cache.fetch('second');

  resolve('second', 'bbb');
  assert.equal(await second, 'bbb');
  assert.equal(cache.calculatedSize, 3);
  resolve('first', 'aa');
  assert.equal(await first, 'aa');

  assertState(cache, [['first', 'aa']]);
  assert.equal(cache.has('second'), false);
  cache.set('third', 'cc');
  assertState(cache, [['third', 'cc'], ['first', 'aa']]);
  assert.equal(cache.get('first'), 'aa');
  cache.set('fourth', 'd');
  assertState(cache, [['fourth', 'd'], ['first', 'aa']]);
  assert.equal(cache.has('third'), false);
  cache.set('fourth', 'ddd');
  assertState(cache, [['fourth', 'ddd']]);
  assert.equal(cache.has('first'), false);
  assert.equal(cache.delete('fourth'), true);
  assertState(cache, []);
  cache.set('reused', 'eeee');
  assertState(cache, [['reused', 'eeee']]);
});

test('fetch-size regression: completion of a middle request moves it before size eviction', async () => {
  const { cache, resolve } = controlledFetch({ maxSize: 5, sizeCalculation: value => value.length });
  const first = cache.fetch('first');
  const middle = cache.fetch('middle');
  const last = cache.fetch('last');

  resolve('last', 'cccc');
  assert.equal(await last, 'cccc');
  resolve('middle', 'bbb');
  assert.equal(await middle, 'bbb');
  assertState(cache, [['middle', 'bbb']]);
  assert.equal(cache.has('first'), false);
  assert.equal(cache.has('last'), false);

  // A fetch evicted while pending still resolves to its caller without reinsertion.
  resolve('first', 'a');
  assert.equal(await first, 'a');
  assertState(cache, [['middle', 'bbb']]);
  cache.set('next', 'dd');
  assertState(cache, [['next', 'dd'], ['middle', 'bbb']]);
});

test('fetch-size regression: deduplicated misses keep completion order when every result fits', async () => {
  const { cache, calls, resolve } = controlledFetch({ maxSize: 6, sizeCalculation: value => value.length });
  const first = cache.fetch('first');
  const duplicate = cache.fetch('first');
  const second = cache.fetch('second');
  const third = cache.fetch('third');
  assert.deepEqual(calls, [['first', undefined], ['second', undefined], ['third', undefined]]);

  resolve('third', 'ccc');
  assert.equal(await third, 'ccc');
  resolve('first', 'a');
  assert.deepEqual(await Promise.all([first, duplicate]), ['a', 'a']);
  resolve('second', 'bb');
  assert.equal(await second, 'bb');
  assertState(cache, [['second', 'bb'], ['first', 'a'], ['third', 'ccc']]);

  assert.equal(await cache.fetch('third'), 'ccc');
  assert.equal(calls.length, 3, 'a fresh cache hit must not invoke fetchMethod');
  assertState(cache, [['third', 'ccc'], ['second', 'bb'], ['first', 'a']]);
  cache.set('fourth', 'dd');
  assertState(cache, [['fourth', 'dd'], ['third', 'ccc']]);
});

test('fetch-size regression: growing forced refresh retains stale size and deduplicates callers', async () => {
  const { cache, calls, resolve } = controlledFetch({ max: 3, maxSize: 5, sizeCalculation: value => value.length });
  cache.set('refresh', 'a');
  cache.set('other', 'bbb');
  const refreshed = cache.fetch('refresh', { forceRefresh: true });
  const duplicate = cache.fetch('refresh');
  assert.equal(await cache.fetch('refresh', { allowStale: true }), 'a');
  assert.equal(cache.peek('refresh'), 'a');
  assert.equal(cache.calculatedSize, 4);
  assert.deepEqual(calls, [['refresh', 'a']]);

  resolve('refresh', 'aaaa');
  assert.deepEqual(await Promise.all([refreshed, duplicate]), ['aaaa', 'aaaa']);
  assertState(cache, [['refresh', 'aaaa']]);
  assert.equal(cache.has('other'), false);
  cache.set('next', 'b');
  assertState(cache, [['next', 'b'], ['refresh', 'aaaa']]);
});

test('fetch-size regression: ordinary size-bound updates preserve MRU and unchanged-value sets', () => {
  const cache = new Cache({ max: 3, maxSize: 5, sizeCalculation: value => value.length });
  cache.set('first', 'a');
  cache.set('second', 'bbb');
  cache.set('first', 'aaa');
  assertState(cache, [['first', 'aaa']]);
  assert.equal(cache.has('second'), false);
  cache.set('third', 'cc');
  cache.set('first', 'aaa');
  assertState(cache, [['first', 'aaa'], ['third', 'cc']]);
  assert.equal(cache.get('third'), 'cc');
  assertState(cache, [['third', 'cc'], ['first', 'aaa']]);
  cache.set('fourth', 'd');
  assertState(cache, [['fourth', 'd'], ['third', 'cc']]);
  assert.equal(cache.has('first'), false);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function controlledCache(options) {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod: (key, stale) => {
      calls.push([key, stale]);
      return new Promise(resolve => pending.set(key, resolve));
    },
  });
  return {
    cache,
    calls,
    resolve(key, value) {
      assert.ok(pending.has(key), `fetch for ${key} must be pending`);
      pending.get(key)(value);
      pending.delete(key);
    },
  };
}

function assertCache(cache, expected) {
  // Expected entries are in public iteration order, most recently used first.
  const expectedSize = expected.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, expectedSize, 'accounted size must match retained values');
  assert.equal(cache.size, expected.length, 'entry count must match retained values');
  assert.ok(cache.calculatedSize <= cache.maxSize, 'retained values must fit the size limit');
  const collect = iterator => {
    const result = [];
    for (const entry of iterator) {
      result.push(entry);
      // A broken linked order should fail instead of looping indefinitely.
      assert.ok(result.length <= expected.length, 'iteration must terminate without duplicate entries');
    }
    return result;
  };
  assert.deepEqual(collect(cache.entries()), expected);
  assert.deepEqual(collect(cache.rentries()), [...expected].reverse());
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

for (const max of [0, 3]) {
  test(`fetch-size historical regression: oldest fetch completes last with max=${max}`, async () => {
    const { cache, resolve } = controlledCache({ max, maxSize: 10 });
    const first = cache.fetch('first');
    const second = cache.fetch('second');
    const third = cache.fetch('third');
    assert.equal(cache.calculatedSize, 0);
    assert.equal(cache.size, 3);

    resolve('third', 'ccccc');
    assert.equal(await third, 'ccccc');
    assert.equal(cache.calculatedSize, 5);
    resolve('second', 'bbbbb');
    assert.equal(await second, 'bbbbb');
    assert.equal(cache.calculatedSize, 10);
    resolve('first', 'aaaaaa');
    assert.equal(await first, 'aaaaaa');

    assertCache(cache, [['first', 'aaaaaa']]);
    assert.equal(cache.has('second'), false);
    assert.equal(cache.has('third'), false);
    cache.set('later', 'dddd');
    assertCache(cache, [['later', 'dddd'], ['first', 'aaaaaa']]);
    assert.equal(cache.get('first'), 'aaaaaa');
    cache.set('newest', 'eeee');
    assertCache(cache, [['newest', 'eeee'], ['first', 'aaaaaa']]);
    assert.equal(cache.has('later'), false);
  });
}

test('fetch-size refresh regression: cached sizes survive reverse completion and oldest growth', async () => {
  const { cache, calls, resolve } = controlledCache({ maxSize: 10 });
  cache.set('first', 'aa');
  cache.set('second', 'bbb');
  cache.set('third', 'cccc');
  const first = cache.fetch('first', { forceRefresh: true });
  const second = cache.fetch('second', { forceRefresh: true });
  assert.equal(cache.calculatedSize, 9);
  assert.equal(cache.peek('first'), 'aa');
  assert.equal(cache.peek('second'), 'bbb');
  assert.deepEqual(calls, [['first', 'aa'], ['second', 'bbb']]);

  resolve('second', 'BBBB');
  assert.equal(await second, 'BBBB');
  assert.equal(cache.calculatedSize, 10);
  resolve('first', 'AAAAAAA');
  assert.equal(await first, 'AAAAAAA');
  assertCache(cache, [['first', 'AAAAAAA']]);
  assert.equal(cache.has('second'), false);
  assert.equal(cache.has('third'), false);
});

test('fetch-size deduplication: callers share one fetch while completions reorder eviction', async () => {
  const { cache, calls, resolve } = controlledCache({ maxSize: 6 });
  const first = cache.fetch('shared');
  const duplicate = cache.fetch('shared');
  const other = cache.fetch('other');
  assert.deepEqual(calls, [['shared', undefined], ['other', undefined]]);
  assert.equal(cache.size, 2);

  resolve('other', 'bbb');
  assert.equal(await other, 'bbb');
  assert.equal(cache.calculatedSize, 3);
  resolve('shared', 'aaaaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaaaa', 'aaaaa']);
  assertCache(cache, [['shared', 'aaaaa']]);
  assert.equal(cache.has('other'), false);
  assert.equal(await cache.fetch('shared'), 'aaaaa');
  assert.equal(calls.length, 2);
});

test('fetch-size capacity: evicted pending results cannot replace entries in reused capacity', async () => {
  const { cache, resolve } = controlledCache({ max: 2, maxSize: 6 });
  const evicted = cache.fetch('evicted');
  const retained = cache.fetch('retained');
  resolve('retained', 'bbbbbb');
  assert.equal(await retained, 'bbbbbb');
  cache.set('replacement', 'c');
  assertCache(cache, [['replacement', 'c']]);

  resolve('evicted', 'aa');
  assert.equal(await evicted, 'aa');
  assert.equal(cache.has('evicted'), false);
  assert.equal(cache.has('retained'), false);
  assertCache(cache, [['replacement', 'c']]);
  cache.set('next', 'ddddd');
  assertCache(cache, [['next', 'ddddd'], ['replacement', 'c']]);
});

test('fetch-size ordinary operations: growing an old entry preserves get set pop and reuse order', () => {
  const cache = new Cache({ max: 3, maxSize: 10, sizeCalculation: value => value.length });
  cache.set('a', 'aaa');
  cache.set('b', 'bb');
  cache.set('c', 'cccc');
  assert.equal(cache.get('b'), 'bb');
  cache.set('a', 'AAAAA');
  assertCache(cache, [['a', 'AAAAA'], ['b', 'bb']]);
  assert.equal(cache.has('c'), false);
  cache.set('d', 'ddd');
  assertCache(cache, [['d', 'ddd'], ['a', 'AAAAA'], ['b', 'bb']]);
  assert.equal(cache.get('b'), 'bb');
  assert.equal(cache.pop(), 'AAAAA');
  assertCache(cache, [['b', 'bb'], ['d', 'ddd']]);
  assert.equal(cache.delete('b'), true);
  assertCache(cache, [['d', 'ddd']]);
  cache.clear();
  assertCache(cache, []);
  cache.set('e', 'ee');
  cache.set('f', 'ffff');
  assertCache(cache, [['f', 'ffff'], ['e', 'ee']]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import Cache from './index.js';

const deferred = () => {
  let resolve;
  const promise = new Promise(done => { resolve = done; });
  return { promise, resolve };
};

// Bound traversal so a broken linked order fails instead of hanging the suite.
const collect = (iterator, count) => {
  const result = [];
  for (const entry of iterator) {
    result.push(entry);
    if (result.length > count) break;
  }
  return result;
};

const assertState = (cache, entries) => {
  const size = entries.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, size, 'size must match retained values');
  assert.ok(cache.calculatedSize <= cache.maxSize, 'size limit must hold');
  assert.equal(cache.size, entries.length, 'entry count must match traversal');
  assert.deepEqual(collect(cache.entries(), entries.length), entries);
  assert.deepEqual(collect(cache.rentries(), entries.length), [...entries].reverse());
  for (const [key, value] of entries) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
};

test('fetch-size historical regression: reverse completion retains the result and correct LRU order', async () => {
  const first = deferred();
  const second = deferred();
  const cache = new Cache({
    max: 3,
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: key => key === 'first' ? first.promise : second.promise,
  });
  const firstResult = cache.fetch('first');
  const secondResult = cache.fetch('second');

  second.resolve('bbbb');
  assert.equal(await secondResult, 'bbbb');
  assert.equal(cache.calculatedSize, 4);
  first.resolve('aaaa');
  assert.equal(await firstResult, 'aaaa');
  assertState(cache, [['first', 'aaaa']]);
  assert.equal(cache.has('second'), false);

  cache.set('third', 'c');
  assertState(cache, [['third', 'c'], ['first', 'aaaa']]);
  assert.equal(cache.get('first'), 'aaaa');
  cache.set('fourth', 'd');
  assertState(cache, [['fourth', 'd'], ['first', 'aaaa']]);
  assert.equal(cache.has('third'), false);
});

test('fetch-size refresh regression: a growing LRU result evicts the older remaining value', async () => {
  const refresh = deferred();
  let calls = 0;
  const cache = new Cache({
    maxSize: 8,
    sizeCalculation: value => value.length,
    fetchMethod: (key, stale) => {
      calls++;
      assert.equal(key, 'first');
      assert.equal(stale, 'aa');
      return refresh.promise;
    },
  });
  cache.set('first', 'aa');
  cache.set('second', 'bbb');
  cache.set('third', 'cc');
  const result = cache.fetch('first', { forceRefresh: true });
  const duplicate = cache.fetch('first');
  assert.equal(calls, 1);
  assert.equal(cache.calculatedSize, 7);
  assert.equal(cache.peek('first'), 'aa');

  refresh.resolve('aaaaa');
  assert.deepEqual(await Promise.all([result, duplicate]), ['aaaaa', 'aaaaa']);
  assertState(cache, [['first', 'aaaaa'], ['third', 'cc']]);
  assert.equal(cache.has('second'), false);
  cache.set('fourth', 'dd');
  assertState(cache, [['fourth', 'dd'], ['first', 'aaaaa']]);
  assert.equal(cache.has('third'), false);
});

test('fetch-size ordinary update regression: growing set preserves recency and explicit sizes', () => {
  const cache = new Cache({ max: 3, maxSize: 7 });
  cache.set('first', 'aa', { size: 2 });
  cache.set('second', 'bb', { size: 2 });
  cache.set('third', 'cc', { size: 2 });
  cache.set('first', 'aaaaa', { size: 5 });
  assertState(cache, [['first', 'aaaaa'], ['third', 'cc']]);
  assert.equal(cache.has('second'), false);
  cache.set('first', 'aaaaa', { size: 5 });
  assertState(cache, [['first', 'aaaaa'], ['third', 'cc']]);
  assert.equal(cache.get('third'), 'cc');
  cache.set('fourth', 'd', { size: 1 });
  assertState(cache, [['fourth', 'd'], ['third', 'cc']]);
  assert.equal(cache.has('first'), false);
});

test('fetch-size compatibility: misses deduplicate and cached fetches update recency', async () => {
  const first = deferred();
  const second = deferred();
  const calls = [];
  const cache = new Cache({
    max: 3,
    maxSize: 10,
    sizeCalculation: value => value.length,
    fetchMethod: key => {
      calls.push(key);
      return key === 'first' ? first.promise : second.promise;
    },
  });
  cache.set('stable', 'ss');
  const firstResult = cache.fetch('first');
  const duplicate = cache.fetch('first');
  const secondResult = cache.fetch('second');
  assert.deepEqual(calls, ['first', 'second']);
  second.resolve('bbb');
  assert.equal(await secondResult, 'bbb');
  first.resolve('aaaa');
  assert.deepEqual(await Promise.all([firstResult, duplicate]), ['aaaa', 'aaaa']);
  assertState(cache, [['first', 'aaaa'], ['second', 'bbb'], ['stable', 'ss']]);

  assert.equal(cache.get('stable'), 'ss');
  assert.equal(await cache.fetch('second'), 'bbb');
  assert.deepEqual(calls, ['first', 'second']);
  assertState(cache, [['second', 'bbb'], ['stable', 'ss'], ['first', 'aaaa']]);
  cache.set('new', 'n');
  assertState(cache, [['new', 'n'], ['second', 'bbb'], ['stable', 'ss']]);
  assert.equal(cache.has('first'), false);
});

test('fetch-size compatibility: replacing a pending fetch preserves the write and later capacity', async () => {
  const first = deferred();
  const second = deferred();
  const cache = new Cache({
    max: 2,
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: key => key === 'first' ? first.promise : second.promise,
  });
  const firstResult = cache.fetch('first');
  const secondResult = cache.fetch('second');
  cache.set('first', 'aa');
  first.resolve('aaaa');
  assert.equal(await firstResult, 'aaaa');
  assert.equal(cache.peek('first'), 'aa');
  assert.equal(cache.calculatedSize, 2);

  second.resolve('bbbb');
  assert.equal(await secondResult, 'bbbb');
  assertState(cache, [['second', 'bbbb']]);
  cache.set('third', 'c');
  assertState(cache, [['third', 'c'], ['second', 'bbbb']]);
  assert.equal(cache.delete('second'), true);
  cache.set('fourth', 'dddd');
  assertState(cache, [['fourth', 'dddd'], ['third', 'c']]);
});

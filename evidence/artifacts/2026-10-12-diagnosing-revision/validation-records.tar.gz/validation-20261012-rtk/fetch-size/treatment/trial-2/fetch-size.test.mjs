#!/usr/bin/env node
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { test } from 'node:test';

const Cache = createRequire(import.meta.url)('./index.js');

function controlledFetch() {
  const pending = new Map();
  const calls = [];
  return {
    pending,
    calls,
    fetchMethod(key, previous, { signal }) {
      calls.push(key);
      return new Promise(resolve => {
        pending.set(key, { resolve, signal, previous });
      });
    },
  };
}

function collect(iterable, expectedLength) {
  const values = [];
  for (const value of iterable) {
    values.push(value);
    assert.ok(values.length <= expectedLength, 'iteration must terminate without repeating entries');
  }
  return values;
}

// Inspect settled entries through public APIs without changing their recency.
function assertSnapshot(cache, expected) {
  const total = expected.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, total, 'calculatedSize must equal retained value sizes');
  assert.ok(cache.calculatedSize <= cache.maxSize, 'retained values must fit maxSize');
  assert.equal(cache.size, expected.length);
  assert.deepEqual(collect(cache.entries(), expected.length), expected);
  assert.deepEqual(collect(cache.rentries(), expected.length), [...expected].reverse());
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

for (const max of [0, 4]) {
  test(`fetch-size historical regression: reverse completion preserves accounting and LRU (max=${max})`, async () => {
    const fetches = controlledFetch();
    const cache = new Cache({
      max,
      maxSize: 5,
      sizeCalculation: value => value.length,
      fetchMethod: fetches.fetchMethod,
    });
    const first = cache.fetch('first');
    const second = cache.fetch('second');
    assert.equal(cache.calculatedSize, 0);

    fetches.pending.get('second').resolve('bbbb');
    assert.equal(await second, 'bbbb');
    assert.equal(cache.calculatedSize, 4);
    fetches.pending.get('first').resolve('aaa');
    assert.equal(await first, 'aaa');

    // Completing the older request must evict the previously completed value.
    assertSnapshot(cache, [['first', 'aaa']]);
    assert.equal(cache.has('second'), false);
    cache.set('third', 'cc');
    assertSnapshot(cache, [['third', 'cc'], ['first', 'aaa']]);
    assert.equal(cache.get('first'), 'aaa');
    assertSnapshot(cache, [['first', 'aaa'], ['third', 'cc']]);
    cache.set('fourth', 'dddd');
    assertSnapshot(cache, [['fourth', 'dddd']]);
    assert.equal(cache.has('first'), false);
    assert.equal(cache.has('third'), false);
    cache.set('fifth', 'e');
    assertSnapshot(cache, [['fifth', 'e'], ['fourth', 'dddd']]);
    assert.equal(cache.pop(), 'dddd');
    assertSnapshot(cache, [['fifth', 'e']]);
    assert.equal(cache.delete('fifth'), true);
    assertSnapshot(cache, []);
    cache.set('reused', 'rr');
    assertSnapshot(cache, [['reused', 'rr']]);
  });
}

test('fetch-size mixed completion makes the last two results most recent', async () => {
  const fetches = controlledFetch();
  const cache = new Cache({
    maxSize: 4,
    sizeCalculation: value => value.length,
    fetchMethod: fetches.fetchMethod,
  });
  const first = cache.fetch('first');
  const second = cache.fetch('second');
  const third = cache.fetch('third');
  fetches.pending.get('third').resolve('cc');
  assert.equal(await third, 'cc');
  fetches.pending.get('first').resolve('aa');
  assert.equal(await first, 'aa');
  fetches.pending.get('second').resolve('bb');
  assert.equal(await second, 'bb');
  assertSnapshot(cache, [['second', 'bb'], ['first', 'aa']]);
  assert.equal(cache.has('third'), false);
  cache.set('fourth', 'dd');
  assertSnapshot(cache, [['fourth', 'dd'], ['second', 'bb']]);
});

test('fetch-size growing refresh preserves the refreshed entry and removes older peers', async () => {
  const fetches = controlledFetch();
  const cache = new Cache({
    max: 3,
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: fetches.fetchMethod,
  });
  cache.set('refresh', 'aa');
  cache.set('peer', 'bbb');
  const result = cache.fetch('refresh', { forceRefresh: true });
  assert.equal(fetches.pending.get('refresh').previous, 'aa');
  assert.equal(cache.peek('refresh'), 'aa');
  assert.equal(cache.calculatedSize, 5);
  fetches.pending.get('refresh').resolve('aaaa');
  assert.equal(await result, 'aaaa');
  assertSnapshot(cache, [['refresh', 'aaaa']]);
  assert.equal(cache.has('peer'), false);
  cache.set('next', 'b');
  assertSnapshot(cache, [['next', 'b'], ['refresh', 'aaaa']]);
});

test('fetch-size ordinary size-changing set and get preserve recency', () => {
  const cache = new Cache({ max: 3, maxSize: 5, sizeCalculation: value => value.length });
  cache.set('first', 'aa');
  cache.set('second', 'bb');
  cache.set('first', 'aaaa');
  assertSnapshot(cache, [['first', 'aaaa']]);
  assert.equal(cache.has('second'), false);
  cache.set('first', 'aaaa');
  cache.set('third', 'c');
  assertSnapshot(cache, [['third', 'c'], ['first', 'aaaa']]);
  assert.equal(cache.get('first'), 'aaaa');
  cache.set('fourth', 'd');
  assertSnapshot(cache, [['fourth', 'd'], ['first', 'aaaa']]);
  assert.equal(cache.has('third'), false);
});

test('fetch-size duplicate fetch callers share one load and cached hits keep LRU behavior', async () => {
  const fetches = controlledFetch();
  const cache = new Cache({
    max: 2,
    maxSize: 4,
    sizeCalculation: value => value.length,
    fetchMethod: fetches.fetchMethod,
  });
  const first = cache.fetch('shared');
  const duplicate = cache.fetch('shared');
  assert.deepEqual(fetches.calls, ['shared']);
  assert.equal(cache.size, 1);
  assert.equal(cache.calculatedSize, 0);
  assert.equal(cache.get('shared'), undefined);
  fetches.pending.get('shared').resolve('aaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaa', 'aaa']);
  assertSnapshot(cache, [['shared', 'aaa']]);
  cache.set('peer', 'b');
  assert.equal(await cache.fetch('shared'), 'aaa');
  assert.deepEqual(fetches.calls, ['shared']);
  assertSnapshot(cache, [['shared', 'aaa'], ['peer', 'b']]);
  cache.set('next', 'c');
  assertSnapshot(cache, [['next', 'c'], ['shared', 'aaa']]);
  assert.equal(cache.has('peer'), false);
});

test('fetch-size an evicted pending result cannot overwrite a reused capacity slot', async () => {
  const fetches = controlledFetch();
  const cache = new Cache({
    max: 2,
    maxSize: 4,
    sizeCalculation: value => value.length,
    fetchMethod: fetches.fetchMethod,
  });
  const result = cache.fetch('pending');
  cache.set('first', 'aa');
  cache.set('second', 'bb');
  assert.equal(fetches.pending.get('pending').signal.aborted, true);
  assertSnapshot(cache, [['second', 'bb'], ['first', 'aa']]);
  fetches.pending.get('pending').resolve('xxx');
  assert.equal(await result, 'xxx');
  assert.equal(cache.has('pending'), false);
  assertSnapshot(cache, [['second', 'bb'], ['first', 'aa']]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import Cache from './index.js';

function fetchingCache(options = {}) {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    maxSize: 5,
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod: key => {
      calls.push(key);
      return new Promise((resolve, reject) => {
        pending.set(key, { resolve, reject });
      });
    },
  });
  return { cache, pending, calls };
}

// Bound iteration so a broken linked order produces an assertion, not a hang.
function collect(iterable, limit) {
  const iterator = iterable[Symbol.iterator]();
  const values = [];
  for (let i = 0; i <= limit; i++) {
    const step = iterator.next();
    if (step.done) return values;
    values.push(step.value);
  }
  assert.fail('cache iteration exceeded the expected entry count');
}

function assertEntries(cache, expected) {
  const size = expected.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, size, 'calculatedSize must count retained values');
  assert.ok(cache.calculatedSize <= cache.maxSize, 'retained values must fit maxSize');
  assert.equal(cache.size, expected.length, 'size must count retained entries');
  assert.deepEqual(collect(cache.entries(), expected.length), expected);
  assert.deepEqual(collect(cache.rentries(), expected.length), [...expected].reverse());
  assert.deepEqual(collect(cache.keys(), expected.length), expected.map(([key]) => key));
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size historical regression: reverse completions preserve accounting and later LRU writes', async () => {
  const { cache, pending } = fetchingCache();
  const first = cache.fetch('first-request');
  const second = cache.fetch('second-request');
  assert.equal(cache.calculatedSize, 0);
  assert.equal(cache.size, 2);

  pending.get('second-request').resolve('bbbb');
  assert.equal(await second, 'bbbb');
  assert.equal(cache.calculatedSize, 4);
  assert.equal(cache.peek('second-request'), 'bbbb');

  pending.get('first-request').resolve('aaaa');
  assert.equal(await first, 'aaaa');
  assertEntries(cache, [['first-request', 'aaaa']]);
  assert.equal(cache.has('second-request'), false);

  cache.set('later', 'cc');
  assertEntries(cache, [['later', 'cc']]);
  assert.equal(cache.has('first-request'), false);
  cache.set('next', 'ddd');
  assertEntries(cache, [['next', 'ddd'], ['later', 'cc']]);
  assert.equal(cache.get('later'), 'cc');
  assertEntries(cache, [['later', 'cc'], ['next', 'ddd']]);
  cache.set('final', 'ee');
  assertEntries(cache, [['final', 'ee'], ['later', 'cc']]);
  assert.equal(cache.has('next'), false);
  assert.equal(cache.delete('later'), true);
  assertEntries(cache, [['final', 'ee']]);
});

test('fetch-size regression: request-order completions respect size and count limits', async () => {
  const { cache, pending } = fetchingCache({ max: 3 });
  const first = cache.fetch('earlier');
  const second = cache.fetch('later');
  pending.get('earlier').resolve('aaaa');
  assert.equal(await first, 'aaaa');
  assert.equal(cache.calculatedSize, 4);
  assert.equal(cache.size, 2);
  pending.get('later').resolve('bbbb');
  assert.equal(await second, 'bbbb');
  assertEntries(cache, [['later', 'bbbb']]);
  assert.equal(cache.has('earlier'), false);
  cache.set('small', 's');
  assertEntries(cache, [['small', 's'], ['later', 'bbbb']]);
});

test('fetch-size regression: a middle placeholder completion evicts older entries without subtracting its new size', async () => {
  const { cache, pending } = fetchingCache({ maxSize: 7, max: 4 });
  cache.set('seed', 'ss');
  const first = cache.fetch('middle');
  const second = cache.fetch('newest');
  pending.get('newest').resolve('bbbb');
  assert.equal(await second, 'bbbb');
  assert.equal(cache.calculatedSize, 6);
  assert.equal(cache.size, 3);
  pending.get('middle').resolve('aaaaa');
  assert.equal(await first, 'aaaaa');
  assertEntries(cache, [['middle', 'aaaaa']]);
  assert.equal(cache.has('seed'), false);
  assert.equal(cache.has('newest'), false);
  cache.set('reuse', 'rr');
  assertEntries(cache, [['reuse', 'rr'], ['middle', 'aaaaa']]);
});

test('fetch-size regression: growing refresh retains stale size until its value arrives', async () => {
  const { cache, pending, calls } = fetchingCache({ maxSize: 6 });
  cache.set('oldest', 'aa');
  cache.set('middle', 'bb');
  cache.set('newest', 'cc');
  const refreshed = cache.fetch('oldest', { forceRefresh: true });
  assert.equal(cache.calculatedSize, 6);
  assert.equal(cache.peek('oldest'), 'aa');
  assert.equal(await cache.fetch('oldest', { allowStale: true }), 'aa');
  assert.deepEqual(calls, ['oldest']);
  pending.get('oldest').resolve('aaaaa');
  assert.equal(await refreshed, 'aaaaa');
  assertEntries(cache, [['oldest', 'aaaaa']]);
  assert.equal(cache.has('middle'), false);
  assert.equal(cache.has('newest'), false);
});

test('fetch-size regression: deduplicated callers share one fetch and one size charge', async () => {
  const { cache, pending, calls } = fetchingCache({ maxSize: 8, max: 3 });
  const first = cache.fetch('shared');
  const duplicate = cache.fetch('shared');
  const other = cache.fetch('other');
  assert.deepEqual(calls, ['shared', 'other']);
  pending.get('other').resolve('bbb');
  assert.equal(await other, 'bbb');
  pending.get('shared').resolve('aaaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaaa', 'aaaa']);
  assertEntries(cache, [['shared', 'aaaa'], ['other', 'bbb']]);
  assert.equal(await cache.fetch('other'), 'bbb');
  assert.deepEqual(calls, ['shared', 'other']);
  assertEntries(cache, [['other', 'bbb'], ['shared', 'aaaa']]);
  cache.set('third', 'ccc');
  assertEntries(cache, [['third', 'ccc'], ['other', 'bbb']]);
});

test('fetch-size regression: late fetch completion cannot replace an explicit set', async () => {
  const { cache, pending } = fetchingCache({ max: 2 });
  const fetched = cache.fetch('replaced');
  cache.set('replaced', 'aaa');
  cache.set('other', 'bb');
  pending.get('replaced').resolve('xxxx');
  assert.equal(await fetched, 'xxxx');
  assertEntries(cache, [['other', 'bb'], ['replaced', 'aaa']]);
  assert.equal(cache.get('replaced'), 'aaa');
  cache.set('next', 'ccc');
  assertEntries(cache, [['next', 'ccc']]);
});

test('fetch-size regression: rejected refresh preserves the configured stale value and accounting', async () => {
  const { cache, pending } = fetchingCache();
  cache.set('oldest', 'aa');
  cache.set('newest', 'bb');
  const refreshed = cache.fetch('oldest', {
    forceRefresh: true,
    allowStaleOnFetchRejection: true,
  });
  pending.get('oldest').reject(new Error('controlled fetch failure'));
  assert.equal(await refreshed, 'aa');
  assertEntries(cache, [['newest', 'bb'], ['oldest', 'aa']]);
  cache.set('oldest', 'aaa');
  assertEntries(cache, [['oldest', 'aaa'], ['newest', 'bb']]);
  cache.set('small', 's');
  assertEntries(cache, [['small', 's'], ['oldest', 'aaa']]);
});

test('fetch-size regression: oversized fetched value leaves existing entries intact', async () => {
  const { cache, pending } = fetchingCache();
  cache.set('retained', 'rrr');
  const fetched = cache.fetch('oversized');
  pending.get('oversized').resolve('xxxxxx');
  assert.equal(await fetched, 'xxxxxx');
  assertEntries(cache, [['retained', 'rrr']]);
  assert.equal(cache.has('oversized'), false);
  cache.set('small', 'ss');
  assertEntries(cache, [['small', 'ss'], ['retained', 'rrr']]);
});

test('fetch-size regression: growing ordinary set promotes the updated entry before eviction', () => {
  const cache = new Cache({ max: 3, maxSize: 5, sizeCalculation: value => value.length });
  cache.set('oldest', 'a');
  cache.set('middle', 'bb');
  cache.set('newest', 'cc');
  cache.set('oldest', 'aaa');
  assertEntries(cache, [['oldest', 'aaa'], ['newest', 'cc']]);
  assert.equal(cache.has('middle'), false);
  assert.equal(cache.get('newest'), 'cc');
  cache.set('next', 'ddd');
  assertEntries(cache, [['next', 'ddd'], ['newest', 'cc']]);
  assert.equal(cache.has('oldest'), false);
});

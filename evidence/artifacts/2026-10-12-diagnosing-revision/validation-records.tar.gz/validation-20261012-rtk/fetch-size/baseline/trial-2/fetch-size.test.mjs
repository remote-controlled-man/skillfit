#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

function deferredCache(options = {}) {
  const resolve = new Map();
  const calls = [];
  const cache = new Cache({
    maxSize: 2,
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod: (key, staleValue) => {
      calls.push([key, staleValue]);
      return new Promise(done => resolve.set(key, done));
    },
  });
  return { cache, resolve, calls };
}

// Inspect only settled values through the public iteration and size APIs.
function assertCache(cache, expected) {
  assert.deepEqual([...cache.entries()], expected);
  assert.deepEqual([...cache.rentries()], [...expected].reverse());
  assert.equal(cache.size, expected.length);
  const total = expected.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, total);
  assert.ok(total <= cache.maxSize);
  if (cache.max) assert.ok(cache.size <= cache.max);
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size regression: reverse completion preserves the latest result and its size', async () => {
  const { cache, resolve } = deferredCache();

  const first = cache.fetch('first');
  const second = cache.fetch('second');
  resolve.get('second')('bb');
  assert.equal(await second, 'bb');
  assert.equal(cache.calculatedSize, 2);

  resolve.get('first')('aa');
  assert.equal(await first, 'aa');
  assert.equal(cache.calculatedSize, 2);
  assertCache(cache, [['first', 'aa']]);
  assert.equal(cache.get('first'), 'aa');
  assert.equal(cache.has('second'), false);
});

test('fetch-size regression: later writes and removals preserve both iteration directions', async () => {
  const { cache, resolve } = deferredCache({ max: 3, maxSize: 3 });
  const first = cache.fetch('first');
  const second = cache.fetch('second');
  resolve.get('second')('bbb');
  await second;
  resolve.get('first')('aaa');
  await first;
  assertCache(cache, [['first', 'aaa']]);

  cache.set('c', 'c').set('d', 'd').set('e', 'e');
  assertCache(cache, [['e', 'e'], ['d', 'd'], ['c', 'c']]);
  assert.equal(cache.has('first'), false);
  assert.equal(cache.get('c'), 'c');
  cache.set('d', 'dd');
  assertCache(cache, [['d', 'dd'], ['c', 'c']]);
  assert.equal(cache.has('e'), false);
  cache.set('f', 'f');
  assertCache(cache, [['f', 'f'], ['d', 'dd']]);
  assert.equal(cache.has('c'), false);
  assert.equal(cache.pop(), 'dd');
  assertCache(cache, [['f', 'f']]);
  assert.equal(cache.delete('f'), true);
  assertCache(cache, []);
  cache.set('g', 'gg').set('h', 'h');
  assertCache(cache, [['h', 'h'], ['g', 'gg']]);
  cache.clear();
  assertCache(cache, []);
});

const completionOrders = [
  ['a', 'b', 'c'], ['a', 'c', 'b'],
  ['b', 'a', 'c'], ['b', 'c', 'a'],
  ['c', 'a', 'b'], ['c', 'b', 'a'],
];
for (const order of completionOrders) {
  test(`fetch-size regression: weighted completion order ${order.join(' -> ')}`, async () => {
    const { cache, resolve } = deferredCache({ max: 3, maxSize: 5 });
    const values = { a: 'aa', b: 'bbb', c: 'c' };
    const pending = new Map(Object.keys(values).map(key => [key, cache.fetch(key)]));
    const expected = [];
    for (const key of order) {
      resolve.get(key)(values[key]);
      assert.equal(await pending.get(key), values[key]);
      expected.unshift([key, values[key]]);
      while (expected.reduce((sum, [, value]) => sum + value.length, 0) > 5) {
        expected.pop();
      }
    }
    assertCache(cache, expected);
    for (const key of Object.keys(values)) {
      assert.equal(cache.has(key), expected.some(([retained]) => retained === key));
    }
  });
}

test('fetch-size regression: ordinary growing and shrinking updates retain LRU behavior', () => {
  const cache = new Cache({ max: 3, maxSize: 4, sizeCalculation: value => value.length });
  cache.set('oldest', 'a').set('middle', 'bb').set('newest', 'c');
  cache.set('oldest', 'aaa');
  assertCache(cache, [['oldest', 'aaa'], ['newest', 'c']]);
  assert.equal(cache.has('middle'), false);
  cache.set('oldest', 'a');
  assertCache(cache, [['oldest', 'a'], ['newest', 'c']]);
  cache.set('third', 'dd');
  assert.equal(cache.get('newest'), 'c');
  assertCache(cache, [['newest', 'c'], ['third', 'dd'], ['oldest', 'a']]);
  cache.set('fourth', 'e');
  assertCache(cache, [['fourth', 'e'], ['newest', 'c'], ['third', 'dd']]);
  assert.equal(cache.has('oldest'), false);
  cache.set('third', 'dd');
  assertCache(cache, [['third', 'dd'], ['fourth', 'e'], ['newest', 'c']]);
});

test('fetch-size regression: explicit fetch sizes are accounted for at completion', async () => {
  const { cache, resolve } = deferredCache({ maxSize: 3, sizeCalculation: undefined });
  const first = cache.fetch('first', { size: 2 });
  const second = cache.fetch('second', { size: 2 });
  resolve.get('second')('bb');
  await second;
  resolve.get('first')('aa');
  await first;
  assertCache(cache, [['first', 'aa']]);
  cache.set('third', 'c', { size: 1 });
  assertCache(cache, [['third', 'c'], ['first', 'aa']]);
});

test('fetch-size regression: duplicate misses share one fetch and one size charge', async () => {
  const { cache, resolve, calls } = deferredCache({ max: 2, maxSize: 4 });
  const first = cache.fetch('shared');
  const duplicate = cache.fetch('shared');
  const other = cache.fetch('other');
  assert.deepEqual(calls, [['shared', undefined], ['other', undefined]]);
  assert.equal(cache.calculatedSize, 0);
  resolve.get('other')('bb');
  await other;
  resolve.get('shared')('aa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aa', 'aa']);
  assertCache(cache, [['shared', 'aa'], ['other', 'bb']]);
  assert.equal(await cache.fetch('other'), 'bb');
  assert.equal(calls.length, 2);
  assertCache(cache, [['other', 'bb'], ['shared', 'aa']]);
  cache.set('third', 'c');
  assertCache(cache, [['third', 'c'], ['other', 'bb']]);
  assert.equal(cache.has('shared'), false);
});

test('fetch-size regression: a growing refresh preserves stale access and fetch deduplication', async () => {
  const { cache, resolve, calls } = deferredCache({ maxSize: 4 });
  cache.set('oldest', 'a').set('other', 'bb');
  const first = cache.fetch('oldest', { forceRefresh: true });
  const duplicate = cache.fetch('oldest', { forceRefresh: true });
  assert.equal(await cache.fetch('oldest', { allowStale: true }), 'a');
  assert.equal(cache.peek('oldest'), 'a');
  assert.equal(cache.calculatedSize, 3);
  assert.deepEqual(calls, [['oldest', 'a']]);
  resolve.get('oldest')('aaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaa', 'aaa']);
  assertCache(cache, [['oldest', 'aaa']]);
  assert.equal(cache.has('other'), false);
});

test('fetch-size regression: replacing an in-flight fetch prevents a late result from changing the cache', async () => {
  const { cache, resolve } = deferredCache({ max: 2, maxSize: 3 });
  const pending = cache.fetch('first');
  cache.set('other', 'b');
  cache.set('first', 'aa');
  assertCache(cache, [['first', 'aa'], ['other', 'b']]);
  resolve.get('first')('zzz');
  assert.equal(await pending, 'zzz');
  assertCache(cache, [['first', 'aa'], ['other', 'b']]);
  cache.set('third', 'c');
  assertCache(cache, [['third', 'c'], ['first', 'aa']]);
});

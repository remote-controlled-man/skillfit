#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

function controlledCache(options = {}) {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    maxSize: 3,
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod(key) {
      calls.push(key);
      return new Promise(resolve => pending.set(key, resolve));
    },
  });
  return { cache, calls, resolve: (key, value) => pending.get(key)(value) };
}

function assertIteration(iterator, expected) {
  // Bound traversal so a damaged linked order fails instead of hanging.
  for (const value of expected) {
    assert.deepEqual(iterator.next(), { value, done: false });
  }
  assert.equal(iterator.next().done, true);
}

function assertState(cache, entries) {
  const total = entries.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, total);
  assert.ok(cache.calculatedSize <= cache.maxSize);
  assert.equal(cache.size, entries.length);
  assertIteration(cache.entries(), entries);
  assertIteration(cache.keys(), entries.map(([key]) => key));
  assertIteration(cache.rentries(), entries.slice().reverse());
  for (const [key, value] of entries) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size regression: reverse completion retains a result filling the size limit', async () => {
  const { cache, resolve } = controlledCache();
  const large = cache.fetch('large');
  const small = cache.fetch('small');

  resolve('small', 'x');
  assert.equal(await small, 'x');
  resolve('large', 'xxx');
  assert.equal(await large, 'xxx');

  assertState(cache, [['large', 'xxx']]);
  assert.equal(cache.has('small'), false);

  cache.set('later', 'y');
  assertState(cache, [['later', 'y']]);
  assert.equal(cache.has('large'), false);
  cache.set('second', 'zz');
  assertState(cache, [['second', 'zz'], ['later', 'y']]);
  assert.equal(cache.get('later'), 'y');
  cache.set('third', 'z');
  assertState(cache, [['third', 'z'], ['later', 'y']]);
  assert.equal(cache.has('second'), false);
});

test('fetch-size regression: every completion order preserves recency and later eviction', async () => {
  const orders = [
    ['a', 'b', 'c'], ['a', 'c', 'b'], ['b', 'a', 'c'],
    ['b', 'c', 'a'], ['c', 'a', 'b'], ['c', 'b', 'a'],
  ];
  for (const max of [0, 3]) {
    for (const order of orders) {
      const { cache, resolve } = controlledCache({ max, maxSize: 6 });
      const requests = new Map(['a', 'b', 'c'].map(key => [key, cache.fetch(key)]));
      for (const key of order) {
        resolve(key, key.repeat(2));
        assert.equal(await requests.get(key), key.repeat(2));
      }
      assertState(cache, order.slice().reverse().map(key => [key, key.repeat(2)]));
      cache.set('later', 'xxx');
      assertState(cache, [['later', 'xxx'], [order[2], order[2].repeat(2)]]);
      assert.equal(cache.has(order[0]), false);
      assert.equal(cache.has(order[1]), false);
    }
  }
});

test('fetch-size regression: a growing refresh replaces stale size and deduplicates callers', async () => {
  const { cache, calls, resolve } = controlledCache({ maxSize: 5 });
  cache.set('refresh', 'x');
  cache.set('older', 'yy');
  cache.set('newer', 'zz');

  const first = cache.fetch('refresh', { forceRefresh: true });
  const second = cache.fetch('refresh', { forceRefresh: true });
  assert.equal(await cache.fetch('refresh', { allowStale: true }), 'x');
  assert.equal(cache.peek('refresh'), 'x');
  assert.equal(cache.calculatedSize, 5);
  assert.deepEqual(calls, ['refresh']);

  resolve('refresh', 'xxxx');
  assert.deepEqual(await Promise.all([first, second]), ['xxxx', 'xxxx']);
  assertState(cache, [['refresh', 'xxxx']]);
  assert.equal(cache.has('older'), false);
  assert.equal(cache.has('newer'), false);
  cache.set('next', 'y');
  assertState(cache, [['next', 'y'], ['refresh', 'xxxx']]);
});

test('fetch-size regression: concurrent miss callers share one fetch and one size charge', async () => {
  const { cache, calls, resolve } = controlledCache({ maxSize: 5 });
  const first = cache.fetch('shared');
  const second = cache.fetch('shared');
  const third = cache.fetch('shared');
  assert.deepEqual(calls, ['shared']);
  resolve('shared', 'xxx');
  assert.deepEqual(await Promise.all([first, second, third]), ['xxx', 'xxx', 'xxx']);
  assertState(cache, [['shared', 'xxx']]);
  assert.equal(await cache.fetch('shared'), 'xxx');
  assert.deepEqual(calls, ['shared']);
  cache.set('other', 'yy');
  assertState(cache, [['other', 'yy'], ['shared', 'xxx']]);
});

test('fetch-size regression: ordinary growing set and get maintain size and LRU order', () => {
  const cache = new Cache({ maxSize: 5, sizeCalculation: value => value.length });
  cache.set('oldest', 'x');
  cache.set('middle', 'yy');
  cache.set('newest', 'zz');
  cache.set('oldest', 'xxxx');
  assertState(cache, [['oldest', 'xxxx']]);
  assert.equal(cache.has('middle'), false);
  assert.equal(cache.has('newest'), false);

  cache.set('next', 'y');
  assert.equal(cache.get('oldest'), 'xxxx');
  assertState(cache, [['oldest', 'xxxx'], ['next', 'y']]);
  cache.set('oldest', 'xx');
  assertState(cache, [['oldest', 'xx'], ['next', 'y']]);
  cache.set('last', 'zz');
  assertState(cache, [['last', 'zz'], ['oldest', 'xx'], ['next', 'y']]);
  assert.equal(cache.get('missing'), undefined);
  assertState(cache, [['last', 'zz'], ['oldest', 'xx'], ['next', 'y']]);
});

test('fetch-size regression: an evicted request cannot overwrite a reused entry', async () => {
  const { cache, resolve } = controlledCache({ max: 2, maxSize: 5 });
  const request = cache.fetch('evicted');
  cache.set('a', 'aa');
  cache.set('b', 'bb');
  assertState(cache, [['b', 'bb'], ['a', 'aa']]);
  resolve('evicted', 'xxxxx');
  assert.equal(await request, 'xxxxx');
  assertState(cache, [['b', 'bb'], ['a', 'aa']]);
  assert.equal(cache.has('evicted'), false);
  cache.set('c', 'c');
  assertState(cache, [['c', 'c'], ['b', 'bb']]);
});

test('fetch-size regression: a pending request cannot replace an explicit set', async () => {
  const { cache, resolve } = controlledCache({ maxSize: 5 });
  const request = cache.fetch('key');
  cache.set('key', 'aa');
  cache.set('other', 'bb');
  resolve('key', 'xxxxx');
  assert.equal(await request, 'xxxxx');
  assertState(cache, [['other', 'bb'], ['key', 'aa']]);
});

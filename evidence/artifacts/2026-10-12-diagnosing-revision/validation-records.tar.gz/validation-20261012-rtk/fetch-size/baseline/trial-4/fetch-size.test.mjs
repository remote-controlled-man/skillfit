#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);

function deferredCache(options = {}) {
  const requests = [];
  const cache = new Cache({
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod: (key, staleValue, { signal }) => new Promise(resolve => {
      requests.push({ key, staleValue, signal, resolve });
    }),
  });
  return { cache, requests };
}

// Check both iteration directions as well as membership: a broken linked order
// can otherwise hide entries while leaving the public entry count unchanged.
function assertContents(cache, expected) {
  assert.equal(cache.calculatedSize, expected.reduce((total, [, value]) => total + value.length, 0));
  assert.equal(cache.size, expected.length);
  assert.deepEqual([...cache.entries()], expected);
  assert.deepEqual([...cache.rentries()], [...expected].reverse());
  assert.deepEqual([...cache.keys()], expected.map(([key]) => key));
  assert.ok(cache.calculatedSize <= cache.maxSize);
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch size regression: reverse completion evicts the older result and keeps accounting correct', async () => {
  const resolve = new Map();
  const cache = new Cache({
    maxSize: 5,
    sizeCalculation: value => value.length,
    fetchMethod: key => new Promise(done => resolve.set(key, done)),
  });
  const first = cache.fetch('first');
  const second = cache.fetch('second');

  resolve.get('second')('bbb');
  assert.equal(await second, 'bbb');
  resolve.get('first')('aaa');
  assert.equal(await first, 'aaa');

  assert.equal(cache.calculatedSize, 3);
  assertContents(cache, [['first', 'aaa']]);
  assert.equal(cache.has('second'), false);
});

const completionOrders = [
  [0, 1, 2], [0, 2, 1], [1, 0, 2],
  [1, 2, 0], [2, 0, 1], [2, 1, 0],
];

for (const order of completionOrders) {
  test(`fetch size regression: three results completing ${order.join('-')} preserve capacity and LRU order`, async () => {
    const keys = ['alpha', 'beta', 'gamma'];
    const values = ['aaa', 'bbb', 'ccc'];
    const { cache, requests } = deferredCache({ maxSize: 6, max: 3 });
    const pending = keys.map(key => cache.fetch(key));

    for (const [completed, index] of order.entries()) {
      requests[index].resolve(values[index]);
      assert.equal(await pending[index], values[index]);
      assert.equal(cache.calculatedSize, Math.min(completed + 1, 2) * 3);
      assert.ok(cache.size <= 3);
    }

    const [evicted, older, newer] = order;
    assertContents(cache, [[keys[newer], values[newer]], [keys[older], values[older]]]);
    assert.equal(cache.has(keys[evicted]), false);

    // A normal get changes which resolved entry the next write must evict.
    assert.equal(cache.get(keys[older]), values[older]);
    cache.set('next', 'ddd');
    assertContents(cache, [['next', 'ddd'], [keys[older], values[older]]]);
    assert.equal(cache.has(keys[newer]), false);
  });
}

test('fetch size regression: later writes, pop, delete and slot reuse keep resolved entries consistent', async () => {
  const { cache, requests } = deferredCache({ maxSize: 5, max: 3 });
  const first = cache.fetch('first');
  const second = cache.fetch('second');
  requests[1].resolve('bbb');
  await second;
  requests[0].resolve('aaa');
  await first;
  assertContents(cache, [['first', 'aaa']]);

  cache.set('small', 'ss');
  assertContents(cache, [['small', 'ss'], ['first', 'aaa']]);
  assert.equal(cache.get('first'), 'aaa');
  cache.set('next', 'nn');
  assertContents(cache, [['next', 'nn'], ['first', 'aaa']]);
  assert.equal(cache.has('small'), false);
  assert.equal(cache.pop(), 'aaa');
  assertContents(cache, [['next', 'nn']]);
  assert.equal(cache.delete('next'), true);
  assertContents(cache, []);
  cache.set('reused', 'rrrrr');
  assertContents(cache, [['reused', 'rrrrr']]);
});

test('fetch size regression: growing a refreshed LRU entry evicts its older neighbour', async () => {
  const { cache, requests } = deferredCache({ maxSize: 7, max: 3 });
  cache.set('refresh', 'aa');
  cache.set('older', 'bb');
  cache.set('newer', 'cc');
  const first = cache.fetch('refresh', { forceRefresh: true });
  const duplicate = cache.fetch('refresh', { forceRefresh: true });
  assert.equal(requests.length, 1);
  assert.equal(requests[0].staleValue, 'aa');
  assert.equal(cache.calculatedSize, 6);
  assert.equal(cache.peek('refresh'), 'aa');

  requests[0].resolve('aaaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaaa', 'aaaa']);
  assertContents(cache, [['refresh', 'aaaa'], ['newer', 'cc']]);
  assert.equal(cache.has('older'), false);
});

test('fetch size regression: ordinary size-changing set promotes the updated entry before eviction', () => {
  const { cache, requests } = deferredCache({ maxSize: 5 });
  cache.set('updated', 'a');
  cache.set('older', 'bb');
  cache.set('updated', 'aaaa');
  assertContents(cache, [['updated', 'aaaa']]);
  assert.equal(cache.has('older'), false);

  cache.set('small', 's');
  assert.equal(cache.get('updated'), 'aaaa');
  cache.set('updated', 'aaaa');
  assertContents(cache, [['updated', 'aaaa'], ['small', 's']]);
  assert.equal(requests.length, 0);
});

test('fetch size regression: duplicate misses share one fetch and cached fetch hits update recency', async () => {
  const { cache, requests } = deferredCache({ maxSize: 5 });
  const first = cache.fetch('shared');
  const duplicate = cache.fetch('shared');
  assert.equal(requests.length, 1);
  assert.equal(cache.get('shared'), undefined);
  assert.equal(cache.calculatedSize, 0);
  requests[0].resolve('aaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaa', 'aaa']);
  assertContents(cache, [['shared', 'aaa']]);

  cache.set('small', 'ss');
  assert.equal(await cache.fetch('shared'), 'aaa');
  assert.equal(requests.length, 1);
  assertContents(cache, [['shared', 'aaa'], ['small', 'ss']]);
  cache.set('next', 'n');
  assertContents(cache, [['next', 'n'], ['shared', 'aaa']]);
  assert.equal(cache.has('small'), false);
});

test('fetch size regression: a set replacing an in-flight fetch remains cached after completion', async () => {
  const { cache, requests } = deferredCache({ maxSize: 5 });
  const pending = cache.fetch('replaced');
  cache.set('replaced', 'ss');
  assert.equal(requests[0].signal.aborted, true);
  requests[0].resolve('aaa');
  assert.equal(await pending, 'aaa');
  assertContents(cache, [['replaced', 'ss']]);
});

test('fetch size regression: count eviction of a pending fetch does not resurrect its result', async () => {
  const { cache, requests } = deferredCache({ maxSize: 5, max: 2 });
  const pending = cache.fetch('evicted');
  cache.set('older', 'aaa');
  cache.set('newer', 'bb');
  assert.equal(requests[0].signal.aborted, true);
  requests[0].resolve('ccc');
  assert.equal(await pending, 'ccc');
  assertContents(cache, [['newer', 'bb'], ['older', 'aaa']]);
  assert.equal(cache.has('evicted'), false);
});

test('fetch size regression: an oversized result removes only its placeholder', async () => {
  const { cache, requests } = deferredCache({ maxSize: 5 });
  cache.set('resident', 'aaa');
  const pending = cache.fetch('oversized');
  requests[0].resolve('xxxxxx');
  assert.equal(await pending, 'xxxxxx');
  assertContents(cache, [['resident', 'aaa']]);
  assert.equal(cache.has('oversized'), false);
});

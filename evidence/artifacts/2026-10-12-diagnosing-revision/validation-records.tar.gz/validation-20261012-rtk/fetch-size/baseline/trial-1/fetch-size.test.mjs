#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function deferredFetches() {
  const pending = new Map();
  const calls = [];
  return {
    calls,
    fetchMethod(key, staleValue, { signal }) {
      calls.push({ key, staleValue, signal });
      return new Promise(resolve => pending.set(key, resolve));
    },
    resolve(key, value) {
      assert.ok(pending.has(key), `fetch for ${key} must have started`);
      pending.get(key)(value);
      pending.delete(key);
    },
  };
}

// All fetches have settled before this helper inspects stored values.
function readEntries(iterator, count) {
  const entries = [];
  for (let i = 0; i < count; i++) {
    const entry = iterator.next();
    assert.equal(entry.done, false, 'cache iteration ended before all entries were visited');
    entries.push(entry.value);
  }
  assert.equal(iterator.next().done, true, 'cache iteration must terminate after visiting each entry once');
  return entries;
}

function assertContents(cache, expected) {
  assert.deepEqual(readEntries(cache.entries(), expected.length), expected);
  assert.deepEqual(readEntries(cache.rentries(), expected.length), [...expected].reverse());
  assert.equal(cache.size, expected.length);
  assert.equal(cache.calculatedSize, expected.reduce((sum, [, value]) => sum + value.length, 0));
  assert.ok(cache.calculatedSize <= cache.maxSize);
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size regression: sequential completions evict the older value without losing size or order', async () => {
  const fetches = deferredFetches();
  const cache = new Cache({ maxSize: 5, sizeCalculation: value => value.length, fetchMethod: fetches.fetchMethod });
  const a = cache.fetch('a');
  const b = cache.fetch('b');

  fetches.resolve('a', 'aaa');
  assert.equal(await a, 'aaa');
  fetches.resolve('b', 'bbb');
  assert.equal(await b, 'bbb');

  assert.equal(cache.calculatedSize, 3);
  assert.equal(cache.has('a'), false);
  assertContents(cache, [['b', 'bbb']]);
  cache.set('c', 'cc');
  assertContents(cache, [['c', 'cc'], ['b', 'bbb']]);
  cache.set('d', 'dd');
  assert.equal(cache.has('b'), false);
  assertContents(cache, [['d', 'dd'], ['c', 'cc']]);
});

test('fetch-size regression: reverse completions preserve capacity and LRU across subsequent get/set', async () => {
  const fetches = deferredFetches();
  const cache = new Cache({ maxSize: 9, sizeCalculation: value => value.length, fetchMethod: fetches.fetchMethod });
  const a = cache.fetch('a');
  const b = cache.fetch('b');
  const c = cache.fetch('c');

  fetches.resolve('c', 'ccc');
  assert.equal(await c, 'ccc');
  assert.equal(cache.calculatedSize, 3);
  fetches.resolve('b', 'bbbb');
  assert.equal(await b, 'bbbb');
  assert.equal(cache.calculatedSize, 7);
  fetches.resolve('a', 'aaaaa');
  assert.equal(await a, 'aaaaa');

  assert.equal(cache.has('c'), false);
  assertContents(cache, [['a', 'aaaaa'], ['b', 'bbbb']]);
  cache.set('d', 'dd');
  assert.equal(cache.has('b'), false);
  assertContents(cache, [['d', 'dd'], ['a', 'aaaaa']]);
  assert.equal(cache.get('a'), 'aaaaa');
  cache.set('e', 'eee');
  assert.equal(cache.has('d'), false);
  assertContents(cache, [['e', 'eee'], ['a', 'aaaaa']]);
});

test('fetch-size regression: refreshing an older entry replaces its size and evicts its LRU neighbor', async () => {
  const fetches = deferredFetches();
  const cache = new Cache({ max: 3, maxSize: 7, sizeCalculation: value => value.length, fetchMethod: fetches.fetchMethod });
  cache.set('a', 'aa');
  cache.set('b', 'bbb');
  const refresh = cache.fetch('a', { forceRefresh: true });
  assert.equal(cache.calculatedSize, 5);
  assert.equal(cache.peek('a'), 'aa');
  assert.equal(fetches.calls[0].staleValue, 'aa');

  fetches.resolve('a', 'aaaaaa');
  assert.equal(await refresh, 'aaaaaa');
  assert.equal(cache.has('b'), false);
  assertContents(cache, [['a', 'aaaaaa']]);
  cache.set('c', 'c');
  assertContents(cache, [['c', 'c'], ['a', 'aaaaaa']]);
  cache.set('a', 'aa');
  assertContents(cache, [['a', 'aa'], ['c', 'c']]);
  assert.equal(cache.delete('a'), true);
  assertContents(cache, [['c', 'c']]);
  assert.equal(cache.delete('c'), true);
  assertContents(cache, []);
  cache.set('d', 'dddd');
  assertContents(cache, [['d', 'dddd']]);
});

test('fetch-size regression: deduplicated requests account for one result and retain count-bound eviction', async () => {
  const fetches = deferredFetches();
  const calculated = [];
  const cache = new Cache({
    max: 2,
    maxSize: 6,
    sizeCalculation(value, key) {
      calculated.push([key, value]);
      return value.length;
    },
    fetchMethod: fetches.fetchMethod,
  });
  const first = cache.fetch('a');
  const duplicate = cache.fetch('a');
  assert.equal(fetches.calls.length, 1);
  assert.equal(cache.calculatedSize, 0);
  fetches.resolve('a', 'aaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaa', 'aaa']);
  assert.deepEqual(calculated, [['a', 'aaa']]);
  assertContents(cache, [['a', 'aaa']]);
  assert.equal(await cache.fetch('a'), 'aaa');
  assert.equal(fetches.calls.length, 1);
  cache.set('b', 'bb');
  assert.equal(cache.get('a'), 'aaa');
  cache.set('c', 'c');
  assert.equal(cache.has('b'), false);
  assertContents(cache, [['c', 'c'], ['a', 'aaa']]);
});

test('fetch-size regression: late evicted fetch results do not overwrite a reused slot', async () => {
  const fetches = deferredFetches();
  const cache = new Cache({ max: 2, maxSize: 5, sizeCalculation: value => value.length, fetchMethod: fetches.fetchMethod });
  const pending = cache.fetch('a');
  cache.set('b', 'bb');
  cache.set('c', 'cc');
  assert.equal(fetches.calls[0].signal.aborted, true);
  assert.equal(cache.has('a'), false);

  fetches.resolve('a', 'aaa');
  assert.equal(await pending, 'aaa');
  assertContents(cache, [['c', 'cc'], ['b', 'bb']]);
  cache.set('d', 'ddd');
  assert.equal(cache.has('b'), false);
  assertContents(cache, [['d', 'ddd'], ['c', 'cc']]);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache } = await loadCache(dirname(fileURLToPath(import.meta.url)));

function deferredCache(options = {}) {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    maxSize: 5,
    sizeCalculation: value => value.length,
    ...options,
    fetchMethod: key => {
      calls.push(key);
      return new Promise(resolve => pending.set(key, resolve));
    },
  });
  return { cache, pending, calls };
}

// Bound traversal so a broken linked order fails instead of looping forever.
function readEntries(iterator, expectedCount) {
  const entries = [];
  for (const entry of iterator) {
    entries.push(entry);
    assert.ok(entries.length <= expectedCount, 'iteration exceeded the expected entry count');
  }
  return entries;
}

function assertCache(cache, expected) {
  assert.equal(cache.calculatedSize, expected.reduce((total, [, value]) => total + value.length, 0));
  assert.ok(cache.calculatedSize <= cache.maxSize, 'cache must stay within its size bound');
  assert.equal(cache.size, expected.length);
  assert.deepEqual(readEntries(cache.entries(), expected.length), expected);
  assert.deepEqual(readEntries(cache.rentries(), expected.length), [...expected].reverse());
  for (const [key, value] of expected) {
    assert.equal(cache.peek(key), value);
  }
}

test('fetch size regression: reverse completion retains the result within capacity', async () => {
  const { cache, pending } = deferredCache();
  const first = cache.fetch('first');
  const second = cache.fetch('second');
  pending.get('second')('sss');
  assert.equal(await second, 'sss');
  pending.get('first')('fff');
  assert.equal(await first, 'fff');

  assertCache(cache, [['first', 'fff']]);
  assert.equal(cache.get('first'), 'fff');
  assert.equal(cache.has('second'), false);
});

test('fetch size regression: later writes and reads preserve order after reverse completion', async () => {
  const { cache, pending } = deferredCache();
  cache.set('old', 'oo');
  const first = cache.fetch('first');
  const second = cache.fetch('second');
  pending.get('second')('sss');
  await second;
  pending.get('first')('fff');
  await first;
  assertCache(cache, [['first', 'fff']]);
  assert.equal(cache.has('old'), false);
  assert.equal(cache.has('second'), false);

  cache.set('next', 'nn');
  assertCache(cache, [['next', 'nn'], ['first', 'fff']]);
  assert.equal(cache.get('first'), 'fff');
  assertCache(cache, [['first', 'fff'], ['next', 'nn']]);
  cache.set('last', 'l');
  assertCache(cache, [['last', 'l'], ['first', 'fff']]);
  assert.equal(cache.has('next'), false);
  assert.equal(cache.pop(), 'fff');
  assertCache(cache, [['last', 'l']]);
  assert.equal(cache.delete('last'), true);
  assertCache(cache, []);
  cache.set('reused', 'rr');
  assertCache(cache, [['reused', 'rr']]);
});

const completionOrders = [
  ['a', 'b', 'c'],
  ['a', 'c', 'b'],
  ['b', 'a', 'c'],
  ['b', 'c', 'a'],
  ['c', 'a', 'b'],
  ['c', 'b', 'a'],
];

for (const order of completionOrders) {
  test(`fetch size regression: three fetches complete in order ${order.join('-')}`, async () => {
    const { cache, pending } = deferredCache({ max: 3, maxSize: 6 });
    const values = { a: 'aaa', b: 'bb', c: 'ccc' };
    const requests = new Map(Object.keys(values).map(key => [key, cache.fetch(key)]));
    for (const key of order) {
      pending.get(key)(values[key]);
      assert.equal(await requests.get(key), values[key]);
      assert.ok(cache.calculatedSize <= 6);
    }

    const expected = order.slice(1).reverse().map(key => [key, values[key]]);
    assertCache(cache, expected);
    assert.equal(cache.has(order[0]), false);
    cache.set('write', 'ww');
    expected.unshift(['write', 'ww']);
    if (expected.reduce((total, [, value]) => total + value.length, 0) > 6) {
      const [evicted] = expected.pop();
      assert.equal(cache.has(evicted), false);
    }
    assertCache(cache, expected);
  });
}

test('fetch size regression: duplicate callers share work and account for each result once', async () => {
  const { cache, pending, calls } = deferredCache();
  const first = cache.fetch('first');
  const duplicateFirst = cache.fetch('first');
  const second = cache.fetch('second');
  const duplicateSecond = cache.fetch('second');
  assert.deepEqual(calls, ['first', 'second']);
  pending.get('second')('sss');
  assert.deepEqual(await Promise.all([second, duplicateSecond]), ['sss', 'sss']);
  assert.equal(cache.calculatedSize, 3);
  pending.get('first')('fff');
  assert.deepEqual(await Promise.all([first, duplicateFirst]), ['fff', 'fff']);
  assert.deepEqual(calls, ['first', 'second']);
  assertCache(cache, [['first', 'fff']]);
});

test('fetch size regression: reverse refresh completion replaces stale sizes before eviction', async () => {
  const { cache, pending } = deferredCache({ maxSize: 6 });
  cache.set('first', 'f');
  cache.set('second', 'ss');
  cache.set('other', 'o');
  const first = cache.fetch('first', { forceRefresh: true });
  const second = cache.fetch('second', { forceRefresh: true });
  assert.equal(cache.calculatedSize, 4);
  assert.equal(cache.peek('first'), 'f');
  assert.equal(cache.peek('second'), 'ss');
  pending.get('second')('sss');
  assert.equal(await second, 'sss');
  assert.equal(cache.calculatedSize, 5);
  pending.get('first')('ffff');
  assert.equal(await first, 'ffff');
  assertCache(cache, [['first', 'ffff']]);
  assert.equal(cache.has('second'), false);
  assert.equal(cache.has('other'), false);
});

test('fetch size regression: ordinary growing updates and identical sets retain LRU behavior', () => {
  const cache = new Cache({ max: 3, maxSize: 5, sizeCalculation: value => value.length });
  cache.set('first', 'f');
  cache.set('second', 'sss');
  cache.set('first', 'fff');
  assertCache(cache, [['first', 'fff']]);
  assert.equal(cache.has('second'), false);
  cache.set('next', 'nn');
  cache.set('first', 'fff');
  assertCache(cache, [['first', 'fff'], ['next', 'nn']]);
  cache.set('last', 'l');
  assertCache(cache, [['last', 'l'], ['first', 'fff']]);
  assert.equal(cache.get('first'), 'fff');
  assertCache(cache, [['first', 'fff'], ['last', 'l']]);
});

test('fetch size regression: a later set survives completion of the replaced fetch', async () => {
  const { cache, pending } = deferredCache({ max: 2 });
  const result = cache.fetch('first');
  cache.set('first', 'f');
  cache.set('second', 'ss');
  pending.get('first')('fff');
  assert.equal(await result, 'fff');
  assertCache(cache, [['second', 'ss'], ['first', 'f']]);
  assert.equal(cache.get('first'), 'f');
  cache.set('last', 'lll');
  assertCache(cache, [['last', 'lll'], ['first', 'f']]);
});

test('fetch size regression: an oversized fetch leaves existing size and order unchanged', async () => {
  const { cache, pending } = deferredCache();
  cache.set('kept', 'kkk');
  const result = cache.fetch('oversized');
  pending.get('oversized')('xxxxxx');
  assert.equal(await result, 'xxxxxx');
  assert.equal(cache.has('oversized'), false);
  assertCache(cache, [['kept', 'kkk']]);
});

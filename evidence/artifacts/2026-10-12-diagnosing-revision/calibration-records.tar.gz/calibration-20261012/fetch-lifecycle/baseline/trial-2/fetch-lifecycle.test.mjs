import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

function deferred() {
  return Promise.withResolvers();
}

async function settles(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 1000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle: asynchronous miss inserts only its application value with add', async () => {
  const request = deferred();
  const insertions = [];
  const value = { version: 1 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => request.promise,
    onInsert: (...args) => insertions.push(args),
  });
  const pending = cache.fetch('missing');
  const whilePending = [...insertions];
  request.resolve(value);
  assert.equal(await settles(pending), value);
  assert.deepEqual(whilePending, []);
  assert.deepEqual(insertions, [[value, 'missing', 'add']]);
  assert.equal(cache.get('missing'), value);
});

test('fetch lifecycle: refresh reports update for the same value and replace for a new value', async () => {
  let request = deferred();
  const insertions = [];
  const original = { version: 1 };
  const replacement = { version: 2 };
  const cache = new Cache({
    max: 2,
    fetchMethod: () => request.promise,
    onInsert: (...args) => insertions.push(args),
  });
  cache.set('refresh', original);
  insertions.length = 0;
  let pending = cache.fetch('refresh', { forceRefresh: true });
  assert.deepEqual(insertions, []);
  request.resolve(original);
  assert.equal(await settles(pending), original);
  assert.deepEqual(insertions, [[original, 'refresh', 'update']]);

  request = deferred();
  pending = cache.fetch('refresh', { forceRefresh: true });
  assert.equal(insertions.length, 1);
  request.resolve(replacement);
  assert.equal(await settles(pending), replacement);
  assert.deepEqual(insertions, [
    [original, 'refresh', 'update'],
    [replacement, 'refresh', 'replace'],
  ]);
  assert.equal(cache.get('refresh'), replacement);
});

test('fetch lifecycle: ordinary set preserves insertion reasons and application Promise values', () => {
  const insertions = [];
  const first = { version: 1 };
  const second = { version: 2 };
  const applicationPromise = Promise.resolve('application');
  const cache = new Cache({
    max: 3,
    fetchMethod: async () => 'unused',
    onInsert: (...args) => insertions.push(args),
  });
  cache.set('ordinary', first);
  cache.set('ordinary', first);
  cache.set('ordinary', second);
  cache.set('promise', applicationPromise);
  assert.deepEqual(insertions, [
    [first, 'ordinary', 'add'],
    [first, 'ordinary', 'update'],
    [second, 'ordinary', 'replace'],
    [applicationPromise, 'promise', 'add'],
  ]);
  assert.equal(cache.get('promise'), applicationPromise);
});

for (const [label, stale] of [['object', { version: 1 }], ['zero', 0], ['false', false], ['empty string', '']]) {
  test(`fetch lifecycle: capacity eviction disposes the stale ${label} exactly once`, async () => {
    const request = deferred();
    const disposed = [];
    const disposedAfter = [];
    let signal;
    const cache = new Cache({
      max: 2,
      fetchMethod: (_key, previous, options) => {
        assert.equal(previous, stale);
        signal = options.signal;
        return request.promise;
      },
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args),
    });
    cache.set('refresh', stale);
    cache.set('keeper', 'keep');
    const pending = cache.fetch('refresh', { forceRefresh: true });
    const rejected = assert.rejects(pending, { message: 'evicted' });
    assert.deepEqual(disposed, []);
    assert.deepEqual(disposedAfter, []);
    cache.set('incoming', 'new');
    assert.equal(signal.aborted, true);
    assert.equal(signal.reason.message, 'evicted');
    assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
    assert.equal(cache.has('refresh'), false);
    assert.deepEqual([...cache.keys()], ['incoming', 'keeper']);
    await settles(rejected);
    request.resolve('late result');
    await setImmediate();
    assert.equal(cache.has('refresh'), false);
    assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
  });
}

test('fetch lifecycle: pop disposes a refreshing stale value and returns it', async () => {
  const request = deferred();
  const stale = { version: 1 };
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => request.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('refresh', stale);
  cache.set('keeper', 'keep');
  const rejected = assert.rejects(cache.fetch('refresh', { forceRefresh: true }), { message: 'evicted' });
  assert.equal(cache.pop(), stale);
  assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
  assert.equal(cache.get('keeper'), 'keep');
  await settles(rejected);
  request.resolve('late result');
  await setImmediate();
  assert.equal(cache.size, 1);
  assert.equal(disposed.length, 1);
  assert.equal(disposedAfter.length, 1);
});

test('fetch lifecycle: size eviction disposes a refreshing value despite noDisposeOnSet', async () => {
  const request = deferred();
  const stale = { size: 1 };
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 3,
    maxSize: 3,
    sizeCalculation: value => value.size,
    fetchMethod: () => request.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('refresh', stale);
  cache.set('keeper', { size: 1 });
  const rejected = assert.rejects(cache.fetch('refresh', { forceRefresh: true }), { message: 'evicted' });
  cache.set('incoming', { size: 2 }, { noDisposeOnSet: true });
  assert.deepEqual(disposed, [[stale, 'refresh', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'refresh', 'evict']]);
  assert.equal(cache.calculatedSize, 3);
  assert.deepEqual([...cache.keys()], ['incoming', 'keeper']);
  await settles(rejected);
  request.resolve({ size: 1 });
  await setImmediate();
  assert.equal(disposed.length, 1);
  assert.equal(disposedAfter.length, 1);
});

test('fetch lifecycle: evicting a pending miss never disposes an internal placeholder', async () => {
  const request = deferred();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => request.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  const rejected = assert.rejects(cache.fetch('missing'), { message: 'evicted' });
  cache.set('incoming', 'new');
  await settles(rejected);
  request.resolve('late result');
  await setImmediate();
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.equal(cache.get('incoming'), 'new');
});

for (const [label, value] of [['object', { version: 1 }], ['zero', 0], ['false', false], ['empty string', '']]) {
  test(`fetch lifecycle: synchronous ${label} results settle misses and refreshes`, async () => {
    const insertions = [];
    let calls = 0;
    const cache = new Cache({
      max: 2,
      fetchMethod: () => {
        calls++;
        return value;
      },
      onInsert: (...args) => insertions.push(args),
    });
    assert.equal(await settles(cache.fetch('sync')), value);
    assert.equal(cache.get('sync'), value);
    assert.equal(await settles(cache.fetch('sync')), value);
    assert.equal(calls, 1);
    assert.equal(await settles(cache.fetch('sync', { forceRefresh: true })), value);
    assert.equal(calls, 2);
    assert.deepEqual(insertions, [[value, 'sync', 'add'], [value, 'sync', 'update']]);
  });
}

test('fetch lifecycle: synchronous undefined settles and preserves an existing stale value', async () => {
  const insertions = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => undefined,
    onInsert: (...args) => insertions.push(args),
  });
  assert.equal(await settles(cache.fetch('missing')), undefined);
  assert.equal(cache.has('missing'), false);
  assert.equal(cache.size, 0);
  assert.deepEqual(insertions, []);
  cache.set('refresh', 'stale');
  insertions.length = 0;
  assert.equal(await settles(cache.fetch('refresh', { forceRefresh: true })), undefined);
  assert.equal(cache.get('refresh'), 'stale');
  assert.deepEqual(insertions, []);
});

test('fetch lifecycle: successful asynchronous fetches coalesce without aborting their provider', async () => {
  let request = deferred();
  const signals = [];
  const aborts = [];
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, { signal }) => {
      calls++;
      signals.push(signal);
      signal.addEventListener('abort', () => aborts.push(signal.reason));
      return request.promise;
    },
  });
  cache.set('older', 'old');
  const first = cache.fetch('loaded');
  const coalesced = cache.fetch('loaded');
  assert.equal(calls, 1);
  request.resolve('loaded value');
  assert.deepEqual(await settles(Promise.all([first, coalesced])), ['loaded value', 'loaded value']);
  assert.equal(signals[0].aborted, false);
  assert.deepEqual(aborts, []);
  assert.equal(await settles(cache.fetch('loaded')), 'loaded value');
  assert.equal(calls, 1);

  request = deferred();
  const refresh = cache.fetch('loaded', { forceRefresh: true });
  request.resolve('refreshed value');
  assert.equal(await settles(refresh), 'refreshed value');
  assert.equal(signals[1].aborted, false);
  assert.deepEqual(aborts, []);
  cache.set('incoming', 'new');
  assert.equal(cache.has('older'), false);
  assert.deepEqual([...cache.entries()], [['incoming', 'new'], ['loaded', 'refreshed value']]);
});

test('fetch lifecycle: explicit replacement cancels refresh and rejects late provider writes', async () => {
  const request = deferred();
  const disposed = [];
  const disposedAfter = [];
  const insertions = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return request.promise;
    },
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
    onInsert: (...args) => insertions.push(args),
  });
  cache.set('refresh', 'stale');
  insertions.length = 0;
  const rejected = assert.rejects(cache.fetch('refresh', { forceRefresh: true }), { message: 'replaced' });
  cache.set('refresh', 'explicit value');
  assert.equal(signal.aborted, true);
  assert.equal(signal.reason.message, 'replaced');
  await settles(rejected);
  request.resolve('late result');
  await setImmediate();
  assert.equal(cache.get('refresh'), 'explicit value');
  assert.deepEqual(disposed, [['stale', 'refresh', 'set']]);
  assert.deepEqual(disposedAfter, [['stale', 'refresh', 'set']]);
  assert.deepEqual(insertions, [['explicit value', 'refresh', 'replace']]);
});

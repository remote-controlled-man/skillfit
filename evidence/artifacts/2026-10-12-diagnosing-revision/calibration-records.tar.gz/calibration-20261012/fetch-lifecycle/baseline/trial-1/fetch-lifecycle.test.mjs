#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setImmediate as nextTurn } from 'node:timers/promises';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), true);
after(cleanup);

// Bound the wait so a synchronous-result regression fails instead of hanging.
async function settles(promise) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error('fetch did not settle')), 1000);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

test('fetch lifecycle: a cache miss reports only the resolved application value as add', async () => {
  const provider = Promise.withResolvers();
  const value = { version: 1 };
  const inserted = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    onInsert: (...args) => inserted.push(args),
  });
  const fetched = cache.fetch('missing');
  const whilePending = inserted.slice();
  provider.resolve(value);
  assert.equal(await settles(fetched), value);
  assert.deepEqual(whilePending, []);
  assert.deepEqual(inserted, [[value, 'missing', 'add']]);
  assert.equal(cache.get('missing'), value);
});

for (const sameValue of [true, false]) {
  test(`fetch lifecycle: refresh reports ${sameValue ? 'update for the same value' : 'replace for a new value'}`, async () => {
    const provider = Promise.withResolvers();
    const stale = { version: 1 };
    const value = sameValue ? stale : { version: 2 };
    const inserted = [];
    const cache = new Cache({
      max: 2,
      fetchMethod: () => provider.promise,
      onInsert: (...args) => inserted.push(args),
    });
    cache.set('refreshing', stale);
    const fetched = cache.fetch('refreshing', { forceRefresh: true });
    const whilePending = inserted.slice();
    assert.equal(cache.peek('refreshing'), stale);
    provider.resolve(value);
    assert.equal(await settles(fetched), value);
    assert.deepEqual(whilePending, [[stale, 'refreshing', 'add']]);
    assert.deepEqual(inserted, [
      [stale, 'refreshing', 'add'],
      [value, 'refreshing', sameValue ? 'update' : 'replace'],
    ]);
    assert.equal(cache.get('refreshing'), value);
  });
}

for (const [label, stale] of [['object', { version: 1 }], ['zero', 0], ['false', false], ['empty string', '']]) {
  test(`fetch lifecycle: capacity eviction disposes the ${label} stale value once per callback`, async () => {
    const provider = Promise.withResolvers();
    const disposed = [];
    const disposedAfter = [];
    let signal;
    let cache;
    cache = new Cache({
      max: 1,
      fetchMethod: (_key, oldValue, options) => {
        assert.equal(oldValue, stale);
        signal = options.signal;
        return provider.promise;
      },
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => {
        disposedAfter.push(args);
        assert.equal(cache.has('refreshing'), false);
      },
    });
    cache.set('refreshing', stale);
    const fetched = cache.fetch('refreshing', { forceRefresh: true });
    const rejected = assert.rejects(fetched, { message: 'evicted' });
    cache.set('survivor', 'kept');
    await rejected;
    provider.resolve('late result');
    await nextTurn();
    assert.equal(signal.aborted, true);
    assert.equal(signal.reason.message, 'evicted');
    assert.deepEqual(disposed, [[stale, 'refreshing', 'evict']]);
    assert.deepEqual(disposedAfter, [[stale, 'refreshing', 'evict']]);
    assert.equal(cache.has('refreshing'), false);
    assert.equal(cache.get('survivor'), 'kept');
    assert.equal(cache.size, 1);
  });
}

test('fetch lifecycle: size eviction cleans up a stale refresh and keeps LRU order', async () => {
  const provider = Promise.withResolvers();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 3,
    maxSize: 2,
    sizeCalculation: () => 1,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('refreshing', 'old');
  cache.set('recent', 'recent value');
  const fetched = cache.fetch('refreshing', { forceRefresh: true });
  const rejected = assert.rejects(fetched, { message: 'evicted' });
  cache.get('recent');
  cache.set('newest', 'new value');
  await rejected;
  provider.resolve('late result');
  await nextTurn();
  assert.deepEqual(disposed, [['old', 'refreshing', 'evict']]);
  assert.deepEqual(disposedAfter, [['old', 'refreshing', 'evict']]);
  assert.deepEqual([...cache.keys()], ['newest', 'recent']);
  assert.equal(cache.calculatedSize, 2);
});

test('fetch lifecycle: pop evicts and disposes the stale application value', async () => {
  const provider = Promise.withResolvers();
  const stale = { version: 1 };
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 2,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('refreshing', stale);
  const fetched = cache.fetch('refreshing', { forceRefresh: true });
  const rejected = assert.rejects(fetched, { message: 'evicted' });
  assert.equal(cache.pop(), stale);
  await rejected;
  provider.resolve({ version: 2 });
  await nextTurn();
  assert.deepEqual(disposed, [[stale, 'refreshing', 'evict']]);
  assert.deepEqual(disposedAfter, [[stale, 'refreshing', 'evict']]);
  assert.equal(cache.size, 0);
});

test('fetch lifecycle: eviction of a pending miss never disposes an internal promise', async () => {
  const provider = Promise.withResolvers();
  const disposed = [];
  const disposedAfter = [];
  const cache = new Cache({
    max: 1,
    fetchMethod: () => provider.promise,
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  const fetched = cache.fetch('missing');
  const rejected = assert.rejects(fetched, { message: 'evicted' });
  cache.set('survivor', 'kept');
  await rejected;
  provider.resolve('late result');
  await nextTurn();
  assert.deepEqual(disposed, []);
  assert.deepEqual(disposedAfter, []);
  assert.equal(cache.get('survivor'), 'kept');
});

for (const [label, value] of [['object', { version: 1 }], ['zero', 0], ['false', false], ['empty string', ''], ['undefined', undefined]]) {
  test(`fetch lifecycle: a synchronous ${label} result settles and preserves cache semantics`, async t => {
    let calls = 0;
    const cache = new Cache({
      max: 2,
      fetchMethod: () => {
        calls++;
        return value;
      },
    });
    t.after(() => cache.clear());
    assert.equal(await settles(cache.fetch('sync')), value);
    assert.equal(cache.get('sync'), value);
    assert.equal(cache.has('sync'), value !== undefined);
    if (value !== undefined) {
      assert.equal(await settles(cache.fetch('sync')), value);
      assert.equal(calls, 1);
    } else {
      assert.equal(cache.size, 0);
    }
  });
}

for (const refresh of [false, true]) {
  test(`fetch lifecycle: successful asynchronous ${refresh ? 'refresh' : 'miss'} does not abort its provider`, async () => {
    const value = { version: 2 };
    const disposed = [];
    const disposedAfter = [];
    let signal;
    let aborts = 0;
    const cache = new Cache({
      max: 2,
      fetchMethod: async (_key, _stale, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => aborts++);
        return value;
      },
      dispose: (...args) => disposed.push(args),
      disposeAfter: (...args) => disposedAfter.push(args),
    });
    if (refresh) cache.set('key', 'old');
    const status = {};
    assert.equal(await settles(cache.fetch('key', { forceRefresh: refresh, status })), value);
    assert.equal(cache.get('key'), value);
    assert.equal(signal.aborted, false);
    assert.equal(aborts, 0);
    assert.equal(status.fetchResolved, true);
    assert.equal(status.fetchUpdated, true);
    const expected = refresh ? [['old', 'key', 'set']] : [];
    assert.deepEqual(disposed, expected);
    assert.deepEqual(disposedAfter, expected);
  });
}

test('fetch lifecycle: explicit replacement cancels a refresh and keeps the replacement', async () => {
  const provider = Promise.withResolvers();
  const inserted = [];
  const disposed = [];
  const disposedAfter = [];
  let signal;
  const cache = new Cache({
    max: 2,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return provider.promise;
    },
    onInsert: (...args) => inserted.push(args),
    dispose: (...args) => disposed.push(args),
    disposeAfter: (...args) => disposedAfter.push(args),
  });
  cache.set('key', 'old');
  const fetched = cache.fetch('key', { forceRefresh: true });
  const rejected = assert.rejects(fetched, { message: 'replaced' });
  cache.set('key', 'replacement');
  await rejected;
  provider.resolve('late result');
  await nextTurn();
  assert.equal(signal.aborted, true);
  assert.equal(signal.reason.message, 'replaced');
  assert.equal(cache.get('key'), 'replacement');
  assert.deepEqual(inserted, [['old', 'key', 'add'], ['replacement', 'key', 'replace']]);
  assert.deepEqual(disposed, [['old', 'key', 'set']]);
  assert.deepEqual(disposedAfter, [['old', 'key', 'set']]);
});

test('fetch lifecycle: coalesced successful fetches remain cached and follow ordinary LRU order', async () => {
  const provider = Promise.withResolvers();
  let calls = 0;
  const cache = new Cache({
    max: 2,
    fetchMethod: () => {
      calls++;
      return provider.promise;
    },
  });
  const first = cache.fetch('fetched');
  const second = cache.fetch('fetched');
  provider.resolve('value');
  assert.deepEqual(await settles(Promise.all([first, second])), ['value', 'value']);
  assert.equal(calls, 1);
  assert.equal(await cache.fetch('fetched'), 'value');
  cache.set('other', 'other value');
  assert.equal(cache.get('fetched'), 'value');
  cache.set('newest', 'new value');
  assert.equal(cache.has('other'), false);
  assert.deepEqual([...cache.keys()], ['newest', 'fetched']);
});

test('fetch lifecycle: ordinary onInsert reasons also include application Promise values', () => {
  const inserted = [];
  const applicationPromise = Promise.resolve('application value');
  const cache = new Cache({
    max: 2,
    fetchMethod: async () => 'unused',
    onInsert: (...args) => inserted.push(args),
  });
  cache.set('key', applicationPromise);
  cache.set('key', applicationPromise);
  cache.set('key', 'replacement');
  assert.deepEqual(inserted, [
    [applicationPromise, 'key', 'add'],
    [applicationPromise, 'key', 'update'],
    ['replacement', 'key', 'replace'],
  ]);
});

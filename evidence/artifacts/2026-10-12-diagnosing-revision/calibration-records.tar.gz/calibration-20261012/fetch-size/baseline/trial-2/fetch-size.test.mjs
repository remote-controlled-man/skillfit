#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import Cache from './index.js';

function controlledCache(options) {
  const calls = [];
  const cache = new Cache({
    ...options,
    fetchMethod(key, staleValue, { signal }) {
      return new Promise((resolve, reject) => {
        calls.push({ key, staleValue, signal, resolve, reject });
      });
    },
  });
  return { cache, calls };
}

// Bound iteration so a broken linked order fails instead of hanging the suite.
function collect(cache, iterable) {
  const items = [];
  for (const item of iterable) {
    items.push(item);
    assert.ok(items.length <= cache.size, 'iteration must not repeat entries');
  }
  return items;
}

function assertCache(cache, expected) {
  assert.equal(cache.calculatedSize, expected.reduce((sum, [, value]) => sum + value.length, 0));
  assert.ok(cache.calculatedSize <= cache.maxSize);
  assert.equal(cache.size, expected.length);
  assert.deepEqual(collect(cache, cache.entries()), expected);
  assert.deepEqual(collect(cache, cache.rentries()), [...expected].reverse());
  for (const [key, value] of expected) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size historical regression: an older miss finishes last and survives size eviction', async () => {
  const { cache, calls } = controlledCache({ maxSize: 10, sizeCalculation: value => value.length });
  const first = cache.fetch('first');
  const duplicate = cache.fetch('first');
  const second = cache.fetch('second');
  assert.equal(calls.length, 2);
  assert.equal(cache.calculatedSize, 0);
  assert.equal(cache.get('first'), undefined);

  calls[1].resolve('bbbbbb');
  assert.equal(await second, 'bbbbbb');
  assert.equal(cache.calculatedSize, 6);
  assert.equal(cache.size, 2);

  calls[0].resolve('aaaaaaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaaaaaa', 'aaaaaaa']);
  assertCache(cache, [['first', 'aaaaaaa']]);
  assert.equal(cache.has('second'), false);

  cache.set('third', 'ccc');
  assertCache(cache, [['third', 'ccc'], ['first', 'aaaaaaa']]);
  assert.equal(cache.get('first'), 'aaaaaaa');
  assertCache(cache, [['first', 'aaaaaaa'], ['third', 'ccc']]);
  cache.set('fourth', 'dd');
  assertCache(cache, [['fourth', 'dd'], ['first', 'aaaaaaa']]);
  assert.equal(cache.has('third'), false);
  cache.set('fifth', 'eeeee');
  assertCache(cache, [['fifth', 'eeeee'], ['fourth', 'dd']]);
  assert.equal(cache.has('first'), false);
});

for (const order of [
  ['a', 'b', 'c'], ['a', 'c', 'b'],
  ['b', 'a', 'c'], ['b', 'c', 'a'],
  ['c', 'a', 'b'], ['c', 'b', 'a'],
]) {
  test(`fetch-size completion order ${order.join(' -> ')} preserves capacity and LRU order`, async () => {
    const { cache, calls } = controlledCache({ max: 3, maxSize: 6, sizeCalculation: value => value.length });
    const requests = new Map(['a', 'b', 'c'].map(key => [key, cache.fetch(key)]));
    assert.equal(calls.length, 3);
    for (const [position, key] of order.entries()) {
      calls.find(call => call.key === key).resolve(key.repeat(3));
      assert.equal(await requests.get(key), key.repeat(3));
      assert.equal(cache.calculatedSize, Math.min(position + 1, 2) * 3);
      assert.equal(cache.size, position < 2 ? 3 : 2);
    }

    assertCache(cache, [[order[2], order[2].repeat(3)], [order[1], order[1].repeat(3)]]);
    assert.equal(cache.has(order[0]), false);
    assert.equal(cache.get(order[1]), order[1].repeat(3));
    assertCache(cache, [[order[1], order[1].repeat(3)], [order[2], order[2].repeat(3)]]);
    cache.set('d', 'dddd');
    assertCache(cache, [['d', 'dddd']]);
    cache.set('e', 'ee');
    assertCache(cache, [['e', 'ee'], ['d', 'dddd']]);
    cache.clear();
    assertCache(cache, []);
    cache.set('reused', 'rr');
    assertCache(cache, [['reused', 'rr']]);
  });
}

test('fetch-size refresh regression: retained stale sizes are replaced in completion order', async () => {
  const { cache, calls } = controlledCache({ maxSize: 10, sizeCalculation: value => value.length });
  cache.set('a', 'aa');
  cache.set('b', 'bbb');
  cache.set('c', 'ccc');
  assertCache(cache, [['c', 'ccc'], ['b', 'bbb'], ['a', 'aa']]);

  const first = cache.fetch('a', { forceRefresh: true });
  const second = cache.fetch('b', { forceRefresh: true });
  assert.equal(await cache.fetch('a', { allowStale: true }), 'aa');
  assert.deepEqual(calls.map(({ key, staleValue }) => [key, staleValue]), [['a', 'aa'], ['b', 'bbb']]);
  assert.equal(cache.calculatedSize, 8);
  assert.equal(cache.peek('a'), 'aa');

  calls[1].resolve('bbbb');
  assert.equal(await second, 'bbbb');
  assert.equal(cache.calculatedSize, 9);
  assert.equal(cache.size, 3);
  assert.equal(cache.peek('a'), 'aa');
  calls[0].resolve('aaaaaa');
  assert.equal(await first, 'aaaaaa');
  assertCache(cache, [['a', 'aaaaaa'], ['b', 'bbbb']]);
  assert.equal(cache.has('c'), false);

  cache.set('c', 'c');
  assertCache(cache, [['c', 'c'], ['a', 'aaaaaa']]);
  cache.set('a', 'a');
  assertCache(cache, [['a', 'a'], ['c', 'c']]);
});

test('fetch-size abort regression: an evicted fetch cannot overwrite a reused cache slot', async () => {
  const { cache, calls } = controlledCache({ max: 2, maxSize: 6, sizeCalculation: value => value.length });
  const pending = cache.fetch('pending');
  cache.set('live', 'll');
  cache.set('other', 'ooo');
  assert.equal(calls[0].signal.aborted, true);
  assertCache(cache, [['other', 'ooo'], ['live', 'll']]);

  const replacement = cache.fetch('pending');
  assert.equal(calls.length, 2);
  calls[1].resolve('pp');
  assert.equal(await replacement, 'pp');
  assertCache(cache, [['pending', 'pp'], ['other', 'ooo']]);
  calls[0].resolve('oldold');
  assert.equal(await pending, 'oldold');
  assertCache(cache, [['pending', 'pp'], ['other', 'ooo']]);
  assert.equal(await cache.fetch('other'), 'ooo');
  assert.equal(calls.length, 2);
  assertCache(cache, [['other', 'ooo'], ['pending', 'pp']]);
  cache.set('new', 'nnn');
  assertCache(cache, [['new', 'nnn'], ['other', 'ooo']]);
});

test('fetch-size explicit-size regression: deduplicated callers keep the original fetch size', async () => {
  const { cache, calls } = controlledCache({ maxSize: 6 });
  const first = cache.fetch('a', { size: 4 });
  const duplicate = cache.fetch('a', { size: 100 });
  const second = cache.fetch('b', { size: 3 });
  assert.equal(calls.length, 2);
  calls[1].resolve('bbb');
  assert.equal(await second, 'bbb');
  calls[0].resolve('aaaa');
  assert.deepEqual(await Promise.all([first, duplicate]), ['aaaa', 'aaaa']);
  assertCache(cache, [['a', 'aaaa']]);

  cache.set('c', 'cc', { size: 2 });
  assertCache(cache, [['c', 'cc'], ['a', 'aaaa']]);
  cache.set('d', 'd', { size: 1 });
  assertCache(cache, [['d', 'd'], ['c', 'cc']]);
});

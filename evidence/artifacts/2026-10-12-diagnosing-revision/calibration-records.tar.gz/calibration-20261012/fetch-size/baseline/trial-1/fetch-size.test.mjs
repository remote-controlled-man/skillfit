#!/usr/bin/env node
import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function deferredCache(options) {
  const pending = new Map();
  const calls = [];
  const cache = new Cache({
    ...options,
    sizeCalculation: value => value.length,
    fetchMethod(key, staleValue, { signal }) {
      calls.push(key);
      return new Promise(resolve => pending.set(key, { resolve, signal }));
    },
  });
  return { cache, pending, calls };
}

// Bound iteration so a broken linked order fails instead of hanging the suite.
function readOrder(iterable, size) {
  const items = [];
  for (const item of iterable) {
    assert.ok(items.length < size, 'cache iteration must terminate within its size');
    items.push(item);
  }
  return items;
}

function assertState(cache, entries) {
  const total = entries.reduce((sum, [, value]) => sum + value.length, 0);
  assert.equal(cache.calculatedSize, total, 'size accounting must match cached values');
  assert.ok(cache.calculatedSize <= cache.maxSize, 'values must fit the size limit');
  assert.equal(cache.size, entries.length);
  if (cache.max) assert.ok(cache.size <= cache.max, 'entries must fit the count limit');
  assert.deepEqual(readOrder(cache.entries(), entries.length), entries);
  assert.deepEqual(readOrder(cache.rentries(), entries.length), entries.slice().reverse());
  for (const [key, value] of entries) {
    assert.equal(cache.has(key), true);
    assert.equal(cache.peek(key), value);
  }
}

test('fetch-size historical regression: reverse completion preserves accounting and later eviction', async () => {
  const { cache, pending } = deferredCache({ maxSize: 10 });
  const first = cache.fetch('first');
  const second = cache.fetch('second');

  pending.get('second').resolve('bbbbbb');
  assert.equal(await second, 'bbbbbb');
  assert.equal(cache.calculatedSize, 6);
  assert.equal(cache.size, 2);

  // The oldest placeholder must become MRU before making room for its result.
  pending.get('first').resolve('aaaaaa');
  assert.equal(await first, 'aaaaaa');
  assertState(cache, [['first', 'aaaaaa']]);
  assert.equal(cache.has('second'), false);

  cache.set('third', 'cccc');
  assertState(cache, [['third', 'cccc'], ['first', 'aaaaaa']]);
  assert.equal(cache.get('first'), 'aaaaaa');
  cache.set('fourth', 'ddd');
  assertState(cache, [['fourth', 'ddd'], ['first', 'aaaaaa']]);
  assert.equal(cache.has('third'), false);
  assert.equal(cache.pop(), 'aaaaaa');
  assertState(cache, [['fourth', 'ddd']]);
  assert.equal(cache.delete('fourth'), true);
  assertState(cache, []);
  cache.set('reused', 'ee');
  assertState(cache, [['reused', 'ee']]);
});

test('fetch-size regression: mixed completion deduplicates requests and preserves both capacity limits', async () => {
  const { cache, pending, calls } = deferredCache({ max: 3, maxSize: 12 });
  const first = cache.fetch('first');
  const joined = cache.fetch('first');
  const second = cache.fetch('second');
  const third = cache.fetch('third');
  assert.deepEqual(calls, ['first', 'second', 'third']);
  assert.equal(cache.get('first'), undefined);

  pending.get('second').resolve('bbbb');
  assert.equal(await second, 'bbbb');
  assert.equal(cache.calculatedSize, 4);
  pending.get('third').resolve('ccccc');
  assert.equal(await third, 'ccccc');
  assert.equal(cache.calculatedSize, 9);
  pending.get('first').resolve('aaaaaa');
  assert.deepEqual(await Promise.all([first, joined]), ['aaaaaa', 'aaaaaa']);
  assertState(cache, [['first', 'aaaaaa'], ['third', 'ccccc']]);
  assert.equal(cache.has('second'), false);

  assert.equal(cache.get('third'), 'ccccc');
  cache.set('fourth', 'dddd');
  assertState(cache, [['fourth', 'dddd'], ['third', 'ccccc']]);
  cache.set('fifth', 'eeee');
  assertState(cache, [['fifth', 'eeee'], ['fourth', 'dddd']]);
  assert.equal(await cache.fetch('fourth'), 'dddd');
  assert.deepEqual(calls, ['first', 'second', 'third']);
  cache.set('sixth', 'ff');
  assertState(cache, [['sixth', 'ff'], ['fourth', 'dddd'], ['fifth', 'eeee']]);
  assert.equal(cache.get('fifth'), 'eeee');
  cache.set('seventh', 'g');
  assertState(cache, [['seventh', 'g'], ['fifth', 'eeee'], ['sixth', 'ff']]);
  assert.equal(cache.has('fourth'), false);
});

test('fetch-size regression: an oldest-entry refresh retains stale size and evicts the next LRU', async () => {
  const { cache, pending, calls } = deferredCache({ maxSize: 8 });
  cache.set('oldest', 'aa');
  cache.set('middle', 'bbb');
  cache.set('latest', 'cc');
  const refreshed = cache.fetch('oldest', { forceRefresh: true });
  const joined = cache.fetch('oldest');
  assert.equal(await cache.fetch('oldest', { allowStale: true }), 'aa');
  assert.equal(cache.peek('oldest'), 'aa');
  assert.equal(cache.calculatedSize, 7);
  assert.deepEqual(calls, ['oldest']);

  pending.get('oldest').resolve('aaaa');
  assert.deepEqual(await Promise.all([refreshed, joined]), ['aaaa', 'aaaa']);
  assertState(cache, [['oldest', 'aaaa'], ['latest', 'cc']]);
  assert.equal(cache.has('middle'), false);
  assert.equal(cache.get('latest'), 'cc');
  cache.set('new', 'ddddd');
  assertState(cache, [['new', 'ddddd'], ['latest', 'cc']]);
  assert.equal(cache.has('oldest'), false);
});

test('fetch-size regression: an evicted fetch cannot publish into a reused entry', async () => {
  const { cache, pending } = deferredCache({ max: 2, maxSize: 6 });
  const first = cache.fetch('first');
  cache.set('kept', 'kkkkkk');
  const third = cache.fetch('third');
  assert.equal(pending.get('first').signal.aborted, true);
  pending.get('first').resolve('aaaaa');
  assert.equal(await first, 'aaaaa');
  assert.equal(cache.has('first'), false);
  assert.equal(cache.peek('kept'), 'kkkkkk');
  assert.equal(cache.calculatedSize, 6);

  pending.get('third').resolve('ccc');
  assert.equal(await third, 'ccc');
  assertState(cache, [['third', 'ccc']]);
  assert.equal(cache.has('kept'), false);
  cache.set('replacement', 'rrrr');
  assertState(cache, [['replacement', 'rrrr']]);
});

test('fetch-size regression: ordinary replacement promotes the updated entry before size eviction', () => {
  const cache = new Cache({ maxSize: 7, sizeCalculation: value => value.length });
  cache.set('first', 'aa');
  cache.set('second', 'bbb');
  cache.set('first', 'aaaaa');
  assertState(cache, [['first', 'aaaaa']]);
  assert.equal(cache.has('second'), false);
  cache.set('third', 'cc');
  cache.set('first', 'aaaaa');
  assertState(cache, [['first', 'aaaaa'], ['third', 'cc']]);
  assert.equal(cache.get('third'), 'cc');
  cache.set('fourth', 'ddd');
  assertState(cache, [['fourth', 'ddd'], ['third', 'cc']]);
});

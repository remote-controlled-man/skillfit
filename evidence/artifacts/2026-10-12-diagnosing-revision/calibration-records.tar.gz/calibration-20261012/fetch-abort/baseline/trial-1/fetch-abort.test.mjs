import assert from 'node:assert/strict';
import { after, test } from 'node:test';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadCache } from './runtime.mjs';

const { Cache, cleanup } = await loadCache(dirname(fileURLToPath(import.meta.url)), false);
after(cleanup);

function deferred() {
  let resolve, reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
}

function pendingCache(max = 2) {
  const provider = deferred();
  let signal, calls = 0;
  const cache = new Cache({
    max,
    fetchMethod(_key, _stale, options) {
      signal = options.signal;
      calls++;
      return provider.promise;
    },
  });
  return { cache, provider, get signal() { return signal; }, get calls() { return calls; } };
}

const nextTurn = () => new Promise(resolve => setImmediate(resolve));
const observe = promise => promise.then(
  value => ({ status: 'fulfilled', value }),
  reason => ({ status: 'rejected', reason }),
);

async function expectAbort(outcome, signal) {
  assert.equal(signal.aborted, true);
  const pending = Symbol('still pending');
  // The provider remains unresolved: cancellation must settle the caller
  // without requiring any further provider progress.
  const result = await Promise.race([
    outcome,
    new Promise(resolve => setImmediate(resolve, pending)),
  ]);
  assert.notEqual(result, pending, 'aborted fetch must settle before the next event-loop turn');
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, signal.reason);
}

const cancellations = [
  {
    name: 'eviction', max: 1,
    cancel(cache) { cache.set('other', 'kept'); },
    verify(cache) {
      assert.equal(cache.has('key'), false);
      assert.equal(cache.get('other'), 'kept');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'deletion', max: 2,
    cancel(cache) {
      cache.set('other', 'kept');
      assert.equal(cache.delete('key'), true);
    },
    verify(cache) {
      assert.equal(cache.has('key'), false);
      assert.equal(cache.get('other'), 'kept');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'replacement', max: 2,
    cancel(cache) { cache.set('key', 'replacement'); },
    verify(cache) {
      assert.equal(cache.get('key'), 'replacement');
      assert.equal(cache.size, 1);
    },
  },
];

for (const cancellation of cancellations) {
  for (const completion of ['undefined', 'bogus value', 'rejection']) {
    test(`fetch cancellation regression: ${cancellation.name} rejects promptly despite late ${completion}`, async () => {
      const state = pendingCache(cancellation.max);
      const outcome = observe(state.cache.fetch('key'));
      cancellation.cancel(state.cache);
      await expectAbort(outcome, state.signal);
      cancellation.verify(state.cache);

      if (completion === 'rejection') {
        state.provider.reject(new Error('late provider failure'));
      } else {
        state.provider.resolve(completion === 'undefined' ? undefined : { bogus: true });
      }
      await nextTurn();
      await expectAbort(outcome, state.signal);
      cancellation.verify(state.cache);
    });
  }
}

test('fetch cancellation regression: clearing a sole pending entry rejects a provider that never settles', async () => {
  const state = pendingCache();
  const outcome = observe(state.cache.fetch('key'));
  state.cache.clear();
  await expectAbort(outcome, state.signal);
  assert.equal(state.cache.size, 0);
  assert.equal(state.cache.has('key'), false);
});

test('fetch cancellation regression: an abort handler returning a bogus value still rejects with the signal reason', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod(_key, _stale, options) {
      signal = options.signal;
      return new Promise(resolve => {
        signal.addEventListener('abort', () => resolve('bogus'), { once: true });
      });
    },
  });
  const outcome = observe(cache.fetch('key'));
  cache.set('key', 'replacement');
  await expectAbort(outcome, signal);
  await nextTurn();
  assert.equal(cache.get('key'), 'replacement');
});

test('fetch cancellation regression: replacement wins when provider resolution is queued before abort', async () => {
  const state = pendingCache();
  const outcome = observe(state.cache.fetch('key'));
  state.provider.resolve('late result');
  state.cache.set('key', 'replacement');
  await expectAbort(outcome, state.signal);
  assert.equal(state.cache.get('key'), 'replacement');
});

test('fetch cancellation regression: abort reason wins over a queued provider rejection', async () => {
  const state = pendingCache();
  const outcome = observe(state.cache.fetch('key'));
  state.provider.reject({ providerFailure: true });
  // Let the rejection reach the bridge, then abort before the caller settles.
  await Promise.resolve();
  state.cache.set('key', 'replacement');
  await expectAbort(outcome, state.signal);
  assert.equal(state.cache.get('key'), 'replacement');
});

test('fetch cancellation compatibility: concurrent successful fetches share one provider and cache the result', async () => {
  const state = pendingCache();
  const first = state.cache.fetch('key');
  const second = state.cache.fetch('key');
  assert.equal(state.calls, 1);
  const value = { loaded: true };
  state.provider.resolve(value);
  const results = await Promise.all([first, second]);
  assert.strictEqual(results[0], value);
  assert.strictEqual(results[1], value);
  assert.strictEqual(state.cache.get('key'), value);
  assert.strictEqual(await state.cache.fetch('key'), value);
  assert.equal(state.calls, 1);
});

test('fetch cancellation regression: all deduplicated callers promptly reject with the shared abort reason', async () => {
  const state = pendingCache();
  const first = observe(state.cache.fetch('key'));
  const second = observe(state.cache.fetch('key'));
  assert.equal(state.calls, 1);
  state.cache.delete('key');
  await Promise.all([expectAbort(first, state.signal), expectAbort(second, state.signal)]);
  assert.equal(state.cache.has('key'), false);
});

test('fetch cancellation compatibility: a synchronous provider result is returned and cached', async () => {
  let calls = 0;
  const cache = new Cache({ max: 1, fetchMethod: () => { calls++; return 'loaded'; } });
  assert.equal(await cache.fetch('key'), 'loaded');
  assert.equal(await cache.fetch('key'), 'loaded');
  assert.equal(cache.get('key'), 'loaded');
  assert.equal(calls, 1);
});

test('fetch cancellation compatibility: allowStaleOnFetchRejection returns and retains the previous value', async () => {
  const state = pendingCache();
  const stale = { previous: true };
  state.cache.set('key', stale);
  const result = state.cache.fetch('key', {
    forceRefresh: true,
    allowStale: false,
    allowStaleOnFetchRejection: true,
  });
  state.provider.reject(new Error('provider failed'));
  assert.strictEqual(await result, stale);
  assert.strictEqual(state.cache.get('key'), stale);
});

test('fetch cancellation compatibility: an ordinary provider rejection preserves its reason and removes the entry', async () => {
  const state = pendingCache();
  const outcome = observe(state.cache.fetch('key'));
  const reason = { providerFailure: true };
  state.provider.reject(reason);
  const result = await outcome;
  assert.equal(result.status, 'rejected');
  assert.strictEqual(result.reason, reason);
  assert.equal(state.cache.has('key'), false);
});

#!/usr/bin/env node
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { setImmediate as nextTurn } from 'node:timers/promises';
import Cache from './index.js';

const deferred = () => {
  let resolve, reject;
  const promise = new Promise((res, rej) => {
    resolve = res;
    reject = rej;
  });
  return { promise, resolve, reject };
};

const observe = promise => promise.then(
  value => ({ state: 'fulfilled', value }),
  reason => ({ state: 'rejected', reason }),
);

const expectAbort = async (outcome, signal) => {
  const result = await Promise.race([outcome, nextTurn({ state: 'pending' })]);
  assert.equal(signal.aborted, true);
  assert.equal(result.state, 'rejected', 'fetch must reject without waiting for its provider');
  assert.strictEqual(result.reason, signal.reason);
};

test('fetch cancellation historical regression: eviction rejects even when the provider resolves undefined on abort', async () => {
  let signal;
  const cache = new Cache({
    max: 1,
    fetchMethod: (_key, _stale, options) => {
      signal = options.signal;
      return new Promise(resolve => {
        signal.addEventListener('abort', () => resolve(undefined), { once: true });
      });
    },
  });
  const outcome = observe(cache.fetch('pending'));
  cache.set('retained', 'retained value');

  await expectAbort(outcome, signal);
  assert.equal(cache.has('pending'), false);
  assert.equal(cache.get('retained'), 'retained value');
  assert.equal(cache.size, 1);
});

const cancellations = [
  {
    name: 'eviction',
    max: 1,
    cancel: cache => cache.set('retained', 'retained value'),
    verify: cache => {
      assert.equal(cache.has('pending'), false);
      assert.equal(cache.get('retained'), 'retained value');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'deletion',
    max: 2,
    cancel: cache => assert.equal(cache.delete('pending'), true),
    verify: cache => {
      assert.equal(cache.has('pending'), false);
      assert.equal(cache.get('retained'), 'retained value');
      assert.equal(cache.size, 1);
    },
  },
  {
    name: 'replacement',
    max: 2,
    cancel: cache => cache.set('pending', 'explicit replacement'),
    verify: cache => {
      assert.equal(cache.get('pending'), 'explicit replacement');
      assert.equal(cache.get('retained'), 'retained value');
      assert.equal(cache.size, 2);
    },
  },
  {
    name: 'clear',
    max: 2,
    cancel: cache => cache.clear(),
    verify: cache => {
      assert.equal(cache.has('pending'), false);
      assert.equal(cache.has('retained'), false);
      assert.equal(cache.size, 0);
    },
  },
];

for (const { name, max, cancel, verify } of cancellations) {
  test(`fetch cancellation regression: ${name} promptly rejects all deduplicated waiters and ignores late success`, async () => {
    const provider = deferred();
    let signal, calls = 0;
    const cache = new Cache({
      max,
      fetchMethod: (_key, _stale, options) => {
        calls++;
        signal = options.signal;
        return provider.promise;
      },
    });
    if (max > 1) cache.set('retained', 'retained value');
    const outcomes = [observe(cache.fetch('pending')), observe(cache.fetch('pending'))];
    assert.equal(calls, 1);
    cancel(cache);

    await Promise.all(outcomes.map(outcome => expectAbort(outcome, signal)));
    verify(cache);
    provider.resolve('late provider value');
    await nextTurn();
    verify(cache);
  });
}

for (const settlement of ['resolve', 'reject']) {
  test(`fetch cancellation regression: replacement uses the signal reason when the provider ${settlement}s a bogus value on abort`, async () => {
    const provider = deferred();
    const bogus = new Error('provider result');
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        signal.addEventListener('abort', () => provider[settlement](bogus), { once: true });
        return provider.promise;
      },
    });
    const outcome = observe(cache.fetch('pending'));
    cache.set('pending', 'explicit replacement');

    await expectAbort(outcome, signal);
    await nextTurn();
    assert.equal(cache.get('pending'), 'explicit replacement');
  });
}

for (const settlement of ['resolve', 'reject']) {
  test(`fetch cancellation regression: replacement during provider ${settlement} still rejects the signal reason`, async () => {
    const provider = deferred();
    let signal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, options) => {
        signal = options.signal;
        return provider.promise;
      },
    });
    const outcome = observe(cache.fetch('pending'));
    const replace = () => cache.set('pending', 'explicit replacement');
    const replacement = provider.promise.then(replace, replace);
    provider[settlement](new Error('provider result'));
    await replacement;

    await expectAbort(outcome, signal);
    assert.equal(cache.get('pending'), 'explicit replacement');
  });
}

for (const settlement of ['resolve', 'reject']) {
  test(`fetch cancellation regression: a removed provider's late ${settlement} leaves a new fetch for the same key intact`, async () => {
    const providers = [deferred(), deferred()];
    let calls = 0, oldSignal;
    const cache = new Cache({
      max: 1,
      fetchMethod: (_key, _stale, { signal }) => {
        if (calls === 0) oldSignal = signal;
        return providers[calls++].promise;
      },
    });
    const oldOutcome = observe(cache.fetch('pending'));
    cache.delete('pending');
    await expectAbort(oldOutcome, oldSignal);

    const current = cache.fetch('pending');
    providers[0][settlement](new Error('obsolete provider result'));
    await nextTurn();
    const deduplicated = cache.fetch('pending');
    assert.equal(calls, 2);
    const value = { current: true };
    providers[1].resolve(value);
    assert.strictEqual(await current, value);
    assert.strictEqual(await deduplicated, value);
    assert.strictEqual(cache.get('pending'), value);
  });
}

test('fetch cancellation compatibility: ordinary success deduplicates concurrent callers and caches the value', async () => {
  const provider = deferred();
  let calls = 0;
  const cache = new Cache({ max: 2, fetchMethod: () => { calls++; return provider.promise; } });
  const callers = [cache.fetch('key'), cache.fetch('key'), cache.fetch('key')];
  assert.equal(calls, 1);
  const value = { successful: true };
  provider.resolve(value);
  for (const result of await Promise.all(callers)) assert.strictEqual(result, value);
  assert.strictEqual(cache.get('key'), value);
  assert.strictEqual(await cache.fetch('key'), value);
  assert.equal(calls, 1);
});

test('fetch cancellation compatibility: a successful refresh serves stale values and shares the pending fetch', async () => {
  const provider = deferred();
  let calls = 0;
  const cache = new Cache({ max: 1, fetchMethod: () => { calls++; return provider.promise; } });
  const stale = { old: true };
  cache.set('key', stale);
  assert.strictEqual(await cache.fetch('key', { forceRefresh: true, allowStale: true }), stale);
  const waiting = cache.fetch('key');
  assert.equal(calls, 1);
  const fresh = { fresh: true };
  provider.resolve(fresh);
  assert.strictEqual(await waiting, fresh);
  assert.strictEqual(cache.get('key'), fresh);
});

test('fetch cancellation compatibility: allowStaleOnFetchRejection returns and retains the stale value', async () => {
  const provider = deferred();
  const cache = new Cache({ max: 1, fetchMethod: () => provider.promise });
  const stale = { old: true };
  cache.set('key', stale);
  const waiting = cache.fetch('key', { forceRefresh: true, allowStaleOnFetchRejection: true });
  provider.reject(new Error('refresh failed'));
  assert.strictEqual(await waiting, stale);
  assert.strictEqual(cache.get('key'), stale);
  assert.strictEqual(await cache.fetch('key'), stale);
});

test('fetch cancellation compatibility: ordinary provider rejection preserves its reason and allows a retry', async () => {
  const failure = new Error('provider failed');
  let calls = 0;
  const cache = new Cache({
    max: 1,
    fetchMethod: () => ++calls === 1 ? Promise.reject(failure) : Promise.resolve('retry value'),
  });
  const result = await observe(cache.fetch('key'));
  assert.equal(result.state, 'rejected');
  assert.strictEqual(result.reason, failure);
  assert.equal(cache.has('key'), false);
  assert.equal(await cache.fetch('key'), 'retry value');
  assert.equal(calls, 2);
});

test('fetch cancellation compatibility: a synchronous provider value is returned and cached', async () => {
  const value = { successful: true };
  const cache = new Cache({ max: 1, fetchMethod: () => value });
  assert.strictEqual(await cache.fetch('key'), value);
  assert.strictEqual(cache.get('key'), value);
});

test('fetch cancellation compatibility: a synchronous provider throw rejects with the original reason', async () => {
  const failure = new Error('synchronous provider failure');
  const cache = new Cache({ max: 1, fetchMethod: () => { throw failure; } });
  const result = await observe(cache.fetch('key'));
  assert.equal(result.state, 'rejected');
  assert.strictEqual(result.reason, failure);
  assert.equal(cache.has('key'), false);
});

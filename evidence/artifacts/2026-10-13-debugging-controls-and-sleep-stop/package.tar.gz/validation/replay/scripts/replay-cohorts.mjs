// Offline-only reproduction of all retained cohorts. Never runs an agent or model API.
import assert from 'node:assert/strict';
import {cpSync,mkdtempSync,readFileSync,rmSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {tmpdir} from 'node:os';
import {basename,dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {loadBench} from '../dist/harness/bench.js';
import {runVerifier} from '../dist/harness/runner.js';
import {verdictFromOutput} from '../dist/harness/verifier-summary.js';
import {summarizeCosts,COST_METRICS} from '../dist/harness/costs.js';
import {mcnemarExactP,pairedDeltaBootstrapCI,pairedScoreBootstrapCI} from '../dist/harness/stats.js';
import {verdictFor} from '../dist/harness/report.js';
const replay=resolve(dirname(fileURLToPath(import.meta.url)),'..'),pkg=resolve(replay,'..');
const spec=JSON.parse(readFileSync(join(pkg,'replay-spec.json'),'utf8'));
const index=JSON.parse(readFileSync(join(pkg,'export-index.json'),'utf8'));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const f of index.files)assert.equal(hash(readFileSync(join(pkg,f.path))),f.exportedSha256,f.path);
const cohorts=[],measured=[];
for(const entry of spec.cohorts){
 const dir=join(pkg,entry.records),manifest=JSON.parse(readFileSync(join(dir,'manifest.json'),'utf8')),bench=loadBench(join(pkg,entry.bench));
 assert.equal(bench.contentSha256,manifest.bench.contentSha256);
 const all={baseline:[],treatment:[]},paired={baseline:[],treatment:[]},taskOutcomes=[],scoreTasks=[];
 let improved=0,regressed=0,regraded=0,invoked=0;
 for(const task of bench.tasks){
  const records={baseline:[],treatment:[]},survivors={baseline:[],treatment:[]};
  for(let trial=1;trial<=manifest.trials;trial++){
   const pair={};
   for(const arm of ['baseline','treatment']){
    const delivery=join(dir,task.id,arm,'trial-'+trial),r=JSON.parse(readFileSync(join(delivery,'_result.json'),'utf8'));
    assert.equal(r.taskId,task.id);assert.equal(r.condition,arm);assert.equal(r.trial,trial);
    records[arm].push(r);all[arm].push(r);pair[arm]=r;
    if(r.executorInvoked){invoked++;measured.push(r);}
    if(r.error!==null)continue;
    const scratch=mkdtempSync(join(tmpdir(),'skillfit-cohort-replay-'));
    try{
     cpSync(delivery,scratch,{recursive:true,filter:path=>basename(path)!=='.git'});
     const grade=await runVerifier(bench.dir,task.verifier,scratch),summary=verdictFromOutput(grade.output);
     assert.equal(grade.exitCode,r.verifierExitCode);assert.equal(grade.exitCode===0,r.passed);assert.equal(summary?.score??null,r.score);
     assert.deepEqual(summary?.checks?.map(({name,pass})=>({name,pass}))??null,r.checks?.map(({name,pass})=>({name,pass}))??null);
    }finally{rmSync(scratch,{recursive:true,force:true});}
    regraded++;
   }
   if(pair.baseline.error===null&&pair.treatment.error===null){
    for(const arm of ['baseline','treatment']){survivors[arm].push(pair[arm]);paired[arm].push(pair[arm]);}
    if(!pair.baseline.passed&&pair.treatment.passed)improved++;
    if(pair.baseline.passed&&!pair.treatment.passed)regressed++;
   }
  }
  const saved=manifest.tasks.find(t=>t.id===task.id),outcomes=Object.fromEntries(['baseline','treatment'].map(arm=>[arm,survivors[arm].map(r=>r.passed)]));
  assert.deepEqual(outcomes,saved.outcomes);taskOutcomes.push(outcomes);assert.deepEqual(summarizeCosts(records,survivors),saved.costs);
  for(const arm of ['baseline','treatment']){
   assert.equal(saved.conditions[arm].passes,survivors[arm].filter(r=>r.passed).length);assert.equal(saved.conditions[arm].trials,survivors[arm].length);
   assert.equal(saved.conditions[arm].errors,records[arm].filter(r=>r.error!==null).length);
  }
  const scores=Object.fromEntries(['baseline','treatment'].map(arm=>[arm,survivors[arm].map(r=>r.score)]));assert.deepEqual(scores,saved.scores);
  const completeScores={baseline:[],treatment:[]};
  for(let i=0;i<scores.baseline.length;i++)if(scores.baseline[i]!==null&&scores.treatment[i]!==null){completeScores.baseline.push(scores.baseline[i]);completeScores.treatment.push(scores.treatment[i]);}
  if(completeScores.baseline.length)scoreTasks.push(completeScores);
 }
 const costs=summarizeCosts(all,paired);assert.deepEqual(costs,manifest.overall.costs);
 const baselinePasses=paired.baseline.filter(r=>r.passed).length,treatmentPasses=paired.treatment.filter(r=>r.passed).length;
 const delta=paired.baseline.length?treatmentPasses/paired.treatment.length-baselinePasses/paired.baseline.length:0;
 assert.equal(manifest.overall.conditions.baseline.passes,baselinePasses);assert.equal(manifest.overall.conditions.treatment.passes,treatmentPasses);
 assert.equal(manifest.overall.deltaPassRate,delta);assert.deepEqual(manifest.overall.stats.discordant,{improved,regressed});
 assert.equal(manifest.overall.stats.mcnemarP,mcnemarExactP(improved,regressed));assert.deepEqual(manifest.overall.stats.deltaCi,pairedDeltaBootstrapCI(taskOutcomes));
 const scoreCi=pairedScoreBootstrapCI(scoreTasks);assert.deepEqual(manifest.overall.stats.scoreDeltaCi,scoreCi);assert.equal(manifest.overall.scoreDelta,scoreCi?.point??null);
 assert.equal(manifest.overall.verdict,verdictFor({improved,regressed,deltaPassRate:delta}).verdict);assert.equal(invoked,manifest.experiment.callsStarted);
 cohorts.push({id:entry.id,status:manifest.experiment.status,agentCliInvocations:invoked,regradedDeliveries:regraded,gradedPairs:paired.baseline.length,baselinePasses,treatmentPasses,improvedPairs:improved,regressedPairs:regressed,statisticalVerdict:manifest.overall.verdict,qualityStatsMatch:true,costsMatch:true,costs});
}
const population=summarizeCosts({baseline:measured,treatment:[]},{baseline:[],treatment:[]}).attempts.baseline;
console.log(JSON.stringify({schemaVersion:1,scope:'Separate frozen benchmark cohorts; never pool quality evidence or reinterpret stopped records. Readiness and other study overhead remain in separate ledgers. Derived export does not assert an unchanged native seal.',modelCallsMadeByReplay:0,agentCliInvocations:measured.length,regradedDeliveries:cohorts.reduce((sum,c)=>sum+c.regradedDeliveries,0),indexedFiles:index.files.length,cohorts,totalRecordedSpending:Object.fromEntries(COST_METRICS.map(metric=>[metric,population.metrics[metric]])),automaticUpgrade:false},null,2));

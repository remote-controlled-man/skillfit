我会先复现默认排序给裸查询参数补上 `=` 的问题，再修改 `index.js`、保留回归测试，并运行指定的本地测试命令。

我会按 `diagnosing-bugs` 技能的流程，先记录公开 API 的失败结果，再做最小修复并验证相关行为。全程只使用当前本地快照。

已复现：修复前，回归测试得到 `?/catalog/item=`。原因是 `URLSearchParams.sort()` 重新序列化查询时，把裸参数和显式空值都写成了 `key=`。我会保留每个参数原有的 `=` 状态，确保排序后仍能区分它们，包括重复参数名。

已修复 `index.js`：默认排序仍开启，排序后保留裸参数与显式空值的区别。新增 `query-parameter-shape-regression.test.mjs`，覆盖所要求的相关行为。

修复前已复现多余 `=`；修复后 `node --test test.mjs *.test.mjs` 全部 14 项通过，`git diff --check` 通过。

所有 supplied 文件保持不变。未访问网络或其他 checkout；AVA 未运行，因本地缺少其开发工具。
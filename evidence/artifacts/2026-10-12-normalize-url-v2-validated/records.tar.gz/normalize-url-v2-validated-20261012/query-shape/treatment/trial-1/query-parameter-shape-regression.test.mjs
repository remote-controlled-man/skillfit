import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('catalog route regression: default sorting preserves a path-like bare query', () => {
	const input = 'https://example.com/index.php?/catalog/item';
	assert.equal(normalizeUrl(input), input);
});

test('archive route regression: default sorting preserves another public path-like query', () => {
	const input = 'https://example.com/router.php?/archive/2026/featured';
	assert.equal(normalizeUrl(input), input);
});

test('bare parameters and explicitly empty values remain distinct', () => {
	for (const query of ['/catalog/item', '/catalog/item=', 'flag', 'flag=']) {
		const input = `https://example.com/index.php?${query}`;
		assert.equal(normalizeUrl(input), input);
	}
});

test('query sorting stays enabled by default and can be explicitly enabled', () => {
	const input = 'https://example.com/index.php?z=last&b=two&a=one';
	const expected = 'https://example.com/index.php?a=one&b=two&z=last';
	assert.equal(normalizeUrl(input), expected);
	assert.equal(normalizeUrl(input, {sortQueryParameters: true}), expected);
});

test('sorting preserves mixed bare and assigned parameters with similar names', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=9&route2=&route&route-extra=x&ready&alpha=1'),
		'https://example.com/index.php?alpha=1&ready&route&route-extra=x&route2=&z=9',
	);
});

test('sorting opt-out preserves query order and bare or empty syntax', () => {
	for (const query of ['/catalog/item', 'z=9&route2=&route&route-extra=x&ready&alpha=1']) {
		const input = `https://example.com/index.php?${query}`;
		assert.equal(normalizeUrl(input, {sortQueryParameters: false}), input);
	}
});

test('sorting retains every explicitly empty value', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=&b=&a='),
		'https://example.com/index.php?a=&b=&z=',
	);
});

test('sorting is stable for repeated names with bare, empty, and nonempty values', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=9&flag=&flag&flag=value&flag=&flag'),
		'https://example.com/index.php?flag=&flag&flag=value&flag=&flag&z=9',
	);
});

test('query filtering retains bare and explicitly empty shapes before sorting', () => {
	const input = 'https://example.com/index.php?z=&utm_source=campaign&flag=&flag&alpha=1';
	assert.equal(normalizeUrl(input), 'https://example.com/index.php?alpha=1&flag=&flag&z=');
	assert.equal(
		normalizeUrl(input, {keepQueryParameters: ['flag', 'z']}),
		'https://example.com/index.php?flag=&flag&z=',
	);
	assert.equal(normalizeUrl(input, {removeQueryParameters: true}), 'https://example.com/index.php');
});

test('ordinary URL normalization still applies around bare query parameters', () => {
	assert.equal(
		normalizeUrl(' HTTPS://user:secret@WWW.Example.com.:443/a//b/../%7Ecatalog/?z=9&route&alpha=1 '),
		'https://example.com/a/~catalog?alpha=1&route&z=9',
	);
});

test('bare query preservation respects fragment options', () => {
	const input = 'https://example.com/index.php?/catalog/item#details:~:text=hello%20world';
	assert.equal(normalizeUrl(input), 'https://example.com/index.php?/catalog/item#details');
	assert.equal(normalizeUrl(input, {stripHash: true}), 'https://example.com/index.php?/catalog/item');
	assert.equal(normalizeUrl(input, {stripTextFragment: false}), input);
});

test('encoded path backslashes remain encoded while mixed query parameters sort', () => {
	assert.equal(
		normalizeUrl('https://example.com/some%5Bthing%5Celse/that-is%40great@coding?z=2&route&a=1#details'),
		'https://example.com/some[thing%5Celse/that-is%40great@coding?a=1&route&z=2#details',
	);
	assert.equal(normalizeUrl('https://example.com/something\\else/great'), 'https://example.com/something/else/great');
});

test('Unicode query values retain their existing URL encoding after sorting', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=雪&a=caf%C3%A9&route'),
		'https://example.com/index.php?a=caf%C3%A9&route&z=%E9%9B%AA',
	);
});

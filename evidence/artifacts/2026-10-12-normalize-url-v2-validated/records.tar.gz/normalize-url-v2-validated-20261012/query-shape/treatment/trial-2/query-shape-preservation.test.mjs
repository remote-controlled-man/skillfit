import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('default sorting preserves the bare catalog route after index.php', () => {
	const url = 'https://example.com/index.php?/catalog/item';
	assert.equal(normalizeUrl(url), url);
});

test('explicit sorting preserves path-like query parameters', () => {
	const url = 'https://example.com/index.php?/catalog/item';
	assert.equal(normalizeUrl(url, {sortQueryParameters: true}), url);
});

test('bare parameters and explicitly empty values remain distinct public inputs', () => {
	for (const parameter of ['flag', '/catalog/item']) {
		const bare = `https://example.com/index.php?${parameter}`;
		const empty = `${bare}=`;
		assert.equal(normalizeUrl(bare), bare);
		assert.equal(normalizeUrl(empty), empty);
		assert.notEqual(normalizeUrl(bare), normalizeUrl(empty));
	}
});

test('default sorting preserves mixed bare, assigned, and explicitly empty parameters', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=last&/catalog/item&empty=&a=first&flag'),
		'https://example.com/index.php?/catalog/item&a=first&empty=&flag&z=last',
	);
});

test('similar parameter names retain their own assignment shape', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?flagship=&prefixflag=&flagged=value&flag'),
		'https://example.com/index.php?flag&flagged=value&flagship=&prefixflag=',
	);
});

test('sorting explicitly empty values keeps their equals signs', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=&a=&b=value'),
		'https://example.com/index.php?a=&b=value&z=',
	);
});

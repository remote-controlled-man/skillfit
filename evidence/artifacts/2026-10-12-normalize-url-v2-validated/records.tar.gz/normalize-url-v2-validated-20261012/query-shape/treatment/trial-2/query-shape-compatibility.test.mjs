import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('sorting opt-out retains parameter order and bare or empty shapes', () => {
	const options = {sortQueryParameters: false};
	for (const url of [
		'https://example.com/index.php?/catalog/item',
		'https://example.com/index.php?z=last&/catalog/item&empty=&a=first&flag',
		'https://example.com/index.php?z=&a=&b=value',
	]) {
		assert.equal(normalizeUrl(url, options), url);
	}
});

test('ordinary URL normalization and default assigned-parameter sorting still apply', () => {
	assert.equal(
		normalizeUrl(' HTTPS://user:pass@WWW.Example.COM:443//shop///items/?z=2&utm_source=test&a=1 '),
		'https://example.com/shop/items?a=1&z=2',
	);
	assert.equal(
		normalizeUrl('https://example.com/?b=2&a=1', {sortQueryParameters: false}),
		'https://example.com/?b=2&a=1',
	);
});

test('path-like queries preserve fragments and honor fragment removal options', () => {
	const url = 'https://example.com/index.php?z=2&/catalog/item#details';
	assert.equal(normalizeUrl(url), 'https://example.com/index.php?/catalog/item&z=2#details');
	assert.equal(normalizeUrl(url, {stripHash: true}), 'https://example.com/index.php?/catalog/item&z=2');
	assert.equal(
		normalizeUrl(`${url}:~:text=catalog`),
		'https://example.com/index.php?/catalog/item&z=2#details',
	);
});

test('sorting path-like queries preserves encoded pathname backslashes', () => {
	assert.equal(
		normalizeUrl('https://example.com/store%5Carchive/index.php?z=2&/catalog/item&a=1#details'),
		'https://example.com/store%5Carchive/index.php?/catalog/item&a=1&z=2#details',
	);
});

test('sorting path-like queries preserves Unicode parameter values', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=雪&/catalog/item&a=café'),
		'https://example.com/index.php?/catalog/item&a=caf%C3%A9&z=%E9%9B%AA',
	);
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=雪&a=café'),
		'https://example.com/index.php?a=caf%C3%A9&z=%E9%9B%AA',
	);
});

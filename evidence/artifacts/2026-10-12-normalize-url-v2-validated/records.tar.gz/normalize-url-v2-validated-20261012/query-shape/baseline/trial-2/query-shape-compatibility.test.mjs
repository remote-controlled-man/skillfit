import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

const cases = [
	{
		name: 'ordinary assigned parameters still sort by default',
		input: 'https://example.com/?z=last&a=first&m=middle',
		expected: 'https://example.com/?a=first&m=middle&z=last',
	},
	{
		name: 'explicitly enabled sorting retains bare and assigned parameters',
		input: 'https://example.com/index.php?z=last&/catalog/item&b=&a=first',
		options: {sortQueryParameters: true},
		expected: 'https://example.com/index.php?/catalog/item&a=first&b=&z=last',
	},
	{
		name: 'multiple bare parameters still sort',
		input: 'https://example.com/?zeta&alpha&middle',
		expected: 'https://example.com/?alpha&middle&zeta',
	},
	{
		name: 'sorting opt-out preserves the reported path-like query',
		input: 'https://example.com/index.php?/catalog/item',
		options: {sortQueryParameters: false},
		expected: 'https://example.com/index.php?/catalog/item',
	},
	{
		name: 'sorting opt-out preserves mixed parameter order and shape',
		input: 'https://example.com/?z=last&flag&empty=&a=first',
		options: {sortQueryParameters: false},
		expected: 'https://example.com/?z=last&flag&empty=&a=first',
	},
	{
		name: 'an explicitly empty path-like parameter retains its equals sign',
		input: 'https://example.com/index.php?/catalog/item=',
		expected: 'https://example.com/index.php?/catalog/item=',
	},
	{
		name: 'all explicitly empty values retain their equals signs when sorted',
		input: 'https://example.com/?z=&a=&m=',
		expected: 'https://example.com/?a=&m=&z=',
	},
	{
		name: 'similar parameter names retain their individual shapes',
		input: 'https://example.com/?foobar=&foo&foo-bar=value&foobaz',
		expected: 'https://example.com/?foo&foo-bar=value&foobar=&foobaz',
	},
	{
		name: 'duplicate names retain stable order and individual empty-value shapes',
		input: 'https://example.com/?flag=&z=9&flag&flag=value&flag=',
		expected: 'https://example.com/?flag=&flag&flag=value&flag=&z=9',
	},
	{
		name: 'equivalent encoded names retain bare versus explicitly empty values',
		input: 'https://example.com/?z=last&a%20b=&a+b',
		expected: 'https://example.com/?a+b=&a+b&z=last',
	},
	{
		name: 'a leading question mark in a parameter name retains its bare shape',
		input: 'https://example.com/?b&?flag&empty=',
		expected: 'https://example.com/??flag&b&empty=',
	},
	{
		name: 'ordinary URL normalization also preserves bare query shape',
		input: ' HTTPS://www.Example.com:443/a//b/../c/?z=last&flag&a=first ',
		expected: 'https://example.com/a/c?a=first&flag&z=last',
	},
	{
		name: 'sorting preserves the fragment separately from the query',
		input: 'https://example.com/index.php?z&empty=&/catalog/item#details=1&flag',
		expected: 'https://example.com/index.php?/catalog/item&empty=&z#details=1&flag',
	},
	{
		name: 'stripHash still removes the fragment with a bare query',
		input: 'https://example.com/index.php?/catalog/item#details',
		options: {stripHash: true},
		expected: 'https://example.com/index.php?/catalog/item',
	},
	{
		name: 'text fragment stripping preserves the ordinary fragment and query',
		input: 'https://example.com/index.php?/catalog/item#details:~:text=hello',
		expected: 'https://example.com/index.php?/catalog/item#details',
	},
	{
		name: 'encoded pathname backslashes remain encoded beside a bare query',
		input: 'https://example.com/something%5Celse/great?z=last&/catalog/item',
		expected: 'https://example.com/something%5Celse/great?/catalog/item&z=last',
	},
	{
		name: 'Unicode parameter values retain their normalized encoding',
		input: 'https://example.com/?z&name=你好&emoji=😀',
		expected: 'https://example.com/?emoji=%F0%9F%98%80&name=%E4%BD%A0%E5%A5%BD&z',
	},
	{
		name: 'assigned path values and spaces retain their normal serialization',
		input: 'https://example.com/?z&path=/catalog/item&label=hello%20world',
		expected: 'https://example.com/?label=hello+world&path=/catalog/item&z',
	},
	{
		name: 'default tracking removal preserves the retained query shapes',
		input: 'https://example.com/?z&empty=&utm_source=test&/catalog/item',
		expected: 'https://example.com/?/catalog/item&empty=&z',
	},
	{
		name: 'keeping selected parameters preserves bare and empty values',
		input: 'https://example.com/?z=last&empty=&flag',
		options: {keepQueryParameters: ['empty', 'flag']},
		expected: 'https://example.com/?empty=&flag',
	},
	{
		name: 'removing every parameter still removes the query',
		input: 'https://example.com/?empty=&flag',
		options: {removeQueryParameters: true},
		expected: 'https://example.com',
	},
	{
		name: 'a URL without query parameters retains ordinary normalization',
		input: 'https://www.example.com:443/a//b/',
		expected: 'https://example.com/a/b',
	},
];

for (const {name, input, options, expected} of cases) {
	test(name, () => {
		assert.equal(normalizeUrl(input, options), expected);
	});
}

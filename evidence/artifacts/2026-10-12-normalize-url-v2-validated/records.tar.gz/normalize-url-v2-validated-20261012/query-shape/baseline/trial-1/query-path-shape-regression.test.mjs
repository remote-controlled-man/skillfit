import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('default sorting preserves a bare path-like query parameter', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?/catalog/item'),
		'https://example.com/index.php?/catalog/item',
	);
});

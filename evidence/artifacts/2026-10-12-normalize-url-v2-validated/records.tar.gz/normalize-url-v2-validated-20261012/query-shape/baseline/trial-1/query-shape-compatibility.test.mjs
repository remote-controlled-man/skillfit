import test from 'node:test';
import assert from 'node:assert/strict';
import normalizeUrl from './index.js';

test('query sorting stays enabled by default and when explicitly enabled', () => {
	const input = 'https://example.com/index.php?z=last&b=two&a=one';
	const expected = 'https://example.com/index.php?a=one&b=two&z=last';

	assert.equal(normalizeUrl(input), expected);
	assert.equal(normalizeUrl(input, {sortQueryParameters: true}), expected);
});

test('sorting opt-out preserves the order and shape of mixed query parameters', () => {
	const input = 'https://example.com/index.php?z=last&/catalog/item&empty=&a=one&flag';

	assert.equal(normalizeUrl(input, {sortQueryParameters: false}), input);
});

test('sorting preserves mixed bare, assigned, and explicitly empty parameters', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=last&flag&empty=&/catalog/item&a=one'),
		'https://example.com/index.php?/catalog/item&a=one&empty=&flag&z=last',
	);
});

test('similar parameter names retain their individual query shapes', () => {
	assert.equal(
		normalizeUrl('https://example.com/index.php?foobar=&foo&xfoo=&fo=assigned&bar'),
		'https://example.com/index.php?bar&fo=assigned&foo&foobar=&xfoo=',
	);
});

test('bare parameters and explicit empty values remain distinct public inputs', () => {
	for (const parameter of ['flag', '/catalog/item']) {
		const bare = `https://example.com/index.php?${parameter}`;
		const empty = `${bare}=`;

		assert.equal(normalizeUrl(bare), bare);
		assert.equal(normalizeUrl(empty), empty);
		assert.notEqual(normalizeUrl(bare), normalizeUrl(empty));
	}
});

test('ordinary URL normalization and parameter removal still apply', () => {
	assert.equal(
		normalizeUrl(' HTTPS://user:password@WWW.Example.COM:443/a//b/../c/?z=last&utm_source=tracking&a=one '),
		'https://example.com/a/c?a=one&z=last',
	);
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=last&ref=tracking&a=one', {removeQueryParameters: ['ref']}),
		'https://example.com/index.php?a=one&z=last',
	);
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=last&ref=tracking&a=one', {keepQueryParameters: ['a']}),
		'https://example.com/index.php?a=one',
	);
});

test('fragments retain their content beside a path-like query', () => {
	const input = 'https://example.com/index.php?z=last&/catalog/item#section=details&flag=';
	const sorted = 'https://example.com/index.php?/catalog/item&z=last';

	assert.equal(normalizeUrl(input), `${sorted}#section=details&flag=`);
	assert.equal(normalizeUrl(input, {stripHash: true}), sorted);
	assert.equal(
		normalizeUrl('https://example.com/index.php?/catalog/item#section:~:text=hello'),
		'https://example.com/index.php?/catalog/item#section',
	);
});

test('encoded path backslashes remain encoded while query shapes are preserved', () => {
	assert.equal(
		normalizeUrl('https://example.com/some%5Bthing%5Celse/that-is%40great@coding?z=last&/catalog/item'),
		'https://example.com/some[thing%5Celse/that-is%40great@coding?/catalog/item&z=last',
	);
});

test('Unicode parameter values retain their existing normalization during sorting', () => {
	const expected = 'https://example.com/index.php?/catalog/item&a=%E4%BD%A0%E5%A5%BD&z=%F0%9F%8C%8D';

	assert.equal(normalizeUrl('https://example.com/index.php?z=🌍&/catalog/item&a=你好'), expected);
	assert.equal(
		normalizeUrl('https://example.com/index.php?z=%F0%9F%8C%8D&/catalog/item&a=%E4%BD%A0%E5%A5%BD'),
		expected,
	);
});
